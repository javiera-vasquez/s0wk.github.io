//var localConfigFile = "config-dev.js";
//var localConfigFile = "config-aqa.js";
//var localConfigFile = "config-sqa.js";
//var localConfigFile = "config-studio.js";
var localConfigFile = "config-vtr.js";


/* ********* DO NOT CHANGE BELOW ***********************************

/* ********* In production, the launch URL or AVPKG settings will **
/* ********* override what appears above. This is ******************
/* ********* to ensure a consistent means to alter the *************
/* ********* configuration file via URL or package parameters*******
/* ********* config=xyz.js **************************************  */

if(navigator  && navigator.getParameter && navigator.getParameter('config')){
	localConfigFile = navigator.getParameter('config');
}else if(location.href.indexOf('config=') != -1){
	localConfigFile = location.href.substring(location.href.indexOf('config=')+7);
	if(localConfigFile.indexOf('&') != -1 ){
		localConfigFile = localConfigFile.substring(0, localConfigFile.indexOf('&'));
	}
	localConfigFile = decodeURIComponent(localConfigFile);
}

if(localConfigFile != ''){
	localConfigFile = localConfigFile.indexOf('://') != -1 ? localConfigFile : 'configs/'+localConfigFile;
	//write to head synchronously if in browser
	if(typeof(document.write) == 'function'){
		document.write('<scr'+'ipt type="text/javascript" charset="UTF-8" src="'+localConfigFile+'"></sc'+'ript>');
	}else{
		var scriptElement = document.createElement('script');
		scriptElement.setAttribute('src',localConfigFile);
		scriptElement.setAttribute ("type", "text/javascript");
		scriptElement.setAttribute("charset", "UTF-8");
		document.getElementsByTagName('head').item(0).appendChild(scriptElement);
	}
}