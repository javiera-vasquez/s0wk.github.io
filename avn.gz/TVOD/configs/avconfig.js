/**
 * @fileDescription The configuration file for most standard properties. Only set properties in this file 
 * which are CONSTANT BETWEEN DEPLOYMENTS. Environmental configurations should be localized
 * using the appropriate config-xyz.js file
 * inside of configs
 */


window.config = {
	//Application configuration parameters
	app : {
		version : '1.0.0',
		appName : 'Nuevo Portal VOD VTR', // full name
		appCode : 'NVOD', // 3-4 letter abbreviation
		lastModified : '20150324',
	},
	
	//AV Library defaults
	av : {
		logLevel 	: 0,
		logLevelLibs: 0,
		libraries	: 'tracker',//libraries to load at runtime
	},
};

