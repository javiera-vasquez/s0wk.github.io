/**
 * @fileDescription Development specific overrides to the configuration, override settings in avconfig.js, uncomment
 * the appropriate lines and override the settings below.
 */

window.config.av.logLevel = 0;