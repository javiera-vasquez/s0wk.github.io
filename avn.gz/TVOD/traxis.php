<?php
	$traxisServer = "http://201.241.255.129";

	function callTraxis( $url, $method = 'GET', $data = array(), $headers = array('Content-type: application/x-www-form-urlencoded') )
	{
		$context = stream_context_create(array
		(
			'http' => array(
				'method' => $method,
				'header' => $headers,
				'content' => http_build_query( $data )
			)
		));
	 
		return file_get_contents($url, false, $context);
	}

	//$url = "http://201.241.255.129/traxis/web/Titles/Propset/all/Limit/20?output=json";
	$url = $traxisServer . $_SERVER['QUERY_STRING'];

	$traxis = callTraxis($url);

	echo $traxis;
?>