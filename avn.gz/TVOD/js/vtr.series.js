/*
	NAME: VTR.Series
	DESCRIPTION: Manejo de las Series
*/

VTR.Series = {
	contentCategories:[]
}

/* Function getListCategoriesAndTitles */
VTR.Series.getListCategoriesAndTitles = function(callback, options){
	var urlContentByCategory = VTR.Properties.traxisProxy + '/' + VTR.Traxis.urlBodyRequest;
	var output = {categoryId: options.categoryId ,"categoryName": options.categoryName, "titlesCount": options.titlesCount, isSeries: options.isSeries, "cats":[]};
        var titlesCount = 0;
        var titlesCatCount = 0;
        var seriesCount = 0;
	var bodyReq = "";
	bodyReq += "<Request xmlns=\"urn:eventis:traxisweb:1.0\">\n";
	bodyReq += "  <Identity>\n";
	bodyReq += "    <CpeId>" + VTR.Account.cpeId + "</CpeId>\n";
	bodyReq += "  </Identity>\n";
	bodyReq += "  <ResourceQuery resourceType=\"category\" resourceId=\"" + options.categoryId + "\">\n";
	bodyReq += "    <Options>\n";
	bodyReq += "      <Option type=\"props\">Name,ChildCategories,ChildCategoryCount,TitleCount,IsAdult,ShortSynopsis,Pictures,CustomProperties</Option>\n";
	bodyReq += "    </Options>\n";
	bodyReq += "    <SubQueries>\n";
	bodyReq += "      <SubQuery relationName=\"titles\">\n";
	bodyReq += "        <Options>\n";
	bodyReq += "          <Option type=\"filter\">IsPreview==false&amp;&amp;IsViewableOnCpe==true&amp;&amp;ContentCount&gt;0</Option>\n";
	bodyReq += "          <Option type=\"sort\">Ordinal</Option>\n";
	bodyReq += "          <Option type=\"limit\">" + options.size + "</Option>\n";
	bodyReq += "          <Option type=\"props\">Name,Categories,Pictures,ShortName,Contents,ContentCount,SeriesCount,Bookmark,DurationInSeconds,VisibilityWindows</Option>\n";
	bodyReq += "        </Options>\n";
	bodyReq += "        <SubQueries>\n";
	bodyReq += "          <SubQuery relationName=\"contents\">\n";
	bodyReq += "            <Options>\n";
	bodyReq += "              <Option type=\"filter\">Products&gt;0&amp;&amp;FirstAvailability&lt;=now()&amp;&amp;LastAvailability&gt;=now()</Option>\n";
	bodyReq += "              <Option type=\"props\">Aliases,IsHD,Is3D</Option>\n";
	bodyReq += "            </Options>\n";
	bodyReq += "            <SubQueries>\n";
	bodyReq += "              <SubQuery relationName=\"products\">\n";
	bodyReq += "                <Options>\n";
	bodyReq += "                  <Option type=\"props\">Type,EntitlementState,EntitlementEnd</Option>\n";
        bodyReq += "                  <Option type=\"filter\">AvailabilityStart&lt;=now()&amp;&amp;AvailabilityEnd&gt;=now()</Option>\n";
	bodyReq += "                </Options>\n";
	bodyReq += "              </SubQuery>\n";
	bodyReq += "            </SubQueries>\n";
	bodyReq += "          </SubQuery>\n";
	bodyReq += "        </SubQueries>\n";
	bodyReq += "      </SubQuery>\n";
	bodyReq += "      <SubQuery relationName=\"childcategories\">\n";
	bodyReq += "        <Options>\n";
	//bodyReq += "          <Option type=\"filter\">CustomProperties.CustomProperty.urn:libertyglobal:RenderingHintsCS:2013:AvnCatWithSeries==true</Option>\n"
	bodyReq += "          <Option type=\"sort\">Ordinal</Option>\n";
	bodyReq += "          <Option type=\"props\">Name,ChildCategories,TitleCount,IsAdult,ShortSynopsis,Pictures,CustomProperties</Option>\n";
	bodyReq += "        </Options>\n";
	bodyReq += "        <SubQueries>\n";
	bodyReq += "          <SubQuery relationName=\"titles\">\n";
	bodyReq += "            <Options>\n";
	bodyReq += "              <Option type=\"filter\">IsPreview==false&amp;&amp;IsViewableOnCpe==true&amp;&amp;Contents&gt;0</Option>\n";
	bodyReq += "              <Option type=\"props\">Name,Categories,Pictures,ShortName,Contents,ContentCount,SeriesCount,Bookmark,DurationInSeconds,VisibilityWindows</Option>\n";
	bodyReq += "              <Option type=\"limit\">" + options.size + "</Option>\n";
        bodyReq += "              <Option type=\"sort\">Ordinal</Option>\n";
	bodyReq += "            </Options>\n";
	bodyReq += "            <SubQueries>\n";
	bodyReq += "              <SubQuery relationName=\"contents\">\n";
	bodyReq += "                <Options>\n";
	bodyReq += "                  <Option type=\"filter\">Products&gt;0&amp;&amp;FirstAvailability&lt;=now()&amp;&amp;LastAvailability&gt;=now()</Option>\n";
	bodyReq += "                  <Option type=\"props\">Aliases,IsHD,Is3D</Option>\n";
	bodyReq += "                </Options>\n";
	bodyReq += "                <SubQueries>\n";
	bodyReq += "                  <SubQuery relationName=\"products\">\n";
	bodyReq += "                    <Options>\n";
        bodyReq += "                      <Option type=\"filter\">AvailabilityStart&lt;=now()&amp;&amp;AvailabilityEnd&gt;=now()</Option>\n";
	bodyReq += "                      <Option type=\"props\">Type,EntitlementState,EntitlementEnd</Option>\n";
	bodyReq += "                    </Options>\n";
	bodyReq += "                  </SubQuery>\n";
	bodyReq += "                </SubQueries>\n";
	bodyReq += "              </SubQuery>\n";
	bodyReq += "            </SubQueries>\n";
	bodyReq += "          </SubQuery>\n";
	bodyReq += "          <SubQuery relationName=\"childcategories\">\n";
	bodyReq += "            <Options>\n";
	bodyReq += "              <Option type=\"sort\">Ordinal</Option>\n";
	bodyReq += "              <Option type=\"props\">Name,TitleCount,IsAdult,ShortSynopsis,Pictures,CustomProperties</Option>\n";
	bodyReq += "            </Options>\n";
	bodyReq += "            <SubQueries>\n";
	bodyReq += "              <SubQuery relationName=\"titles\">\n";
	bodyReq += "                <Options>\n";
	bodyReq += "                  <Option type=\"filter\">IsPreview==false&amp;&amp;IsViewableOnCpe==true&amp;&amp;Contents&gt;0</Option>\n";
	bodyReq += "                  <Option type=\"props\">Name,Categories,Pictures,ShortName,Contents,ContentCount,SeriesCount,Bookmark,DurationInSeconds,VisibilityWindows</Option>\n";
	bodyReq += "                  <Option type=\"limit\">1</Option>\n";
                bodyReq += "          <Option type=\"sort\">Ordinal</Option>\n";
	bodyReq += "                </Options>\n";
	bodyReq += "                <SubQueries>\n";
	bodyReq += "                  <SubQuery relationName=\"contents\">\n";
	bodyReq += "                    <Options>\n";
	bodyReq += "                      <Option type=\"filter\">Products&gt;0&amp;&amp;FirstAvailability&lt;=now()&amp;&amp;LastAvailability&gt;=now()</Option>\n";
	bodyReq += "                      <Option type=\"props\">Aliases,IsHD,Is3D</Option>\n";
	bodyReq += "                    </Options>\n";
	bodyReq += "                    <SubQueries>\n";
	bodyReq += "                      <SubQuery relationName=\"products\">\n";
	bodyReq += "                        <Options>\n";
        bodyReq += "                          <Option type=\"filter\">AvailabilityStart&lt;=now()&amp;&amp;AvailabilityEnd&gt;=now()</Option>\n";
	bodyReq += "                          <Option type=\"props\">Type,EntitlementState,EntitlementEnd</Option>\n";
	bodyReq += "                        </Options>\n";
	bodyReq += "                      </SubQuery>\n";
	bodyReq += "                    </SubQueries>\n";
	bodyReq += "                  </SubQuery>\n";
	bodyReq += "                </SubQueries>\n";
	bodyReq += "              </SubQuery>\n";
	bodyReq += "              <SubQuery relationName=\"childcategories\">\n";
	bodyReq += "                <Options>\n";
	//bodyReq += "                  <Option type=\"filter\">CustomProperties.CustomProperty.urn:libertyglobal:RenderingHintsCS:2013:AvnCatWithSeries==true</Option>\n"
	bodyReq += "                  <Option type=\"sort\">Ordinal</Option>\n";
	bodyReq += "                  <Option type=\"props\">Name,TitleCount,IsAdult,ShortSynopsis,Pictures,CustomProperties</Option>\n";
	bodyReq += "                </Options>\n";
	bodyReq += "                <SubQueries>\n";
	bodyReq += "                  <SubQuery relationName=\"titles\">\n";
	bodyReq += "                    <Options>\n";
	bodyReq += "                      <Option type=\"filter\">IsPreview==false&amp;&amp;IsViewableOnCpe==true&amp;&amp;Contents&gt;0</Option>\n";
	bodyReq += "                      <Option type=\"props\">Name,Categories,Pictures,ShortName,Contents,ContentCount,SeriesCount,Bookmark,DurationInSeconds,VisibilityWindows</Option>\n";
	bodyReq += "                      <Option type=\"limit\">1</Option>\n";
                    bodyReq += "          <Option type=\"sort\">Ordinal</Option>\n";
	bodyReq += "                    </Options>\n";
	bodyReq += "                    <SubQueries>\n";
	bodyReq += "                      <SubQuery relationName=\"contents\">\n";
	bodyReq += "                        <Options>\n";
	bodyReq += "                          <Option type=\"filter\">Products&gt;0&amp;&amp;FirstAvailability&lt;=now()&amp;&amp;LastAvailability&gt;=now()</Option>\n";
	bodyReq += "                          <Option type=\"props\">Aliases,IsHD,Is3D</Option>\n";
	bodyReq += "                        </Options>\n";
	bodyReq += "                        <SubQueries>\n";
	bodyReq += "                          <SubQuery relationName=\"products\">\n";
	bodyReq += "                            <Options>\n";
        bodyReq += "                              <Option type=\"filter\">AvailabilityStart&lt;=now()&amp;&amp;AvailabilityEnd&gt;=now()</Option>\n";
	bodyReq += "                              <Option type=\"props\">Type,EntitlementState,EntitlementEnd</Option>\n";
	bodyReq += "                            </Options>\n";
	bodyReq += "                          </SubQuery>\n";
	bodyReq += "                        </SubQueries>\n";
	bodyReq += "                      </SubQuery>\n";
	bodyReq += "                    </SubQueries>\n";
	bodyReq += "                  </SubQuery>\n";
        
        
        bodyReq += "                <SubQuery relationName=\"childcategories\">\n";
	bodyReq += "                <Options>\n";
	//bodyReq += "                  <Option type=\"filter\">CustomProperties.CustomProperty.urn:libertyglobal:RenderingHintsCS:2013:AvnCatWithSeries==true</Option>\n"
	bodyReq += "                  <Option type=\"sort\">Ordinal</Option>\n";
	bodyReq += "                  <Option type=\"props\">Name,TitleCount,IsAdult,ShortSynopsis,Pictures,CustomProperties</Option>\n";
	bodyReq += "                </Options>\n";
	bodyReq += "                <SubQueries>\n";
	bodyReq += "                  <SubQuery relationName=\"titles\">\n";
	bodyReq += "                    <Options>\n";
	bodyReq += "                      <Option type=\"filter\">IsPreview==false&amp;&amp;IsViewableOnCpe==true&amp;&amp;Contents&gt;0</Option>\n";
	bodyReq += "                      <Option type=\"props\">Name,Categories,Pictures,ShortName,Contents,ContentCount,SeriesCount,Bookmark,DurationInSeconds,VisibilityWindows</Option>\n";
	bodyReq += "                      <Option type=\"limit\">1</Option>\n";
                    bodyReq += "          <Option type=\"sort\">Ordinal</Option>\n";
	bodyReq += "                    </Options>\n";
	bodyReq += "                    <SubQueries>\n";
	bodyReq += "                      <SubQuery relationName=\"contents\">\n";
	bodyReq += "                        <Options>\n";
	bodyReq += "                          <Option type=\"filter\">Products&gt;0&amp;&amp;FirstAvailability&lt;=now()&amp;&amp;LastAvailability&gt;=now()</Option>\n";
	bodyReq += "                          <Option type=\"props\">Aliases,IsHD,Is3D</Option>\n";
	bodyReq += "                        </Options>\n";
	bodyReq += "                        <SubQueries>\n";
	bodyReq += "                          <SubQuery relationName=\"products\">\n";
	bodyReq += "                            <Options>\n";
        bodyReq += "                              <Option type=\"filter\">AvailabilityStart&lt;=now()&amp;&amp;AvailabilityEnd&gt;=now()</Option>\n";
	bodyReq += "                              <Option type=\"props\">Type,EntitlementState,EntitlementEnd</Option>\n";
	bodyReq += "                            </Options>\n";
	bodyReq += "                          </SubQuery>\n";
	bodyReq += "                        </SubQueries>\n";
	bodyReq += "                      </SubQuery>\n";
	bodyReq += "                    </SubQueries>\n";
	bodyReq += "                  </SubQuery>\n";
	bodyReq += "                </SubQueries>\n";
	bodyReq += "              </SubQuery>\n";
        
        
	bodyReq += "                </SubQueries>\n";
	bodyReq += "              </SubQuery>\n";
	bodyReq += "            </SubQueries>\n";
	bodyReq += "            <SubQueries>\n";
	bodyReq += "              <SubQuery relationName=\"titles\">\n";
	bodyReq += "                <Options>\n";
	bodyReq += "                  <Option type=\"filter\">IsPreview==false&amp;&amp;IsViewableOnCpe==true&amp;&amp;Contents&gt;0</Option>\n";
	bodyReq += "                  <Option type=\"props\">Name,Categories,Pictures,ShortName,Contents,ContentCount,SeriesCount,Bookmark,DurationInSeconds,VisibilityWindows</Option>\n";
	bodyReq += "                  <Option type=\"limit\">1</Option>\n";
                bodyReq += "          <Option type=\"sort\">Ordinal</Option>\n";
	bodyReq += "                </Options>\n";
	bodyReq += "                <SubQueries>\n";
	bodyReq += "                  <SubQuery relationName=\"contents\">\n";
	bodyReq += "                    <Options>\n";
	bodyReq += "                      <Option type=\"filter\">Products&gt;0&amp;&amp;FirstAvailability&lt;=now()&amp;&amp;LastAvailability&gt;=now()</Option>\n";
	bodyReq += "                      <Option type=\"props\">Aliases,IsHD,Is3D</Option>\n";
	bodyReq += "                    </Options>\n";
	bodyReq += "                    <SubQueries>\n";
	bodyReq += "                      <SubQuery relationName=\"products\">\n";
	bodyReq += "                        <Options>\n";
        bodyReq += "                          <Option type=\"filter\">AvailabilityStart&lt;=now()&amp;&amp;AvailabilityEnd&gt;=now()</Option>\n";
	bodyReq += "                          <Option type=\"props\">Type,EntitlementState,EntitlementEnd</Option>\n";
	bodyReq += "                        </Options>\n";
	bodyReq += "                      </SubQuery>\n";
	bodyReq += "                    </SubQueries>\n";
	bodyReq += "                  </SubQuery>\n";
	bodyReq += "                </SubQueries>\n";
	bodyReq += "              </SubQuery>\n";
	bodyReq += "              <SubQuery relationName=\"childcategories\">\n";
	bodyReq += "                <Options>\n";
	//bodyReq += "                  <Option type=\"filter\">CustomProperties.CustomProperty.urn:libertyglobal:RenderingHintsCS:2013:AvnCatWithSeries==true</Option>\n"
	bodyReq += "                  <Option type=\"sort\">Ordinal</Option>\n";
	bodyReq += "                  <Option type=\"props\">Name,TitleCount,IsAdult,ShortSynopsis,Pictures,CustomProperties</Option>\n";
	bodyReq += "                </Options>\n";
	bodyReq += "                <SubQueries>\n";
	bodyReq += "                  <SubQuery relationName=\"titles\">\n";
	bodyReq += "                    <Options>\n";
	bodyReq += "                      <Option type=\"filter\">IsPreview==false&amp;&amp;IsViewableOnCpe==true&amp;&amp;Contents&gt;0</Option>\n";
	bodyReq += "                      <Option type=\"props\">Name,Categories,Pictures,ShortName,Contents,ContentCount,SeriesCount,Bookmark,DurationInSeconds,VisibilityWindows</Option>\n";
	bodyReq += "                      <Option type=\"limit\">1</Option>\n";
                    bodyReq += "          <Option type=\"sort\">Ordinal</Option>\n";
	bodyReq += "                    </Options>\n";
	bodyReq += "                    <SubQueries>\n";
	bodyReq += "                      <SubQuery relationName=\"contents\">\n";
	bodyReq += "                        <Options>\n";
	bodyReq += "                          <Option type=\"filter\">Products&gt;0&amp;&amp;FirstAvailability&lt;=now()&amp;&amp;LastAvailability&gt;=now()</Option>\n";
	bodyReq += "                          <Option type=\"props\">Aliases,IsHD,Is3D</Option>\n";
	bodyReq += "                        </Options>\n";
	bodyReq += "                        <SubQueries>\n";
	bodyReq += "                          <SubQuery relationName=\"products\">\n";
	bodyReq += "                            <Options>\n";
        bodyReq += "                              <Option type=\"filter\">AvailabilityStart&lt;=now()&amp;&amp;AvailabilityEnd&gt;=now()</Option>\n";
	bodyReq += "                              <Option type=\"props\">Type,EntitlementState,EntitlementEnd</Option>\n";
	bodyReq += "                            </Options>\n";
	bodyReq += "                          </SubQuery>\n";
	bodyReq += "                        </SubQueries>\n";
	bodyReq += "                      </SubQuery>\n";
	bodyReq += "                    </SubQueries>\n";
	bodyReq += "                  </SubQuery>\n";
	bodyReq += "                </SubQueries>\n";
	bodyReq += "              </SubQuery>\n";
	bodyReq += "            </SubQueries>\n"; 
	bodyReq += "          </SubQuery>\n";
	bodyReq += "        </SubQueries>\n";
	bodyReq += "      </SubQuery>\n";
	bodyReq += "    </SubQueries>\n";
	bodyReq += "  </ResourceQuery>\n";
	bodyReq += "</Request>\n";
    
	$.post(urlContentByCategory, bodyReq, function(data){
            eval("VTR.Catalog.contentCategories = " + JSON.stringify(data));
        try {
            if(VTR.Utils.isset(data.Category.ChildCategories)) { 
                $.each(data.Category.ChildCategories.Category, function(i1, d1){
                    output.cats.push({
                        'categoryId': d1.id,
                        'categoryName': d1.Name.toUpperCase(),
                        'titlesCount': d1.TitleCount,
                        'childCategoryCount': d1.ChildCategoryCount,
                        'isAdult': d1.IsAdult,
                        'isSeries': (VTR.Utils.isset(d1.CustomProperties) ? VTR.Utils.getHrefCustomProperty(d1.CustomProperties, VTR.Properties.seriesHrefCustomProperty) : false),
                        'listtitleschildren': [],
                        'listtitlesorder': [],
                        'listseriesorder': []
                    });					

                    /* obtiene los titles y los almacena en listtitleschildren */
                    if(VTR.Utils.isset(d1.Titles)) {
                        $.each(d1.Titles.Title, function(i, d){
                            var img = null;
                            var pics = (VTR.Utils.isset(d.Pictures) ? d.Pictures.Picture : "");
                            
                            if (pics){
                                $.each(pics, function(ix,dx) {
                                    if(dx.type == 'BoxCover') {
                                        img = dx.Value.replace("http://" + VTR.Properties.posterServerName + "/", "http://" + VTR.Properties.posterServer + "/");
                                        return false;
                                   }
                                    else {
                                        img = dx.Value.replace("http://" + VTR.Properties.posterServerName + "/", "http://" + VTR.Properties.posterServer + "/");
                                    }
                                });
                            }
                            output.cats[i1].listtitlesorder.push({
                                categoryId : 'CATEGORY_ID',
                                subcategoryId : 'SUB_CATEGORY_ID',
                                titleId : d.id,
                                name : (VTR.UI.screenFormat == "HD" ? d.ShortName.substring(0, 18) : d.ShortName.substring(0, VTR.Properties.titleMaxSize)),
                                is3D : d.Contents.Content[0].Is3D,
                                isHD : d.Contents.Content[0].IsHD,
                                pictureUri : img,
                                contentType : (VTR.Utils.isset(d.Contents.Content[0].Products) ? d.Contents.Content[0].Products.Product[0].Type : ''),
                                bookmark: (VTR.Utils.isset(d.Bookmark) ? d.Bookmark : "0"),
                                duration: (VTR.Utils.isset(d.DurationInSeconds) ? d.DurationInSeconds : ""),
                                assetId: d.Contents.Content[0].Aliases.Alias[0].Value,
                                LastViewDate: d.LastViewDate,
                                contentId: d.Contents.Content[0].id,
                                entitlementState: d.Contents.Content[0].Products.Product[0].EntitlementState,
                                entitlementEnd: d.Contents.Content[0].Products.Product[0].EntitlementEnd,
                                visibilityWindowStart: (VTR.Utils.isset(d.VisibilityWindows) ? d.VisibilityWindows.VisibilityWindow[0].start : ''),
                                isSeries: false
                            });
                            titlesCount++;
                            titlesCatCount++;
                        });
//                        titlesCount2 = 0;
//                        output.cats[i1].listtitlesorder.sort(function(a, b){
//                            a = new Date(a.FirstAvailability);
//                            b = new Date(b.FirstAvailability);
//                            return b-a;
//                        });   
                        
                    }

                    /* obtiene las series y los almacena en listtitleschildren */
                    if(VTR.Utils.isset(d1.ChildCategories)) {
                        $.each(d1.ChildCategories.Category, function(i, d){
                            var isSeries = false;
                            isSeries = (VTR.Utils.isset(d.CustomProperties) ? VTR.Utils.getHrefCustomProperty(d.CustomProperties, VTR.Properties.seriesHrefCustomProperty) : isSeries);                            
                            
                            if (isSeries == "true" && (VTR.Utils.isset(d.ChildCategories)) && (VTR.Utils.isset(d.ChildCategories.Category[0].Titles))){
                                var img = null;
                                var pics = (VTR.Utils.isset(d.Pictures) ? d.Pictures.Picture : "");
                                if (pics){
                                    $.each(pics, function(ix,dx) {
                                        if(dx.type == 'BoxCover') {
                                            img = dx.Value.replace("http://" + VTR.Properties.posterServerName + "/", "http://" + VTR.Properties.posterServer + "/");
                                            return false;
                                       }
                                        else {
                                            img = dx.Value.replace("http://" + VTR.Properties.posterServerName + "/", "http://" + VTR.Properties.posterServer + "/");
                                        }
                                    });
                                }
                                if(seriesCount < VTR.Properties.carruselSize){
                                    output.cats[i1].listseriesorder.push({
                                        categoryId : 'CATEGORY_ID',
                                        subcategoryId : 'SUB_CATEGORY_ID',
                                        titleId : d.id,
                                        name : (VTR.UI.screenFormat == "HD" ? d.Name.substring(0, 18) : d.Name.substring(0, VTR.Properties.titleMaxSize)),
                                        is3D : (VTR.Utils.isset(d.ChildCategories.Category[0].Titles) ? d.ChildCategories.Category[0].Titles.Title[0].Contents.Content[0].Is3D : ''),
                                        isHD : (VTR.Utils.isset(d.ChildCategories.Category[0].Titles) ? d.ChildCategories.Category[0].Titles.Title[0].Contents.Content[0].isHD : ''),
                                        pictureUri : img,
                                        contentType : (VTR.Utils.isset(d.ChildCategories.Category[0].Titles) ? d.ChildCategories.Category[0].Titles.Title[0].Contents.Content[0].Products.Product[0].Type : ''),
                                        bookmark : (VTR.Utils.isset(d.ChildCategories.Category[0].Titles) ? d.ChildCategories.Category[0].Titles.Title[0].Bookmark : '0'),
                                        duration : (VTR.Utils.isset(d.ChildCategories.Category[0].Titles) ? d.ChildCategories.Category[0].Titles.Title[0].DurationInSeconds : ''),
                                        assetId : (VTR.Utils.isset(d.ChildCategories.Category[0].Titles) ? d.ChildCategories.Category[0].Titles.Title[0].Contents.Content[0].Aliases.Alias[0].Value : ''),
                                        LastViewDate : (VTR.Utils.isset(d.ChildCategories.Category[0].Titles) ? d.ChildCategories.Category[0].Titles.Title[0].LastViewDate : ''),
                                        contentId : (VTR.Utils.isset(d.ChildCategories.Category[0].Titles) ? d.ChildCategories.Category[0].Titles.Title[0].Contents.Content[0].id : ''),
                                        entitlementState : (VTR.Utils.isset(d.ChildCategories.Category[0].Titles) ? d.ChildCategories.Category[0].Titles.Title[0].Contents.Content[0].Products.Product[0].EntitlementState : ''),
                                        entitlementEnd : (VTR.Utils.isset(d.ChildCategories.Category[0].Titles) ? d.ChildCategories.Category[0].Titles.Title[0].Contents.Content[0].Products.Product[0].EntitlementEnd : ''),
                                        visibilityWindowStart: (VTR.Utils.isset(d.ChildCategories.Category[0].Titles) ? d.ChildCategories.Category[0].Titles.Title[0].VisibilityWindows.VisibilityWindow[0].start : ''),
                                        isSeries: isSeries
                                    });
                                }
                                titlesCount++;
                                titlesCatCount++;
                                seriesCount++;
                            }
                        });
                    seriesCount = 0;
                    }

                    if(navi.navigate.length == 1 && navi.navigate[0].categoryName == VTR.Properties.titleMenuPremium && VTR.Properties.titleMenu2ndLevel == ""){
                        if(VTR.Utils.isset(d1.ChildCategories.Category)) {
                            $.each(d1.ChildCategories.Category, function(i, d){
//                                if(d.Name == "Series" && d.ChildCategories.Category[0].Name == "Game Of Thrones "){
                                    var isSeries = "false";
                                    if(d.Name == "Series"){
                                        isSeries = (VTR.Utils.isset(d.ChildCategories.Category[0].CustomProperties) ? VTR.Utils.getHrefCustomProperty(d.ChildCategories.Category[0].CustomProperties, VTR.Properties.seriesHrefCustomProperty) : isSeries); 
                                    }else{
                                        isSeries = (VTR.Utils.isset(d.CustomProperties) ? VTR.Utils.getHrefCustomProperty(d.CustomProperties, VTR.Properties.seriesHrefCustomProperty) : isSeries); 
                                                               
                                    }
                                    if (isSeries == "true" && (VTR.Utils.isset(d.ChildCategories)) && (VTR.Utils.isset(d.ChildCategories.Category[0].ChildCategories.Category[0].Titles))){
                                        var img = null;
                                        var pics = (VTR.Utils.isset(d.ChildCategories.Category[0].Pictures) ? d.ChildCategories.Category[0].Pictures.Picture : "");
                                        if (pics){
                                            $.each(pics, function(ix,dx) {
                                                if(dx.type == 'BoxCover') {
                                                    img = dx.Value.replace("http://" + VTR.Properties.posterServerName + "/", "http://" + VTR.Properties.posterServer + "/");
                                                    return false;
                                               }
                                                else {
                                                    img = dx.Value.replace("http://" + VTR.Properties.posterServerName + "/", "http://" + VTR.Properties.posterServer + "/");
                                                }
                                            });
                                        }
                                        if(seriesCount < VTR.Properties.carruselSize){
                                            output.cats[i1].listseriesorder.push({
                                                categoryId : 'CATEGORY_ID',
                                                subcategoryId : 'SUB_CATEGORY_ID',
                                                titleId : d.id,
                                                name : (VTR.UI.screenFormat == "HD" ? d.ChildCategories.Category[0].Name.substring(0, 18) : d.ChildCategories.Category[0].Name.substring(0, VTR.Properties.titleMaxSize)),
                                                is3D : (VTR.Utils.isset(d.ChildCategories.Category[0].ChildCategories.Category[0].Titles) ? d.ChildCategories.Category[0].ChildCategories.Category[0].Titles.Title[0].Contents.Content[0].Is3D : ''),
                                                isHD : (VTR.Utils.isset(d.ChildCategories.Category[0].ChildCategories.Category[0].Titles) ? d.ChildCategories.Category[0].ChildCategories.Category[0].Titles.Title[0].Contents.Content[0].IsHD : ''),
                                                pictureUri : img,
                                                contentType : (VTR.Utils.isset(d.ChildCategories.Category[0].ChildCategories.Category[0].Titles) ? d.ChildCategories.Category[0].ChildCategories.Category[0].Titles.Title[0].Contents.Content[0].Products.Product[0].Type : ''),
                                                bookmark : (VTR.Utils.isset(d.ChildCategories.Category[0].ChildCategories.Category[0].Titles) ? d.ChildCategories.Category[0].ChildCategories.Category[0].Titles.Title[0].Bookmark : '0'),
                                                duration : (VTR.Utils.isset(d.ChildCategories.Category[0].ChildCategories.Category[0].Titles) ? d.ChildCategories.Category[0].ChildCategories.Category[0].Titles.Title[0].DurationInSeconds : ''),
                                                assetId : (VTR.Utils.isset(d.ChildCategories.Category[0].ChildCategories.Category[0].Titles) ? d.ChildCategories.Category[0].ChildCategories.Category[0].Titles.Title[0].Contents.Content[0].Aliases.Alias[0].Value : ''),
                                                LastViewDate : (VTR.Utils.isset(d.ChildCategories.Category[0].ChildCategories.Category[0].Titles) ? d.ChildCategories.Category[0].ChildCategories.Category[0].Titles.Title[0].LastViewDate : ''),
                                                contentId : (VTR.Utils.isset(d.ChildCategories.Category[0].ChildCategories.Category[0].Titles) ? d.ChildCategories.Category[0].ChildCategories.Category[0].Titles.Title[0].Contents.Content[0].id : ''),
                                                entitlementState : (VTR.Utils.isset(d.ChildCategories.Category[0].ChildCategories.Category[0].Titles) ? d.ChildCategories.Category[0].ChildCategories.Category[0].Titles.Title[0].Contents.Content[0].Products.Product[0].EntitlementState : ''),
                                                entitlementEnd : (VTR.Utils.isset(d.ChildCategories.Category[0].ChildCategories.Category[0].Titles) ? d.ChildCategories.Category[0].ChildCategories.Category[0].Titles.Title[0].Contents.Content[0].Products.Product[0].EntitlementEnd : ''),
                                                visibilityWindowStart: (VTR.Utils.isset(d.ChildCategories.Category[0].ChildCategories.Category[0].Titles) ? d.ChildCategories.Category[0].ChildCategories.Category[0].Titles.Title[0].VisibilityWindows.VisibilityWindow[0].start : ''),
                                                isSeries: isSeries
                                            });
                                        }
                                        titlesCount++;
                                        titlesCatCount++;
                                        seriesCount++;
                                    }
//                                }
                            });
                        seriesCount = 0;
                        }
                    }
                    
                    var total = output.cats[i1].listtitlesorder.length;
                    if(VTR.Utils.isset(d1.ChildCategories)) {
                        $.each(d1.ChildCategories.Category, function(ix, dx){
                            if(VTR.Utils.isset(dx.Titles)) {
                                $.each(dx.Titles.Title, function(i3, d3){
                                    var img = null;
                                    var pics = (VTR.Utils.isset(d3.Pictures) ? d3.Pictures.Picture : "");
                                    if (pics){
                                        $.each(pics, function(ix,dx) {
                                            if(dx.type == 'BoxCover') {
                                                img = dx.Value.replace("http://" + VTR.Properties.posterServerName + "/", "http://" + VTR.Properties.posterServer + "/");
                                                return false;
                                           }
                                            else {
                                                img = dx.Value.replace("http://" + VTR.Properties.posterServerName + "/", "http://" + VTR.Properties.posterServer + "/");
                                            }
                                        });
                                    }
                                    if(total < (VTR.Properties.carruselSize - 1)) {
                                        output.cats[i1].listtitlesorder.push({
                                            categoryId : 'CATEGORY_ID',
                                            subcategoryId : 'SUB_CATEGORY_ID',
                                            titleId : d3.id,
                                            name : (VTR.UI.screenFormat == "HD" ? d3.ShortName.substring(0, 18) : d3.ShortName.substring(0, VTR.Properties.titleMaxSize)),
                                            is3D : d3.Contents.Content[0].Is3D,
                                            isHD : d3.Contents.Content[0].IsHD,
                                            pictureUri : img,
                                            contentType : (VTR.Utils.isset(d3.Contents.Content[0].Products) ? d3.Contents.Content[0].Products.Product[0].Type : ''),
                                            bookmark: (VTR.Utils.isset(d3.Bookmark) ? d3.Bookmark : "0"),
                                            duration: d3.DurationInSeconds,
                                            assetId: d3.Contents.Content[0].Aliases.Alias[0].Value,
                                            LastViewDate: d3.LastViewDate,
                                            contentId: d3.Contents.Content[0].id,
                                            entitlementState: d3.Contents.Content[0].Products.Product[0].EntitlementState,
                                            entitlementEnd: d3.Contents.Content[0].Products.Product[0].EntitlementEnd,
                                            visibilityWindowStart: (VTR.Utils.isset(d3.VisibilityWindows) ? d3.VisibilityWindows.VisibilityWindow[0].start : ''),
                                            isSeries: false
                                        }); 
                                        total++;
                                        titlesCount++;
                                        titlesCatCount++;
                                    }
                                });
//                                output.cats[i1].listtitlesorder.sort(function(a, b){
//                                    a = new Date(a.FirstAvailability);
//                                    b = new Date(b.FirstAvailability);
//                                    return b-a;
//                                }); 
                         
                            } else{
                                if(options.categoryName == VTR.Properties.titleMenuPremium && VTR.Utils.isset(dx.ChildCategories)) {
                                    $.each(dx.ChildCategories.Category, function(i4, d4){
                                            if(VTR.Utils.isset(d4.Titles)) {
                                            $.each(d4.Titles.Title, function(i5, d5){
                                                var img = null;
                                                var pics = (VTR.Utils.isset(d5.Pictures) ? d5.Pictures.Picture : "");
                                                if (pics){
                                                    $.each(pics, function(ix,dx) {
                                                        if(dx.type == 'BoxCover') {
                                                            img = dx.Value.replace("http://" + VTR.Properties.posterServerName + "/", "http://" + VTR.Properties.posterServer + "/");
                                                            return false;
                                                        }else {
                                                            img = dx.Value.replace("http://" + VTR.Properties.posterServerName + "/", "http://" + VTR.Properties.posterServer + "/");
                                                        }
                                                    });
                                                }

                                            if(total < (VTR.Properties.carruselSize - 1)) {
                                                output.cats[i1].listtitlesorder.push({
                                                    categoryId : 'CATEGORY_ID',
                                                    subcategoryId : 'SUB_CATEGORY_ID',
                                                    titleId : d5.id,
                                                    name : (VTR.UI.screenFormat == "HD" ? d5.ShortName.substring(0, 18) : d5.ShortName.substring(0, VTR.Properties.titleMaxSize)),
                                                    is3D : d5.Contents.Content[0].Is3D,
                                                    isHD : d5.Contents.Content[0].IsHD,
                                                    pictureUri : img,
                                                    contentType : (VTR.Utils.isset(d5.Contents.Content[0].Products) ? d5.Contents.Content[0].Products.Product[0].Type : ''),
                                                    bookmark: (VTR.Utils.isset(d5.Bookmark) ? d5.Bookmark : "0"),
                                                    duration: d5.DurationInSeconds,
                                                    assetId: d5.Contents.Content[0].Aliases.Alias[0].Value,
                                                    LastViewDate: d5.LastViewDate,
                                                    contentId: d5.Contents.Content[0].id,
                                                    entitlementState: d5.Contents.Content[0].Products.Product[0].EntitlementState,
                                                    entitlementEnd: d5.Contents.Content[0].Products.Product[0].EntitlementEnd,
                                                    visibilityWindowStart: (VTR.Utils.isset(d5.VisibilityWindows) ? d5.VisibilityWindows.VisibilityWindow[0].start : ''),
                                                    isSeries: false
                                                }); 
                                                total++;
                                                titlesCount++;
                                                titlesCatCount++;
                                            }
                                    });
//                                    output.cats[i1].listtitlesorder.sort(function(a, b){
//                                        a = new Date(a.FirstAvailability);
//                                        b = new Date(b.FirstAvailability);
//                                        return b-a;
//                                    });                            
                                }
                                        
                                    });
                                    
                                    
                                }
                                
                            }
                        });
                    }
                    /* ordenamiento entre series y titulos (4+4) */
                    if ((output.cats[i1].listtitlesorder.length == 0) && (output.cats[i1].listseriesorder.length > 0)) {
                        output.cats[i1].listtitleschildren = output.cats[i1].listseriesorder;
                    } else {
                        if ((output.cats[i1].listseriesorder.length == 0) && (output.cats[i1].listtitlesorder.length > 0)) {
                            output.cats[i1].listtitleschildren = output.cats[i1].listtitlesorder;
                        } else {
                            $.each(output.cats[i1].listseriesorder, function(id, data){
                                if (id < VTR.Properties.carruselMixedSize) {
                                    output.cats[i1].listtitleschildren.push(data);
                                }
                            });
                            $.each(output.cats[i1].listtitlesorder, function(id, data){
                                if(output.cats[i1].listtitleschildren.length <= VTR.Properties.carruselSize-1){
                                    output.cats[i1].listtitleschildren.push(data);
                                }      
                            });
                        }
                    }

                    output.cats[i1].titlesCount = titlesCatCount;
                    titlesCatCount = 0;
                });
                output.titlesCount = titlesCount;
            }
        }
        catch (err) {
            console.log('Error AVN API: '+err.message);
        }
        callback(output);
    }).fail(function(xhr, errorType, error){
        VTR.Utils.handleErrorFromTraxis(xhr.response);
    	console.log('xhr:' + JSON.stringify(xhr.response) + ' - ' + 'error:' + error);
    }).done(function(data, status, xhr){
    });
}

/* Function getListTitlesByCategory */
VTR.Series.getListTitlesByCategory = function(callback, options){
	var fieldList = 'Name,Categories,Pictures,ShortName,Contents,ContentCount,SeriesCount,Bookmark,DurationInSeconds';
	var urlContentByCategory = VTR.Properties.traxisProxy + '/' + VTR.Traxis.urlBodyRequest;
	var bodyReq = "";
	var output = {categoryId: options.categoryId ,"categoryName": options.categoryName, "titlesCount": options.titlesCount, position: 'options.position', isSeries: options.isSeries, "listtitles":[]};
        var titlesCount = 0;
	bodyReq += "<Request xmlns=\"urn:eventis:traxisweb:1.0\">\n";
	bodyReq += "  <Identity>\n";
	bodyReq += "    <CpeId>" + VTR.Account.cpeId + "</CpeId>\n";
	bodyReq += "  </Identity>\n";
	bodyReq += "  <ResourceQuery resourceType=\"category\" resourceId=\"" + options.categoryId + "\">\n";
	bodyReq += "    <Options>\n";
	bodyReq += "      <Option type=\"props\">Name,ChildCategories,ChildCategoryCount,TitleCount,IsAdult,ShortSynopsis,Pictures,CustomProperties</Option>\n";
	bodyReq += "    </Options>\n";
	bodyReq += "    <SubQueries>\n";
	bodyReq += "      <SubQuery relationName=\"titles\">\n";
	bodyReq += "        <Options>\n";
	bodyReq += "          <Option type=\"filter\">IsPreview==false&amp;&amp;IsViewableOnCpe==true&amp;&amp;ContentCount&gt;0&amp;&amp;Contents.Content.ProductCount&gt;0</Option>\n";
	bodyReq += "          <Option type=\"sort\">Ordinal</Option>\n";
	bodyReq += "          <Option type=\"limit\">" + options.size + "</Option>\n";
	bodyReq += "          <Option type=\"props\">" + fieldList + "</Option>\n";
	bodyReq += "        </Options>\n";
	bodyReq += "        <SubQueries>\n";
	bodyReq += "          <SubQuery relationName=\"contents\">\n";
	bodyReq += "            <Options>\n";
	bodyReq += "              <Option type=\"filter\">Products&gt;0&amp;&amp;FirstAvailability&lt;=now()&amp;&amp;LastAvailability&gt;=now()</Option>\n";
	bodyReq += "              <Option type=\"props\">Aliases,IsHD,Is3D</Option>\n";
	bodyReq += "            </Options>\n";
	bodyReq += "            <SubQueries>\n";
	bodyReq += "              <SubQuery relationName=\"products\">\n";
	bodyReq += "                <Options>\n";
	bodyReq += "                  <Option type=\"props\">Type,EntitlementState,EntitlementEnd</Option>\n";
	bodyReq += "                </Options>\n";
	bodyReq += "              </SubQuery>\n";
	bodyReq += "            </SubQueries>\n";
	bodyReq += "          </SubQuery>\n";
	bodyReq += "        </SubQueries>\n";
	bodyReq += "      </SubQuery>\n";
	bodyReq += "      <SubQuery relationName=\"childcategories\">\n";
	bodyReq += "        <Options>\n";
	bodyReq += "          <Option type=\"sort\">Ordinal</Option>\n";
	bodyReq += "          <Option type=\"props\">Name,ChildCategories,TitleCount,IsAdult,ShortSynopsis,Pictures,CustomProperties</Option>\n";
	bodyReq += "        </Options>\n";
	bodyReq += "        <SubQueries>\n";
	bodyReq += "          <SubQuery relationName=\"titles\">\n";
	bodyReq += "            <Options>\n";
	bodyReq += "              <Option type=\"filter\">IsPreview==false&amp;&amp;IsViewableOnCpe==true&amp;&amp;Contents&gt;0</Option>\n";
	bodyReq += "              <Option type=\"props\">" + fieldList + "</Option>\n";
	bodyReq += "              <Option type=\"limit\">" + options.size + "</Option>\n";
	bodyReq += "            </Options>\n";
	bodyReq += "            <SubQueries>\n";
	bodyReq += "              <SubQuery relationName=\"contents\">\n";
	bodyReq += "                <Options>\n";
	bodyReq += "                  <Option type=\"filter\">Products&gt;0</Option>\n";
	bodyReq += "                  <Option type=\"props\">Aliases,IsHD,Is3D</Option>\n";
	bodyReq += "                </Options>\n";
	bodyReq += "                <SubQueries>\n";
	bodyReq += "                  <SubQuery relationName=\"products\">\n";
	bodyReq += "                    <Options>\n";
	bodyReq += "                      <Option type=\"props\">Type,EntitlementState,EntitlementEnd</Option>\n";
	bodyReq += "                    </Options>\n";
	bodyReq += "                  </SubQuery>\n";
	bodyReq += "                </SubQueries>\n";
	bodyReq += "              </SubQuery>\n";
	bodyReq += "            </SubQueries>\n";
	bodyReq += "          </SubQuery>\n";
	bodyReq += "          <SubQuery relationName=\"childcategories\">\n";
	bodyReq += "            <Options>\n";
	bodyReq += "              <Option type=\"sort\">Ordinal</Option>\n";
	bodyReq += "              <Option type=\"props\">Name,TitleCount,IsAdult,ShortSynopsis,Pictures,CustomProperties</Option>\n";
	bodyReq += "            </Options>\n";
	bodyReq += "            <SubQueries>\n";
	bodyReq += "              <SubQuery relationName=\"titles\">\n";
	bodyReq += "                <Options>\n";
	bodyReq += "                  <Option type=\"filter\">IsPreview==false&amp;&amp;IsViewableOnCpe==true&amp;&amp;Contents&gt;0</Option>\n";
	bodyReq += "                  <Option type=\"props\">" + fieldList + "</Option>\n";
	bodyReq += "                  <Option type=\"limit\">1</Option>\n";
	bodyReq += "                </Options>\n";
	bodyReq += "                <SubQueries>\n";
	bodyReq += "                  <SubQuery relationName=\"contents\">\n";
	bodyReq += "                    <Options>\n";
	bodyReq += "                      <Option type=\"filter\">Products&gt;0</Option>\n";
	bodyReq += "                      <Option type=\"props\">Aliases,IsHD,Is3D</Option>\n";
	bodyReq += "                    </Options>\n";
	bodyReq += "                    <SubQueries>\n";
	bodyReq += "                      <SubQuery relationName=\"products\">\n";
	bodyReq += "                        <Options>\n";
	bodyReq += "                          <Option type=\"props\">Type,EntitlementState,EntitlementEnd</Option>\n";
	bodyReq += "                        </Options>\n";
	bodyReq += "                      </SubQuery>\n";
	bodyReq += "                    </SubQueries>\n";
	bodyReq += "                  </SubQuery>\n";
	bodyReq += "                </SubQueries>\n";
	bodyReq += "              </SubQuery>\n";
	bodyReq += "            </SubQueries>\n";
	bodyReq += "          </SubQuery>\n";
	bodyReq += "        </SubQueries>\n";
	bodyReq += "      </SubQuery>\n";
	bodyReq += "    </SubQueries>\n";
	bodyReq += "  </ResourceQuery>\n";
	bodyReq += "</Request>\n";
    
	$.post(urlContentByCategory, bodyReq, function(data){
            eval("VTR.Catalog.contentCategories = " + JSON.stringify(data));
        try {
            /* obtiene los titles y los almacena en listtitles */
            if(VTR.Utils.isset(data.Category.Titles)) {
                $.each(data.Category.Titles.Title, function(i, d){
                	if(d.ContentCount > 0){
	                    var img = null;
	                    var pics = (VTR.Utils.isset(d.Pictures) ? d.Pictures.Picture : "");
	                    if (pics){
	                        $.each(pics, function(ix,dx) {
	                            if(dx.type == 'BoxCover') {
	                                img = dx.Value.replace("http://" + VTR.Properties.posterServerName + "/", "http://" + VTR.Properties.posterServer + "/");
	                                return false;
	                           }
	                            else {
	                                img = dx.Value.replace("http://" + VTR.Properties.posterServerName + "/", "http://" + VTR.Properties.posterServer + "/");
	                            }
	                        });
	                    }
	                    output.listtitles.push({
	                        categoryId : 'CATEGORY_ID',
	                        subcategoryId : 'SUB_CATEGORY_ID',
	                        titleId : d.id,
	                        name : (VTR.UI.screenFormat == "HD" ? d.ShortName.substring(0, 18) : d.ShortName.substring(0, VTR.Properties.titleMaxSize)),
	                        is3D : d.Contents.Content[0].Is3D,
	                        isHD : d.Contents.Content[0].IsHD,
	                        pictureUri : img,
	                        contentType : (VTR.Utils.isset(d.Contents.Content[0].Products) ? d.Contents.Content[0].Products.Product[0].Type : ''),
	                        bookmark: (VTR.Utils.isset(d.Bookmark) ? d.Bookmark : "0"),
	                        duration: d.DurationInSeconds,
	                        assetId: d.Contents.Content[0].Aliases.Alias[0].Value,
	                        LastViewDate: d.LastViewDate,
	                        contentId: d.Contents.Content[0].id,
	                        entitlementState: d.Contents.Content[0].Products.Product[0].EntitlementState,
	                        entitlementEnd: d.Contents.Content[0].Products.Product[0].EntitlementEnd,
	                        isSeries: false
	                    });
	                    titlesCount++;
	                }
                });
            }

            if(VTR.Utils.isset(data.Category.ChildCategories)) {
                $.each(data.Category.ChildCategories.Category, function(i, d){
                    var isSeries = false;
                    isSeries = (VTR.Utils.isset(d.CustomProperties) ? VTR.Utils.getHrefCustomProperty(d.CustomProperties, VTR.Properties.seriesHrefCustomProperty) : isSeries);                            

                    if (isSeries == "true" && (VTR.Utils.isset(d.ChildCategories)) && (VTR.Utils.isset(d.ChildCategories.Category[0].Titles))){
                        var img = null;
                        var pics = (VTR.Utils.isset(d.Pictures) ? d.Pictures.Picture : "");
                        if (pics){
                            $.each(pics, function(ix,dx) {
                                if(dx.type == 'BoxCover') {
                                    img = dx.Value.replace("http://" + VTR.Properties.posterServerName + "/", "http://" + VTR.Properties.posterServer + "/");
                                    return false;
                               }
                                else {
                                    img = dx.Value.replace("http://" + VTR.Properties.posterServerName + "/", "http://" + VTR.Properties.posterServer + "/");
                                }
                            });
                        }
                        output.listtitles.push({
                            categoryId : 'CATEGORY_ID',
                            subcategoryId : 'SUB_CATEGORY_ID',
                            titleId : d.id,
                            name : (VTR.UI.screenFormat == "HD" ? d.Name.substring(0, 18) : d.Name.substring(0, VTR.Properties.titleMaxSize)),
                            is3D : (VTR.Utils.isset(d.ChildCategories.Category[0].Titles) ? d.ChildCategories.Category[0].Titles.Title[0].Contents.Content[0].Is3D : ''),
                            isHD : (VTR.Utils.isset(d.ChildCategories.Category[0].Titles) ? d.ChildCategories.Category[0].Titles.Title[0].Contents.Content[0].isHD : ''),
                            pictureUri : img,
                            contentType : (VTR.Utils.isset(d.ChildCategories.Category[0].Titles) ? d.ChildCategories.Category[0].Titles.Title[0].Contents.Content[0].Products.Product[0].Type : ''),
                            bookmark : (VTR.Utils.isset(d.ChildCategories.Category[0].Titles) ? d.ChildCategories.Category[0].Titles.Title[0].Bookmark : '0'),
                            duration : (VTR.Utils.isset(d.ChildCategories.Category[0].Titles) ? d.ChildCategories.Category[0].Titles.Title[0].DurationInSeconds : ''),
                            assetId : (VTR.Utils.isset(d.ChildCategories.Category[0].Titles) ? d.ChildCategories.Category[0].Titles.Title[0].Contents.Content[0].Aliases.Alias[0].Value : ''),
                            LastViewDate : (VTR.Utils.isset(d.ChildCategories.Category[0].Titles) ? d.ChildCategories.Category[0].Titles.Title[0].LastViewDate : ''),
                            contentId : (VTR.Utils.isset(d.ChildCategories.Category[0].Titles) ? d.ChildCategories.Category[0].Titles.Title[0].Contents.Content[0].id : ''),
                            entitlementState : (VTR.Utils.isset(d.ChildCategories.Category[0].Titles) ? d.ChildCategories.Category[0].Titles.Title[0].Contents.Content[0].Products.Product[0].EntitlementState : ''),
                            entitlementEnd : (VTR.Utils.isset(d.ChildCategories.Category[0].Titles) ? d.ChildCategories.Category[0].Titles.Title[0].Contents.Content[0].Products.Product[0].EntitlementEnd : ''),
                            isSeries: isSeries
                        });
                        titlesCount++;
                    }
                });
            }
            output.titlesCount = titlesCount;
        }
        catch (err) {
            console.log('Error AVN API: '+err.message);
        }
        callback(output);
    }).fail(function(xhr, errorType, error){
        VTR.Utils.handleErrorFromTraxis(xhr.response);
    	console.log('xhr:' + JSON.stringify(xhr.response) + ' - ' + 'error:' + error);
    }).done(function(data, status, xhr){
    });
}

/* Function getListSeriesBySeasonAndTitles */
VTR.Series.getListSeriesBySeasonAndTitles = function(callback, options){
	var fieldList = 'Name,ShortName,Pictures,LongSynopsis,MediumSynopsis,ShortSynopsis,DurationInSeconds,ProductionDate,DirectorNames,Directors,ActorsCharacters,Actors,SeriesCount,ContentCount,Contents,Bookmark,PreviewCount,OnWishList,AllGenres,MinimumAge,IsAdult';
	var urlGetTitleDetail = VTR.Properties.traxisProxy + '/' + VTR.Traxis.urlBodyRequest;
	var bodyReq = "";
	bodyReq += "<Request xmlns=\"urn:eventis:traxisweb:1.0\">\n";
	bodyReq += "  <Identity>\n";
	bodyReq += "    <CpeId>" + VTR.Account.cpeId + "</CpeId>\n";
	bodyReq += "  </Identity>\n";
	bodyReq += "  <ResourceQuery resourceType=\"category\" resourceId=\"" + options.categoryId + "\">\n";
	bodyReq += "    <Options>\n";
	bodyReq += "      <Option type=\"props\">Name,ChildCategories,ChildCategoryCount,TitleCount,IsAdult,ShortSynopsis,Pictures,CustomProperties</Option>\n";
	bodyReq += "    </Options>\n";
	bodyReq += "    <SubQueries>\n";
	bodyReq += "      <SubQuery relationName=\"childcategories\">\n";
	bodyReq += "        <Options>\n";
	bodyReq += "          <Option type=\"sort\">Ordinal</Option>\n";
	bodyReq += "          <Option type=\"props\">Name,ChildCategories,TitleCount,IsAdult,ShortSynopsis,Pictures,CustomProperties</Option>\n";
	bodyReq += "        </Options>\n";
	bodyReq += "        <SubQueries>\n";
	bodyReq += "          <SubQuery relationName=\"titles\">\n";
	bodyReq += "            <Options>\n";
	bodyReq += "              <Option type=\"sort\">Ordinal</Option>\n";
	bodyReq += "              <Option type=\"props\">" + fieldList + "</Option>\n";
	bodyReq += "            </Options>\n";
	bodyReq += "            <SubQueries>\n";
	bodyReq += "              <SubQuery relationName=\"contents\">\n";
	bodyReq += "                <Options>\n";
	bodyReq += "                  <Option type=\"filter\">Products&gt;0</Option>\n";
	bodyReq += "                  <Option type=\"props\">IsHD,Is3D,ProductCount,PlayInfos,LastAvailability,Aliases,OriginalLanguages,CaptionLanguages</Option>\n";
	bodyReq += "                </Options>\n";
	bodyReq += "                <SubQueries>\n";
	bodyReq += "                  <SubQuery relationName=\"products\">\n";
	bodyReq += "                    <Options>\n";
	bodyReq += "                      <Option type=\"filter\">(!isnull(EntitlementState)||EntitlementState==Entitled)</Option>\n";
	bodyReq += "                      <Option type=\"props\">Type,ListPrice,RentalPeriodInMinutes,EntitlementState,Currency,EntitlementEnd,Name</Option>\n";
	bodyReq += "                    </Options>\n";
	bodyReq += "                  </SubQuery>\n";
	bodyReq += "                </SubQueries>\n";
	bodyReq += "              </SubQuery>\n";
	bodyReq += "              <SubQuery relationName=\"Previews\">\n";
	bodyReq += "                <SubQueries>\n";
	bodyReq += "                  <SubQuery relationName=\"Contents\">\n";
	bodyReq += "                    <Options>\n";
	bodyReq += "    	          <Option type=\"props\">Aliases</Option>\n";
	bodyReq += "        	        </Options>\n";
	bodyReq += "	              </SubQuery>\n";
	bodyReq += "	            </SubQueries>\n";
	bodyReq += "	          </SubQuery>\n";
        bodyReq += "            </SubQueries>\n";
	bodyReq += "          </SubQuery>\n";
        bodyReq += "      <SubQuery relationName=\"childcategories\">\n";
	bodyReq += "        <Options>\n";
	bodyReq += "          <Option type=\"sort\">Ordinal</Option>\n";
	bodyReq += "          <Option type=\"props\">Name,ChildCategories,TitleCount,IsAdult,ShortSynopsis,Pictures,CustomProperties</Option>\n";
	bodyReq += "        </Options>\n";
	bodyReq += "        <SubQueries>\n";
	bodyReq += "          <SubQuery relationName=\"titles\">\n";
	bodyReq += "            <Options>\n";
	bodyReq += "              <Option type=\"sort\">Ordinal</Option>\n";
	bodyReq += "              <Option type=\"props\">" + fieldList + "</Option>\n";
	bodyReq += "            </Options>\n";
	bodyReq += "            <SubQueries>\n";
	bodyReq += "              <SubQuery relationName=\"contents\">\n";
	bodyReq += "                <Options>\n";
	bodyReq += "                  <Option type=\"filter\">Products&gt;0</Option>\n";
	bodyReq += "                  <Option type=\"props\">IsHD,Is3D,ProductCount,PlayInfos,LastAvailability,Aliases,OriginalLanguages,CaptionLanguages</Option>\n";
	bodyReq += "                </Options>\n";
	bodyReq += "                <SubQueries>\n";
	bodyReq += "                  <SubQuery relationName=\"products\">\n";
	bodyReq += "                    <Options>\n";
	bodyReq += "                      <Option type=\"filter\">(!isnull(EntitlementState)||EntitlementState==Entitled)</Option>\n";
	bodyReq += "                      <Option type=\"props\">Type,ListPrice,RentalPeriodInMinutes,EntitlementState,Currency,EntitlementEnd,Name</Option>\n";
	bodyReq += "                    </Options>\n";
	bodyReq += "                  </SubQuery>\n";
	bodyReq += "                </SubQueries>\n";
	bodyReq += "              </SubQuery>\n";
	bodyReq += "              <SubQuery relationName=\"Previews\">\n";
	bodyReq += "                <SubQueries>\n";
	bodyReq += "                  <SubQuery relationName=\"Contents\">\n";
	bodyReq += "                    <Options>\n";
	bodyReq += "    	          <Option type=\"props\">Aliases</Option>\n";
	bodyReq += "        	        </Options>\n";
	bodyReq += "	              </SubQuery>\n";
	bodyReq += "	            </SubQueries>\n";
	bodyReq += "	          </SubQuery>\n";
        bodyReq += "            </SubQueries>\n";
	bodyReq += "          </SubQuery>\n";
	bodyReq += "        </SubQueries>\n";
	bodyReq += "      </SubQuery>\n";
	bodyReq += "        </SubQueries>\n";
	bodyReq += "      </SubQuery>\n";
	bodyReq += "    </SubQueries>\n";
	bodyReq += "  </ResourceQuery>\n";
	bodyReq += "</Request>\n";

	sessionStorage.setItem("titleId", options.titleId);
	sessionStorage.setItem("categoryName", options.categoryName);
        sessionStorage.setItem("categoryId", options.categoryId);
	var output = {categoryId: options.categoryId ,"categoryName": options.categoryName.toUpperCase(), "titlesCount": options.titlesCount, isSeries: options.isSeries, "cats":[]};

	$.post(urlGetTitleDetail, bodyReq, function(data2){
            eval("VTR.Content.titledetail = " + JSON.stringify(data2));
        try {
            if(((navi.navigate.length == 1) && (navi.navigate[0].categoryName == VTR.Properties.titleMenuPremium) && (localStorage.getItem("premiumSection") == 1)) || ((navi.navigate.length == 2) && (navi.navigate[0].categoryName == VTR.Properties.titleMenuPremium)&& (localStorage.getItem("premiumSection") == 1) && (navi.navigate[navi.navigate.length -1].isSeries == true))){
                if(VTR.Utils.isset(data2.Category.ChildCategories)) { 
                    $.each(data2.Category.ChildCategories.Category[0].ChildCategories.Category, function(i1, d1){
                        var imgposter = "";
                        var pic = (VTR.Utils.isset(d1.Pictures) ? d1.Pictures.Picture : "");
                        if (pic.length > 0){
                            $.each(pic, function(ix,dx) {
                                if(dx.type == 'BoxCover') {
                                    imgposter = dx.Value.replace("http://" + VTR.Properties.posterServerName + "/", "http://" + VTR.Properties.posterServer + "/");
                                    return false;
                                } else {
                                    imgposter = dx.Value.replace("http://" + VTR.Properties.posterServerName + "/", "http://" + VTR.Properties.posterServer + "/");
                                }
                            });
                        }

                        output.cats.push({
                            'categoryId': d1.id,
                            'categoryName': d1.Name.toUpperCase(),
                            'titlesCount': d1.TitleCount,
                            'childCategoryCount': (VTR.Utils.isset(d1.ChildCategoryCount) ? d1.ChildCategoryCount : "0"),
                            'isAdult': d1.IsAdult,
                            'isSeries': (VTR.Utils.isset(d1.CustomProperties) ? VTR.Utils.getHrefCustomProperty(d1.CustomProperties, VTR.Properties.seriesHrefCustomProperty) : false),
                            'poster': imgposter,
                            'titledetail': [],
                            'contents': [],
                            'pricesformats': []
                        });					

                        /* obtiene los titles y los almacena en titledetail */
                        if(VTR.Utils.isset(d1.Titles)) {
                            $.each(d1.Titles.Title, function(i, d){
                                var names = "";
                                var shortNames = "";
                                var genres = "";
                                var img = null;
                                var synopsis = "";
                                var shortSynopsis = "";
                                var languages = "";
                                var subtitles = "";
                                var directors = "";
                                var actors = "";
                                var rating = "";
                                var trailerURI = "";
                                var playerURI = "";
                                var elapsedTime = ""
                                var lastAvailability = "";
                                var duration = "";
                                var year = "";
                                var bookmark = "";
                                var assetIdTrailer = "";
                                var isAdult = "";

                                names = (VTR.Utils.isset(d.Name) ? d.Name : "");
                                shortNames = (VTR.Utils.isset(d.ShortName) ? d.ShortName : "");
                                if (VTR.Utils.isset(d.AllGenres)){
                                    $.each(d.AllGenres.AllGenre, function(i, item) {
                                        genres += item.Value.toUpperCase();
                                        if(i != d.AllGenres.AllGenre.length - 1){
                                            genres += ", ";
                                        }
                                    });
                                } else {
                                    genres = VTR.Properties.notAvailable;
                                }

                                var pic = (VTR.Utils.isset(d.Pictures) ? d.Pictures.Picture : "");
                                if (pic.length > 0){
                                    $.each(pic, function(ix,dx) {
                                        if(dx.type == 'BoxCover') {
                                            img = dx.Value.replace("http://" + VTR.Properties.posterServerName + "/", "http://" + VTR.Properties.posterServer + "/");
                                            return false;
                                        } else {
                                            img = dx.Value.replace("http://" + VTR.Properties.posterServerName + "/", "http://" + VTR.Properties.posterServer + "/");
                                        }
                                    });
                                }

                                if (VTR.Utils.isset(d.MediumSynopsis)) {
                                    synopsis = d.MediumSynopsis.replace(/["']/g, "");
                                }

                                if(VTR.Utils.isset(d.ShortSynopsis)) {
                                    shortSynopsis = d.ShortSynopsis.replace(/["']/g, "");
                                }

                                duration = (VTR.Utils.isset(d.DurationInSeconds) ? d.DurationInSeconds : "");
                                rating = (VTR.Utils.isset(d.MinimumAge) ? VTR.Utils.convertMinimumAgeToParentalRating(d.MinimumAge.type) : "");
                                year = (VTR.Utils.isset(d.ProductionDate) ? d.ProductionDate : "");
                                if (VTR.Utils.isset(d.DirectorNames)) {
                                    $.each(d.DirectorNames.DirectorName, function(i, item){
                                        directors += (VTR.Utils.isset(item.givenName) ? $.trim(item.givenName) : "") + (VTR.Utils.isset(item.familyName) ? " "+$.trim(item.familyName) : "");
                                        if (i != d.DirectorNames.DirectorName.length - 1){
                                            directors += ", ";
                                        }
                                    });
                                } else {
                                    directors = VTR.Properties.notAvailable;
                                }

                                if (VTR.Utils.isset(d.ActorsCharacters)) {
                                    $.each(d.ActorsCharacters.Actor, function(i, item) {
                                        actors += (VTR.Utils.isset(item.givenName) ? $.trim(item.givenName) : "") + (VTR.Utils.isset(item.familyName) ? " "+$.trim(item.familyName) : "");
                                        if (i != d.ActorsCharacters.Actor.length - 1){
                                            actors += ", ";
                                        }
                                    });
                                } else {
                                    actors = VTR.Properties.notAvailable;
                                }

                                bookmark = (VTR.Utils.isset(d.Bookmark) ? d.Bookmark : ""); 

                                if(VTR.Utils.isset(d.Previews)) {
                                    assetIdTrailer = d.Previews.Title[0].Contents.Content[0].Aliases.Alias[0].Value;
                                }
                                isAdult = (VTR.Utils.isset(d.IsAdult) ? d.IsAdult : false); 

                                output.cats[i1].IsOnWishlist = (VTR.Utils.isset(d.OnWishList) ? d.OnWishList : "");
                                output.cats[i1].Bookmark = (VTR.Utils.isset(d.Bookmark) ? d.Bookmark : "0");
                                output.cats[i1].titledetail.push({
                                    "categoryId": d1.id,
                                    "categoryName" : d1.Name.toUpperCase(),
                                    "name" : names.toUpperCase(),
                                    "shortName" : shortNames.toUpperCase(),
                                    "genre" : genres,
                                    "poster" : img,
                                    "synopsis" : synopsis,
                                    "shortSynopsis" : shortSynopsis,
                                    "duration" : duration,
                                    "year" : year,
                                    "director": directors,
                                    "actors": actors,
                                    "rating": rating,
                                    "trailerURI": trailerURI,
                                    "playerURI": playerURI,
                                    "elapsedTime": elapsedTime,
                                    "lastAvailability": lastAvailability,
                                    "bookmark": bookmark,
                                    "isAdult": isAdult,
                                    "isSeries": false
                                });

                                if (VTR.Utils.isset(d.Contents)) {
                                    var assetId = "";
                                    $.each(d.Contents.Content[0].Aliases.Alias, function(i, alias) {
                                        if(alias.type == "VodBackOfficeId") {
                                            assetId = alias.Value;
                                        }
                                    })

                                    if (VTR.Utils.isset(d.Contents.Content[0].OriginalLanguages)) {
                                        $.each(d.Contents.Content[0].OriginalLanguages.OriginalLanguage, function(i, item) {
                                            languages += VTR.Utils.convertLangCodeToLangName(item);
                                            if (i != d.Contents.Content[0].OriginalLanguages.OriginalLanguage.length - 1){
                                                languages += ", ";
                                            }
                                        })
                                    };

                                    if (VTR.Utils.isset(d.Contents.Content[0].CaptionLanguages)) {
                                        $.each(d.Contents.Content[0].CaptionLanguages.CaptionLanguage, function(i, item) {
                                            subtitles += VTR.Utils.convertLangCodeToLangName(item);
                                            if (i != d.Contents.Content[0].CaptionLanguages.CaptionLanguage.length - 1){
                                                subtitles += ", ";
                                            }
                                        })
                                    };
                                    output.cats[i1].pricesformats.push({
                                        "isHD": d.Contents.Content[0].IsHD,
                                        "is3D": d.Contents.Content[0].Is3D,
                                        "LastAvailability": d.Contents.Content[0].LastAvailability,
                                        "Type": d.Contents.Content[0].Products.Product[0].Type,
                                        "Currency": d.Contents.Content[0].Products.Product[0].Currency,
                                        "ListPrice": d.Contents.Content[0].Products.Product[0].ListPrice,
                                        "RentalPeriod": d.Contents.Content[0].Products.Product[0].RentalPeriodInMinutes,
                                        //"PlayerURI": playerURI + assetId + "?STBId=" + VTR.Account.cpeId,
                                        "assetId": assetId,
                                        "trailerAssetId": assetIdTrailer,
                                        //"IsOnWishlist": isOnWishlist,
                                        "EntitlementState": d.Contents.Content[0].Products.Product[0].EntitlementState,
                                        "titleId": d.id,
                                        "productId": d.Contents.Content[0].Products.Product[0].id,
                                        //"bookmark": bookmark,
                                        "EntitlementEnd": (VTR.Utils.isset(d.Contents.Content[0].Products.Product[0].EntitlementEnd) ? d.Contents.Content[0].Products.Product[0].EntitlementEnd : ""),
                                        "previewCount": d.PreviewCount,
                                        "languages": languages,
                                        "subtitles": subtitles,
                                        "Name": d.Contents.Content[0].Products.Product[0].Name
                                    });
                                }
                            });
                        }
                    });
                }
            }else{
                if(VTR.Utils.isset(data2.Category.ChildCategories)) { 
                    $.each(data2.Category.ChildCategories.Category, function(i1, d1){
                        var imgposter = "";
                        var pic = (VTR.Utils.isset(d1.Pictures) ? d1.Pictures.Picture : "");
                        if (pic.length > 0){
                            $.each(pic, function(ix,dx) {
                                if(dx.type == 'BoxCover') {
                                    imgposter = dx.Value.replace("http://" + VTR.Properties.posterServerName + "/", "http://" + VTR.Properties.posterServer + "/");
                                    return false;
                                } else {
                                    imgposter = dx.Value.replace("http://" + VTR.Properties.posterServerName + "/", "http://" + VTR.Properties.posterServer + "/");
                                }
                            });
                        }

                        output.cats.push({
                            'categoryId': d1.id,
                            'categoryName': d1.Name.toUpperCase(),
                            'titlesCount': d1.TitleCount,
                            'childCategoryCount': (VTR.Utils.isset(d1.ChildCategoryCount) ? d1.ChildCategoryCount : "0"),
                            'isAdult': d1.IsAdult,
                            'isSeries': (VTR.Utils.isset(d1.CustomProperties) ? VTR.Utils.getHrefCustomProperty(d1.CustomProperties, VTR.Properties.seriesHrefCustomProperty) : false),
                            'poster': imgposter,
                            'titledetail': [],
                            'contents': [],
                            'pricesformats': []
                        });					

                        /* obtiene los titles y los almacena en titledetail */
                        if(VTR.Utils.isset(d1.Titles)) {
                            $.each(d1.Titles.Title, function(i, d){
                                var names = "";
                                var shortNames = "";
                                var genres = "";
                                var img = null;
                                var synopsis = "";
                                var shortSynopsis = "";
                                var languages = "";
                                var subtitles = "";
                                var directors = "";
                                var actors = "";
                                var rating = "";
                                var trailerURI = "";
                                var playerURI = "";
                                var elapsedTime = ""
                                var lastAvailability = "";
                                var duration = "";
                                var year = "";
                                var bookmark = "";
                                var assetIdTrailer = "";
                                var isAdult = "";

                                names = (VTR.Utils.isset(d.Name) ? d.Name : "");
                                shortNames = (VTR.Utils.isset(d.ShortName) ? d.ShortName : "");
                                if (VTR.Utils.isset(d.AllGenres)){
                                    $.each(d.AllGenres.AllGenre, function(i, item) {
                                        genres += item.Value.toUpperCase();
                                        if(i != d.AllGenres.AllGenre.length - 1){
                                            genres += ", ";
                                        }
                                    });
                                } else {
                                    genres = VTR.Properties.notAvailable;
                                }

                                var pic = (VTR.Utils.isset(d.Pictures) ? d.Pictures.Picture : "");
                                if (pic.length > 0){
                                    $.each(pic, function(ix,dx) {
                                        if(dx.type == 'BoxCover') {
                                            img = dx.Value.replace("http://" + VTR.Properties.posterServerName + "/", "http://" + VTR.Properties.posterServer + "/");
                                            return false;
                                        } else {
                                            img = dx.Value.replace("http://" + VTR.Properties.posterServerName + "/", "http://" + VTR.Properties.posterServer + "/");
                                        }
                                    });
                                }

                                if (VTR.Utils.isset(d.MediumSynopsis)) {
                                    synopsis = d.MediumSynopsis.replace(/["']/g, "");
                                }

                                if(VTR.Utils.isset(d.ShortSynopsis)) {
                                    shortSynopsis = d.ShortSynopsis.replace(/["']/g, "");
                                }

                                duration = (VTR.Utils.isset(d.DurationInSeconds) ? d.DurationInSeconds : "");
                                rating = (VTR.Utils.isset(d.MinimumAge) ? VTR.Utils.convertMinimumAgeToParentalRating(d.MinimumAge.type) : "");
                                year = (VTR.Utils.isset(d.ProductionDate) ? d.ProductionDate : "");
                                if (VTR.Utils.isset(d.DirectorNames)) {
                                    $.each(d.DirectorNames.DirectorName, function(i, item){
                                        directors += (VTR.Utils.isset(item.givenName) ? $.trim(item.givenName) : "") + (VTR.Utils.isset(item.familyName) ? " "+$.trim(item.familyName) : "");
                                        if (i != d.DirectorNames.DirectorName.length - 1){
                                            directors += ", ";
                                        }
                                    });
                                } else {
                                    directors = VTR.Properties.notAvailable;
                                }

                                if (VTR.Utils.isset(d.ActorsCharacters)) {
                                    $.each(d.ActorsCharacters.Actor, function(i, item) {
                                        actors += (VTR.Utils.isset(item.givenName) ? $.trim(item.givenName) : "") + (VTR.Utils.isset(item.familyName) ? " "+$.trim(item.familyName) : "");
                                        if (i != d.ActorsCharacters.Actor.length - 1){
                                            actors += ", ";
                                        }
                                    });
                                } else {
                                    actors = VTR.Properties.notAvailable;
                                }

                                bookmark = (VTR.Utils.isset(d.Bookmark) ? d.Bookmark : ""); 

                                if(VTR.Utils.isset(d.Previews)) {
                                    assetIdTrailer = d.Previews.Title[0].Contents.Content[0].Aliases.Alias[0].Value;
                                }
                                isAdult = (VTR.Utils.isset(d.IsAdult) ? d.IsAdult : false); 

                                output.cats[i1].IsOnWishlist = (VTR.Utils.isset(d.OnWishList) ? d.OnWishList : "");
                                output.cats[i1].Bookmark = (VTR.Utils.isset(d.Bookmark) ? d.Bookmark : "0");
                                output.cats[i1].titledetail.push({
                                    "categoryId": d1.id,
                                    "categoryName" : d1.Name.toUpperCase(),
                                    "name" : names.toUpperCase(),
                                    "shortName" : shortNames.toUpperCase(),
                                    "genre" : genres,
                                    "poster" : img,
                                    "synopsis" : synopsis,
                                    "shortSynopsis" : shortSynopsis,
                                    "duration" : duration,
                                    "year" : year,
                                    "director": directors,
                                    "actors": actors,
                                    "rating": rating,
                                    "trailerURI": trailerURI,
                                    "playerURI": playerURI,
                                    "elapsedTime": elapsedTime,
                                    "lastAvailability": lastAvailability,
                                    "bookmark": bookmark,
                                    "isAdult": isAdult,
                                    "isSeries": false
                                });

                                if (VTR.Utils.isset(d.Contents)) {
                                    var assetId = "";
                                    $.each(d.Contents.Content[0].Aliases.Alias, function(i, alias) {
                                        if(alias.type == "VodBackOfficeId") {
                                            assetId = alias.Value;
                                        }
                                    })

                                    if (VTR.Utils.isset(d.Contents.Content[0].OriginalLanguages)) {
                                        $.each(d.Contents.Content[0].OriginalLanguages.OriginalLanguage, function(i, item) {
                                            languages += VTR.Utils.convertLangCodeToLangName(item);
                                            if (i != d.Contents.Content[0].OriginalLanguages.OriginalLanguage.length - 1){
                                                languages += ", ";
                                            }
                                        })
                                    };

                                    if (VTR.Utils.isset(d.Contents.Content[0].CaptionLanguages)) {
                                        $.each(d.Contents.Content[0].CaptionLanguages.CaptionLanguage, function(i, item) {
                                            subtitles += VTR.Utils.convertLangCodeToLangName(item);
                                            if (i != d.Contents.Content[0].CaptionLanguages.CaptionLanguage.length - 1){
                                                subtitles += ", ";
                                            }
                                        })
                                    };
                                    output.cats[i1].pricesformats.push({
                                        "isHD": d.Contents.Content[0].IsHD,
                                        "is3D": d.Contents.Content[0].Is3D,
                                        "LastAvailability": d.Contents.Content[0].LastAvailability,
                                        "Type": d.Contents.Content[0].Products.Product[0].Type,
                                        "Currency": d.Contents.Content[0].Products.Product[0].Currency,
                                        "ListPrice": d.Contents.Content[0].Products.Product[0].ListPrice,
                                        "RentalPeriod": d.Contents.Content[0].Products.Product[0].RentalPeriodInMinutes,
                                        //"PlayerURI": playerURI + assetId + "?STBId=" + VTR.Account.cpeId,
                                        "assetId": assetId,
                                        "trailerAssetId": assetIdTrailer,
                                        //"IsOnWishlist": isOnWishlist,
                                        "EntitlementState": d.Contents.Content[0].Products.Product[0].EntitlementState,
                                        "titleId": d.id,
                                        "productId": d.Contents.Content[0].Products.Product[0].id,
                                        //"bookmark": bookmark,
                                        "EntitlementEnd": (VTR.Utils.isset(d.Contents.Content[0].Products.Product[0].EntitlementEnd) ? d.Contents.Content[0].Products.Product[0].EntitlementEnd : ""),
                                        "previewCount": d.PreviewCount,
                                        "languages": languages,
                                        "subtitles": subtitles,
                                        "Name": d.Contents.Content[0].Products.Product[0].Name
                                    });
                                }
                            });
                        }
                    });
                }
            }
            callback(output);
    	}
        catch (err) {
            console.log('Error AVN API: '+err.message);
        }
    }).fail(function(xhr, errorType, error){
    	console.log('xhr:' + JSON.stringify(xhr.response) + ' - ' + 'error:' + error);
    }).done(function(data, status, xhr){
    	console.log('data:' + data + ' - ' + 'status:' + status);
    });
}
