
/*var lis = document.querySelectorAll('li span');

for(var i=0; i<lis.length;i++){
    lis[i].style.backgroundImage = 'url(/img/movies/'+(i%36)+'.jpg)';
    //console.log(lis[i].style.backgroundImage);
}*/

/**
 * For lists with less than 8 items, do some cloning
 */
 $(function() {
    for(var i=1; i<=7; i++){
        //console.log($('.items'+i));
        var listsWithN = document.querySelectorAll('.items'+i);
        //a list with the class "item1" or "item2" etc
        for(var L=0; L<listsWithN.length; L++){
            var ul = listsWithN[L];
            ul.style.display = 'none';

            var items = ul.querySelectorAll('ul>li');
            //we need to duplicate the items so that they
            //are the place holders

            //We need (a) enough clones to fill up 2 spots in front
            //and (b) a multiple of the current number of cells
            //so that we have a clean repeating sequence without skipping any
            //and 1 spot after
            //so Extras >= 3
            //so N*i >= 3
            //so N >= 3/i
            var numClonesNeeded = Math.ceil(3/i);

            var lastItem = items[items.length-1];

            for(var p=0; p<numClonesNeeded*items.length; p++){
                var item = items[p % items.length];
                ul.appendChild(item.cloneNode(true));
            }

            //move last 2 to the beginning for animation to have intial place holders
            var firstItem = ul.querySelector('ul>li:first-child');
            var lastItem = ul.querySelector('ul>li:last-child');
            ul.insertBefore(lastItem, firstItem);

            var firstItem = ul.querySelector('ul>li:first-child');
            var lastItem = ul.querySelector('ul>li:last-child');
            ul.insertBefore(lastItem, firstItem);

            console.log(i, "Started with " + items.length + ", and now we have " + ul.querySelectorAll('ul>li').length);

            ul.style.display = null;
        }


    }

});

// Duplicar carruseles cuando hay tres o menos carruseles
(function ()
{
    // Obtener todos los carruseles
    var carrousels = document.querySelectorAll (".carrousels > li");
    // Verificar límite
    if (carrousels.length >= 4 && carrousels.length <= 1)

        return;

    // Duplicar todos
    var contenedor = document.querySelector (".carrousels");
    for (i = 0; i < carrousels.length; i++)
    {
        var item = carrousels [i];
        contenedor.appendChild(item.cloneNode(true));
    }
})();

// Duplicar ítems en barra de navegación detalle de película cuándo hay 8 o menos elementos
(function ()
{
    // Obtener todos los carruseles
    var carrousels = document.querySelectorAll (".nav-detail > li");
    
    // Añadir clase para mascara
    if(carrousels.length == 3){
        $(".nav-detail").addClass('nav-3-items')
    }; 
    if(carrousels.length == 4){
        $(".nav-detail").addClass('nav-4-items')
    }; 
    if(carrousels.length == 5){
        $(".nav-detail").addClass('nav-5-items')
    }; 
    if(carrousels.length == 6){
        $(".nav-detail").addClass('nav-6-items')
    }; 

    // Verificar límite
    if (carrousels.length >= 8)
        return;
    // Duplicar todos
    var contenedor = document.querySelector (".nav-detail");
    for (i = 0; i < carrousels.length; i++)
    {
        var item = carrousels [i];
        contenedor.appendChild(item.cloneNode(true));
    };


})();
/*
$(function () {
    //
    var elems = $('ul.carrousels > li:nth-child(2) ul.carrousel');
    console.log(elems);
    elems.each(function() {
        console.log($(this).data("hd"));
    })
$("ul.carrousels > li ul.carrousel li").each(function() { 
        console.log($(this).data("hd"));
        if($(this).data("hd") == "hd") {
            $(this).append("<div class='tag-hd'><p>HD</p></div>");
        }
    });
});
*/
/*
$(function() {
    $("ul.carrousels > li ul.carrousel li").each(function() { 
        if($(this).data("hd") == "hd") {
            $(this).append("<div class='tag-hd'><p>HD</p></div>");
        }
        if($(this).data("3d") == "3d") {
            $(this).append("<div class='tag-3d'><p>3D</p></div>");
        }
        
        if($(this).data("content-type") == "Free") {
            $(this).append("<div class='tag-rent'>GRATIS</div>");                   
        }
        else if($(this).data("content-type") == "Subscription") {
            $(this).append("<div class='tag-rent'>SUSCRIPCIÓN</div>");                  
        }
        else if($(this).data("content-type") == "Transaction") {
            $(this).append("<div class='tag-rent'>ARRIENDA</div>");                 
        }
        //console.log($(this).data("crid"));
        var mainId = $(this).data("crid");
        var mythis = $(this);
        if(mainId != "{{MOVIE_URL}}" && mainId != "undefined") {
            var fieldList = 'Name,ContentCount,Contents,Previews,OnWishList';
            var urlListContentByTitle = VTR.Properties.traxisProxy + '/' + VTR.Traxis.urlContentsByTitle + '&ProfileId=' + VTR.Account.profileId;
            urlListContentByTitle = urlListContentByTitle.replace('{{TITLE_ID}}', mainId);
            //urlListContentByTitle = urlListContentByTitle.replace('{{FIELD_LIST}}', fieldList);
            $.getJSON(urlListContentByTitle, function(d){
                if(d.Contents.Content.length > 0) {
                    if(d.Contents.Content[0].IsHD == true) {
                        mythis.append("<div class='tag-hd'><p>HD</p></div>");
                    }
                    var contentId = d.Contents.Content[0].id;
                    var productFieldList = 'Type,ListPrice,RentalPeriodInMinutes,EntitlementState,Currency';
                    var urlGetProductByContent = VTR.Properties.traxisProxy + '/' + VTR.Traxis.urlProductByContent;
                    urlGetProductByContent = urlGetProductByContent.replace("{{CONTENT_ID}}", contentId);
                    urlGetProductByContent = urlGetProductByContent.replace("{{PROFILE_ID}}", VTR.Account.profileId);
                    urlGetProductByContent = urlGetProductByContent.replace("{{FIELD_LIST}}", productFieldList);
                    $.getJSON(urlGetProductByContent, function(dd) {
                        if(dd.Products.Product[0].Type == "Free") {
                            mythis.append("<div class='tag-rent'>GRATIS</div>");                   
                        }
                        else if(dd.Products.Product[0].Type == "Subscription") {
                            mythis.append("<div class='tag-rent'>SUSCRIPCIÓN</div>");                  
                        }
                        else if(dd.Products.Product[0].Type == "Transaction") {
                            mythis.append("<div class='tag-rent'>ARRIENDA</div>");                 
                        }

                    });
                //console.log(d);
                }
            });
        }
    });
    //$(document).off('AjaxStop');

});

*/