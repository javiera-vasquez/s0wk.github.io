function doit() {
  console.log("TVOD vod handoff test by k.");
  window.__openUrl__("webkit:http://192.168.239.66/TVOD/js/vod-ref/index.html");
}


window.addEventListener("load", function(){
  console.log("hello how are you");
  setTimeout(doit, 3000);
})
