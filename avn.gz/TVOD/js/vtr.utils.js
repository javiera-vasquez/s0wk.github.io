/*
	NAME: VTR.Utils 
	DESCRIPTION:
*/

VTR.Utils = {
	debugMode:true,
	debug: function(msgObj){
		if(VTR.Utils.debugMode){
			//console.log(JSON.stringify(msgObj));
			console.log(msgObj);
		}
	},
	detectSize: function(){
        var w = window.innerWidth;
        if (w >= 1280){
			window.appSize = 'hd';
			VTR.UI.screenFormat = 'HD';
            VTR.UI.titleMaxLenght = VTR.Properties.HDTitleMaxLenght;
		} else { 
			window.appSize = 'sd'; 
			VTR.UI.screenFormat = 'SD';
            VTR.UI.titleMaxLenght = VTR.Properties.SDTitleMaxLenght;
		}
	},
	/* Funcion utilitaria para reemplazo de caracteres  */
	replaceAll: function(text, busca, reemplaza){
		while (text.toString().indexOf(busca) != -1)
			text = text.toString().replace(busca,reemplaza);
		return text;
	},
	/* Funcion que verifica que un elemento exista, similar al isset de php */
	isset: function(element){
		if (typeof(element) != "undefined" && element !== null && element !== "unknown") {
			return true;
		} else {
			return false;
		}
	},
	openPlayer: function(urlPlayback, callback){
		if (window.__openUrl__){   
			console.log("Using window.__openUrl__(" + urlPlayback + ")");          
			window.__openUrl__("webkit:http://" + urlPlayback);   
		} else if (window.openApplication){   
			console.log("Using window.openApplication(" + urlPlayback + ")");          
			window.openApplication("webkit:http://" + urlPlayback);   
		} else {  
			console.log("Using window.open(" + urlPlayback + ")");        
			window.open(urlPlayback);    
		} 
		return true; 
	},
	openAsset: function(assetId, bookmark, callback){
		var urlPlayback = "";
		urlPlayback = "webkit:http://" + location.hostname + ":80" + VTR.Properties.vodplayer + "?assetId=" + assetId + "&cpeId=" + VTR.Account.cpeId + "&bookmark=" + bookmark;
		if (window.__openUrl__){   
			console.log("Using window.__openUrl__(" + urlPlayback + ")");          
			window.__openUrl__(urlPlayback);   
		} else if (window.openApplication){   
			console.log("Using window.openApplication(" + urlPlayback + ")");          
			window.openApplication(urlPlayback);   
		} else {  
			console.log("Using window.open(" + urlPlayback + ")");        
			window.open(urlPlayback);    
		} 
		return true; 
	},
	doNavigate: function(categoryId, categoryName, isSeries, isDetailMovie){
		if(isSeries == 'undefined'){
                isSeries = false;
            }
            if(isDetailMovie == 'undefined'){
                isDetailMovie = false;
            }
		navi.navigate.push({
			'categoryId': categoryId,
			'categoryName': categoryName,
			'isSeries': isSeries,
            'isDetailMovie': isDetailMovie
		});
	},
	/* Function: Get Unit Address & CRC Checksum  */
	crc_40_110011011: function(MacAddr){
		var i;
		var j=0;
		var data;
		var mask = 0x80; // 1000 0000
		var ua_string;
		// The polynomial G(x) = x8 + x7 + x4 + x3 + x + 1.
		var poly = 0xCD; //  1100 1101
		// Create the array object to store the 40bit Unit Address
		var ua = new ArrayBuffer(6);
		// Creating views for the ua
		// Just for the sake of suffering with views, not necessary if not intended for multiplatform.
		var uaA = new DataView(ua, 0, 5);		// View containing Byte's 0,1,2,3 & 4, for CRC calculations
		var ua0 = new DataView(ua, 0, 1);		// Byte-0 of the ua, this is the MSB
		var uaC = new DataView(ua, 1, 4);		// Byte's-1,2,3 & 4 (Center) of the ua
		var uaCRC = new DataView(ua, 5, 1);	// Byte-5 of the ua will be the crc
		
		ua0.setUint8(0, parseInt(MacAddr.substr(2, 2), 16)); 	// Store the ua byte 0 into the array buffer. 
		uaC.setUint32(0, parseInt(MacAddr.substr(4, 8), 16));	// Store ua byte's 1,2,3 and 4 into the array buffer.
		uaCRC.setUint8(0, 255); 								// Initiate to 1's the shift register.
		
		crc = uaCRC.getUint8(0);
		
		for (j = 0; j < uaA.byteLength; j++) {	
			data = uaA.getUint8(j);				// Shift the next byte into the circuit.
			for (i = 0; i < 8; i++) {
				if ((crc ^ data) & mask){		// Test to see if the MSB of data XOR crc is 1.
					crc = crc ^ poly;
					crc = (crc << 1) + 1;		// CRC bit 8 = CRC bit 1
				}
				else
					crc = crc << 1;
				data = data << 1;					// Shift next bit into CRC.
			}
		}
		uaCRC.setUint8(0,crc);					//put crc into array;
		
		// Formating to 16 charecter device id format
		ua_string = VTR.Utils.pad(ua0.getUint8(0),3);
		ua_string = ua_string + VTR.Utils.pad(uaC.getUint32(0).toString(),10);
		ua_string = ua_string + VTR.Utils.pad(uaCRC.getUint8(0),3);
		
		return ua_string;
	},
	/*For pading the sections of the unit address with 0*/
	pad: function(value, length) {
    	return (value.toString().length < length) ? VTR.Utils.pad("0" + value, length) : value;
	},
	/*Computes crc value*/
	computeCRC: function(data) {
  		var deviceId;
  		deviceId = VTR.Utils.crc_40_110011011(data);         // computes crc value
  		return deviceId;
	},
	concatenateTitlesMenu: function(title1st, title2nd, title3rd) {
		var separator2nd = (title2nd.toString().length > 0) ? " / " : "";
		var separator3rd = (title3rd.toString().length > 0) ? " / " : "";
		var titlesMenu = title1st + separator2nd + title2nd + separator3rd + title3rd;
		return titlesMenu;
	},
        concatenateTitlesMenu4Levels: function(title1st, title2nd, title3rd, title4rd) {
		var separator2nd = (title2nd.toString().length > 0) ? " / " : "";
		var separator3rd = (title3rd.toString().length > 0) ? " / " : "";
                var separator4rd = (title4rd.toString().length > 0) ? " / " : "";
		var titlesMenu = title1st + separator2nd + title2nd + separator3rd + title3rd + separator4rd + title4rd;
		return titlesMenu;
	},
	executeTraxis: function(param){
		$.ajax({
			type: typeof param.type != 'undefined' ? param.type : 'GET',
			url: VTR.Properties.traxisProxy + '/' + param.url,
			async: typeof param.async != 'undefined' ? param.async : false,
			data: typeof param.data != 'undefined' ? param.data : '',
			contentType: typeof param.contentType != 'undefined' ? param.contentType : 'application/json; charset=utf-8',
			dataType: typeof param.dataType != 'undefined' ? param.dataType : 'jsonp',
			jsonp: typeof param.jsonp != 'undefined' ? param.jsonp : 'callback',
			jsonpCallback: typeof param.jsonpCallback != 'undefined' ? param.jsonpCallback : 'jsonp{N}',
			processData: typeof param.processData != 'undefined' ? param.processData : true,
			timeout: typeof param.timeout != 'undefined' ? param.timeout : 999,
			cache: typeof param.cache != 'undefined' ? param.cache : true,
			success: function (data, status) {
				try {
					console.log('executeTraxis: ' + data);
					return data;
				} 
				catch (err) {
					return 'executeTraxis (success)';
				}
			}, 
			error: function (xhr, errorType, error) {
				return 'executeTraxis (error)';
			}
		});
	},
	stripLeadingZeroes: function(param){
		if((param.length > 1) && (param.substr(0,1) == "0")){
      		return param.substr(1);
      	}else{
      		return param;
      	}
	}, 
	converDateToUnixTime: function(year,month,day){
		var output = "";
	 	var unixTime = Date.UTC(year,
		VTR.Utils.stripLeadingZeroes(month-1),
		VTR.Utils.stripLeadingZeroes(day));
		output = (unixTime/1000.0).toString();
		return output;
	},
    	convertDateToUnixTime: function(mydate){
		var output = "";
	 	var unixTime = Date.UTC(mydate.getFullYear(), mydate.getMonth(), mydate.getDate());
		output = (unixTime/1000.0).toString();
		return output;
	},

    handleErrorFromTraxis: function(response) {
        var result = $.parseJSON(response);
        var msgErr = '';
        var detailErr = '';
        switch(result.Error.InternalError) {
            case 'EInvalidCustomerId':
                msgErr = VTR.Messages.code1002.msg;
                detailErr = VTR.Messages.code1002.detail;
                break;
            case 'EInvalidSTBId':
                msgErr = VTR.Messages.code1004.msg;
                detailErr = VTR.Messages.code1004.detail;
                break;
            case 'ERestServiceError':
                msgErr = VTR.Messages.code1005.msg;
                detailErr = result.Error.Message;
                break;
            case 'EInvalidEntitlementState':
                msgErr = VTR.Messages.code1018.msg;
                detailErr = result.Error.Message;
                break;
            case 'ERestServiceResourceNotFound':
                msgErr = VTR.Messages.code1019.msg;
                detailErr = result.Error.Message;
                break;
            default:
                msgErr = VTR.Messages.code1006.msg;
                detailErr = result.Error.Message;
                break;
        }
        $("body").animate({
          opacity: 0,
          scale:1.3,
          translate3d: '0,-40px,0'
        }, VTR.Properties.transitionTime, 'ease-in', function(){
            $.ajax({
                url: "html/error.html",
                success: function(data){
                    $('body').html(data).animate({
                        opacity:1,
                        translate3d: '0,0,0'
                    }, VTR.Properties.transitionTime, 'ease-out');
                    VTR.UI.renderMessagePage({messageBody: msgErr, messageTitle: '', messageButton: 'ACEPTAR', returnPath: 'index.html'});
                    console.log('Error AVN API:'+detailErr);
                    mode = 'message';
                }
            });
        });
    },
            
        
    sessionExit: function(){
        console.log("sessionExit() - xhr url: 'http://session/management/exit?reason=SessionIdleTimeout'");
        var xhr = new XMLHttpRequest;
        xhr.open("GET", "http://session/management/exit?reason=SessionIdleTimeout", false);
        var retText = xhr.responseText;
        xhr.send(null);
        console.log("sessionExit() - retText: " + retText);
    },
    
    convertLangCodeToLangName: function(code) {
        switch(code) {
                case 'en':
                    return 'Inglés';
                case 'es':
                    return 'Español';
                case 'pt':
                    return 'Portugués';
                case 'fr':
                    return 'Francés';
                case 'de':
                    return 'Aleman';
                case 'it':
                    return 'Italiano';
                default:
                    return 'Otro';
        }
    },
    convertMinimumAgeToParentalRating: function(age) {
        switch(age) {
                case '1':
                    return 'NR';
                case '6':
                    return 'PG';
                case '13':
                    return 'PG-13';
                case '17':
                    return 'R';
                case '18':
                    return 'NC-17';
                case 'all':
                    return 'G';    
                default:
                    return '';
        }
    },

    getHrefCustomProperty : function (arr, value) {
        for (var i=0, iLen=arr.CustomProperty.length; i<iLen; i++) {            
            var href = arr.CustomProperty[i].href;
            if (href.search(value) >= 0) {
            	if(arr.CustomProperty[i].Value){
            		return VTR.Properties.seriesFlagValue;
            	}
            } 
        }
    },    
    getIndexOfRowContainingTitleId : function (arr, value) {
        for(var i = 0; i < arr.length; i++) {
            if(arr[i].titleId === value) {
                return i;
            }
        }
    }
}

Number.prototype.formatMoney = function(decPlaces, thouSeparator, decSeparator) {
    var n = this,
        decPlaces = isNaN(decPlaces = Math.abs(decPlaces)) ? 2 : decPlaces,
        decSeparator = decSeparator == undefined ? "." : decSeparator,
        thouSeparator = thouSeparator == undefined ? "," : thouSeparator,
        sign = n < 0 ? "-" : "",
        i = parseInt(n = Math.abs(+n || 0).toFixed(decPlaces)) + "",
        j = (j = i.length) > 3 ? j % 3 : 0;
    return sign + (j ? i.substr(0, j) + thouSeparator : "") + i.substr(j).replace(/(\d{3})(?=\d)/g, "$1" + thouSeparator) + (decPlaces ? decSeparator + Math.abs(n - i).toFixed(decPlaces).slice(2) : "");
};
