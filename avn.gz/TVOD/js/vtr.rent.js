/*
	NAME: VTR.Rent
	DESCRIPTION: Rent Transaction Product Entity
*/


VTR.Rent = {

}

/* Funcion  valida condiciones previas al arriendo */
VTR.Rent.validatePurchase = function(callback, options){
	var output = {"prePurchase":[]};
	//get OfferId
	var urlOfferId = VTR.Properties.traxisProxy + '/' + VTR.Traxis.urlGetOfferId;
    urlOfferId = urlOfferId.replace('{{PRODUCT_ID}}',options.productId);
    urlOfferId = urlOfferId.replace('{{CUSTOMER_ID}}',options.customerId);

    var willExceedExpenditureLimit = "";
	$.getJSON(urlOfferId, function(data){
		sessionStorage.setItem("offerId",data.Product.OfferPrice.Offer[0].id);
		//$.each(data, function(i, d){
		//});
        willExceedExpenditureLimit = data.Product.OfferPrice.Offer[0].willExceedExpenditureLimit;
        if(willExceedExpenditureLimit == "true") { 
			output.prePurchase.push({
				code  : VTR.Messages.code1003.code,
				type  : VTR.Messages.code1003.type,
				msg   : VTR.Messages.code1003.msg,
				detail: VTR.Messages.code1003.detail
			});
            callback(output);
        } else {
            if(sessionStorage.getItem("offerId") != null && sessionStorage.getItem("offerId") != "" && sessionStorage.getItem("offerId") != 'undefined'){
                comercialFactibility();
            } else {
                output.prePurchase.push({
                    code  : VTR.Messages.code1001.code,
                    type  : VTR.Messages.code1001.type,
                    msg   : VTR.Messages.code1001.msg,
                    detail: VTR.Messages.code1001.detail
                });
            }
        }
	}).fail(function(xhr, errorType, error){
		console.log('xhr:' + xhr + ' - ' + 'error:' + error);
	}).done(function(data, status, xhr){
		console.log('data:' + data + ' - ' + 'status:' + status);
	});

	 // Validaciones
	var comercialFactibility = function(){
		// Customer Info	 
		VTR.Account.getCustomer(function(result){
			$.each(result.customer, function(id, data){
				// En Cobranza ?
				  if(data.IsBarred == false){
						output.prePurchase.push({
							code  : VTR.Messages.code0000.code,
							type  : VTR.Messages.code0000.type,
							msg   : VTR.Messages.code0000.msg,
							detail: VTR.Messages.code0000.detail
						});
						 //window.location.replace("../html/detail-rent-pin.html");
					} 

					else if (data.IsBarred == true) {
							output.prePurchase.push({
								code  : VTR.Messages.code1002.code,
								type  : VTR.Messages.code1002.type,
								msg   : VTR.Messages.code1002.msg,
								detail: VTR.Messages.code1002.detail
							});
					}
				 else {
						output.prePurchase.push({
							code  : VTR.Messages.code1000.code,
							type  : VTR.Messages.code1000.type,
							msg   : VTR.Messages.code1000.msg,
							detail: VTR.Messages.code1000.detail
						});
				}	
			});
			callback(output);
		}, {cpeId: options.cpeId}); 
	}
}

/* Funcion  que hace efectivo el arriendo */
VTR.Rent.setPurchaseProduct = function(callback, options){
	var output = {"purchase":[]};
											
	var urlSetPurchase     	=  VTR.Properties.traxisProxy + '/' + VTR.Traxis.urlSetPurchaseProduct;   
	urlSetPurchase     		=  urlSetPurchase.replace('{{PRODUCT_ID}}',sessionStorage.getItem("productId"));
	urlSetPurchase     		=  urlSetPurchase.replace('{{CPE_ID}}',options.cpeId);
			
	// invoca arriendo (purchase)
	var xmlDocument ='<?xml version="1.0" encoding="utf-8"?><Purchase xmlns="urn:eventis:traxisweb:1.0"><OfferId>'+sessionStorage.getItem("offerId")+'</OfferId></Purchase>';

	$.ajax({
		type: 'PUT',
		url: urlSetPurchase,
		data: xmlDocument,
		dataType: 'xml',
		success: function(data){
			console.log('data:'+JSON.stringify(data));
			output.purchase.push({
				code  : VTR.Messages.code0000.code,
				type  : VTR.Messages.code0000.type,
				msg   : VTR.Messages.code0000.msg,
				detail: VTR.Messages.code0000.detail
			});

			callback(output);
		},
		error: function(xhr, errorType, error){
			console.log('Error:' + error + ':' + xhr.responseText);
            VTR.Utils.handleErrorFromTraxis(xhr.response);
//			output.purchase.push({
//				code  : VTR.Messages.code1003.code,
//				type  : VTR.Messages.code1003.type,
//				msg   : VTR.Messages.code1003.msg,
//				detail: VTR.Messages.code1003.detail
//			});
//			callback(output);
		}
	}); 
}
