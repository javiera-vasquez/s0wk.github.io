//BCP Example - Send PIN to session API. Polling for the response from session API
//Alan Mih; ActiveVideo - Extracted from SCN [Ven Virtusio]
//The code snippets below illustrate the progression of the PIN check flow, and is in accordance with sections 5.3 validate_pin and 5.4 validate_pin_response of the LGI-PR BCP Addendum

/* ADDENDUM SNIPPET FOR 5.3 AND 5.4
5.3	validate_pin
validate_pin() is sent from the H5 application to the client for parental PIN validation. The H5 application  captures the PIN entry and sends the values entered to client so that it can be verified using OS/middleware API.
The client will send validate_pin_response() in response.

Syntax:
validate_pin() {	
  pin_type	
  pin_len
  for(i = 0; i < pin_len; ++i) {		
      pin
  }		
}

pin_type  
0 for parental PIN, 
1 for purchase PIN. 

pin_len  The number of characters in the pin.
No. of bits: 8
Type: uint

pin   A variable length pin field carrying ASCII value of PIN entered (ex: if PIN entered is 1234, this field will carry 1234). 
No. of bits: 8
Type: vbytes


5.4	validate_pin_response
validate_pin_response() is sent from the client to the H5 application in response to validate_pin().

Syntax
validate_pin_response() {		
  result
}

No. of bits: 8
Type: uint

result  Result of the pin validation.
	0 Invalid pin.
	1  Valid pin.
*/
//av.sessionMgr.sendPIN(currentPIN, pinSent, type);

VTR.PIN = {
    Parental: 0,
    Purchase: 1
}

VTR.STB = {
    //CODE SNIPPETS OF ALL RELEVANT PIN PROCESSING STEPS
    //1) Provide the PIN value and a callback function to function sendPIN
    // Set up Class for Session Manager
    sessionMgr: function() {
        var _self = this;
        this.clientID = 0;
        this.isReady = false;
        this.log = {};
        this.log.debug = function(msg){console.log(msg);}
        this.log.info  = function(msg){console.log(msg);}
        this.log.warn  = function(msg){console.warn(msg);}
        this.log.error = function(msg){console.error(msg);}
        this.log.fatal = function(msg){console.error(msg);}

        this.getSessionProperties = function(cb) {
            //this.log.info("sessionMgr.getSessionProperties() - xhr url: 'http://session/properties.json");
            console.log("sessionMgr.getSessionProperties() - xhr url: 'http://session/properties.json");
            var xhr = new XMLHttpRequest();
            xhr.url="http://session/properties.json";
            xhr.onreadystatechange = function() {
                if (this.readyState == 4) {
                    _self.log.debug("sessionMgr.getSessionProperties() - responseText: " + this.responseText);
                    try{    
                        var retText = this.responseText;
                        _self.sessionProperties = JSON.parse(retText);
                    }catch (err){
                        _self.sessionProperties = {};
                        _self.sessionProperties.userAgent = navigator.userAgent;
                    }
                    cb(_self.sessionProperties);
                }                        
            };
            xhr.open("POST", xhr.url, true);
            xhr.send("");                    
        }

        this.getClientProperties = function(cb) {
            //this.log.info("sessionMgr.getClientProperties() - xhr url: 'http://session/client/properties.json");
            console.log("sessionMgr.getClientProperties() - xhr url: 'http://session/client/properties.json");
            var xhr = new XMLHttpRequest();
            xhr.url="http://session/client/properties.json";
            xhr.onreadystatechange = function() {
                if (this.readyState == 4) {
                    _self.log.debug("sessionMgr.getClientProperties() - responseText: " + this.responseText);
                    try{    
                        var retText = this.responseText;
                        _self.clientProperties = JSON.parse(retText);
                    }catch (err){
                        _self.clientProperties = {};
                    }
                    cb(_self.clientProperties);
                }                        
            };
            xhr.open("POST", xhr.url, true);
            xhr.send("");                    
        }

        //2) sendPIN accepts the value, binary encodes it according to spec, and sends it to the session API. Upon "sent" success, trigger the callback function (pinSent)
        this.sendPIN = function(pin,cb,type){
            var protocolid=0x10;//16;
            this.log.info("sessionMgr.sendPIN("+pin+")");
            //make sure its a string
            pin=pin.toString();

            //create required special arrays (they dont seem to work however)
            var buf = new ArrayBuffer(pin.length+2);
            var u8s = new Uint8Array(buf);

            // Message id (validate_pin)
            //u8s[0] = type; //0: Adult PIN - 1: Rent PIN
            // Message length
            //u8s[1] = pin.length;
            // Message id (validate_pin)
            u8s[0] = 3; //always 3 for validate! (currentPinAction==0) ? 3 : 5;
            // Message length
            u8s[1] = (type==VTR.PIN.Purchase) ? 132 : pin.length;


            // convert to ascii
            for ( var i = 0; i < pin.length; i++ ) {
                //convert to ascii
                u8s[2+i]=pin[i].charCodeAt();
            }

            //create the binary packet to submit to post url
            var retStr = String.fromCharCode.apply(null, new Uint8Array(buf));

            if (XMLHttpRequest.prototype.sendAsBinary === undefined) {
                XMLHttpRequest.prototype.sendAsBinary = function(string) {
                    var bytes = Array.prototype.map.call(string, function(c) {
                        return c.charCodeAt(0) & 0xff;
                    });
                    //this.send(new Uint8Array(bytes).buffer); //deprecated call in javascript, no need to ".buffer" anymore
                    //Devin!!  taking out the .buffer is what was giving us the jacked up data!
                    this.send(new Uint8Array(bytes).buffer);
                };
            }
            //make submition to usm
            var xhr = new XMLHttpRequest();
            xhr.url="http://session/client/send?protocolid=" + protocolid;
            var cbmsg = "xhr url: '" + xhr.url + "' - send('"+retStr+"')";
            console.log("sessionMgr.sendPIN("+pin+") - " + cbmsg);
            xhr.onreadystatechange = function() {
                if (this.readyState == 4) {
                    var retText = xhr.responseText;
                    console.log("sessionMgr.sendPIN("+pin+") - xhr.responseText: " + retText);
                    cb(cbmsg, type);
                }
            }
            xhr.open("POST", xhr.url, true);
            //xhr.send(retStr);
            xhr.sendAsBinary(retStr);
        }

        this.listenForPassthrough = function(cb,type){   
            var protocolid=0x10;//16;
            try{xhr.abort();}catch(e){};
            xhr = new XMLHttpRequest();
            xhr.url = "http://session/client/poll?protocolid=" + protocolid;
            //this.log.info("sessionMgr.listenForPassthrough() - xhr url: '" + xhr.url + "'");
            console.log("sessionMgr.listenForPassthrough() - xhr url: '" + xhr.url + "'");
            xhr.onreadystatechange = function() {
                if ((this.readyState == 4) && (this.status==200)) {
                    console.log("sessionMgr.listenForPassthrough() - responseText: " + this.responseText);
                    ret = {};
                    ret.message_id = this.responseText.charCodeAt(0);
                    ret.result     = this.responseText.charCodeAt(1);
                    cb(ret,type);
                }                        
            }
            xhr.open("POST", xhr.url, true); 
            xhr.send("");                    
        }
    },
    //3) pinSent accepts the response from the API, which should just be a confirmation. The actual message payload is retrieved by polling the API for a response. pollForPINReturn executes the polling
    pinSent: function(msg, type){
        console.log("xmlhttp POST: " + msg + "<br>");
        startTime = new Date().getTime();
        //check every xxx;
        try {
            clearTimeout(passthroughTimer);
        }
        catch(e) {

        };
        VTR.STB.pollForPINReturn(type);
    },

    //4) pollForPINReturn triggers of listenForPassthrough, which is responsible for executing the query for a result response and to do basic parsing of the result. If a response is received, then pinReturned is called to handle the response payload
    pollForPINReturn: function(type){
        console.log("pollForPINReturn() polling for validate_pin_response...('http://session/client/poll?protocolid=')");
        av.sessionMgr.listenForPassthrough(VTR.STB.pinReturned, type);
        var checkTime = new Date().getTime();
        if ((checkTime-startTime) < (30*1000)){
            passthroughTimer = setTimeout(VTR.STB.pollForPINReturn,5000);
        } else {
            stopTime = new Date().getTime();
            var totalTime = stopTime-startTime;
            console.log("validate_pin_response passthrough message never received! Total Time: " + totalTime + "ms");
//            var msg = "Error al intentar validar el PIN. Timeout: " + totalTime + "ms.";
            var msg = VTR.Messages.code1017.msg;
            $.ajax({
                url: 'html/error.html',
                success: function(data){
					$('body').html(data).animate({
						opacity:1,
						translate3d: '0,0,0'
					}, 200, 'ease-out');
					VTR.UI.renderMessagePage({messageBody: msg, messageTitle: '', messageButton: 'ACEPTAR'});
					mode = 'message';
                },
				error: function(xhr, errorType, error){
					console.log('Error:' + error + ':' + xhr.responseText);
				}
            });
        }
    },

    //5) pinReturned interprets the response and triggers the appropriate app behaviors. The End.
    pinReturned: function(obj,type){
        //we finally get a return from the session...
        stopTime = new Date().getTime();
        var totalTime = stopTime-startTime;
        console.log("pinReturned() - time between pin submit and message return: " + totalTime);
        if (obj.message_id==4 || obj.message_id==6) {
            //then pin message
            console.log("validate_pin_response passthrough message is <b>valid</b> (message_id == 4)");
            /*
            0  Invalid PIN.
            1  Valid PIN.
            */
           
           console.log("VTR.STB - VALOR VALIDACION PIN obj.result - VALOR:" + obj.result);
           
            if (obj.result==1) {
                if(type == VTR.PIN.Purchase) {
                    //return true;
                    VTR.Rent.setPurchaseProduct(function(data) { 
                        console.log(JSON.stringify(data)); 
                        $.each(data.purchase, function(i, d) {
                            if(d.code == '0000') {
                                localStorage.setItem('returnKey'+VTR.Account.cpeId, 'play');
                                localStorage.setItem('returnData'+VTR.Account.cpeId, JSON.stringify({'status': 'play', 'message': '', 'titleId': sessionStorage.getItem('titleId'), 'categoryName': VTR.Properties.titlesMenu, 'navi': navi.navigate}));
                                VTR.Utils.openAsset(sessionStorage.getItem("assetId"));
                            }
                            else {
                                $.ajax({
                                    url: "html/error.html",
                                    success: function(data){
                                        $('body').html(data).animate({
                                            opacity:1,
                                            translate3d: '0,0,0'
                                        }, VTR.Properties.transitionTime, 'ease-out');
                                        VTR.UI.renderMessagePage({messageBody: d.msg, messageTitle: '', messageButton: 'ACEPTAR', returnPath: 'index.html'});
                                        mode = 'message';
                                        console.log('Detalle: ' + d.detail);
                                    },
                                    error: function(xhr, errorType, error){
                                        console.log('Error:' + error + ':' + xhr.responseText);
                                    }
                                });                                
                            }
                        });
                    },{cpeId:VTR.Account.cpeId});
                    //VTR.Utils.openPlayer(location.hostname + VTR.Properties.vodplayer + "?assetId=" + VTR.Properties.assetId + "&cpeId=" + VTR.Account.cpeId);
                }
                else {
                    var catId = sessionStorage.getItem("categoryId");
                    $("body").animate({ 
                      opacity: 0,
                      scale:1.3,
                      translate3d: '0,-40px,0'
                    }, VTR.Properties.transitionTime, 'ease-in', function(){
                        $.ajax({
                            url: "index.html",
                            success: function(data){
								$('body').html(data).animate({
									opacity:1,
									translate3d: '0,0,0'
								}, VTR.Properties.transitionTime, 'ease-out');
								//VTR.UI.renderListSubMenu({categoryId: catId, categoryName: 'ADULTOS', isCarrusel: true, isSeries: ''});
								mode = 'nav';
                            },
							error: function(xhr, errorType, error){
								console.log('Error:' + error + ':' + xhr.responseText);
							}
                        });
                    });
                }
            } else {
                //console.log("PINS don't match! currentPIN: " + currentPIN + " checkPIN: " + checkPIN);
                //window.location.href = "html/error.html";
                $("body").animate({
                  opacity: 0,
                  scale:1.3,
                  translate3d: '0,-40px,0'
                }, VTR.Properties.transitionTime, 'ease-in', function(){
                    var msg = "";
                    var returnPath = "";
                    if(type == VTR.PIN.Parental) {
                        returnPath = "html/pin-parental.html";
//                        msg = "Tu PIN CONTROL FAMILIAR no es correcto, por favor ingrésalo nuevamente. (UI-2004)";
                        msg = VTR.Messages.code1009.msg;
                    }
                    else if(type == VTR.PIN.Purchase){
                        returnPath =  "html/detail-rent-pin.html";
//                        msg = "Tu PIN DE ARRIENDO no es correcto, por favor ingrésalo nuevamente para realizar el arriendo. (UI-2003)"
                        msg = VTR.Messages.code1008.msg;
                    }
                    
                    console.log("VTR.STB - Mensaje UI:" + msg);
                     
                    $.ajax({
                        url: 'html/error.html',
                        success: function(data){
							$('body').html(data).animate({
								opacity:1,
								translate3d: '0,0,0'
							}, VTR.Properties.transitionTime, 'ease-out');
							VTR.UI.renderMessagePage({messageBody: msg, messageTitle: '', messageButton: 'ACEPTAR', returnPath: returnPath});
//                            navi.navigate.pop();
							mode = 'message';
                        },
						error: function(xhr, errorType, error){
							console.log('Error:' + error + ':' + xhr.responseText);
						}
                    });
                });
            }
        } else {
            //document.getElementById("messageBox").innerHTML+="<br>validate_pin_response passthrough message is <b>invalid</b> (message_id != 2)";
            $.ajax({
                url: 'html/error.html',
                success: function(data){
					$('body').html(data).animate({
						opacity:1,
						translate3d: '0,0,0'
					}, 200, 'ease-out');
					//VTR.UI.renderMessagePage({messageBody: msg + 'Resultado: ' + obj.result, messageTitle: 'ERROR AL VERIFICAR PIN', messageButton: 'REINTENTAR', returnPath: returnPath});
//					VTR.UI.renderMessagePage({messageBody: 'Se ha producido al intentar validar PIN. Por favor llamar al 600 800 9000. (UI-5000)', messageTitle: 'ERROR AL VERIFICAR PIN', messageButton: 'REINTENTAR'});
					VTR.UI.renderMessagePage({messageBody: VTR.Messages.code1017.msg, messageTitle: '', messageButton: 'ACEPTAR'});
					mode = 'message';
                },
				error: function(xhr, errorType, error){
					console.log('Error:' + error + ':' + xhr.responseText);
				}
            });
            //window.location.href = "html/error.html";
            console.log('Error al validar el PIN. Resultado: ' + JSON.stringify(obj));
        }
        clearTimeout(passthroughTimer);
    },
    //Here's our call back function where clientID that is returned is the mac address.  Then we format it correctly. If it's missing some digits, it dropped the Leading 0's
    sessionPropertiesReturn: function(theReturn){
        console.log("sessionPropertiesReturn callback function called, theReturn: "+JSON.stringify(theReturn));
        //console.log("sessionPropertiesReturn callback function called, theReturn: "+JSON.stringify(theReturn));
        var obj=theReturn;
        av.global.sessionProperties=theReturn;
        av.global.macAddress=(obj.clientID != undefined) ? obj.clientID : av.config.genericMacAddress;
        try {
            if (obj.clientID.length < 12) {
                var missing = 12 - obj.clientID.length;
                console.log("we are missing this many digits from mac address: " + missing);
                switch (missing) {
                    case 1:
                        av.global.macAddress = "0" + av.global.macAddress;
                        break;
                    case 2:
                        av.global.macAddress = "00" + av.global.macAddress;
                        break;
                    case 3:
                        av.global.macAddress = "000" + av.global.macAddress;
                        break;
                    case 4:
                        av.global.macAddress = "0000" + av.global.macAddress;
                        break;
                    default:
                        break;
                }
            }
        }
        catch(err){
            av.log.error("ERROR: "+err.message);
        };
        VTR.Account.cpeId = VTR.Utils.computeCRC(av.global.macAddress);
        var bodyReq = "";
        bodyReq += "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
        bodyReq += "<Request xmlns=\"urn:eventis:traxisweb:1.0\">";
        bodyReq += "  <Identity>";
        bodyReq += "    <CpeId>"+VTR.Account.cpeId+"</CpeId>";
        bodyReq += "  </Identity>";
        bodyReq += "  <RootRelationQuery relationName=\"Profiles\">";
        bodyReq += "    <Options>";
        bodyReq += "      <Option type=\"Props\">Name</Option>";
        bodyReq += "    </Options>";
        bodyReq += "  </RootRelationQuery>";
        bodyReq += "</Request>";
        var urlGetProfileInfo = VTR.Properties.traxisProxy + '/' + VTR.Traxis.urlBodyRequest;
        $.post(urlGetProfileInfo, bodyReq, function(data2) {
            $.each(data2.Profiles.Profile, function(ix, d2){
                VTR.Account.profileId = d2.id;
                var bodyReq2 = "";
                bodyReq2 += "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
                bodyReq2 += "<Request xmlns=\"urn:eventis:traxisweb:1.0\">";
                bodyReq2 += "  <Identity>";
                bodyReq2 += "    <CpeId>"+VTR.Account.cpeId+"</CpeId>";
                bodyReq2 += "  </Identity>";
                bodyReq2 += "  <RootRelationQuery relationName=\"Customers\">";
                bodyReq2 += "    <Options>";
                bodyReq2 += "      <Option type=\"Props\">Aliases</Option>";
                bodyReq2 += "    </Options>";
                bodyReq2 += "  </RootRelationQuery>";
                bodyReq2 += "</Request>";
                var urlGetCustomerInfo = VTR.Properties.traxisProxy + '/' + VTR.Traxis.urlBodyRequest;
                $.post(urlGetCustomerInfo, bodyReq2, function(data3) {
                    $.each(data3.Customers.Customer, function(i3, d3){
                        VTR.init();
                        VTR.Account.customerId = (VTR.Utils.isset(d3.Aliases) ? d3.Aliases.Alias[0].Value : null);
                        if(VTR.Account.customerId == null) {
                            VTR.Utils.handleErrorFromTraxis('{"Error":{"InternalError":"EInvalidSTBId"}}');
                            return false;
                        }
                        console.log('VTR.Account.cpeId:'+VTR.Account.cpeId);
                        console.log('VTR.Account.customerId:'+VTR.Account.customerId);
                        console.log('VTR.Account.profileId:'+VTR.Account.profileId);
                    });
                });
            }); 
		}).fail(function(xhr, errorType, error){
			console.log('xhr:' + JSON.stringify(xhr.response) + ' - ' + 'error:' + error);
            VTR.Utils.handleErrorFromTraxis(xhr.response);
		}).done(function(data, status, xhr){
			console.log('data:' + data + ' - ' + 'status:' + status);
        });
    },    

    //Here's our call back function where clientID that is returned is the mac address.  Then we format it correctly. If it's missing some digits, it dropped the Leading 0's
    clientPropertiesReturn: function(theReturn){
        console.log("clientPropertiesReturn callback function called, theReturn: "+JSON.stringify(theReturn));
        //console.log("sessionPropertiesReturn callback function called, theReturn: "+JSON.stringify(theReturn));
        var obj = theReturn;
        av.global.clientProperties=theReturn;
        av.global.launchParameter={};
        console.log('lp:'+av.global.clientProperties.launchParameter);
        var myOverrideUserAgent = (VTR.Utils.isset(obj.deviceClass) ? obj.deviceClass : av.config.genericUserAgent);
//        var user_agent = "ActiveVideo CloudTV H5/2; VTR/VOD (VTR; " + myOverrideUserAgent + "; Wired)";
        var user_agent = "ActiveVideo H5 HbbTV/1.1.1 (VOD; VTR; " + myOverrideUserAgent + "; ; ;)";
        console.log('userAgent:'+user_agent);
        VTR.Properties.userAgent = user_agent;
        $(document).on('ajaxBeforeSend', function(e, xhr, options){
            xhr.setRequestHeader("x-user-agent", user_agent);
        });
        if(VTR.Utils.isset(av.global.clientProperties.launchParameter)) {
            av.global.launchParameter = VTR.STB.getLaunchParameters(av.global.clientProperties.launchParameter);
            console.log('lp:'+av.global.clientProperties.launchParameter);
            //Interpret supported_pin_set value
            //convert into binary represented by a string
            var pinSetString = parseInt(av.global.launchParameter.supported_pin_set, 16).toString(2);
            if(pinSetString.length!=3){
                var diff = 3-pinSetString.length;
                switch(diff){
                    case 2:
                        pinSetString="00"+pinSetString;
                        break;
                    case 1:
                        pinSetString="0"+pinSetString;
                        break;
                    default:
                        break;
                }
            }
            if (pinSetString.substr(0, 1) == "1") {
                av.global.purchasePinSet = true;
            } else {av.global.purchasePinSet = false;}

            if (pinSetString.substr(1, 2) == "1") {
                av.global.lockAPISupported = true;
            } else {av.global.lockAPISupported = false;}

            if (pinSetString.substr(2, 3) == "1") {
                av.global.parentalPinSet = true;
            } else {av.global.parentalPinSet = false;}

            //Interpret parental_rating_level value
            if (parseInt(av.global.launchParameter.parental_rating_level) > 0) {
                av.global.parental_ratings_locks = true;
                av.global.ratingsArrayString = parseInt(av.global.launchParameter.parental_rating_level, 16).toString(2);
            } else {
                av.global.parental_ratings_locks = false;
            }
            VTR.Account.parentalPinSet = av.global.parentalPinSet;
            VTR.Account.purchasePinSet = av.global.purchasePinSet;
            console.log('parentalPinSet:'+VTR.Account.parentalPinSet+', purchasePinSet:'+VTR.Account.purchasePinSet);
        } else{
            //launchParameter value is not valid
        }
    },

    getLaunchParameters: function(lp){
        launchParameter={};
        launchParameter.type = lp.substring(0, 2);
        launchParameter.supported_pin_set = lp.substring(2, 4);
        launchParameter.parental_rating_level = lp.substring(4, 12);
        launchParameter.subcomplete = lp.substring(0, 12);
        return launchParameter;
   }   
}

// We are using a library but you can add an event listener for DomContentLoaded
/*av.onDomReady(
    function(evt){
        av.sessionMgr = new VTR.STB.sessionMgr;
        av.sessionMgr.getSessionProperties(VTR.STB.sessionPropertiesReturn);
        av.sessionMgr.getClientProperties(VTR.STB.clientPropertiesReturn);
        //console.log('stb:'+VTR.Utils.computeCRC(av.global.macAddress));
    }
);*/
