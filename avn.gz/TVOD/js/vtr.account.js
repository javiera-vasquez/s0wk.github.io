/*
	NAME: VTR.Account
	DESCRIPTION:
*/

VTR.Account = {
	customerId: 'VTREE015',
	cpeId: '0000037959911213',
	profileId: '65459cf2-c875-4a9d-b205-40d5ae591ac2~~23MasterProfile',
	parentalPinSet: false,
	purchasePinSet: false
}

/* Function to get my wishlist or favourites using Body Request */
VTR.Account.getMyWishList = function (callback, options){
    
        var titlesSize = 0;
        if(options.size === VTR.Properties.carruselSize){
            titlesSize = options.size;
            options.size = VTR.Properties.lienzoSize;           
        } else {
             titlesSize = options.size;
        }
    
    
	var fieldList = 'Name,Categories,Pictures,ShortName,Contents';
	var urlGetWishList = VTR.Properties.traxisProxy + '/' + VTR.Traxis.urlBodyRequest;
	var output = {"mywishlist":[]};
	var bodyReq = "";
	bodyReq += "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
	bodyReq += "<Request xmlns=\"urn:eventis:traxisweb:1.0\">";
	bodyReq += "  <Identity>";
	bodyReq += "    <CpeId>"+VTR.Account.cpeId+"</CpeId>";
	bodyReq += "  </Identity>";
	bodyReq += "  <RootRelationQuery relationName=\"Wishlist\">";
	bodyReq += "    <Options>";
	bodyReq += "      <Option type=\"Limit\">"+options.size+"</Option>";
	bodyReq += "      <Option type=\"Props\">Name,Pictures,ShortName,Contents</Option>";
	bodyReq += "      <Option type=\"filter\">ContentCount&gt;0&amp;&amp;Contents.ProductCount&gt;0&amp;&amp;IsViewableOnCpe==true&amp;&amp;IsAdult==false&amp;&amp;[AllGenres.AllGenre.Value!=adult||isnull(AllGenres)]</Option>";
	bodyReq += "    </Options>";
	bodyReq += "    <SubQueries>";
	bodyReq += "      <SubQuery relationName=\"Contents\">";
	bodyReq += "        <Options>";
	bodyReq += "          <Option type=\"props\">IsHD,Is3D</Option>";
	bodyReq += "          <Option type=\"filter\">ProductCount&gt;0&amp;&amp;FirstAvailability&lt;=now()&amp;&amp;LastAvailability&gt;=now()</Option>";
	bodyReq += "        </Options>";
	bodyReq += "        <SubQueries>";
	bodyReq += "          <SubQuery relationName=\"Products\">";
	bodyReq += "            <Options>";
	bodyReq += "              <Option type=\"props\">Type,EntitlementState</Option>";
	bodyReq += "            </Options>";
	bodyReq += "          </SubQuery>";
	bodyReq += "        </SubQueries>";
	bodyReq += "      </SubQuery>";
	bodyReq += "    </SubQueries>";
	bodyReq += "  </RootRelationQuery>";
	bodyReq += "</Request>";
    $.post(urlGetWishList, bodyReq, function(data) {
        try {
            
            var countTitleCarrusel = 0;
            
            $.each(data.Titles.Title, function(i, d){
                
                if(countTitleCarrusel < titlesSize) {
                    
                    if(d.Contents.Content[0].Products.Product[0].Type == 'Subscription' && d.Contents.Content[0].Products.Product[0].EntitlementState == 'NotEntitled') {                    
                    } else {

                        var img = null;
                        var pics = (VTR.Utils.isset(d.Pictures) ? d.Pictures.Picture : null);
                        if(pics){
                            $.each(pics, function(ix,dx) {
                                if(dx.type == 'BoxCover') {
                                    img = dx.Value.replace("http://" + VTR.Properties.posterServerName + "/", "http://" + VTR.Properties.posterServer + "/");
                                    return false;
                               }
                                else {
                                    img = dx.Value.replace("http://" + VTR.Properties.posterServerName + "/", "http://" + VTR.Properties.posterServer + "/");
                                }
                            });
                        }
        //                    if(d.Contents.Content[0].Products.Product[0].Type == 'Subscription' && d.Contents.Content[0].Products.Product[0].EntitlementState == 'NotEntitled') {
        //                        //nothing here
        //                    }
        //                    else { 
                        if(VTR.Utils.isset(d.Contents)) {
                            if(VTR.Utils.isset(d.Contents.Content[0].Products)) {

                                output.mywishlist.push({
                                    categoryId : 'CATEGORY_ID',
                                    subcategoryId : 'SUB_CATEGORY_ID',
                                    titleId : d.id,
                                    name : d.ShortName,
                                    is3D : d.Contents.Content[0].Is3D,
                                    isHD : d.Contents.Content[0].IsHD,
                                    pictureUri : img,
                                    contentType : d.Contents.Content[0].Products.Product[0].Type,
                                    contentId: d.Contents.Content[0].id
                                });
                                
                                 countTitleCarrusel++;
                            }
                        }
                    }
                } else {
                    return false;                    
                }
                    //}
            });
            callback(output);  	
        }
        catch(err) {
            console.log('Error AVN API: '+err.message);
        }
    }).fail(function(xhr, errorType, error){
    	console.log('Error AVN API: ' + JSON.stringify(xhr) + ' - ' + 'error:' + error);
    }).done(function(data, status, xhr){
    	console.log('data:' + data + ' - ' + 'status:' + status);
	});
}

/* Function to get My Keep Watching List using body Request */
VTR.Account.getMyViewings = function (callback, options){ 
	var urlGetKeepWatching = VTR.Properties.traxisProxy + '/' + VTR.Traxis.urlBodyRequest;
	var output = {"myviewings":[]};
	var bodyReq = "";
	bodyReq += "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
	bodyReq += "<Request xmlns=\"urn:eventis:traxisweb:1.0\">";
	bodyReq += "  <Identity>";
	bodyReq += "    <CustomerId>"+VTR.Account.customerId+"</CustomerId>";
	bodyReq += "    <ProfileId>"+VTR.Account.profileId+"</ProfileId>";
	bodyReq += "    <CpeId>"+VTR.Account.cpeId+"</CpeId>";
	bodyReq += "  </Identity>";
	bodyReq += "  <RootRelationQuery relationName=\"ViewedTitles\">";
	bodyReq += "    <Options>";
	bodyReq += "      <Option type=\"Limit\">"+options.size+"</Option>";
	bodyReq += "      <Option type=\"Props\">Name,Pictures,ShortName,Bookmark,ContentCount,Contents,LastViewDate,DurationInSeconds</Option>";
	bodyReq += "	  <Option type=\"filter\">ContentCount&gt;0&amp;&amp;Contents.ProductCount&gt;0&amp;&amp;Bookmark&gt;0&amp;&amp;IsViewableOnCpe==true&amp;&amp;!isnull(LastViewDate)&amp;&amp;IsPreview==false"+(options.isAdult == true ? "&amp;&amp;(IsAdult==true||AllGenres.AllGenre.Value==adult)" : "&amp;&amp;IsAdult==false&amp;&amp;[AllGenres.AllGenre.Value!=adult||isnull(AllGenres)]")+"</Option>";
	//bodyReq += "	  <Option type=\"filter\">ContentCount&gt;0&amp;&amp;Bookmark&gt;0&amp;&amp;IsViewableOnCpe==true&amp;&amp;IsPreview==false"+(options.isAdult == true ? "&amp;&amp;(IsAdult==true||AllGenres.AllGenre.Value==adult)" : "&amp;&amp;IsAdult==false&amp;&amp;[AllGenres.AllGenre.Value!=adult||isnull(AllGenres)]")+"</Option>";
    bodyReq += "      <Option type=\"Sort\">~LastViewDate</Option>";
	bodyReq += "    </Options>";
	bodyReq += "    <SubQueries>";
	bodyReq += "      <SubQuery relationName=\"Contents\">";
	bodyReq += "        <Options>";
	bodyReq += "          <Option type=\"props\">Aliases,IsHD,Is3D</Option>";
	bodyReq += "          <Option type=\"filter\">EntitlementState==Entitled&amp;&amp;ProductCount&gt;0&amp;&amp;FirstAvailability&lt;=now()&amp;&amp;LastAvailability&gt;=now()</Option>";
	bodyReq += "        </Options>";
	bodyReq += "        <SubQueries>";
	bodyReq += "          <SubQuery relationName=\"Products\">";
	bodyReq += "            <Options>";
	bodyReq += "              <Option type=\"props\">Type,EntitlementState,EntitlementEnd</Option>";
	bodyReq += "              <Option type=\"filter\">EntitlementState==Entitled</Option>";
	bodyReq += "            </Options>";
	bodyReq += "          </SubQuery>";
	bodyReq += "        </SubQueries>";
	bodyReq += "      </SubQuery>";
	bodyReq += "    </SubQueries>";
	bodyReq += "  </RootRelationQuery>";
	bodyReq += "</Request>";

	$.post(urlGetKeepWatching, bodyReq, function(data) {
        try {
            $.each(data.Titles.Title, function(i, d){
                var img = null;
                var pics = (VTR.Utils.isset(d.Pictures) ? d.Pictures.Picture : null);
                if (pics){
                    $.each(pics, function(ix,dx) {
                        if(dx.type == 'BoxCover') {
                            img = dx.Value.replace("http://" + VTR.Properties.posterServerName + "/", "http://" + VTR.Properties.posterServer + "/");
                            return false;
                        }
                        else {
                            img = dx.Value.replace("http://" + VTR.Properties.posterServerName + "/", "http://" + VTR.Properties.posterServer + "/");
                        }
                    });
                }
                if(VTR.Utils.isset(d.Contents)) {
                    if(VTR.Utils.isset(d.Contents.Content[0].Products)) {
                        output.myviewings.push({
                            categoryId : 'CATEGORY_ID',
                            subcategoryId : 'SUB_CATEGORY_ID',
                            titleId : d.id,
                            name : d.ShortName,
                            is3D : d.Contents.Content[0].Is3D,
                            isHD : d.Contents.Content[0].IsHD,
                            pictureUri : img,
                            contentType : (VTR.Utils.isset(d.Contents.Content[0].Products) ? d.Contents.Content[0].Products.Product[0].Type : 'CONTENT_TYPE'),
                            bookmark: d.Bookmark,
                            duration: d.DurationInSeconds,
                            assetId: d.Contents.Content[0].Aliases.Alias[0].Value,
                            LastViewDate: d.LastViewDate,
                            contentId: d.Contents.Content[0].id,
                            entitlementState: (VTR.Utils.isset(d.Contents.Content[0].Products) ? d.Contents.Content[0].Products.Product[0].EntitlementState : ''),
                            entitlementEnd: (VTR.Utils.isset(d.Contents.Content[0].Products) ? d.Contents.Content[0].Products.Product[0].EntitlementEnd : '')
                        });
                    }
                }
            });
            callback(output);
        }
        catch(err) {
            console.log('Error AVN API: '+err.message);
        }
	}).fail(function(xhr, errorType, error){
    	console.log('Error API AVN:' + JSON.stringify(xhr) + ' - ' + 'error:' + error);
    }).done(function(data, status, xhr){
    	console.log('data:' + data + ' - ' + 'status:' + status);
	});
}

/* Function to get My Viewing History using Body Request */
VTR.Account.getMyHistory = function (callback, options){
	var fieldList = 'Name,Categories,Pictures,ShortName,Bookmark,Contents';
	var mydate = new Date();
	mydate.setDate(mydate.getDate() - VTR.Properties.historyDaysLimit);
	var urlGetMyHistory = VTR.Properties.traxisProxy + '/' + VTR.Traxis.urlBodyRequest;
	// urlGetMyHistory = urlGetMyHistory.replace('{{FIELD_LIST}}', fieldList);
	// urlGetMyHistory = urlGetMyHistory.replace('{{PROFILE_ID}}', VTR.Account.profileId);
	// urlGetMyHistory = urlGetMyHistory.replace('{{PAGE_SIZE}}', VTR.Properties.carruselSize);
	// urlGetMyHistory = urlGetMyHistory.replace('{{DATE}}', mydate.toISOString());
	var output = {"myhistory":[]};
	var bodyReq = "";
	bodyReq += "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
	bodyReq += "<Request xmlns=\"urn:eventis:traxisweb:1.0\">";
	bodyReq += "  <Identity>";
	bodyReq += "    <CpeId>"+VTR.Account.cpeId+"</CpeId>";
	bodyReq += "  </Identity>";
	bodyReq += "  <RootRelationQuery relationName=\"ViewedTitles\">";
	bodyReq += "    <Options>";
	bodyReq += "      <Option type=\"Limit\">"+options.size+"</Option>";
	bodyReq += "      <Option type=\"Props\">Name,Categories,Pictures,ShortName,Bookmark,Contents</Option>";
	bodyReq += "	  <Option type=\"filter\">ContentCount&gt;0&amp;&amp;Bookmark&gt;=0&amp;&amp;IsViewableOnCpe==true&amp;&amp;IsAdult==false&amp;&amp;[AllGenres.AllGenre.Value!=adult||isnull(AllGenres)]&amp;&amp;LastViewDate&gt;" + mydate.toISOString() + "</Option>";
	bodyReq += "      <Option type=\"Sort\">~LastViewDate</Option>";
	bodyReq += "    </Options>";
	bodyReq += "    <SubQueries>";
	bodyReq += "      <SubQuery relationName=\"Contents\">";
	bodyReq += "        <Options>";
	bodyReq += "          <Option type=\"props\">Aliases,IsHD,Is3D,EntitlementState,EntitlementEnd</Option>";
	bodyReq += "          <Option type=\"filter\">ProductCount&gt;0&amp;&amp;FirstAvailability&lt;=now()&amp;&amp;LastAvailability&gt;=now()</Option>";
	bodyReq += "        </Options>";
	bodyReq += "        <SubQueries>";
	bodyReq += "          <SubQuery relationName=\"Products\">";
	bodyReq += "            <Options>";
	bodyReq += "              <Option type=\"props\">Type,EntitlementState</Option>";
	bodyReq += "            </Options>";
	bodyReq += "          </SubQuery>";
	bodyReq += "        </SubQueries>";
	bodyReq += "      </SubQuery>";
	bodyReq += "    </SubQueries>";
	bodyReq += "  </RootRelationQuery>";
	bodyReq += "</Request>";

    $.post(urlGetMyHistory, bodyReq, function(data) {
        try {
            $.each(data.Titles.Title, function(i, d){
                var img = null;
                var pics = (VTR.Utils.isset(d.Pictures) ? d.Pictures.Picture : null);

                if (pics){
                    $.each(pics, function(ix,dx) {
                        if(dx.type == 'BoxCover') {
                            img = dx.Value.replace("http://" + VTR.Properties.posterServerName + "/", "http://" + VTR.Properties.posterServer + "/");
                            return false;
                       }
                        else {
                            img = dx.Value.replace("http://" + VTR.Properties.posterServerName + "/", "http://" + VTR.Properties.posterServer + "/");
                        }
                    });
                }
                if(VTR.Utils.isset(d.Contents)) {
                    if(VTR.Utils.isset(d.Contents.Content[0].Products)) {
                        output.myhistory.push({
                            categoryId : 'CATEGORY_ID',
                            subcategoryId : 'SUB_CATEGORY_ID',
                            titleId : d.id,
                            name : d.ShortName,
                            is3D : d.Contents.Content[0].Is3D,
                            isHD : d.Contents.Content[0].IsHD,
                            pictureUri : img,
                            contentType : d.Contents.Content[0].Products.Product[0].Type,
                            bookmark: d.Bookmark,
                            duration: d.DurationInSeconds,
                            assetId: d.Contents.Content[0].Aliases.Alias[0].Value,
                            LastViewDate: d.LastViewDate,
                            contentId: d.Contents.Content[0].id,
                            entitlementState: d.Contents.Content[0].Products.Product[0].EntitlementState,
                            entitlementEnd: d.Contents.Content[0].Products.Product[0].EntitlementEnd
                        });
                    }
                }
            });
            callback(output);													
        }
        catch(err) {
            console.log('Error AVN API: '+err.message);
        }
	}).fail(function(xhr, errorType, error){
    	console.log('Error AVN API:' + JSON.stringify(xhr) + ' - ' + 'error:' + error);
    }).done(function(data, status, xhr){
    	console.log('data:' + data + ' - ' + 'status:' + status);
    });
}

/* Function to get My Purchased Products/Titles using Body Request */
VTR.Account.getMyPurchasedProducts = function(callback, options){
//	var fieldList = 'Name,Categories,Pictures,ShortName,Bookmark';
	var urlGetMyPurchasedProucts =  VTR.Properties.traxisProxy + '/' + VTR.Traxis.urlBodyRequest;
//	urlGetMyPurchasedProucts     =  urlGetMyPurchasedProucts.replace('{{FIELD_LIST}}', fieldList);
//	urlGetMyPurchasedProucts     =  urlGetMyPurchasedProucts.replace('{{CUSTOMER_ID}}',options.customerId);
	var output = {"mypurchasedprod":[]};
	var bodyReq = "";
	bodyReq += "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
	bodyReq += "<Request xmlns=\"urn:eventis:traxisweb:1.0\">";
	bodyReq += "  <Identity>";
	bodyReq += "    <CpeId>"+VTR.Account.cpeId+"</CpeId>";
	bodyReq += "  </Identity>";
	bodyReq += "  <RootRelationQuery relationName=\"Products\">";
	bodyReq += "    <Options>";
	bodyReq += "      <Option type=\"Limit\">"+VTR.Properties.lienzoSize+"</Option>";
	bodyReq += "      <Option type=\"Props\">Type</Option>";
	bodyReq += "	  <Option type=\"filter\">NumberOfPurchases&gt;0&amp;&amp;ContentsTitles&gt;0</Option>";
	//bodyReq += "      <Option type=\"Sort\">~LastViewDate</Option>";
	bodyReq += "    </Options>";
	bodyReq += "    <SubQueries>";
	bodyReq += "      <SubQuery relationName=\"ContentsTitles\">";
	bodyReq += "        <Options>";
	bodyReq += "          <Option type=\"props\">Name,Categories,Pictures,ShortName,Bookmark</Option>";
	bodyReq += "          <Option type=\"filter\">ContentCount&gt;0&amp;&amp;IsAdult==false&amp;&amp;[AllGenres.AllGenre.Value!=adult||isnull(AllGenres)]</Option>";
	//bodyReq += "          <Option type=\"props\">Name,Categories,Pictures,ShortName,Bookmark,AllGenres,IsAdult</Option>";
	//bodyReq += "          <Option type=\"filter\">ContentCount&gt;0</Option>";
	bodyReq += "        </Options>";
	bodyReq += "        <SubQueries>";
	bodyReq += "          <SubQuery relationName=\"Contents\">";
	bodyReq += "            <Options>";
	bodyReq += "              <Option type=\"props\">Aliases,IsHD,Is3D,EntitlementState,EntitlementEnd</Option>";
	bodyReq += "            </Options>";
	bodyReq += "          </SubQuery>";
	bodyReq += "        </SubQueries>";
	bodyReq += "      </SubQuery>";
	bodyReq += "    </SubQueries>";
	bodyReq += "  </RootRelationQuery>";
	bodyReq += "</Request>";

	$.post(urlGetMyPurchasedProucts, bodyReq, function(data) {
        try {
            $.each(data.Products.Product, function(i,d){
                $.each(d.ContentsTitles.Title, function(i2, d2) {
                    var img = null;
                    var pics = (VTR.Utils.isset(d2.Pictures) ? d2.Pictures.Picture : null);

                    if (pics){
                        $.each(pics, function(ix,dx) {
                            if(dx.type == 'BoxCover') {
                                img = dx.Value.replace("http://" + VTR.Properties.posterServerName + "/", "http://" + VTR.Properties.posterServer + "/");
                                return false;
                            }
                            else {
                                img = dx.Value.replace("http://" + VTR.Properties.posterServerName + "/", "http://" + VTR.Properties.posterServer + "/");
                            }
                        });
                    }
                    if(output.mypurchasedprod.length < options.size) {
                        if((VTR.UI.screenFormat == "SD")&&(d2.Contents.Content[0].IsHD == true)){
                            console.log("contenido no corresponde: ");
                            return false;
                        }else{
                            output.mypurchasedprod.push({
                                categoryId : 'CATEGORY_ID',
                                subcategoryId : 'SUB_CATEGORY_ID',
                                titleId : d2.id,
                                name : d2.ShortName,
                                is3D : d2.Is3D,
                                isHD : d2.IsHD,
                                pictureUri : img,
                                contentType : d.Type,
                                bookmark: d2.Bookmark
                                //genre: (VTR.Utils.isset(d2.AllGenres) ? d2.AllGenres.AllGenre[0].Value.toUpperCase() : VTR.Properties.notAvailable),
                                //isAdult: d2.IsAdult
                            }); 
                        }
                    }
                });
          });
            callback(output);
        }
        catch(err) {
            console.log('Error AVN API: '+err.message);
        }
    }).fail(function(xhr, errorType, error){
    	console.log('Error AVN API:' + JSON.stringify(xhr) + ' - ' + 'error:' + error);
    }).done(function(data, status, xhr){
    	console.log('data:' + data + ' - ' + 'status:' + status);
	});
}

VTR.Account.getSTBInfo = function(callback, options){
	//var deviceID = VTR.Utils.computeCRC(options.deviceID);
	
	var urlGetSTBInfo =  VTR.Properties.traxisProxy + '/' + VTR.Traxis.urlBodyRequest;
//	urlGetSTBInfo     =  urlGetSTBInfo.replace('{{CPE_ID}}',options.deviceID);
    var bodyReq = "";
    var output = {"cpeInfo":[]};
    bodyReq += "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n";
    bodyReq += "<Request xmlns=\"urn:eventis:traxisweb:1.0\">\n";
    bodyReq += "  <Identity>\n";
    bodyReq += "    <CpeId>"+options.deviceID+"</CpeId>\n";
    bodyReq += "  </Identity>\n";
    bodyReq += "  <RootRelationQuery relationName=\"Cpes\">\n";
    bodyReq += "    <Options>\n";
    bodyReq += "      <Option type=\"Props\">CpeType,CustomerManaged,LinearServiceGroupId,VodServiceGroupId,EncodingProfiles</Option>\n";
    bodyReq += "    </Options>\n";
    bodyReq += "  </RootRelationQuery>\n";
    bodyReq += "</Request>\n";
	$.post(urlGetSTBInfo, bodyReq, function(data) {
        try {
            $.each(data.Cpes.Cpe, function(d){
                if(this.id == options.deviceID){
                    output.cpeInfo.push({
                        cpeId: this.id,
                        cpeType: this.CpeType,
                        customerManaged: this.CustomerManaged,
                        linearServiceGroupId: this.LinearServiceGroupId,
                        vodServiceGroupId: this.VodServiceGroupId,
                        encodingProfile: this.EncodingProfiles.EncodingProfile
                    });
                }
            });		
            callback(output);           
        }
        catch (err) {
            console.log('Error AVN API: '+err.message);
        }
    }).fail(function(xhr, errorType, error){
    	console.log('xhr:' + xhr + ' - ' + 'error:' + error);
    }).done(function(data, status, xhr){
    	console.log('data:' + data + ' - ' + 'status:' + status);
	});
}

VTR.Account.getProfile =  function(callback, options){
	var urlGetProfileInfo = VTR.Properties.traxisProxy + '/' + VTR.Traxis.urlBodyRequest;
//	urlGetProfileInfo = urlGetProfileInfo.replace('{{CUSTOMER_ID}}',options.customerId);
    var bodyReq = "";
    var output = {"profile":[]};

    bodyReq += "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n";
    bodyReq += "<Request xmlns=\"urn:eventis:traxisweb:1.0\">\n";
    bodyReq += "  <Identity>\n";
    bodyReq += "    <CustomerId>"+options.customerId+"</CustomerId>\n";
    bodyReq += "  </Identity>\n";
    bodyReq += "  <RootRelationQuery relationName=\"Profiles\">\n";
    bodyReq += "    <Options>\n";
    bodyReq += "      <Option type=\"Props\">Name,Language,CustomData,Pin</Option>\n";
    bodyReq += "    </Options>\n";
    bodyReq += "  </RootRelationQuery>\n";
    bodyReq += "</Request>\n";
	$.post(urlGetProfileInfo, bodyReq, function(data) {
        try {
            $.each(data.Profiles.Profile, function(d){
                output.profile.push(
                {
                    profileId: this.id,
                    profileName: this.Name,
                    profileLanguage: this.Language,
                    profileDefaultData: this.CustomData,
                    profilePin: this.Pin
                });
            });	
            callback(output);
        }
        catch (err) {
            console.log('Error AVN API: '+err.message);
        }
    }).fail(function(xhr, errorType, error){
    	console.log('xhr:' + xhr + ' - ' + 'error:' + error);
    }).done(function(data, status, xhr){
    	console.log('data:' + data + ' - ' + 'status:' + status);
	});
}


VTR.Account.getCustomer =  function(callback, options){

	var fieldList = 'Aliases,IsBarred,ChannelMapGroupId,IsAdultPinUsed,PersonalizationOptIn,NpvrQuotaRemaining,ExpenditureLimit,ExpenditureRemaining';

	var urlGetCustomerInfo = VTR.Properties.traxisProxy + '/' + VTR.Traxis.urlBodyRequest;
//	urlGetCustomerInfo = urlGetCustomerInfo.replace('{{CPE_ID}}',options.cpeId);
//	urlGetCustomerInfo = urlGetCustomerInfo.replace('{{FIELD_LIST}}',fieldList);
    var bodyReq = "";	
	var output = {"customer":[]};
    bodyReq += "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n";
    bodyReq += "<Request xmlns=\"urn:eventis:traxisweb:1.0\">\n";
    bodyReq += "  <Identity>\n";
    bodyReq += "    <CpeId>"+options.cpeId+"</CpeId>\n";
    bodyReq += "  </Identity>\n";
    bodyReq += "  <RootRelationQuery relationName=\"Customers\">\n";
    bodyReq += "    <Options>\n";
    bodyReq += "      <Option type=\"Props\">"+fieldList+"</Option>\n";
    bodyReq += "    </Options>\n";
    bodyReq += "  </RootRelationQuery>\n";
    bodyReq += "</Request>\n";

	

	$.post(urlGetCustomerInfo, bodyReq, function(data) {
        try {
            $.each(data.Customers.Customer, function(d){
                output.customer.push(
                {
                    customerId: this.Aliases.Alias[0].Value,
                    aliasType: this.Aliases.Alias[0].type,
                    aliasAuthority: this.Aliases.Alias[0].authority,
                    IsBarred: this.IsBarred,
                    ChannelMapGroupId: this.ChannelMapGroupId,
                    IsAdultPinUsed: this.IsAdultPinUsed,
                    PersonalizationOptIn:this.PersonalizationOptIn,
                    NpvrQuotaRemaining: this.NpvrQuotaRemaining,
                    ExpenditureLimit: this.ExpenditureLimit,
                    ExpenditureRemaining: this.ExpenditureRemaining
                });
            });	
            callback(output);
        }
        catch (err) {
            console.log('Error AVN API: '+err.message);
        }
    }).fail(function(xhr, errorType, error){
    	console.log('xhr:' + xhr + ' - ' + 'error:' + error);
    }).done(function(data, status, xhr){
    	console.log('data:' + data + ' - ' + 'status:' + status);
	});
}