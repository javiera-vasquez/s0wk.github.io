/*
	NAME: VTR.Content 
	DESCRIPTION:

	options: {customerId: VTR.Account.customerId,	cpeId: VTR.Account.cpeId, profileId: VTR.Account.profileId,	categoryId: "", titleId: "", isCarrusel: true, position: 1}
*/

VTR.Content = {
	contentDetail:[],
	contentById:[],
	titledetail:[],
	SeasonBySerieId:[],
	EpisodesBySeasonId:[]
}

VTR.Content.getTitleDetail = function(callback, options){
	var fieldList = 'Name,Pictures,LongSynopsis,MediumSynopsis,ShortSynopsis,DurationInSeconds,ProductionDate,DirectorNames,Directors,ActorsCharacters,Actors,SeriesCount,ContentCount,Contents,Bookmark,PreviewCount,OnWishList,AllGenres,MinimumAge,IsAdult,LastViewDate';
	var urlGetTitleDetail = VTR.Properties.traxisProxy + '/' + VTR.Traxis.urlBodyRequest;
	var bodyReq = "";
	bodyReq += "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n";
	bodyReq += "<Request xmlns=\"urn:eventis:traxisweb:1.0\">\n";
	bodyReq += "  <Identity>\n";
	bodyReq += "    <CpeId>"+VTR.Account.cpeId+"</CpeId>\n";
	bodyReq += "  </Identity>\n";
	bodyReq += "  <ResourceQuery resourceType=\"Title\" resourceId=\"" + VTR.Utils.replaceAll(options.titleId, "/", "~~2F" ) + "\">\n";
	bodyReq += "    <Options>\n";
	bodyReq += "      <Option type=\"Props\">"+fieldList+"</Option>\n";
	bodyReq += "    </Options>\n";
	bodyReq += "    <SubQueries>\n";
	bodyReq += "      <SubQuery relationName=\"Contents\">\n";
	bodyReq += "        <Options>\n";
	bodyReq += "          <Option type=\"props\">IsHD,Is3D,ProductCount,PlayInfos,LastAvailability,Aliases,OriginalLanguages,CaptionLanguages,FirstAvailability,LastAvailability</Option>\n";
	bodyReq += "          <Option type=\"filter\">ProductCount&gt;0&amp;&amp;FirstAvailability&lt;=now()&amp;&amp;LastAvailability&gt;=now()</Option>\n";
	bodyReq += "        </Options>\n";
	bodyReq += "        <SubQueries>\n";
	bodyReq += "          <SubQuery relationName=\"Products\">\n";
	bodyReq += "            <Options>\n";
	bodyReq += "              <Option type=\"props\">Type,ListPrice,RentalPeriodInMinutes,EntitlementState,Currency,EntitlementEnd,Name,ShortSynopsis,AvailabilityStart,AvailabilityEnd</Option>\n";
	bodyReq += "              <Option type=\"filter\">(!isnull(EntitlementState)||EntitlementState==Entitled)&amp;&amp;AvailabilityStart&lt;=now()&amp;&amp;AvailabilityEnd&gt;=now()</Option>\n";
//	bodyReq += "              <Option type=\"sort\">Type</Option>\n";
	bodyReq += "            </Options>\n";
	bodyReq += "          </SubQuery>\n";
	bodyReq += "        </SubQueries>\n";
	bodyReq += "      </SubQuery>\n";
	bodyReq += "      <SubQuery relationName=\"Previews\">\n";
	bodyReq += "	    <SubQueries>\n";
	bodyReq += "	      <SubQuery relationName=\"Contents\">\n";
	bodyReq += "	        <Options>\n";
	bodyReq += "    	      <Option type=\"props\">Aliases</Option>\n";
	bodyReq += "        	</Options>\n";
	bodyReq += "	      </SubQuery>\n";
	bodyReq += "	   	</SubQueries>\n";
	bodyReq += "	  </SubQuery>\n";
	bodyReq += "    </SubQueries>\n";
	bodyReq += "  </ResourceQuery>\n";
	bodyReq += "</Request>\n";
        
	sessionStorage.setItem("titleId", options.titleId);
	sessionStorage.setItem("categoryName", options.categoryName);
    var output = {"titledetail":[], "contents":[], "pricesformats":[], IsOnWishlist: 'isOnWishlist', Bookmark: 'bookmark', EntitlementState:'entitlementState', LastViewDate:'lastViewDate',}

	$.post(urlGetTitleDetail, bodyReq, function(data2){
		eval("VTR.Content.titledetail = " + JSON.stringify(data2));
        try {
			var names = "";
			var genres = "";
			var img = null;
			var synopsis = "";
			var shortSynopsis = "";
			var languages = "";
			var subtitles = "";
			var directors = "";
			var actors = "";
			var rating = "";
			var trailerURI = "";
			var playerURI = "";
			var elapsedTime = ""
			var isSeries = false;
			var lastAvailability = "";
			var duration = "";
			var year = "";
			var bookmark = "";
			var assetIdTrailer = "";
                        var isAdult = "";
			var entitlementState = "";
                        names = (VTR.Utils.isset(data2.Title.Name) ? data2.Title.Name : "");
			if (VTR.Utils.isset(data2.Title.AllGenres)){
				$.each(data2.Title.AllGenres.AllGenre, function(i, item) {
					genres += item.Value.toUpperCase();
					if(i != data2.Title.AllGenres.AllGenre.length - 1){
						genres += ", ";
					}
				});
			}
            else {
                genres = VTR.Properties.notAvailable;
            }
			var pic = (VTR.Utils.isset(data2.Title.Pictures) ? data2.Title.Pictures.Picture : "");
			if (pic.length > 0){
                $.each(pic, function(ix,dx) {
                    if(dx.type == 'BoxCover') {
                        img = dx.Value.replace("http://" + VTR.Properties.posterServerName + "/", "http://" + VTR.Properties.posterServer + "/");
                        return false;
                   }
                    else {
				        img = dx.Value.replace("http://" + VTR.Properties.posterServerName + "/", "http://" + VTR.Properties.posterServer + "/");
                    }
                });
			}
			if (VTR.Utils.isset(data2.Title.LongSynopsis)){
				synopsis = data2.Title.LongSynopsis;
			}
			else if (VTR.Utils.isset(data2.Title.MediumSynopsis)) {
				synopsis = data2.Title.MediumSynopsis;
			}
			else if(VTR.Utils.isset(data2.Title.ShortSynopsis)) {
				synopsis = data2.Title.ShortSynopsis;
			}
			//console.log(data2.Title);
			duration = (VTR.Utils.isset(data2.Title.DurationInSeconds) ? data2.Title.DurationInSeconds : "");
			rating = (VTR.Utils.isset(data2.Title.MinimumAge) ? VTR.Utils.convertMinimumAgeToParentalRating(data2.Title.MinimumAge.type) : "");
			year = (VTR.Utils.isset(data2.Title.ProductionDate) ? data2.Title.ProductionDate : VTR.Properties.notAvailable);
			if (VTR.Utils.isset(data2.Title.DirectorNames)) {
				$.each(data2.Title.DirectorNames.DirectorName, function(i, item){
					directors += (VTR.Utils.isset(item.givenName) ? $.trim(item.givenName) : "") + (VTR.Utils.isset(item.familyName) ? " "+$.trim(item.familyName) : "");
					if (i != data2.Title.DirectorNames.DirectorName.length - 1){
						directors += ", ";
					}
				});
			}
			else {
				directors = VTR.Properties.notAvailable;
			}
			if (VTR.Utils.isset(data2.Title.ActorsCharacters)) {
				$.each(data2.Title.ActorsCharacters.Actor, function(i, item) {
					actors += (VTR.Utils.isset(item.givenName) ? $.trim(item.givenName) : "") + (VTR.Utils.isset(item.familyName) ? " "+$.trim(item.familyName) : "");
					if (i != data2.Title.ActorsCharacters.Actor.length - 1){
						actors += ", ";
					}
				});
			}
			else {
				actors = VTR.Properties.notAvailable;
			}
			if (VTR.Utils.isset(data2.Title.SeriesCount)){
				if (data2.Title.SeriesCount > 0){
					isSeries = true;
				}
			}
			bookmark = (VTR.Utils.isset(data2.Title.Bookmark) ? data2.Title.Bookmark : ""); 
//			entitlementState = (VTR.Utils.isset(data2.Title.Contents.Content[0].Products.Product[0].EntitlementState) ? data2.Title.Contents.Content[0].Products.Product[0].EntitlementState : "");
			if(VTR.Utils.isset(data2.Title.Previews)) {
				assetIdTrailer = data2.Title.Previews.Title[0].Contents.Content[0].Aliases.Alias[0].Value;
			}
                        isAdult = (VTR.Utils.isset(data2.Title.IsAdult) ? data2.Title.IsAdult : false); 
			/*
			if (VTR.Utils.isset(data2.Title.ContentCount)){
				if (data2.Title.ContentCount > 0){
					var contentId = data2.Title.Contents.Content[0].id;
					urlGetContentById = urlGetContentById.replace('{{CONTENT_ID}}', VTR.Utils.replaceAll(contentId, "/", "~~2F"));
					
					$.getJSON(urlGetContentById, function(data2.Title){
						eval("VTR.Content.contentById = " + JSON.stringify(data2.Title));
						lastAvailability = (VTR.Utils.isset(VTR.Content.contentById.Content.LastAvailability) ? VTR.Content.contentById.Content.LastAvailability : "");
					});
				}
			}*/
			output.IsOnWishlist = (VTR.Utils.isset(data2.Title.OnWishList) ? data2.Title.OnWishList : "");
			output.Bookmark = (VTR.Utils.isset(data2.Title.Bookmark) ? data2.Title.Bookmark : "0");
                        output.LastViewDate = (VTR.Utils.isset(data2.Title.LastViewDate) ? data2.Title.LastViewDate : "0");
			output.titledetail.push({
				"categoryId": options.categoryId, //"CATEGORY_ID",
				"categoryName" : options.categoryName, //"CATEGORY_NAME",
				"name" : names,
				"genre" : genres,
				"poster" : img,
				"synopsis" : synopsis,
				"shortSynopsis" : shortSynopsis,
				"duration" : duration,
				"year" : year,
				"director": directors,
				"actors": actors,
				"rating": rating,
				"trailerURI": trailerURI,
				"playerURI": playerURI,
				"elapsedTime": elapsedTime,
				"isSeries": isSeries,
				"lastAvailability": lastAvailability,
				"bookmark": bookmark,
                                "isAdult": isAdult,
				"entitlementState":entitlementState
			});
			if (VTR.Utils.isset(data2.Title.Contents)) {
                $.each(data2.Title.Contents.Content, function(i3, d3) {
                    var assetId = "";
                    $.each(d3.Aliases.Alias, function(i, alias) {
                        if(alias.type == "VodBackOfficeId") {
                            assetId = alias.Value;
                            languages = "";
                            if (VTR.Utils.isset(d3.OriginalLanguages)) {
                                $.each(d3.OriginalLanguages.OriginalLanguage, function(i, item) {
                                    languages += VTR.Utils.convertLangCodeToLangName(item);
                                    if (i != d3.OriginalLanguages.OriginalLanguage.length - 1){
                                        languages += ", ";
                                    }
                                });
                            }
                            else {
                                languages = VTR.Properties.notAvailable;
                            }
                            subtitles = "";
                            if (VTR.Utils.isset(d3.CaptionLanguages)) {
                                $.each(d3.CaptionLanguages.CaptionLanguage, function(i, item) {
                                    subtitles += VTR.Utils.convertLangCodeToLangName(item);
                                    if (i != d3.CaptionLanguages.CaptionLanguage.length - 1){
                                        subtitles += ", ";
                                    }
                                });
                            }
                            else {
                                subtitles = VTR.Properties.notAvailable;
                            }
                            if(VTR.Utils.isset(d3.Products)) {
                                $.each(d3.Products.Product, function(i4, d4) {
                                    output.pricesformats.push({
                                        "isHD": d3.IsHD,
                                        "is3D": d3.Is3D,
                                        "LastAvailability": d3.LastAvailability,
                                        "Type": d4.Type,
                                        "Currency": d4.Currency,
                                        "ListPrice": d4.ListPrice,
                                        "RentalPeriod": d4.RentalPeriodInMinutes,
                                        //"PlayerURI": playerURI + assetId + "?STBId=" + VTR.Account.cpeId,
                                        "assetId": assetId,
                                        "trailerAssetId": assetIdTrailer,
                                        //"IsOnWishlist": isOnWishlist,
                                        "EntitlementState": d4.EntitlementState,
                                        "titleId": data2.Title.id,
                                        "productId": d4.id,
                                        //"bookmark": bookmark,
                                        "EntitlementEnd": d4.EntitlementEnd,
                                        "previewCount": data2.Title.PreviewCount,
                                        "languages": languages,
                                        "subtitles": subtitles,
                                        "Name": d4.ShortSynopsis
                                    });
                                    if(i4 == 0) { // TODO mejorar inclusion de multi-producto, por ahora solo uno
                                        return false;
                                    }
                                });
                            }
                            return false;
                        }
                    });
                    if(VTR.Utils.isset(assetId)) { // TODO mejorar el despliegue de multi-asset SD-HD-3D-4K, por ahora solo uno
                        return false;
                    }
                });
			}
            callback(output);
    	}
        catch (err) {
            console.log('Error AVN API: '+err.message);
        }
    }).fail(function(xhr, errorType, error){
    	console.log('xhr:' + JSON.stringify(xhr.response) + ' - ' + 'error:' + error);
    }).done(function(data, status, xhr){
    	console.log('data:' + data + ' - ' + 'status:' + status);
	});
}


/*VTR.Content.getTitleOptions = function(callback, options){
	var fieldList = 'Name,ContentCount,Contents,Previews,OnWishList,Bookmark';
	var urlListContentByTitle = VTR.Properties.traxisProxy + '/' + VTR.Traxis.urlTitleDetail + '&ProfileId=' + VTR.Account.profileId;
	urlListContentByTitle = urlListContentByTitle.replace('{{TITLE_ID}}', options.titleId);
	urlListContentByTitle = urlListContentByTitle.replace('{{FIELD_LIST}}', fieldList);
	urlListContentByTitle = urlListContentByTitle.replace('{{CPE_ID}}', VTR.Account.cpeId);

	$.getJSON(urlListContentByTitle, function(d){
		var contentCount = "";
		contentCount = (VTR.Utils.isset(d.Title.ContentCount) ? d.Title.ContentCount : "0");
		var previewTitleId = "";
		previewTitleId = (VTR.Utils.isset(d.Title.Previews) ? d.Title.Previews.Title[0].id : "");
		var isOnWishlist = "";
		isOnWishlist = (VTR.Utils.isset(d.Title.OnWishList) ? d.Title.OnWishList : "");
		var bookmark = "";
		bookmark = (VTR.Utils.isset(d.Title.Bookmark) ? d.Title.Bookmark : "0");

		var output = {IsOnWishlist: isOnWishlist, Bookmark: bookmark,"pricesformats":[]}
		if (contentCount > 0) {
			$.each(d.Title.Contents.Content, function(i3, data3) {
				var contentFieldList = 'IsHD,Is3D,ProductCount,PlayInfos,LastAvailability,Aliases';
				var urlGetContentById = VTR.Properties.traxisProxy + '/' + VTR.Traxis.urlContentById;
				urlGetContentById = urlGetContentById.replace("{{CONTENT_ID}}", data3.id);
				urlGetContentById = urlGetContentById.replace('{{FIELD_LIST}}', contentFieldList);
				urlGetContentById = urlGetContentById.replace('{{CPE_ID}}', VTR.Account.cpeId);

				$.getJSON(urlGetContentById, function(data) {
					var productCount = "";
					var isHD = "";
					var is3D = "";
					var Type = "";
					//var playerURI = "";
					var trailerURI = "";
					productCount = (VTR.Utils.isset(data.Content.ProductCount) ? data.Content.ProductCount : "0");
					isHD = (VTR.Utils.isset(data.Content.IsHD) ? data.Content.IsHD : "");
					is3D = (VTR.Utils.isset(data.Content.Is3D) ? data.Content.Is3D : "");
					lastAvailability = (VTR.Utils.isset(data.Content.LastAvailability) ? data.Content.LastAvailability : "");
					var assetId = "";
					$.each(data.Content.Aliases.Alias, function(i, alias) {
						if(alias.type == "VodBackOfficeId") {
							assetId = alias.Value;
						}
					})
					if (productCount > 0) {
						//$.each(data.Content.Products.Product, function(i, dd) {
							var productFieldList = 'Type,ListPrice,RentalPeriodInMinutes,EntitlementState,Currency,EntitlementEnd';
							//var filterList = 'EntitlementState==Entitled';
							var urlGetProductById = VTR.Properties.traxisProxy + '/' + VTR.Traxis.urlProductByContent;
							urlGetProductById = urlGetProductById.replace("{{CONTENT_ID}}", data.Content.id);
							urlGetProductById = urlGetProductById.replace("{{PROFILE_ID}}", VTR.Account.profileId);
							urlGetProductById = urlGetProductById.replace("{{FIELD_LIST}}", productFieldList);
							urlGetProductById = urlGetProductById.replace("{{CPE_ID}}", VTR.Account.cpeId);
							$.getJSON(urlGetProductById, function(ddd){
								output.pricesformats.push({
									"isHD": isHD,
									"is3D": is3D,
									"LastAvailability": lastAvailability,
									"Type": ddd.Products.Product[0].Type,
									"Currency": ddd.Products.Product[0].Currency,
									"ListPrice": ddd.Products.Product[0].ListPrice,
									"RentalPeriod": ddd.Products.Product[0].RentalPeriodInMinutes,
									//"PlayerURI": playerURI + assetId + "?STBId=" + VTR.Account.cpeId,
									"assetId": assetId,
									"TrailerURI": trailerURI,
									//"IsOnWishlist": isOnWishlist,
									"EntitlementState": ddd.Products.Product[0].EntitlementState,
									"titleId": d.Title.id,
									"productId": ddd.Products.Product[0].id,
									//"bookmark": bookmark,
									"EntitlementEnd": ddd.Products.Product[0].EntitlementEnd
								});
								callback(output);
							});
						//});
					}
				});

			});
		}
		else {
			callback(output);
		}
    }).fail(function(xhr, errorType, error){
    	console.log('xhr:' + JSON.stringify(xhr.response) + ' - ' + 'error:' + error);
    }).done(function(data, status, xhr){
    	console.log('data:' + data + ' - ' + 'status:' + status);
	});
}*/

VTR.Content.setWishList = function(callback, options) {
	var urlWishList = 'http://'+VTR.Properties.traxisServer + '/' + VTR.Traxis.urlSetWishList; 
	urlWishList = urlWishList.replace('{{TITLE_ID}}', VTR.Utils.replaceAll(options.titleId, "/", "~~2F"));
	urlWishList = urlWishList.replace('{{PROFILE_ID}}', VTR.Utils.replaceAll(VTR.Account.profileId, "/", "~~2F"));
	
	$.ajax({
		type: 'PUT',
		url: urlWishList,
		//data: ,
		dataType: 'json',
		success: callback,
		error: function(xhr, errorType, error){
			console.log('Error setWishList:' + error + ':' + xhr.responseText);
		}
	});
}

VTR.Content.deleteWishList = function(callback, options) {
	var urlWishList = 'http://'+VTR.Properties.traxisServer + '/' + VTR.Traxis.urlSetWishList; 
	urlWishList = urlWishList.replace('{{TITLE_ID}}', VTR.Utils.replaceAll(options.titleId, "/", "~~2F"));
	urlWishList = urlWishList.replace('{{PROFILE_ID}}', VTR.Utils.replaceAll(VTR.Account.profileId, "/", "~~2F"));
	
	$.ajax({
		type: 'DELETE',
		url: urlWishList,
		//data: ,
		dataType: 'json',
		success: callback,
		error: function(xhr, errorType, error){
			console.log('Error deleteWishList:' + error + ':' + xhr.responseText);
		}
	});
}

VTR.Content.getListPriceByFormat = function(callback, options) {
	var output = {"priceList":[]};

	$.each(options.content, function(i, id){
		var urlGetFormatProp = "http://"+VTR.Properties.traxisServer + '/' + VTR.Traxis.urlIsHD3D;
			urlGetFormatProp = urlGetFormatProp.replace('{{CONTENT_ID}}', VTR.Utils.replaceAll(options.content[i].id, "/", "~~2F" ));
		var urlListPriceByFormat = 'http://'+VTR.Properties.traxisServer + '/' + VTR.Traxis.urlGetListPrice; 
			urlListPriceByFormat = urlListPriceByFormat.replace('{{CONTENT_ID}}', VTR.Utils.replaceAll(options.content[i].id, "/", "~~2F" ));
			
		$.getJSON(urlGetFormatProp, function(d){
			var formatHD = false;
			var format3D = false;
			var formatSD = false;
			var idContent   =""; 
			var typeProduct ="";
			var currency    ="";
			var listPrice   ="";

			format3D = d.Content.Is3D;
			formatHD = d.Content.IsHD;

			if (format3D == false && formatHD == false){
				formatSD = true;
			};

			$.getJSON(urlListPriceByFormat, function(data){
				idContent   =  VTR.Utils.replaceAll(options.content[i].id, "/", "~~2F" );
				typeProduct = data.Products.Product[i].Type;
				currency    = data.Products.Product[i].Currency;
				listPrice   = data.Products.Product[i].ListPrice;
			});

			output.priceList.push({
				"contentId"   :  idContent,
				"HD"          :  formatHD,
				"3D"          :  format3D,
				"SD"          :  formatSD, 
				"type"        :  typeProduct,
				"currency"    :  currency,
				"price"       :  listPrice
			});
		});
	});
	callback(output);
}

VTR.Content.getElapsedRemainingTime = function(callback, options) {
	var urlGetElapRemaTime = "http://"+VTR.Properties.traxisServer + '/' + VTR.Traxis.urlElapsedRemaining;
	urlGetElapRemaTime = urlGetElapRemaTime.replace('{{TITLE_ID}}', VTR.Utils.replaceAll(options.titleId, "/", "~~2F" ));
	urlGetElapRemaTime = urlGetElapRemaTime.replace('{{PROFILE_ID}}', VTR.Utils.replaceAll(VTR.Account.profileId, "/", "~~2F" ));
	var output = {"elapsedRemaining":[]};
		
	$.getJSON(urlGetElapRemaTime, function(d){
		var bookmark  = d.Title.Bookmark;
		var duration  = d.Title.DurationInSeconds;
		var remaining = 0;
		remaining = parseInt(duration) - parseInt(bookmark);

		output.elapsedRemaining.push({
			"titleId" : options.titleId,
			"elapsedTime" : bookmark,
			"remainingTime" : remaining
		});
		callback(output);
    }).fail(function(xhr, errorType, error){
    	console.log('xhr:' + xhr + ' - ' + 'error:' + error);
    }).done(function(data, status, xhr){
    	console.log('data:' + data + ' - ' + 'status:' + status);
	});
}

VTR.Content.getProductCategoryAndContent = function(callback, options) {
	var urlGetProductInfo = "http://"+VTR.Properties.traxisServer + '/' + VTR.Traxis.urlGetProductCatCont;
	urlGetProductInfo = urlGetProductInfo.replace('{{PRODUCT_ID}}', VTR.Utils.replaceAll(options.productId, "/", "~~2F" ));
	var output = {"productInfo":[]};

	$.getJSON(urlGetProductInfo, function(data){
		output.productInfo.push({
			"categoryId" : data.Product.Categories.Category[0].id,
			"contentId"  : data.Product.Contents.Content[0].id
		});

		if(data.Product.Categories.Category[0].id != null && data.Product.Categories.Category[0].id != "" && data.Product.Categories.Category[0].id != "undefined"){
			sessionStorage.setItem('categoryId', data.Product.Categories.Category[0].id);	
		} else {
			sessionStorage.setItem('categoryId', VTR.Properties.notAvailable);
		}
		
		if(data.Product.Contents.Content[0].id != null && data.Product.Contents.Content[0].id != "" && data.Product.Contents.Content[0].id != "undefined"){
			sessionStorage.setItem('contentId',data.Product.Contents.Content[0].id);
		} else {
			sessionStorage.setItem('contentId', VTR.Properties.notAvailable);
		}
		
		callback(output);
    });
}
