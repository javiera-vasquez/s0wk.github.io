/*
	NAME: VTR.Catalog
	DESCRIPTION:

	options: {customerId: VTR.Account.customerId,	cpeId: VTR.Account.cpeId, profileId: VTR.Account.profileId,	categoryId: "", titleId: "", isCarrusel: true, position: 1}
*/

VTR.Catalog = {
	parentCategories:[],
	filteredCategories:[],
	childCategories:[],
	contentCategories:[],
	contentByCategory:[]
}

VTR.Catalog.getListMenu0 = function(callback, options){
	var urlGetParentCategories  = VTR.Properties.traxisProxy + '/' + VTR.Traxis.urlRootCategory;
	var output = {"listmenu":[]};
//console.log('list menu:'+urlGetParentCategories);
    $.getJSON(urlGetParentCategories, function(data, status, xhr){
		//console.log('error en listmenu:'+JSON.stringify(xhr));
		eval("VTR.Catalog.parentCategories = " + JSON.stringify(data));
        $.each(VTR.Catalog.parentCategories, function(){
        	urlGetFilteredCategories = VTR.Properties.traxisProxy + '/' + VTR.Traxis.urlFilteredCategories;
        	urlGetFilteredCategories = urlGetFilteredCategories.replace('{{CATEGORY_ID}}', VTR.Utils.replaceAll(this.Category[0].id, "/", "~~2F" ));
        	urlGetFilteredCategories = urlGetFilteredCategories.replace('{{FILTER_NAME}}', VTR.Properties.defaultRootCategory);

			$.getJSON(urlGetFilteredCategories, function(data2){
				eval("VTR.Catalog.filteredCategories = " + JSON.stringify(data2));
				$.each(VTR.Catalog.filteredCategories.Categories.Category, function(){
		        	urlGetChildCategories = VTR.Properties.traxisProxy + '/' + VTR.Traxis.urlChildCategories;
		        	/*if(options.categoryId == null || options.categoryId == "") {
		        	//urlGetChildCategories = urlGetChildCategories.replace('{{CATEGORY_ID}}', VTR.Utils.replaceAll(this.id, "/", "~~2F" ));
					}
					else {
			        	urlGetChildCategories = urlGetChildCategories.replace('{{CATEGORY_ID}}', replaceAll(options.categoryId, "/", "~~2F" ));
		        	}*/
		        	urlGetChildCategories = urlGetChildCategories.replace('{{CATEGORY_ID}}', VTR.Utils.replaceAll(this.id, "/", "~~2F" )); 
		        	//urlGetChildCategories = urlGetChildCategories.replace('{{CATEGORY_ID}}', VTR.Utils.replaceAll("crid:~~2F~~2Fschange.com~~2Ff165084e-db75-43be-b8c1-96de20939bd1", "/", "~~2F" ));
		        	//urlGetChildCategories = urlGetChildCategories.replace('{{CATEGORY_ID}}', VTR.Utils.replaceAll("crid:~~2F~~2Fschange.com~~2F332b7e80-505f-46e1-bfd1-55d7b56b45f4", "/", "~~2F" ));
		        	$.getJSON(urlGetChildCategories , function(data3){
						eval("VTR.Catalog.childCategories = " + JSON.stringify(data3));
						$.each(VTR.Catalog.childCategories.Categories.Category, function(){
							output.listmenu.push({
								'id': this.id,
								'name': this.Name.toUpperCase(),
								'childCategories': this.ChildCategoryCount,
								'isAdult': this.IsAdult
							});					
						});
						callback(output);
		        	});
				});
			});
    	});
    }).fail(function(xhr, errorType, error){
    	console.log('xhr:' + xhr + ' - ' + 'error:' + error);
    }).done(function(data, status, xhr){
    	console.log('data:' + data + ' - ' + 'status:' + status);
    });
}

VTR.Catalog.getListMenu = function(callback, options){
	var urlGetParentCategories  = VTR.Properties.traxisProxy + '/' + VTR.Traxis.urlBodyRequest;
	var output = {"listmenu":[]};
	var bodyReq = "";
	bodyReq += "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
	bodyReq += "<Request xmlns=\"urn:eventis:traxisweb:1.0\">";
	bodyReq += "  <RootRelationQuery relationName=\"RootCategories\">";
	bodyReq += "    <Options>";
	bodyReq += "      <Option type=\"Limit\">100</Option>";
	bodyReq += "    </Options>";
	bodyReq += "    <SubQueries>";
	bodyReq += "      <SubQuery relationName=\"ChildCategories\">";
	bodyReq += "        <Options>";
	bodyReq += "		  <Option type=\"filter\">Name^AVN</Option>";
	bodyReq += "        </Options>";
	bodyReq += "        <SubQueries>";
	bodyReq += "          <SubQuery relationName=\"ChildCategories\">";
	bodyReq += "            <Options>";
	bodyReq += "      	 	  <Option type=\"Props\">Name,TitleCount,IsAdult</Option>";
	bodyReq += "      	 	  <Option type=\"Sort\">Ordinal</Option>";
	bodyReq += "      	 	  <Option type=\"Filter\">Name!=Nigel</Option>";
	bodyReq += "            </Options>";
	bodyReq += "          </SubQuery>";
	bodyReq += "        </SubQueries>";
	bodyReq += "      </SubQuery>";
	bodyReq += "    </SubQueries>";
	bodyReq += "  </RootRelationQuery>";
	bodyReq += "</Request>";
    $.post(urlGetParentCategories, bodyReq, function(data, status, xhr){
		eval("VTR.Catalog.parentCategories = " + JSON.stringify(data));
        $.each(VTR.Catalog.parentCategories, function(i1, d1){
			$.each(d1.Category, function(i2, d2){
				$.each(d2.ChildCategories.Category, function(i3, d3){
					$.each(d3.ChildCategories.Category, function(i4, d4) {
						output.listmenu.push({
							'id': d4.id,
							'name': d4.Name.toUpperCase(),
							'childCategories': d4.ChildCategoryCount,
							'isAdult': d4.IsAdult
						});					
					});
				});
			});
    	});
		callback(output);
    }).fail(function(xhr, errorType, error){
    	console.log('xhr:' + JSON.stringify(xhr.response) + ' - ' + 'error:' + error);
    }).done(function(data, status, xhr){
    	console.log('data:' + data + ' - ' + 'status:' + status);
    });
}

VTR.Catalog.getListCategories0 = function(callback, options){
	var urlGetChildCategories = VTR.Properties.traxisProxy + '/' + VTR.Traxis.urlChildCategories;
    urlGetChildCategories = urlGetChildCategories.replace('{{CATEGORY_ID}}', VTR.Utils.replaceAll(options.categoryId, "/", "~~2F" ));
	var output = {"listcategories":[]};

	$.getJSON(urlGetChildCategories , function(data){
		eval("VTR.Catalog.childCategories = " + JSON.stringify(data));
        $.each(VTR.Catalog.childCategories.Categories.Category, function(i, d){
			output.listcategories.push({
				'id': d.id,
				'name': d.Name.toUpperCase(),
				'titlesCount': d.TitleCount,
				'childCategoryCount': d.ChildCategoryCount,
				'isAdult': d.IsAdult
			});					
		});
		callback(output);
    }).fail(function(xhr, errorType, error){
    	console.log('xhr:' + xhr + ' - ' + 'error:' + error);
    }).done(function(data, status, xhr){
    	console.log('data:' + data + ' - ' + 'status:' + status);
	});
}

VTR.Catalog.getListCategories = function(callback, options){
	var urlGetChildCategories = VTR.Properties.traxisProxy + '/' + VTR.Traxis.urlBodyRequest;
    //urlGetChildCategories = urlGetChildCategories.replace('{{CATEGORY_ID}}', VTR.Utils.replaceAll(options.categoryId, "/", "~~2F" ));
	var output = {"listcategories":[]};

	var bodyReq = "";
	bodyReq += "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
	bodyReq += "<Request xmlns=\"urn:eventis:traxisweb:1.0\">";
	bodyReq += "  <Identity>";
	bodyReq += "    <CpeId>"+VTR.Account.cpeId+"</CpeId>";
	bodyReq += "  </Identity>";
	bodyReq += "  <RelationQuery resourceType=\"Category\" resourceId=\"" + options.categoryId + "\" relationName=\"ChildCategories\">";
	bodyReq += "    <Options>";
	bodyReq += "      <Option type=\"Limit\">100</Option>";
	bodyReq += "      <Option type=\"Props\">Name,TitleCount,IsAdult</Option>";
	//bodyReq += "	  <Option type=\"filter\">IsPreview==false&amp;&amp;IsViewableOnCpe==true</Option>";
	bodyReq += "	  <Option type=\"Sort\">Name</Option>";
	bodyReq += "    </Options>";
	bodyReq += "  </RelationQuery>";
	bodyReq += "</Request>";
	$.post(urlGetChildCategories, bodyReq, function(data){
		eval("VTR.Catalog.childCategories = " + JSON.stringify(data));
        $.each(VTR.Catalog.childCategories.Categories.Category, function(i, d){
			output.listcategories.push({
				'id': d.id,
				'name': d.Name.toUpperCase(),
				'titlesCount': d.TitleCount,
				'childCategoryCount': d.ChildCategoryCount,
				'isAdult': d.IsAdult
			});					
		});
		callback(output);
    }).fail(function(xhr, errorType, error){
    	console.log('xhr:' + xhr + ' - ' + 'error:' + error);
    }).done(function(data, status, xhr){
    	console.log('data:' + data + ' - ' + 'status:' + status);
	});
}

VTR.Catalog.getListContentByCategory = function(callback, options){
	var fieldList = 'Name,Categories,Pictures';
	var urlContentByCategory = VTR.Properties.traxisProxy + '/' + VTR.Traxis.urlContentByCategory;
	urlContentByCategory = urlContentByCategory.replace('{{CATEGORY_ID}}', VTR.Utils.replaceAll(options.categoryId, "/", "~~2F" ));
	urlContentByCategory = urlContentByCategory.replace('{{FIELD_LIST}}', fieldList);
	urlContentByCategory = (options.isCarrusel) ? urlContentByCategory.replace('{{PAGE_SIZE}}', VTR.Properties.carruselSize) : urlContentByCategory.replace('{{PAGE_SIZE}}', VTR.Properties.lienzoSize);
	var output = {"listcontent":[]};

	$.getJSON(urlContentByCategory, function(data){
		eval("VTR.Catalog.contentCategories = " + JSON.stringify(data));
		$.each(VTR.Catalog.contentCategories.Titles.Title, function(){
			output.listcontent.push({
				'id': this.id,
				'shortName': this.ShortName.toUpperCase(),
				'pictures': this.Pictures
			});					
		});
		callback(output);
	});
}

VTR.Catalog.getContentTypeByTitle = function(callback, options){
	var contentFieldList = 'IsHD,Is3D,ProductCount,PlayInfos,LastAvailability,Products';
	var urlGetContentById = VTR.Properties.traxisProxy + '/' + VTR.Traxis.urlContentsByTitle;
	urlGetContentById = urlGetContentById.replace("{{TITLE_ID}}", options.titleId);
	urlGetContentById = urlGetContentById.replace('{{FIELD_LIST}}', contentFieldList);
	var output = {"listcontents":[]};
	$.getJSON(urlGetContentById, function(dd) {
		$.each(dd.Contents.Content, function(ix, ddd){
			//console.log(ddd);
			var productFieldList = 'Type,EntitlementState';
			var urlGetProductById = VTR.Properties.traxisProxy + '/' + VTR.Traxis.urlProductById;
			urlGetProductById = urlGetProductById.replace("{{PRODUCT_ID}}", ddd.Products.Product[0].id);
			urlGetProductById = urlGetProductById.replace("{{PROFILE_ID}}", VTR.Account.profileId);
			urlGetProductById = urlGetProductById.replace("{{FIELD_LIST}}", productFieldList);
			$.getJSON(urlGetProductById, function(dddd) {
				//console.log(i);
				output.listcontents.push({
					is3D : ddd.Is3D,
					isHD : ddd.IsHD,
					contentType : dddd.Product.Type
				});
				//if(i == (VTR.Catalog.contentCategories.Titles.Title.length - 1)) {
					callback(output);
				//}
			});
		});
	});
}


VTR.Catalog.getListTitlesByCategory0 = function(callback, options){
	var fieldList = 'Name,Categories,Pictures,ShortName,Contents,ContentCount,SeriesCount';
	var urlContentByCategory = VTR.Properties.traxisProxy + '/' + VTR.Traxis.urlTitleByCategory;
	urlContentByCategory = urlContentByCategory.replace('{{CATEGORY_ID}}', VTR.Utils.replaceAll(options.categoryId, "/", "~~2F" ));
	urlContentByCategory = urlContentByCategory.replace('{{FIELD_LIST}}', fieldList);
	urlContentByCategory = (options.isCarrusel) ? urlContentByCategory.replace('{{PAGE_SIZE}}', VTR.Properties.carruselSize) : urlContentByCategory.replace('{{PAGE_SIZE}}', VTR.Properties.lienzoSize);

	var output = {categoryId: options.categoryId ,"categoryName": options.categoryName, "titlesCount": options.titlesCount, position: 'options.position', "listtitles":[]};
	$.getJSON(urlContentByCategory, function(data){
		eval("VTR.Catalog.contentCategories = " + JSON.stringify(data));
		var urlGetCategoryName = VTR.Properties.traxisProxy + '/' + VTR.Traxis.urlCategoryName;
		urlGetCategoryName = urlGetCategoryName.replace('{{CATEGORY_ID}}', VTR.Utils.replaceAll(options.categoryId, "/", "~~2F" ));
		var categoryName = "";
		var categoryId = "";
		var titlesCount = "";

		//$.getJSON(urlGetCategoryName, function(d) {
			//categoryName = d.Category.Name;
			//categoryId = d.Category.id;
			//titlesCount = d.Category.TitleCount;
			$.each(VTR.Catalog.contentCategories.Titles.Title, function(i, d){
				var isSeries = false;
				var img = "";
				var pics = this.Pictures;
				if (pics){
				  img =  pics.Picture[0].Value.replace("http://" + VTR.Properties.posterServerName + "/", "http://" + VTR.Properties.posterServer + "/");
				}
				if (VTR.Utils.isset(this.SeriesCount)){
					if (this.SeriesCount > 0){
						isSeries = true;
					}
				}				
				output.listtitles.push({
					categoryId : 'CATEGORY_ID',
					subcategoryId : 'SUB_CATEGORY_ID',
					titleId : d.id,
					name : (VTR.UI.screenFormat == "HD" ? d.ShortName.substring(0, 18) : d.ShortName.substring(0, VTR.Properties.titleMaxSize)),
					is3D : false, //d.Content.Is3D,
					isHD : false, //d.Content.IsHD,
					pictureUri : img,
					isSeries: isSeries,
					contentType : 'CONTENT_TYPE',
					contentId: d.Contents.Content[0].id
					//position: options.position
				});
			});
			//callback(output);
		//});
	}).then(function() {
		$.each(output.listtitles, function(i, d) {
			var fieldList = 'Aliases,IsHD,Is3D';
			var urlGetContentByTitle = VTR.Properties.traxisProxy + '/' + VTR.Traxis.urlContentById;
			urlGetContentByTitle = urlGetContentByTitle.replace('{{FIELD_LIST}}', fieldList);
			urlGetContentByTitle = urlGetContentByTitle.replace('{{CONTENT_ID}}', d.contentId);
			urlGetContentByTitle = urlGetContentByTitle.replace('{{CPE_ID}}', VTR.Account.cpeId);
			$.getJSON(urlGetContentByTitle, function(data2){
				var assetId = "";
				$.each(data2.Content.Aliases.Alias, function(ix, alias) {
					if(alias.type == "VodBackOfficeId") {
						assetId = alias.Value;
					}
				});
				output.listtitles[i].assetId = assetId;
				output.listtitles[i].isHD = data2.Content.IsHD;
				output.listtitles[i].is3D = data2.Content.Is3D;
			});
		});
	}).then(function() {
		$.each(output.listtitles, function(i, d) {
			var productFieldList = 'Type,EntitlementState';
			var urlGetProductByContentId = VTR.Properties.traxisProxy + '/' + VTR.Traxis.urlProductByContent;
			urlGetProductByContentId = urlGetProductByContentId.replace("{{CONTENT_ID}}", d.contentId);
			urlGetProductByContentId = urlGetProductByContentId.replace("{{PROFILE_ID}}", VTR.Account.profileId);
			urlGetProductByContentId = urlGetProductByContentId.replace("{{CPE_ID}}", VTR.Account.cpeId);
			urlGetProductByContentId = urlGetProductByContentId.replace("{{FIELD_LIST}}", productFieldList);
			$.getJSON(urlGetProductByContentId, function(data2) {
				output.listtitles[i].contentType = data2.Products.Product[0].Type;
			});
		});
    }).fail(function(xhr, errorType, error){
    	//console.log('xhr:' + xhr + ' - ' + 'error:' + error);
    }).done(function(data, status, xhr){
    	//console.log('data:' + data + ' - ' + 'status:' + status);
		setTimeout(function(){
			callback(output);													
			//console.log(output);
		}, 300);
    });
}

VTR.Catalog.getListTitlesByCategory = function(callback, options){
	var fieldList = 'Name,Categories,Pictures,ShortName,Contents,ContentCount,SeriesCount';
	var urlContentByCategory = VTR.Properties.traxisProxy + '/' + VTR.Traxis.urlBodyRequest;
	// urlContentByCategory = urlContentByCategory.replace('{{CATEGORY_ID}}', VTR.Utils.replaceAll(options.categoryId, "/", "~~2F" ));
	// urlContentByCategory = urlContentByCategory.replace('{{FIELD_LIST}}', fieldList);
	// urlContentByCategory = (options.isCarrusel) ? urlContentByCategory.replace('{{PAGE_SIZE}}', VTR.Properties.carruselSize) : urlContentByCategory.replace('{{PAGE_SIZE}}', VTR.Properties.lienzoSize);

	var bodyReq = "";
	bodyReq += "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n";
	bodyReq += "<Request xmlns=\"urn:eventis:traxisweb:1.0\">\n";
	bodyReq += "  <Identity>\n";
	bodyReq += "    <CpeId>"+VTR.Account.cpeId+"</CpeId>\n";
	bodyReq += "  </Identity>\n";
	bodyReq += "  <RelationQuery resourceType=\"Category\" resourceId=\"" + options.categoryId + "\" relationName=\"Titles\">\n";
	bodyReq += "    <Options>\n";
	bodyReq += "      <Option type=\"Limit\">"+VTR.Properties.carruselSize+"</Option>\n";
	bodyReq += "      <Option type=\"Props\">Name,Categories,Pictures,ShortName,Contents,ContentCount,SeriesCount</Option>\n";
	bodyReq += "	  <Option type=\"filter\">IsPreview==false&amp;&amp;IsViewableOnCpe==true</Option>\n";
	bodyReq += "    </Options>\n";
	bodyReq += "    <SubQueries>\n";
	bodyReq += "      <SubQuery relationName=\"Contents\">\n";
	bodyReq += "        <Options>\n";
	bodyReq += "          <Option type=\"props\">Aliases,IsHD,Is3D</Option>\n";
	bodyReq += "        </Options>\n";
	bodyReq += "        <SubQueries>\n";
	bodyReq += "          <SubQuery relationName=\"Products\">\n";
	bodyReq += "            <Options>\n";
	bodyReq += "              <Option type=\"props\">Type,EntitlementState,EntitlementEnd</Option>\n";
	bodyReq += "            </Options>\n";
	bodyReq += "          </SubQuery>\n";
	bodyReq += "        </SubQueries>\n";
	bodyReq += "      </SubQuery>\n";
	bodyReq += "    </SubQueries>\n";
	bodyReq += "  </RelationQuery>\n";
	bodyReq += "</Request>\n";
	var output = {categoryId: options.categoryId ,"categoryName": options.categoryName, "titlesCount": options.titlesCount, position: 'options.position', "listtitles":[]};
	$.post(urlContentByCategory, bodyReq, function(data){
		eval("VTR.Catalog.contentCategories = " + JSON.stringify(data));
		$.each(VTR.Catalog.contentCategories.Titles.Title, function(i, d){
			var isSeries = false;
			var img = "";
			var pics = this.Pictures;
			if (pics){
			  img =  pics.Picture[0].Value.replace("http://" + VTR.Properties.posterServerName + "/", "http://" + VTR.Properties.posterServer + "/");
			}
			if (VTR.Utils.isset(this.SeriesCount)){
				if (this.SeriesCount > 0){
					isSeries = true;
				}
			}
			output.listtitles.push({
				categoryId : 'CATEGORY_ID',
				subcategoryId : 'SUB_CATEGORY_ID',
				titleId : d.id,
				name : (VTR.UI.screenFormat == "HD" ? d.ShortName.substring(0, 18) : d.ShortName.substring(0, VTR.Properties.titleMaxSize)),
				is3D : d.Contents.Content[0].Is3D,
				isHD : d.Contents.Content[0].IsHD,
				pictureUri : img,
				contentType : d.Contents.Content[0].Products.Product[0].Type,
				bookmark: d.Bookmark,
				duration: d.DurationInSeconds,
				assetId: d.Contents.Content[0].Aliases.Alias[0].Value,
				LastViewDate: d.LastViewDate,
				contentId: d.Contents.Content[0].id,
				entitlementState: d.Contents.Content[0].Products.Product[0].EntitlementState,
				entitlementEnd: d.Contents.Content[0].Products.Product[0].EntitlementEnd
			});
		});
		callback(output);
	});
}

VTR.Catalog.getSeriesCollection = function(callback, options) {
	var fieldList = 'ParentSeriesCollection,Name,IsAdult,Type';
	var urlGetSeriesCollection = VTR.Properties.traxisProxy + '/' + VTR.Traxis.urlSeriesCollection;  
	urlGetSeriesCollection = urlGetSeriesCollection.replace('{{FIELD_LIST}}', fieldList);
	urlGetSeriesCollection = (options.isCarrusel) ? urlGetSeriesCollection.replace('{{PAGE_SIZE}}', VTR.Properties.carruselSize) : urlGetSeriesCollection.replace('{{PAGE_SIZE}}', VTR.Properties.lienzoSize);
	var output = {"listseries":[]}
	
	$.getJSON(urlGetSeriesCollection, function(d){
		if (VTR.Utils.isset(d.SeriesCollection.Series)) {
			$.each(d.SeriesCollection.Series, function(i, item) {
				output.listseries.push({
					"serieId": this.id,
					"name": this.Name,
					"isAdult": this.IsAdult,
					"type": this.Type,
					"pictureUri": VTR.Properties.vodImage, //"http://" + VTR.Properties.posterServer + "/" + VTR.Properties.vodImage, //this.pictureUri,
					"isHD": "HD" //this.isHD
				});
			});
		}
		callback(output);
    }).fail(function(xhr, errorType, error){
    	console.log('xhr:' + xhr + ' - ' + 'error:' + error);
    }).done(function(data, status, xhr){
    	console.log('data:' + data + ' - ' + 'status:' + status);
	});
}

VTR.Catalog.learnActionForTA = function(options) { //IngenieriaTv
    var fieldList = 'Contents,Bookmark';
    var urlGetTitle = VTR.Properties.traxisProxy + '/' + VTR.Traxis.urlTitleDetail;
    urlGetTitle = urlGetTitle.replace('{{TITLE_ID}}', options.titleId);
    urlGetTitle = urlGetTitle.replace('{{CPE_ID}}', VTR.Account.cpeId);
    urlGetTitle = urlGetTitle.replace('{{FIELD_LIST}}', fieldList);
//    console.log(urlGetTitle);
    $.getJSON(urlGetTitle, function(d) {
        //$.each(d.Title, function(i2, d2) {
            //console.log('title:'+JSON.stringify(d));
            console.log('Bookmark:'+d.Title.Bookmark);
            if(d.Title.Bookmark > VTR.Properties.secondsLearnAction) {
                var contentId = d.Title.Contents.Content[0].id;
                var instanceId = contentId.split(",");
                var urlLearnActionTA = VTR.Properties.traxisProxy2 + VTR.Properties.thinkAnalyticsServer + '/' + VTR.Traxis.urlSetLearnAction;
                var pId = VTR.Account.profileId.replace('~~', '%');
                var iId = instanceId[1].replace(/~~2F/g, '/');
                var tId = options.titleId.replace(/~~2F/g, '/');
                var unixTime = VTR.Utils.convertDateToUnixTime(new Date());
                urlLearnActionTA = urlLearnActionTA.replace('{{PROFILE_ID}}', pId);
                urlLearnActionTA = urlLearnActionTA.replace('{{ACTION_TYPE}}', options.action);
                urlLearnActionTA = urlLearnActionTA.replace('{{TITLE_ID}}', encodeURIComponent(tId));
                urlLearnActionTA = urlLearnActionTA.replace('{{INSTANCE_ID}}', encodeURIComponent(iId));
                urlLearnActionTA = urlLearnActionTA.replace('{{TIME}}', unixTime);
                console.log(urlLearnActionTA);
                $.get(urlLearnActionTA, function(data) {
                    console.log('learnAction('+options.action+'):['+data+']');
                });
            }
        //});
    });
                    
}