var mode = "";
var carruselfocus = false;

if(sessionStorage.getItem("debugInfo") == "detail"){
    mode = "detailMovie";
}else if(sessionStorage.getItem("debugInfo") == "search"){
    mode = "search"; 
}else{
    mode = "carrousels";
}

// set a key filter so that the numeric keys can be handled by the app
var xhrKeyFilter = new XMLHttpRequest();
xhrKeyFilter.open("GET", "http://session/client/keyfilter?process=remote&keycode=VK_0&keycode=VK_1&keycode=VK_2&keycode=VK_3&keycode=VK_4&keycode=VK_5&keycode=VK_6&keycode=VK_7&keycode=VK_8&keycode=VK_9", true);
xhrKeyFilter.send("");

var returnCategory = "";
var pintype = 'rent';
var navi = {"navigate":[]};
var idc2 = {"menuId":[]};
var seriesBackTemp = null;
//Get progesss movie
var progress = $('section#frame-carrousels ul.carrousels li:nth-child(2) ul.carrousel > li:nth-child(2)').data('bookmark');
if(progress == null) {
    progress = $('section#frame-carrousels ul.carrousels li ul.carrousel > li').data('bookmark');
}
//$('section#frame-carrousels div.foco div.progress').css('width', progress+'%')
//console.log(window.location);

var onKeyDown = function(evt){
    
    console.log("main.js - keydown() - key: " + evt.keyCode);    
    
    // Variables for move movies
    var ul = document.querySelector('ul.carrousels > li:nth-child(2) ul.carrousel');
    var last = document.querySelector('ul.carrousels > li:nth-child(2) ul.carrousel >li:last-child');
    var first = document.querySelector('ul.carrousels > li:nth-child(2) ul.carrousel >li');

    // Variables for move carrousels
    var ulCarrousel = document.querySelector('ul.carrousels');
    var lastCarrousel = document.querySelector('ul.carrousels>li:last-child');
    var firstCarrousel = document.querySelector('ul.carrousels>li');
   
    var positionFirstCarrousel = $('section#frame-carrousels ul.carrousels li:nth-child(2)').attr('class');  
    
    /* CONTROL REMOTO */

    if (mode == "carrousels"){
        switch(evt.keyCode){
            // DEBUG INFO CODE                           
                case KEYS.INFO:
                case KEYS.H:
                if(VTR.Properties.debugInfo==1){  
                    sessionStorage.setItem("button1", evt.keyCode);
                }

                evt.preventDefault();                     
                break;
                case KEYS.ONE:
                    if(sessionStorage.getItem("button1") == KEYS.INFO){
                       sessionStorage.setItem("button2", evt.keyCode); 
                    }
                    evt.preventDefault();                     
                    break;
                case KEYS.TWO:
                    if(sessionStorage.getItem("button1") == KEYS.INFO && sessionStorage.getItem("button2") == KEYS.ONE){
                        window.location.replace("html/debug.html");
                    }
                    evt.preventDefault();                     
                    break;                                                     
            // FIN DEBUG INFO CODE
            
            case KEYS.LEFT:
                if (sessionStorage.getItem("searchHasResults") == "true"){
//                  var kb = document.getElementById('AVKeyboard0p0k4');
//                  $('#AVKeyboard0p0k4').focus();
                    keyboard.focus(true);
//                    keyboard.moveCursorToBeginning();
                    keyboard.setText(VTR.Utils.isset(localStorage.getItem("term"+VTR.Account.cpeId)) ? localStorage.getItem("term"+VTR.Account.cpeId) : "");
                    $('.focoRepository').hide();
                    // carruselfocus = false;
                    evt.preventDefault();
                    mode = 'search';
                } else {
                    ul.insertBefore(last,first);
                    evt.preventDefault();
                    //Get progesss movie
                    progress = $('ul.carrousels > li:nth-child(2) ul li:nth-child(2)').data('progress');
                    if(progress == null) {
                        progress = $('ul.carrousels > li:nth-child(2) ul li').data('progress');
                    }
                    if(!VTR.Utils.isset(progress)) {
                        $('section#frame-carrousels div.foco div.progress').hide();
                    }
                    else {
                        $('section#frame-carrousels div.foco div.progress').show();
                        $('section#frame-carrousels div.foco div.progress').css('width', progress+'%');                  
                    }
                    
                    var playCarrousel = $('section#frame-carrousels ul.carrousels li ul.carrousel > li:nth-child(2) .play-element').attr('class');
                    var continuaViendo = $('section#frame-carrousels ul.carrousels li:nth-child(2)').attr('id');
                    var viewAll = $('section#frame-carrousels ul.carrousels li:nth-child(2)').attr('class');
                    if(playCarrousel == 'play-element' && continuaViendo == 'continua-viendo' && viewall != 'view-all'){
                        $('.play-element-fix').show();
                    }
                    else {
                        $('.play-element-fix').hide();
                        $('section#frame-carrousels div.foco div.progress').hide();
                    }
                }
                break;

            case KEYS.RIGHT:
                // if (carruselfocus){
                    ul.appendChild(first);
                    evt.preventDefault();
                    //Get progesss movie
                    progress = $('ul.carrousels > li:nth-child(2) ul li:nth-child(2)').data('progress');
                    if(progress == null) {
                        progress = $('ul.carrousels > li:nth-child(2) ul li').data('progress');
                    }
                    if(!VTR.Utils.isset(progress)) {
                        $('section#frame-carrousels div.foco div.progress').hide();
                    }
                    else {
                        $('section#frame-carrousels div.foco div.progress').show();
                        $('section#frame-carrousels div.foco div.progress').css('width', progress+'%');                   
                    }
                    // Show Play in covers
                    var playCarrousel = $('section#frame-carrousels ul.carrousels li ul.carrousel > li:nth-child(2) .play-element').attr('class');
                    var continuaViendo = $('section#frame-carrousels ul.carrousels li:nth-child(2)').attr('id');
                    var viewAll = $('section#frame-carrousels ul.carrousels li:nth-child(2)').attr('class');
                    if(playCarrousel == 'play-element' && continuaViendo == 'continua-viendo' && viewall != 'view-all'){
                        $('.play-element-fix').show();
                    }
                    else {
                        $('.play-element-fix').hide();
						$('section#frame-carrousels div.foco div.progress').hide();
                    }
                // } else {
                //     carruselfocus = true;
                // }
                break;

            case KEYS.ENTER:
            case KEYS.OK:
                var indice = 2;
                if($("#frame-carrousels").hasClass("repository")) {
                     indice = 3;
                }
                    //Load new page with Ajax
                    var url = "";
                    var primaryId = "";
                    primaryId = $('section#frame-carrousels ul.carrousels li:nth-child(2) ul.carrousel > li:nth-child('+indice+')').attr("href");
                    if(primaryId == null) {
                        primaryId = $('section#frame-carrousels ul.carrousels li:nth-child(2) ul.carrousel > li').attr("href");
                    }
                    var titleId = $('section#frame-carrousels ul.carrousels li:nth-child(2) ul.carrousel > li:nth-child('+indice+')').data("crid");
                    if(titleId == null) { 
                        titleId = $('section#frame-carrousels ul.carrousels li:nth-child(2) ul.carrousel > li').data("crid");
                    }
                    var viewall = $('section#frame-carrousels ul.carrousels li:nth-child(2) ul.carrousel > li:nth-child('+indice+')').attr("class");
                    var titleName = $('section#frame-carrousels ul.carrousels li:nth-child(2) ul.carrousel > li:nth-child('+indice+') h3').text();
                    if(titleName == null) {
                        titleName = $('section#frame-carrousels ul.carrousels li:nth-child(2) ul.carrousel > li h3').text();
                    }
                    var serName = $('section#frame-carrousels ul.carrousels li:nth-child(2) ul.carrousel > li:nth-child('+indice+')').attr("serie-name");
                    var catName = $('section#frame-carrousels ul.carrousels li:nth-child(2) h2').text();
                    if(catName == null) {
                        catName = $("section#frame-carrousels.repository ul.carrousels > li:nth-child(2)").data("categoryname");
                    }
                    var catId = $('section#frame-carrousels ul.carrousels li:nth-child(2) h2').data("categoryid");
                    if(catId == null) {
                        catId = $("section#frame-carrousels.repository ul.carrousels > li:nth-child(2)").data("categoryid");
                    }
                    var series = $('section#frame-carrousels ul.carrousels li:nth-child(2) ul.carrousel > li:nth-child('+indice+')').data("is-series");
                    if(series == null) {
                        series = $('section#frame-carrousels ul.carrousels li:nth-child(2) ul.carrousel > li').data("is-series");
                    }
                    var assetId = $('section#frame-carrousels ul.carrousels li:nth-child(2) ul.carrousel > li:nth-child('+indice+')').data("assetid");
                    if(assetId == null) {
                        assetId = $('section#frame-carrousels ul.carrousels li:nth-child(2) ul.carrousel > li').data("assetid");
                    }
                    var bookmark = $('section#frame-carrousels ul.carrousels li:nth-child(2) ul.carrousel > li:nth-child('+indice+')').data("bookmark");
                    if(bookmark == null) {
                        bookmark = $('section#frame-carrousels ul.carrousels li:nth-child(2) ul.carrousel > li').data("bookmark");
                    }
                
                seriesBackTemp = series;
		var firstNav = document.querySelector('nav .mask ul>li');
                var firstNavCrid = $(firstNav).data("crid");
                var firstNavName = $(firstNav).data("name");
                var firstNavIsseries = $(firstNav).data("isseries");

                localStorage.setItem('isSeries_concurrencia', series);
                localStorage.setItem('primariId_concurrencia', primaryId);		
		localStorage.setItem('titleId_concurrencia', titleId);
                localStorage.setItem('categoryName_concurencia', catName);
		localStorage.setItem('primariId', primaryId);
		localStorage.setItem('isSeries', series);
		localStorage.setItem('categoryName', catName);
                

                /*if(catName == 'CONTINUA VIENDO' && viewall != "view-all"){
                    if(VTR.Utils.isset(assetId)) {
                        localStorage.setItem('returnKey'+VTR.Account.cpeId, 'play');
                        localStorage.setItem('returnData'+VTR.Account.cpeId, JSON.stringify({'status': 'play', 'message': '', 'titleId': titleId, 'categoryName': catName, 'navi': navi.navigate}));
                        VTR.Utils.openAsset(assetId,bookmark);                    
                    }        
                }else{*/
                        if (viewall == "view-all") {
                            url = "html/repository.html";
                            av.tracker.track('click', {'title': titleName, 'page': '[VER TODO] '+catName});
                        } 
                        else {
                            av.tracker.track('click', {'title': titleName, 'page': '[CARRUSEL] '+catName});
                            url = "html/detail-premium-movie.html";
                        }
                    $("body").animate({
                      opacity: 0,
                      scale:1.3,
                      translate3d: '0,-40px,0'
                    }, VTR.Properties.transitionTime, 'ease-in', function(){
                        $.ajax({
                            url: url,
                            success: function(data){
                                $('body').html(data).animate({
                                    opacity:1,
                                    translate3d: '0,0,0'
                                }, VTR.Properties.transitionTime, 'ease-out');

                                if (viewall == "view-all") {
                                    if(VTR.Properties.titleMenu1stLevel == "") {
                                        if(navi.navigate.length > 0){
                                            if(navi.navigate[0].categoryName == "MI VOD"){
                                                navi.navigate.pop()
                                            }
                                        }
                                        VTR.Utils.doNavigate('[CATEGORY_ID]','MI VOD','', 'false');
                                        VTR.Properties.titleMenu1stLevel = "MI VOD";
                                    }
                                    VTR.Utils.doNavigate(primaryId,catName, '', 'false');
                                    if(navi.navigate.length == 1){
                                        av.tracker.track('page-view', {'title': '[LIENZO]', url: navi.navigate[0].categoryName, 'cat': navi.navigate[0].categoryName});
                                    }
                                    else if(navi.navigate.length == 2) {
                                        av.tracker.track('page-view', {'title': '[LIENZO]', url: navi.navigate[0].categoryName+' / '+navi.navigate[1].categoryName, 'cat': navi.navigate[0].categoryName, 'subcat': navi.navigate[1].categoryName});
                                    }
                                    else if(navi.navigate.length == 3) {
                                        av.tracker.track('page-view', {'title': '[LIENZO]', url: navi.navigate[0].categoryName+' / '+navi.navigate[1].categoryName+' / '+navi.navigate[2].categoryName, 'cat': navi.navigate[1].categoryName, 'subcat': navi.navigate[2].categoryName});
                                    }
                                    else if(navi.navigate.length == 4) {
                                        av.tracker.track('page-view', {'title': '[LIENZO]', url: navi.navigate[0].categoryName+' / '+navi.navigate[1].categoryName+' / '+navi.navigate[2].categoryName +' / '+navi.navigate[3].categoryName, 'cat': navi.navigate[2].categoryName, 'subcat': navi.navigate[3].categoryName});
                                    }
                                    switch (catName) {
                                        case "CONTINUA VIENDO":
                                            VTR.Properties.titleMenu2ndLevel = "CONTINUA VIENDO";
                                            VTR.UI.renderCanvasMyViewings({firstCarrousel: true, isAdult: false, size: VTR.Properties.lienzoSize});
                                            break;
                                        case "MI LISTA":
                                            VTR.Properties.titleMenu2ndLevel = "MI LISTA";
                                            VTR.UI.renderCanvasMyWishList({firstCarrousel: true, size: VTR.Properties.lienzoSize});
                                            break;
                                        case "MIS ARRIENDOS":
                                            VTR.Properties.titleMenu2ndLevel = "MIS ARRIENDOS";
                                            VTR.UI.renderCanvasMyPurchasedProducts({firstCarrousel: true, size: VTR.Properties.lienzoSize});
                                            break;
                                        case "MI HISTORIAL":
                                            VTR.Properties.titleMenu2ndLevel = "MI HISTORIAL";
                                            VTR.UI.renderCanvasMyHistory({firstCarrousel: true, size: VTR.Properties.lienzoSize});
                                            break;
                                        case "TE RECOMENDAMOS ":
                                            VTR.Properties.titleMenu2ndLevel = "TE RECOMENDAMOS ";
                                            VTR.UI.renderCanvasMyRecommendations({firstCarrousel: true, size: VTR.Properties.lienzoSize});
                                            break;
                                        case "SIMILARES":
                                            VTR.UI.renderCanvasSearchRelatedRecommendations({'titleId': sessionStorage.getItem('titleId'), size: VTR.Properties.lienzoSize});
                                            break;
                                        default:
                                            if(primaryId.substring(0,5) == 'RECOM') {
                                                var arr_term = primaryId.split('_');
                                                VTR.UI.renderCanvasSearch({term: arr_term[1], isExact: true});
                                            }
                                            else {
                                            VTR.UI.renderCanvas({categoryId: primaryId, categoryName: catName, isCarrusel: false, size: VTR.Properties.lienzoSize});
                                            }
                                    }
                                    mode = 'carrousels';
                                }
                                else {

                                        if(catName == null) catName = "";
                                    if(VTR.Properties.titleMenu1stLevel == "" && VTR.Properties.titleMenu1stLevel.length == 0 && firstNavName=="MI VOD" && navi.navigate.length == 0) {                                      
											VTR.Utils.doNavigate(firstNavCrid,firstNavName, series, 'true');                                            
                                    } else if((VTR.Properties.titleMenu1stLevel.length == 0) && navi.navigate[0].categoryName != "MI VOD") {
                                            VTR.Properties.titleMenu1stLevel = catName;
                                        /*REVISAR ESTABILIZACION*/ //VTR.Utils.doNavigate(catId, catName, false);
                                    } else if ((VTR.Properties.titleMenu2ndLevel.length == 0) && VTR.Properties.titleMenu1stLevel != catName) {
                                        VTR.Properties.titleMenu2ndLevel = catName;
                                        /*REVISAR ESTABILIZACION*/ //VTR.Utils.doNavigate(catId, catName, false);
                                    } else if ((VTR.Properties.titleMenu3rdLevel.length == 0) && VTR.Properties.titleMenu2ndLevel != catName) {
                                        VTR.Properties.titleMenu3rdLevel = catName;
                                        //SE COMENTA LINEA QUE PROVOCABA LA CAIDA DEL FLUJO "LIENZO-FICHA-BACK-LIENZO" - ERROR UI-10000
                                        //VTR.Utils.doNavigate(catId, catName, 'false', 'true');
                                    }
                                     else if ((VTR.Properties.titleMenu4rdLevel.length == 0) && VTR.Properties.titleMenu3rdLevel != catName) {
                                        VTR.Properties.titleMenu4rdLevel = catName;
                                        //SE COMENTA LINEA QUE PROVOCABA LA CAIDA DEL FLUJO "LIENZO-FICHA-BACK-LIENZO" - ERROR UI-10000
                                        //VTR.Utils.doNavigate(catId, catName, 'false', 'true');
                                    }
										localStorage.setItem('subCategoryName'+VTR.Account.cpeId, catName);
                                    if (series == true) {
                                        VTR.UI.renderTitleDetailSeries({categoryId: primaryId, categoryName: titleName, isSeries: series, selSeason: 0, selEpisode: null, isCarrusel: true});
                                    } else {
                                        VTR.UI.renderTitleDetail({titleId: primaryId, categoryName: catName});
                                        // VTR.UI.renderTitleOptions({titleId: primaryId});
                                    }
                                    mode = 'detailMovie';
                                }
                            },
                            error: function(xhr, errorType, error){
                                console.log('Error:' + error + ':' + xhr.responseText);
                            }
                        });
                    });
                    //mode = 'detailMovie';

                //}                           
                break;
            case KEYS.EXIT:
                window.close();
                evt.preventDefault();
                break;
            case KEYS.BACK:
            case KEYS.LAST:
            case KEYS.RED:
            case KEYS.BUTTON_C:
                //returnCategory = $(firstNav).data("crid") + '|' + $('section#frame-carrousels ul.carrousels li:nth-child(2) h2').text();
                sessionStorage.removeItem("searchHasResults");
                evt.preventDefault();
                if(navi.navigate.length == 0) {
                    break;
                }
                if((navi.navigate.length == 3) && (navi.navigate[0].categoryName==VTR.Properties.titleMenuPremium)) {
                    localStorage.setItem("thirdLevelFlag", 1);
                }else if((navi.navigate.length == 4) && (navi.navigate[0].categoryName==VTR.Properties.titleMenuPremium)){
                    localStorage.setItem("thirdLevelFlag", 1);
                }               
                else{
		    localStorage.setItem("thirdLevelFlag", 0);                
		}
                navi.navigate.pop();
                
                $("body").animate({
                  opacity: 0,
                  scale:1.3,
                  translate3d: '0,-40px,0'
                }, VTR.Properties.transitionTime, 'ease-in', function(){
                    $.ajax({
                        url: "index.html",
                        success: function(data){
                            $('body').html(data).animate({
                                opacity:1,
                                translate3d: '0,0,0'
                            }, VTR.Properties.transitionTime, 'ease-out');
                        }
                    });
                });
                mode = "carrousels";
                break;
            case KEYS.PLAY:
            case KEYS.P:
                var assetId = $('section#frame-carrousels ul.carrousels li:nth-child(2) ul.carrousel > li:nth-child(2)').data("assetid");
                if(assetId == null) {
                    assetId = $('section#frame-carrousels ul.carrousels li:nth-child(2) ul.carrousel > li').data("assetid");
                }
                var bookmark = $('section#frame-carrousels ul.carrousels li:nth-child(2) ul.carrousel > li:nth-child(2)').data("bookmark");
                if(bookmark == null) {
                    bookmark = $('section#frame-carrousels ul.carrousels li:nth-child(2) ul.carrousel > li').data("bookmark");
                }
                var titleId = $('section#frame-carrousels ul.carrousels li:nth-child(2) ul.carrousel > li:nth-child(2)').data("crid");
                if(!VTR.Utils.isset(titleId)){
                    titleId = $('section#frame-carrousels ul.carrousels li:nth-child(2) ul.carrousel > li').data("crid");        
                }
                var categoryName = $('section#frame-carrousels ul.carrousels li:nth-child(2) h2').text();
                
                var firstNav         = document.querySelector('nav .mask ul>li');
                var firstNavCrid     = $(firstNav).data("crid");
                var firstNavName     = $(firstNav).data("name");
                
                if(VTR.Utils.isset(assetId)) {
                    if(VTR.Properties.titleMenu1stLevel == "" && VTR.Properties.titleMenu1stLevel.length == 0 && firstNavName=="MI VOD" && navi.navigate.length == 0) {                                      
                        VTR.Utils.doNavigate(firstNavCrid,firstNavName,'', 'true');
                        localStorage.setItem('subCategoryName'+VTR.Account.cpeId , "CONTINUA VIENDO");
                    }
                    localStorage.setItem('returnKey'+VTR.Account.cpeId, 'play');
                    localStorage.setItem('returnData'+VTR.Account.cpeId, JSON.stringify({'status': 'play', 'message': '', 'titleId': titleId, 'categoryName': categoryName, 'navi': navi.navigate}));
                    VTR.Utils.openAsset(assetId,bookmark);                    
                }

                localStorage.setItem('titleId_concurrencia', titleId);
                localStorage.setItem('categoryName_concurencia', categoryName);
                
                evt.preventDefault();
                break;

            case KEYS.B:
            case KEYS.BLUE:
            case KEYS.BUTTON_B:
                localStorage.removeItem("term"+VTR.Account.cpeId);
                VTR.Utils.doNavigate('[SEARCH]','BUSCAR','', 'false');
                $("body").animate({
                  opacity: 0,
                  scale:1.3,
                  translate3d: '0,-40px,0'
                }, VTR.Properties.transitionTime, 'ease-in', function(){
                    $.ajax({
                        url: "html/search.html",
                        success: function(data){
                            $('body').html(data).animate({
                                opacity:1,
                                translate3d: '0,0,0'
                            }, VTR.Properties.transitionTime, 'ease-out');
                            VTR.UI.renderKeyboard();
                        },
                        error: function(xhr, errorType, error){
                            console.log('Error:' + error + ':' + xhr.responseText);
                        }
                    });
                }); 
                mode = 'search';
                evt.preventDefault();
               break;

            case KEYS.YELLOW:
            case KEYS.BUTTON_A:
            case KEYS.HOME:
                if(!$("#frame-carrousels").hasClass("repository")) {
                    $('nav .mask ul').addClass('active');
                    $('#focusEdge').css('width', $('nav .mask ul>li').css('width')).show();
                    $('section#frame-carrousels ul').removeClass('active');
                    $('div.foco').hide();
                    $('section#frame-carrousels ul.carrousels li ul.carrousel > li:nth-child(2) div.tag-valid-for').attr('style','background: transparent');
                    $('.load-content').attr('style','opacity:0.3');
                    mode = 'nav';
                }
                break;
       }
        // If first carrousel is in first position, when de user move to top active nav
        if(positionFirstCarrousel == "first"){
            switch(evt.keyCode){
                case KEYS.UP:
                    if(!$("#frame-carrousels").hasClass("repository")) {
                        $('nav .mask ul').addClass('active');
                        $('#focusEdge').css('width', $('nav .mask ul>li').css('width')).show();
                        $('section#frame-carrousels ul').removeClass('active');
                        $('div.foco').hide();
                        $('.load-content').attr('style','opacity:0.3');
                        $('section#frame-carrousels ul.carrousels li ul.carrousel > li:nth-child(2) div.tag-valid-for').attr('style','background: transparent');
                        mode = 'nav';
                    }
                    break;

                case KEYS.DOWN:
                    ulCarrousel.appendChild(firstCarrousel);
                    evt.preventDefault();
                    $('nav ul li:nth-child(1)').removeClass('active');
                    $('div.foco').show();
                    $('.play-element-fix').hide();
                    $('section#frame-carrousels div.foco div.progress').hide();
                    var playCarrousel = $('section#frame-carrousels ul.carrousels li:nth-child(2) ul.carrousel > li:nth-child(2) .play-element').attr('class');
                    if(playCarrousel == 'play-element'){
                        $('.play-element-fix').show();
                    }
                    else {
                        $('.play-element-fix').hide();
                    }
                    $('.load-content').attr('style','opacity:1');
                    mode = 'carrousels';
                    break;
            }
        }else{
            switch(evt.keyCode){
                case KEYS.UP:
                    ulCarrousel.insertBefore(lastCarrousel, firstCarrousel);
                    $('section#frame-carrousels div.foco div.progress').hide();
                    $('.play-element-fix').hide();
                    var playCarrousel = $('section#frame-carrousels ul.carrousels li:nth-child(2) ul.carrousel > li:nth-child(2) .play-element').attr('class');
                    if(playCarrousel == null) {
                        playCarrousel = $('section#frame-carrousels ul.carrousels li:nth-child(2) ul.carrousel > li:only-child .play-element').attr('class');
                    }
                    progress = $('section#frame-carrousels ul.carrousels li:nth-child(2) ul.carrousel > li:nth-child(2)').data('progress');
                    if(progress == null) {
                        progress = $('ul.carrousels > li:nth-child(2) ul li:only-child').data('progress');
                    }
                    if(!VTR.Utils.isset(progress)) {
                        $('section#frame-carrousels div.foco div.progress').hide();
                    }
                    else {
                        $('section#frame-carrousels div.foco div.progress').show();
                        $('section#frame-carrousels div.foco div.progress').css('width', progress+'%')                    
                        if(playCarrousel == 'play-element'){
                            $('.play-element-fix').show();
                        }
                        else {
                            $('.play-element-fix').hide();
                        }
                    }
                    evt.preventDefault();
                    break;

                case KEYS.DOWN:
                    ulCarrousel.appendChild(firstCarrousel);
                    $('section#frame-carrousels div.foco div.progress').hide();
                    $('.play-element-fix').hide();
                    var playCarrousel = $('section#frame-carrousels ul.carrousels li:nth-child(2) ul.carrousel > li:nth-child(2) .play-element').attr('class');
                    if(playCarrousel == null) {
                        playCarrousel = $('section#frame-carrousels ul.carrousels li:nth-child(2) ul.carrousel > li:only-child .play-element').attr('class');
                    }
                    if(playCarrousel == 'play-element'){
                        $('.play-element-fix').show();
                    }
                    else {
                        $('.play-element-fix').hide();
                    }
                    progress = $('ul.carrousels > li:nth-child(2) ul li:nth-child(2)').data('progress');
                    if(progress == null) {
                        progress = $('ul.carrousels > li:nth-child(2) ul li:only-child').data('progress');
                    }
                    if(!VTR.Utils.isset(progress)) {
                        $('section#frame-carrousels div.foco div.progress').hide();
                    }
                    else {
                        $('section#frame-carrousels div.foco div.progress').show();
                        $('section#frame-carrousels div.foco div.progress').css('width', progress+'%')                    
                    }
                    evt.preventDefault();
                    break;
            }
        }
    } else if ((mode == "nav") || (mode == "navseries")){
        var ulNav = document.querySelector('nav .mask ul');
        var lastNav = document.querySelector('nav .mask ul>li:last-child');
        var firstNav = document.querySelector('nav .mask ul>li');
        var secondNav = document.querySelector('nav .mask ul>li:nth-child(2)');
        var focusEdgeNav = document.getElementById('focusEdge');
//alert(focusEdgeNav.offsetWidth);
        var elementWidth = function(element){
//          console.log(element.offsetWidth);
            return element.offsetWidth;
        }
        
        switch(evt.keyCode){
             // DEBUG INFO CODE                           
                case KEYS.INFO:
                if(VTR.Properties.debugInfo==1){  
                    sessionStorage.setItem("button1", evt.keyCode);
                }

                evt.preventDefault();                     
                break;
                case KEYS.ONE:
                    if(sessionStorage.getItem("button1") == KEYS.INFO){
                       sessionStorage.setItem("button2", evt.keyCode); 
                    }
                    evt.preventDefault();                     
                    break;
                case KEYS.TWO:
                    if(sessionStorage.getItem("button1") == KEYS.INFO && sessionStorage.getItem("button2") == KEYS.ONE){
                        window.location.replace("html/debug.html");
                    }
                    evt.preventDefault();                     
                    break;                                                       
            // FIN DEBUG INFO CODE    
            case KEYS.DOWN:
                evt.preventDefault();
                $('nav .mask ul').removeClass('active');
                $('section#frame-carrousels ul').addClass('active');
                $('div.foco').show();
                $('section#frame-carrousels ul.carrousels li ul.carrousel > li:nth-child(2) div.tag-valid-for').attr('style','background: rgba(0,0,0,0.7)');
                focusEdgeNav.style.width = "0px";
                $('.border-menu').show();
                $('.load-content').attr('style','opacity:1');
                $('section#detail-rent-movie').attr('style','opacity:1');
                mode = (mode == "nav" ? 'carrousels' : 'detailMovie');
                break;

            case KEYS.LEFT:
                var scrollWidth = elementWidth(lastNav);
                focusEdgeNav.style.width = scrollWidth + "px";
                var inSubMenu = ulNav.classList.contains('category-menu');
                if (inSubMenu) { ulNav.className="category-menu inactive";} else {ulNav.className="inactive";}
                ulNav.style.webkitTransform = "translate3d("+(scrollWidth+parseInt(getComputedStyle(firstNav).marginRight.replace("px","")))+"px,0,0)";


                ulNav.addEventListener('webkitTransitionEnd', function() {
                    if (inSubMenu) { this.className="category-menu notransition";} else {this.className="notransition";}

                    var cln = lastNav.cloneNode(true);
                    this.insertBefore(lastNav,firstNav);
                    this.style.webkitTransform = "translate3d(0px,0,0)";
                    if (inSubMenu) { this.className="category-menu active notransition";} else {this.className="active notransition";}

                });
                evt.preventDefault();
                break;

            case KEYS.RIGHT:
                var scrollWidth = elementWidth(firstNav);
                focusEdgeNav.style.width = elementWidth(secondNav)+ "px";
                var inSubMenu = ulNav.classList.contains('category-menu');
                if (inSubMenu) { ulNav.className="category-menu inactive";} else {ulNav.className="inactive";}

                ulNav.style.webkitTransform = "translate3d(-"+(scrollWidth+parseInt(getComputedStyle(firstNav).marginRight.replace("px","")))+"px,0,0)";
                ulNav.addEventListener('webkitTransitionEnd', function() {
                    if (inSubMenu) { this.className="category-menu notransition";} else {this.className="notransition";}

                    var cln = firstNav.cloneNode(true);
                    this.appendChild(firstNav);
                    this.style.webkitTransform = "translate3d(0px,0,0)";
                    if (inSubMenu) { this.className="category-menu active notransition";} else {this.className="active notransition";}

                });
//                  ulNav.appendChild(firstNav);
                evt.preventDefault();
                break;

            case KEYS.BACK:
            case KEYS.LAST:
            case KEYS.RED:
            case KEYS.BUTTON_C:
                var naviLength = navi.navigate.length;
                sessionStorage.removeItem("searchHasResults");
                
                if((navi.navigate[0].categoryName==VTR.Properties.titleMenuPremium) && (naviLength <= 2)){
                        localStorage.setItem("thirdLevelFlag", 1);
                }else  
                    if((naviLength == 3)&&(navi.navigate[naviLength-1].isSeries == true)){
                        localStorage.setItem("thirdLevelFlag", 1);
                    }else{
                    localStorage.setItem("thirdLevelFlag", 0);
                }

                if(seriesBackTemp == true){
                    if(((navi.navigate.length == 1) && (navi.navigate[0].categoryName == VTR.Properties.titleMenuPremium)) || ((navi.navigate.length == 2) && (navi.navigate[0].categoryName == VTR.Properties.titleMenuPremium) && (navi.navigate[navi.navigate.length -1].isSeries == true))){
                        localStorage.removeItem("premiumSection");
                    }
                    if(navi.navigate[naviLength-1].isSeries == true){
                        navi.navigate.pop();
                    }
                }else{
                    navi.navigate.pop();
                }
                    $("body").animate({
                      opacity: 0,
                      scale:1.3,
                      translate3d: '0,-40px,0'
                    }, VTR.Properties.transitionTime, 'ease-in', function(){
                        $.ajax({
                            url: "index.html",
                            success: function(data){
                                $('body').html(data).animate({
                                    opacity:1,
                                    translate3d: '0,0,0'
                                }, VTR.Properties.transitionTime, 'ease-out');
                            },
                            error: function(xhr, errorType, error){
                                console.log('Error:' + error + ':' + xhr.responseText);
                            }
                        });
                    });
                    mode = 'carrousels';
                    submenu = true;
                    evt.preventDefault();
                    seriesBackTemp = false;
                    break;

            case KEYS.EXIT:
                window.close();
                break;
            case KEYS.B:
            case KEYS.BLUE:
            case KEYS.BUTTON_B:
                localStorage.removeItem("term"+VTR.Account.cpeId);
                VTR.Utils.doNavigate('[SEARCH]','BUSCAR','','false');
                $("body").animate({
                  opacity: 0,
                  scale:1.3,
                  translate3d: '0,-40px,0'
                }, VTR.Properties.transitionTime, 'ease-in', function(){
                    $.ajax({
                        url: "html/search.html",
                        success: function(data){
                            $('body').html(data).animate({
                                opacity:1,
                                translate3d: '0,0,0'
                            }, VTR.Properties.transitionTime, 'ease-out');
                            VTR.UI.renderKeyboard();
                        },
                        error: function(xhr, errorType, error){
                            console.log('Error:' + error + ':' + xhr.responseText);
                        }
                    });
                }); 
                mode = 'search';
                evt.preventDefault();
               break;

            case KEYS.ENTER:
            case KEYS.OK:
                //VTR.Utils.doNavigate($(firstNav).data("crid"),$(firstNav).data("name"),$(firstNav).data("isseries"),'false');
				var inSubMenu = ulNav.classList.contains('category-menu');
                if(!inSubMenu) {
                    navi = {"navigate":[]};
                }
                if(navi.navigate.length === 0) {
                    VTR.Utils.doNavigate($(firstNav).data("crid"),$(firstNav).data("name"),$(firstNav).data("isseries"),'false');
                    var menuArrayLength = idc2.menuId.length;
                    for (var i=0; i<menuArrayLength; i++) {
                        if($(firstNav).data("crid").toString() == idc2.menuId[i].categoryId.toString()){
                            while (navi.navigate.length > 1){
                                navi.navigate.pop();
                            }
                            if(navi.navigate.length == 1){
                                navi.navigate.pop();
                                VTR.Utils.doNavigate($(firstNav).data("crid"),$(firstNav).data("name"),$(firstNav).data("isseries"),'false');  
                            }
                        }
                    } 
                } else {
                    var crid = $(firstNav).data("crid");
                    var result = $.grep(navi.navigate, function(e){ return e.categoryId == crid; });                 
                    if( result.length === 0 ){
                       VTR.Utils.doNavigate( crid, $(firstNav).data("name"),$(firstNav).data("isseries"),'false');
                    }
                }
                /* Event Reports - Page View */
                if(navi.navigate.length == 1){
                    av.tracker.track('page-view', {'title': '[MENU]', url: navi.navigate[0].categoryName, 'cat': navi.navigate[0].categoryName});
                }
                else if(navi.navigate.length == 2) {
                    av.tracker.track('page-view', {'title': '[MENU]', url: navi.navigate[0].categoryName+' / '+navi.navigate[1].categoryName, 'cat': navi.navigate[0].categoryName, 'subcat': navi.navigate[1].categoryName});
                }
                else if(navi.navigate.length == 3) {
                    av.tracker.track('page-view', {'title': '[MENU]', url: navi.navigate[0].categoryName+' / '+navi.navigate[1].categoryName+' / '+navi.navigate[2].categoryName, 'cat': navi.navigate[1].categoryName, 'subcat': navi.navigate[2].categoryName});
                }
                else if(navi.navigate.length == 4) {
                    av.tracker.track('page-view', {'title': '[MENU]', url: navi.navigate[0].categoryName+' / '+navi.navigate[1].categoryName+' / '+navi.navigate[2].categoryName +' / '+navi.navigate[3].categoryName, 'cat': navi.navigate[2].categoryName, 'subcat': navi.navigate[3].categoryName});
                }


                var isAdult = $(firstNav).data("isadult");
                if(isAdult == true || $(firstNav).data("name") == 'ADULTOS') {
                    if(VTR.Account.parentalPinSet == true) {
                        pintype = 'adult';
                        sessionStorage.setItem("categoryId", $(firstNav).data("crid"));
                        $("body").animate({
                          opacity: 0,
                          scale:1.3,
                          translate3d: '0,-40px,0'
                        }, VTR.Properties.transitionTime, 'ease-in', function(){
                            $.ajax({
                                url: 'html/pin-parental.html',
                                success: function(data){
                                    $('body').html(data).animate({
                                        opacity:1,
                                        translate3d: '0,0,0'
                                    }, VTR.Properties.transitionTime, 'ease-out');
                                },
                                error: function(xhr, errorType, error){
                                    console.log('Error:' + error + ':' + xhr.responseText);
                                }
                            });
                        });
                        mode = 'rentPin';
//                        pintype = 'rent';
                        break;
                    }
                    else {
                        $("body").animate({
                          opacity: 0,
                          scale:1.3,
                          translate3d: '0,-40px,0'
                        }, VTR.Properties.transitionTime, 'ease-in', function(){
                            $.ajax({
                                url: 'html/error.html',
                                success: function(data){
                                    $('body').html(data).animate({
                                        opacity:1,
                                        translate3d: '0,0,0'
                                    }, VTR.Properties.transitionTime, 'ease-out');
                                    VTR.UI.renderMessagePage({
                                        messageBody: 'ADVERTENCIA<br>Este contenido es para mayores de 18 años.',
                                        messageTitle: 'CONTROL FAMILIAR',
                                        messageButton: 'INGRESAR DIRECTAMENTE',
                                        messageButton2: 'COMO CREAR PIN PARENTAL',
                                        returnPath: 'index.html',
                                        returnPath2: 'html/error.html',
                                        preloadedCategory: $(firstNav).data("crid"),
                                        preloadedCategory2: 'message2'
                                    });
                                    mode = 'message';
                                    returned = true;
                                },
                                error: function(xhr, errorType, error){
                                    console.log('Error:' + error + ':' + xhr.responseText);
                                }
                            });
                        });
                        break;
                    }
                }
                
                if ($(firstNav).data("isseries") != true) {
                    $("#frame-carrousels > ul").empty();
                    $("#frame-carrousels > ul").append("<div class='foco'><div class='progress'></div><a href='' class='play-element-fix' style='display: none;'></a></div>");
                }
                switch ($(firstNav).data("name")) {
                    case "MI VOD":
                        VTR.UI.renderMyVOD();
                        VTR.UI.renderListCarruselsWithTitles({categoryId: $(firstNav).data("crid"), categoryName: $(firstNav).data("name"), isCarrusel: true, size: VTR.Properties.carruselSize});
                        break;
                    case "MI CUENTA":
                        VTR.UI.renderListSubMenu({categoryId: $(firstNav).data("crid"), categoryName: $(firstNav).data("name"), isSeries: $(firstNav).data("isseries"), isCarrusel: true});
                        VTR.UI.renderMyAccount({categoryId: $(firstNav).data("crid"), categoryName: $(firstNav).data("name"), isSeries: $(firstNav).data("isseries"), isCarrusel: true, size: VTR.Properties.carruselSize});
                        break;
                    case "CONTINUA VIENDO":
                        $('nav .mask ul').empty();
                        VTR.Properties.titleMenu2ndLevel = "CONTINUA VIENDO";
                        VTR.UI.renderCanvasMyViewings({firstCarrousel: false, isAdult: false, isCarrusel: false, size: VTR.Properties.lienzoSize});
                        mode = 'carrousels';
                        break;
                    case "MI LISTA":
                        $('nav .mask ul').empty();
                        VTR.Properties.titleMenu2ndLevel = "MI LISTA";
                        VTR.UI.renderCanvasMyWishList({firstCarrousel: false, isCarrusel: false, size: VTR.Properties.lienzoSize});
                        break;
                    case "MI HISTORIAL":
                        $('nav .mask ul').empty();
                        VTR.Properties.titleMenu2ndLevel = "MI HISTORIAL";
                        VTR.UI.renderCanvasMyHistory({firstCarrousel: false, isCarrusel: false, size: VTR.Properties.lienzoSize});
                        break;
                    case "TE RECOMENDAMOS ":
                        $('nav .mask ul').empty();
                        VTR.Properties.titleMenu2ndLevel = "TE RECOMENDAMOS VIENDO";
                        VTR.UI.renderCanvasMyRecommendations({firstCarrousel: true, isCarrusel: false, size: VTR.Properties.lienzoSize});
                        break;
                    case "MIS ARRIENDOS":
                        $('nav .mask ul').empty();
                        VTR.Properties.titleMenu2ndLevel = "MIS ARRIENDOS";
                        VTR.UI.renderCanvasMyPurchasedProducts({firstCarrousel: false, isCarrusel: false, size: VTR.Properties.lienzoSize});
                        //VTR.UI.renderCanvas({categoryId: $(firstNav).data("crid"), isCarrusel: false, position: 1});
                        break;
                    case "INICIO":
                        VTR.UI.renderListCarruselsWithTitles({categoryId: $(firstNav).data("crid"), categoryName: $(firstNav).data("name"), isCarrusel: true});
                        break;
                    case "RECOMENDACIONES":
                        VTR.UI.renderRecommendations({firstCarrousel: true, isCarrusel: false, 'titleId': $(firstNav).data("crid")});
                        break;
                    default:
                        if($(firstNav).data("crid").substring(0,5) == 'RECOM') {
                            VTR.UI.renderListRecomMenu({'categoryId': sessionStorage.getItem('titleId'), 'relations': {}});
                            switch ($(firstNav).data("name")) {
                                case "SIMILARES":
                                    VTR.UI.renderCanvasSearchRelatedRecommendations({'titleId': sessionStorage.getItem('titleId'), size: VTR.Properties.lienzoSize});
                                    break;
                                default: 
                                    VTR.UI.renderCanvasSearch({term: $(firstNav).data("name"), isExact: true, size: VTR.Properties.lienzoSize});
                                    break;
                            }
                        } else {
                            var firstNavText = $(firstNav).text();
                            if ($(firstNav).data("isseries") != true) {
                                if (((VTR.Properties.titleMenu1stLevel == VTR.Properties.titleMenuKids) || (VTR.Properties.titleMenu1stLevel == VTR.Properties.titleMenuClub)) && firstNavText != "INICIO") {
                                    VTR.UI.renderCanvas({categoryId: $(firstNav).data("crid"), categoryName: $(firstNav).data("name"), isCarrusel: false, size: VTR.Properties.lienzoSize});
                                } else {
                                    if ((VTR.Properties.titleMenu1stLevel == VTR.Properties.titleMenuPremium) && (VTR.Properties.titleMenu2ndLevel != '' && firstNavText == VTR.Properties.premiumChannelCatSeries)) {
                                        VTR.UI.renderCanvas({categoryId: $(firstNav).data("crid"), categoryName: $(firstNav).data("name"), isCarrusel: false, size: VTR.Properties.lienzoSize});
                                    } else if ((VTR.Properties.titleMenu1stLevel == VTR.Properties.titleMenuPremium)&&(VTR.Properties.titleMenu4rdLevel != '') && firstNavText == VTR.Properties.premiumChannelCatMovies){
                                        VTR.UI.renderCanvas({categoryId: $(firstNav).data("crid"), categoryName: $(firstNav).data("name"), isCarrusel: false, size: VTR.Properties.lienzoSize});
                                    }
                                    else {
                                        VTR.UI.renderListSubMenuWithCarrouselsAndTitles({categoryId: $(firstNav).data("crid"), categoryName: $(firstNav).data("name"), isSeries: $(firstNav).data("isseries"), isCarrusel: true, size: VTR.Properties.carruselSize});
                                        //VTR.UI.renderListSubMenu({categoryId: $(firstNav).data("crid"), categoryName: $(firstNav).data("name"), isSeries: $(firstNav).data("isseries"), isCarrusel: true});
                                        //VTR.UI.renderListCarruselsWithTitles({categoryId: $(firstNav).data("crid"), categoryName: $(firstNav).data("name"), isCarrusel: true, size: VTR.Properties.carruselSize});
                                    }
                                }
                            } else {
                                $("body").animate({
                                  opacity: 0,
                                  scale:1.3,
                                  translate3d: '0,-40px,0'
                                }, VTR.Properties.transitionTime, 'ease-in', function(){
                                    $.ajax({
                                        url: "html/detail-premium-movie.html",
                                        success: function(data){
                                            $('body').html(data).animate({
                                                opacity:1,
                                                translate3d: '0,0,0'
                                            }, VTR.Properties.transitionTime, 'ease-out');

                                            var catId   = $(firstNav).data("crid");
                                            var catNam  = $(firstNav).data("name");
                                            var serFlag = $(firstNav).data("isseries");
                                            var selSeason = $(firstNav).data("selseason");
                                            
                                            VTR.UI.renderTitleDetailSeries({categoryId: catId, categoryName: catNam, isSeries: serFlag, selSeason: selSeason, selEpisode: null, isCarrusel: true});
                                        },
                                        error: function(xhr, errorType, error){
                                            console.log('Error:' + error + ':' + xhr.responseText);
                                        }
                                    });
                                });
                                mode = 'navseries';
                                
                            }
                        }
                        break;
                }
                $('#exit-button').hide();
                $('#back-button').show();
//                mode = (mode == "nav" ? 'carrousels' : 'detailMovie');

                if ($(firstNav).data("isseries") != true) {
                    $('nav .mask ul').removeClass('active');
                    $('section#frame-carrousels ul').addClass('active');
                    $('#focusEdge').hide();
                    $('.load-content').attr('style','opacity:1');
                    mode = "carrousels";
                }    
                else {
                    mode = "detailMovie";
                }
        }
    }else if(mode == "detailMovie"){
        // Variables for move right nav

        var ulNavDetail = document.querySelector('ul.nav-detail');
        var lastNavDetail = document.querySelector('ul.nav-detail>li:last-child');
        var firstNavDetail = document.querySelector('ul.nav-detail>li');

        // Variables for rating
        var rating = $('#rating-menu');
        var positionRating = rating.attr('alt');

        //Change name rating
        function nameRating(){
            var classRating = $('#rating-menu').attr('class');
            var nameRating = $('.name-rating');
            if(classRating == 'star1'){
                nameRating.text('SIN CALIFICAR');
                $('.name-rating.button').css('display', 'none');
            }else if(classRating == 'star2'){
                nameRating.text('ME GUSTA');
                $('.name-rating.button').css('display', 'block');
            }else if(classRating == 'star3'){
                nameRating.text('NO ME GUSTA');
                $('.name-rating.button').css('display', 'block');
            }
        };

        var isSeries = $("section#detail-rent-movie").data('is-series');
		var episodeChangueDetail = $('section#detail-rent-movie article:nth-child(3) nav ul > li:nth-child(3)').data('episode');
                var episodeChangueDetailUp = $('section#detail-rent-movie article:nth-child(3) nav ul > li:nth-child(1)').data('episode');
		switch(evt.keyCode){
            // DEBUG INFO CODE                           
                case KEYS.INFO:
               if(VTR.Properties.debugDetailMovie==1){  
                    sessionStorage.setItem("button1", evt.keyCode);
                }

                evt.preventDefault();                     
                break;
                case KEYS.ONE:
                    if(sessionStorage.getItem("button1") == KEYS.INFO){
                       sessionStorage.setItem("button2", evt.keyCode); 
                    }
                    evt.preventDefault();                     
                    break;
                case KEYS.TWO:
                    if(sessionStorage.getItem("button1") == KEYS.INFO && sessionStorage.getItem("button2") == KEYS.ONE){
                        var prod = sessionStorage.getItem("productId");
                        if(prod != null && prod != "" && prod != "undefined"){
                            VTR.Content.getProductCategoryAndContent(function (value) { console.log(value); },{productId:sessionStorage.getItem("productId")});          
                        }
                        window.location.replace("html/debug_detail.html"); 
                    }
                    evt.preventDefault();                     
                    break;                                                       
            // FIN DEBUG INFO CODE
            case KEYS.UP:
                /*$('nav ul li:nth-child(1)').removeClass('active');
                $('#focusEdge').css('width', $('nav .mask ul>li').css('width'));
                if(isSeries != '' && VTR.Utils.isset(isSeries)) {
                    //$('article ul li:nth-child(1)').removeClass('active');
                    $('.border-menu').hide();
                    $('#player').removeClass('active');
                    mode = 'navseries';
                }
                else*/
                            
                $('nav ul li:nth-child(1)').removeClass('active');
                $('.border-menu').show();
                mode = 'detailMovie';
                ulNavDetail.insertBefore(lastNavDetail,firstNavDetail);
                evt.preventDefault();
                
                if (VTR.Utils.isset(episodeChangueDetailUp) == true) {
                        VTR.UI.renderChangeEpisodeDetail({episode: episodeChangueDetailUp});
                }
                            
                break;

            case KEYS.DOWN:
                $('nav ul li:nth-child(1)').removeClass('active');
                $('.border-menu').show();
                mode = 'detailMovie';
                ulNavDetail.appendChild(firstNavDetail);
                evt.preventDefault();
                //var episode = $('section#detail-rent-movie article:nth-child(3) nav ul > li:nth-child(2)').data('episode');
                //if (VTR.Utils.isset(episode) == true) {
                //    VTR.UI.renderChangeEpisodeDetail({episode: episode});
                //}
				if (VTR.Utils.isset(episodeChangueDetail) == true) {
					VTR.UI.renderChangeEpisodeDetail({episode: episodeChangueDetail});
				}
                break;
            //----------TA-----------
            case KEYS.B:
            case KEYS.BLUE:
            case KEYS.BUTTON_B:
                localStorage.removeItem("term"+VTR.Account.cpeId);
                var titleId = $('[id^="wishlist"]').attr('href');
                var categoryName = $('#category-name').text();
                VTR.Utils.doNavigate(titleId,categoryName,'','true');
                VTR.Utils.doNavigate('[SEARCH]','BUSCAR','','false');
                $("body").animate({
                  opacity: 0,
                  scale:1.3,
                  translate3d: '0,-40px,0'
                }, VTR.Properties.transitionTime, 'ease-in', function(){
                    $.ajax({
                        url: "html/search.html",
                        success: function(data){
                            $('body').html(data).animate({
                                opacity:1,
                                translate3d: '0,0,0'
                            }, VTR.Properties.transitionTime, 'ease-out');
                            VTR.UI.renderKeyboard();
                        },
                        error: function(xhr, errorType, error){
                            console.log('Error:' + error + ':' + xhr.responseText);
                        }
                    });
                });
                mode = 'search';
                evt.preventDefault();
                break;
            //----------TA-----------
            case KEYS.YELLOW:
            case KEYS.BUTTON_A:
            case KEYS.HOME:
                $('nav ul li:nth-child(1)').removeClass('active');
                $('#focusEdge').css('width', $('nav .mask ul>li').css('width'));
                if(isSeries != '' && VTR.Utils.isset(isSeries)) {
                    //$('article ul li:nth-child(1)').removeClass('active');
                    $('section#detail-rent-movie').attr('style','opacity:0.3');
                    $('.border-menu').hide();
                    $('#player').removeClass('active');
                    mode = 'navseries';
                }
                else
                    ulNavDetail.insertBefore(lastNavDetail,firstNavDetail);
                    evt.preventDefault();
                break;
            case KEYS.EXIT:
            case KEYS.BACK:
            case KEYS.LAST:
            case KEYS.RED:
            case KEYS.BUTTON_C:
                var url = "";
                var naviLength = navi.navigate.length;
                url = "index.html";    
                VTR.Properties.titlesMenu = "";
                mode = 'carrousels';

                if((VTR.Utils.isset(navi.navigate[0])) && (navi.navigate[0].categoryName==VTR.Properties.titleMenuPremium) && (naviLength <= 2)){
                        localStorage.setItem("thirdLevelFlag", 1);
                }else  
                    if((naviLength == 3)&&(navi.navigate[naviLength-1].isSeries == true)){
                        localStorage.setItem("thirdLevelFlag", 1);
                    }else{
                    localStorage.setItem("thirdLevelFlag", 0);
                }
                
                if((VTR.Utils.isset(navi.navigate[naviLength-1])) && navi.navigate[naviLength-1].isSeries == true){
                        navi.navigate.pop();
                        seriesBackTemp = false;    
                }

                localStorage.removeItem("premiumSection");
                
                $("body").animate({
                  opacity: 0,
                  scale:1.3,
                  translate3d: '0,-40px,0'
                }, VTR.Properties.transitionTime, 'ease-in', function(){
                    $.ajax({
                        url: url,
                        success: function(data){
                            $('body').html(data).animate({
                                opacity:1,
                                translate3d: '0,0,0'
                            }, VTR.Properties.transitionTime, 'ease-out');

//                            if (VTR.Properties.titlesMenu.match(/BUSCAR/gi)){
//                                VTR.UI.renderKeyboard();
//                                VTR.UI.renderListSearchResults({firstCarrousel: true});
//                            }
                        },
                        error: function(xhr, errorType, error){
                            console.log('Error:' + error + ':' + xhr.responseText);
                        }
                    });
                });
                evt.preventDefault();
                break;

            case KEYS.LEFT:
                // Rest stars in rating
                if($('#calification').is(':nth-child(2)')) {
                    // Rest stars in rating
                    if(positionRating > '1'){
                        var restRating = parseInt(positionRating) - 1;
                        rating.attr({alt:restRating});
                        rating.attr({class:'star' + restRating});
                        $('#rating').attr({class:'star' + restRating});
                        nameRating();
                    } else if(positionRating == '1') {
                        var sumRating = 3;
                        rating.attr({alt:sumRating});
                        rating.attr({class:'star' + sumRating});
                        $('#rating').attr({class:'star' + sumRating});
                        nameRating();
                    }
                         
                }else if(isSeries != '' && VTR.Utils.isset(isSeries)){
                    $('nav ul li:nth-child(1)').removeClass('active');
                    $('#focusEdge').css('width', $('nav .mask ul>li').css('width'));
                    //$('article ul li:nth-child(1)').removeClass('active');
                    $('section#detail-rent-movie').attr('style','opacity:0.3');
                    $('.border-menu').hide();
                    $('#player').removeClass('active');
                    mode = 'navseries';
		}
                break;
            case KEYS.RIGHT:
                if($('#calification').is(':nth-child(2)')) {
                    // Rest stars in rating
                    if(positionRating < '3'){
                        var sumRating = parseInt(positionRating) + 1;
                        rating.attr({alt:sumRating});
                        rating.attr({class:'star' + sumRating});
                        $('#rating').attr({class:'star' + sumRating});
                        nameRating();
                    } else if(positionRating == '3') {
                        var sumRating = 1;
                        rating.attr({alt:sumRating});
                        rating.attr({class:'star' + sumRating});
                        $('#rating').attr({class:'star' + sumRating});
                        nameRating();
                    }
                }
                break;
            case KEYS.PLAY:
            case KEYS.P:
                var assetId = $('section#detail-rent-movie article:nth-child(3) nav ul > li:nth-child(2)').data('asset-id');
                assetId = VTR.Utils.isset(assetId) ? assetId : $('section#section-options ul > li:nth-child(2)').data('asset-id');
                var bookmark = $('section#detail-rent-movie article:nth-child(3) nav ul > li:nth-child(2)').data('bookmark');
                var entitlementState = $('section#detail-rent-movie article:nth-child(3) nav ul > li:nth-child(2)').data('entitlement-state');
                var wishlist = $('[id^="wishlist"]').attr('href');
                var titleId = $('section#detail-rent-movie article:nth-child(3) nav ul > li:nth-child(2)').data('crid');
                var titleName = $('#title-name').text();
                var categoryName = $('#category-name').text();
                var serieName = $('#serie-name').text();
                serieName = VTR.Utils.isset(serieName) ? serieName : $('section#section-options ul > li:nth-child(2)').data('categoryname');
                var serieId = $('#serie-name').data('serieid');
                serieId = VTR.Utils.isset(serieId) ? serieId : $('section#section-options ul > li:nth-child(2)').data('categoryid');
                var itemId = $('section#detail-rent-movie article:nth-child(3) nav ul > li:nth-child(2)').attr('id');
                itemId = VTR.Utils.isset(itemId) ? itemId : $('section#section-options ul > li:nth-child(2)').attr('id');
                var episode = $('section#detail-rent-movie article:nth-child(3) nav ul > li:nth-child(2)').data('episode');
                var selSeason = $('section#detail-rent-movie article:nth-child(3) nav ul > li:nth-child(2)').data('selseason');
                selSeason = VTR.Utils.isset(selSeason) ? selSeason : $('section#section-options ul > li:nth-child(2)').data('selseason');
                var selEpisode = $('section#detail-rent-movie article:nth-child(3) nav ul > li:nth-child(2)').data('crid');
                //var selEpisode = $('section#detail-rent-movie article:nth-child(3) nav ul > li:nth-child(2)').data('selepisode');
                selEpisode = VTR.Utils.isset(selEpisode) ? selEpisode : $('section#section-options ul > li:nth-child(2)').data('selepisode');
                var isSeries = $('section#detail-rent-movie article:nth-child(3) nav ul > li:nth-child(2)').data('isseries');
                isSeries = VTR.Utils.isset(isSeries) ? isSeries : $('section#section-options ul > li:nth-child(2)').data('isseries');
                isSeries = VTR.Utils.isset(isSeries) ? isSeries : false;
                
                localStorage.setItem('selEpisode_concurrencia', selEpisode);
                localStorage.setItem('selSeason_concurrencia', selSeason);
                localStorage.setItem('titleId_concurrencia', titleId);
                localStorage.setItem('titleName_concurencia', titleName);
                localStorage.setItem('categoryName_concurencia', categoryName);

                switch(itemId) {
                    case "player":
                        if(VTR.Utils.isset(assetId)) {
                            if ((bookmark > 0) && (entitlementState == 'Entitled') && (isSeries == true)) {
                                $.ajax({
                                    url: 'html/detail-transition.html',
                                    success: function(d){
                                        $('body').html(d).animate({
                                            opacity:1,
                                            translate3d: '0,0,0'
                                        }, VTR.Properties.transitionTime, 'ease-out');

                                        localStorage.setItem('returnKey'+VTR.Account.cpeId, 'transitionplayer');
                                        localStorage.setItem('returnData'+VTR.Account.cpeId, JSON.stringify({'status': 'transitionplayer', 'message': '', 'categoryId': serieId, 'categoryName': serieName, 'isSerie': isSeries, 'selSeason': selSeason, 'selEpisode': selEpisode, 'navi': navi.navigate}));
                                        VTR.UI.renderTransitionPlayer({titleId: titleId, episodeName: episode.name, assetId: assetId, bookmark: bookmark, isSeries: isSeries, entitlementState: entitlementState});
                                    },
                                    error: function(xhr, errorType, error){
                                        console.log('Error:' + error + ':' + xhr.responseText);
                                    }
                               });
                            } else {
                                if ((bookmark == 0) || (isSeries == false)) {
                                    localStorage.setItem('returnKey'+VTR.Account.cpeId, 'play');
                                    if (isSeries == true) {
                                        localStorage.setItem('returnData'+VTR.Account.cpeId, JSON.stringify({'status': 'play', 'message': '', 'categoryId': serieId, 'categoryName': serieName, 'isSerie': isSeries, 'selSeason': selSeason, 'selEpisode': selEpisode, 'navi': navi.navigate}));
                                    } else {
                                        localStorage.setItem('returnData'+VTR.Account.cpeId, JSON.stringify({'status': 'play', 'message': '', 'titleId': wishlist, 'categoryName': categoryName, 'navi': navi.navigate}));
                                    }
                                    VTR.Utils.openAsset(assetId,bookmark);
                                    av.tracker.track('click', {'title': titleName, 'page': '[REPRODUCIR]'});
                                }
                            }
                        }
                        break;
                    case "transitionplayer":
                        localStorage.setItem('returnKey'+VTR.Account.cpeId, 'play');
                        if (isSeries == true) {
                            localStorage.setItem('returnData'+VTR.Account.cpeId, JSON.stringify({'status': 'play', 'message': '', 'categoryId': serieId, 'categoryName': serieName, 'isSerie': isSeries, 'selSeason': selSeason, 'selEpisode': selEpisode, 'navi': navi.navigate}));
                        } else {
                            localStorage.setItem('returnData'+VTR.Account.cpeId, JSON.stringify({'status': 'play', 'message': '', 'titleId': wishlist, 'categoryName': categoryName, 'navi': navi.navigate}));
                        }
                        VTR.Utils.openAsset(assetId,bookmark);
                        av.tracker.track('click', {'title': titleName, 'page': '[REPRODUCIR]'});
                        break;
                }
                break;                
            case KEYS.ENTER:
            case KEYS.OK:
                var checkLink = $('section#detail-rent-movie article:nth-child(3) nav ul > li:nth-child(2)').attr('id');
                var trailer = $('#trailer').data('asset-id');
                var player = $('#player').attr('href');
                var wishlist = $('[id^="wishlist"]').attr('href');
                var itemId = $('section#detail-rent-movie article:nth-child(3) nav ul > li:nth-child(2)').attr('id');
                itemId = VTR.Utils.isset(itemId) ? itemId : $('section#section-options ul > li:nth-child(2)').attr('id');
                var titleId = $('section#detail-rent-movie article:nth-child(3) nav ul > li:nth-child(2)').data('crid');
                var assetid = $('section#detail-rent-movie article:nth-child(3) nav ul > li:nth-child(2)').data('asset-id');
                assetid = VTR.Utils.isset(assetid) ? assetid : $('section#section-options ul > li:nth-child(2)').data('asset-id');
                var bookmark = $('section#detail-rent-movie article:nth-child(3) nav ul > li:nth-child(2)').data('bookmark');
                bookmark = VTR.Utils.isset(bookmark) ? bookmark : $('section#section-options ul > li:nth-child(2)').data('bookmark');
                var entitlementState = $('section#detail-rent-movie article:nth-child(3) nav ul > li:nth-child(2)').data('entitlement-state');
                var isSeries = $('section#detail-rent-movie article:nth-child(3) nav ul > li:nth-child(2)').data('isseries');
                isSeries = VTR.Utils.isset(isSeries) ? isSeries : $('section#section-options ul > li:nth-child(2)').data('isseries');
                isSeries = VTR.Utils.isset(isSeries) ? isSeries : false;
                var episode = $('section#detail-rent-movie article:nth-child(3) nav ul > li:nth-child(2)').data('episode');
                var selSeason = $('section#detail-rent-movie article:nth-child(3) nav ul > li:nth-child(2)').data('selseason');
                selSeason = VTR.Utils.isset(selSeason) ? selSeason : $('section#section-options ul > li:nth-child(2)').data('selseason');
                var selEpisode = $('section#detail-rent-movie article:nth-child(3) nav ul > li:nth-child(2)').data('crid');
                //var selEpisode = $('section#detail-rent-movie article:nth-child(3) nav ul > li:nth-child(2)').data('selepisode');
                selEpisode = VTR.Utils.isset(selEpisode) ? selEpisode : $('section#section-options ul > li:nth-child(2)').data('selepisode');
                var categoryName = $('#category-name').text();
                var serieName = $('#serie-name').text();
                serieName = VTR.Utils.isset(serieName) ? serieName : $('section#section-options ul > li:nth-child(2)').data('categoryname');
                var serieId = $('#serie-name').data('serieid');
                serieId = VTR.Utils.isset(serieId) ? serieId : $('section#section-options ul > li:nth-child(2)').data('categoryid');
                if(VTR.Utils.isset(serieId) == false){
                    var serieId = sessionStorage.getItem("categoryId");
                }
                var titleName = $('#title-name').text();
                var calif = $('#rating-menu').attr('alt');
                
                localStorage.setItem('selEpisode_concurrencia', selEpisode);
                localStorage.setItem('selSeason_concurrencia', selSeason);
                localStorage.setItem('titleId_concurrencia', titleId);
                localStorage.setItem('titleName_concurencia', titleName);
                localStorage.setItem('categoryName_concurencia', categoryName);

                switch(itemId) {
                    case "calification":
                        if(calif == '2') {
                            VTR.TA.learnActionForTA({'titleId': wishlist, 'action': VTR.ActionType.like});
                        }
                        else if(calif == '3') {
                            VTR.TA.learnActionForTA({'titleId': wishlist, 'action': VTR.ActionType.dislike});
                        }
                        else {}
                        break;
                    case "recommendations":
                        var miVod = categoryName.replace("MI VOD / ", "");
                        VTR.Utils.doNavigate(titleId, miVod,'','true');
                        VTR.Utils.doNavigate(titleId, 'RECOMENDACIONES','','false');
                        sessionStorage.setItem('director', $('#director').text());
                        sessionStorage.setItem('actors', $('#actors').text());
                        $("body").animate({
                          opacity: 0,
                          scale:1.3,
                          translate3d: '0,-40px,0'
                        }, VTR.Properties.transitionTime, 'ease-in', function(){
                            $.ajax({
                                url: "index.html",
                                success: function(data){
                                    $('body').html(data).animate({
                                        opacity:1,
                                        translate3d: '0,0,0'
                                    }, VTR.Properties.transitionTime, 'ease-out');
                                },
                                error: function(xhr, errorType, error){
                                    console.log('Error:' + error + ':' + xhr.responseText);
                                }
                            });
                        });
                        mode = 'carrousels';
                        //VTR.UI.renderRecommendations({'titleId': wishlist});
                        //VTR.TA.learnActionForTA({'titleId': wishlist, 'action': VTR.ActionType.favourite});                        
                        break;
                    case "wishlist-add":
                        mode = "skipMovieDetail";
                        VTR.UI.renderSetMyWishList({profileId: VTR.Account.profileId, titleId: wishlist});
                        VTR.TA.learnActionForTA({'titleId': wishlist, 'action': VTR.ActionType.favourite});
                        av.tracker.track('click', {'title': titleName, 'page': '[AGREGAR A MI LISTA]'});
                        break;
                    case "wishlist-del":
                        mode = "skipMovieDetail";
                        VTR.UI.renderDeleteMyWishList({profileId: VTR.Account.profileId, titleId: wishlist});                    
                        av.tracker.track('click', {'title': titleName, 'page': '[QUITAR A MI LISTA]'});
                        break;
                    case "trailer":
                        localStorage.setItem('returnKey'+VTR.Account.cpeId, 'play');
                        localStorage.setItem('returnData'+VTR.Account.cpeId, JSON.stringify({'status': 'play', 'message': '', 'titleId': wishlist, 'categoryName': categoryName, 'navi': navi.navigate}));
                        VTR.Utils.openAsset(trailer);
                        av.tracker.track('click', {'title': titleName, 'page': '[TRAILER]'});
                        break;
                    case "player":
                        if ((bookmark > 0) && (entitlementState == 'Entitled') && (isSeries == true)) {
                            $.ajax({
                                url: 'html/detail-transition.html',
                                success: function(d){
                                    $('body').html(d).animate({
                                        opacity:1,
                                        translate3d: '0,0,0'
                                    }, VTR.Properties.transitionTime, 'ease-out');

                                    localStorage.setItem('returnKey'+VTR.Account.cpeId, 'transitionplayer');
                                    localStorage.setItem('returnData'+VTR.Account.cpeId, JSON.stringify({'status': 'transitionplayer', 'message': '', 'categoryId': serieId, 'categoryName': serieName, 'isSerie': isSeries, 'selSeason': selSeason, 'selEpisode': selEpisode, 'navi': navi.navigate}));
                                    VTR.UI.renderTransitionPlayer({titleId: titleId, episodeName: episode.name, assetId: assetid, bookmark: bookmark, isSeries: isSeries, entitlementState: entitlementState, categoryId: serieId, categoryName: serieName, selSeason: selSeason, selEpisode: selEpisode});
                                },
                                error: function(xhr, errorType, error){
                                    console.log('Error:' + error + ':' + xhr.responseText);
                                }
                           });
                        } else {
                            if ((bookmark == 0) || (isSeries == false)) {
                                localStorage.setItem('returnKey'+VTR.Account.cpeId, 'play');
                                if (isSeries == true) {
                                    localStorage.setItem('returnData'+VTR.Account.cpeId, JSON.stringify({'status': 'play', 'message': '', 'categoryId': serieId, 'categoryName': serieName, 'isSerie': isSeries, 'selSeason': selSeason, 'selEpisode': selEpisode, 'navi': navi.navigate}));
                                } else {
                                    localStorage.setItem('returnData'+VTR.Account.cpeId, JSON.stringify({'status': 'play', 'message': '', 'titleId': wishlist, 'categoryName': categoryName, 'navi': navi.navigate}));
                                }
                                VTR.Utils.openAsset(assetid,bookmark);
                                av.tracker.track('click', {'title': titleName, 'page': '[REPRODUCIR]'});
                            }
                        }
                        break;
                    case "transitionplayer":
                        localStorage.setItem('returnKey'+VTR.Account.cpeId, 'play');
                        if (isSeries == true) {
                            localStorage.setItem('returnData'+VTR.Account.cpeId, JSON.stringify({'status': 'play', 'message': '', 'categoryId': serieId, 'categoryName': serieName, 'isSerie': isSeries, 'selSeason': selSeason, 'selEpisode': selEpisode, 'navi': navi.navigate}));
                        } else {
                            localStorage.setItem('returnData'+VTR.Account.cpeId, JSON.stringify({'status': 'play', 'message': '', 'titleId': wishlist, 'categoryName': categoryName, 'navi': navi.navigate}));
                        }
                        VTR.Utils.openAsset(assetid,bookmark);
                        av.tracker.track('click', {'title': titleName, 'page': '[REPRODUCIR]'});
                        break;
                    case "rent":
                        // Aca va llamada a pre_purchase
                        mode = 'rentPin';
                        var prePurchase = function(){
                            VTR.Rent.validatePurchase(function(result){
                                pintype = 'rent';
                                $.each(result.prePurchase, function(id, data){
                                    if(data.code=='0000'){
                                        //console.log("respuesta prepurchase code OK: " + data.code);
                                        $.ajax({
                                            url: 'html/detail-rent-pin.html',
                                            success: function(data){
                                                $('body').html(data).animate({
                                                    opacity:1,
                                                    translate3d: '0,0,0'
                                                }, VTR.Properties.transitionTime, 'ease-out');
                                                VTR.UI.renderPartialTitle({"titleId": sessionStorage.getItem("titleId")});
                                                mode = 'rentPin';
                                            },
                                            error: function(xhr, errorType, error){
                                                console.log('Error:' + error + ':' + xhr.responseText);
                                            }
                                        });
                                    } else {
                                         //console.log("respuesta prepurchase code NO OK: " + data.code);
                                         $.ajax({
                                                url: 'html/error.html',
                                                success: function(d){
                                                    $('body').html(d).animate({
                                                        opacity:1,
                                                        translate3d: '0,0,0'
                                                    }, VTR.Properties.transitionTime, 'ease-out');
                                                    VTR.UI.renderMessagePage({messageBody: data.msg , messageTitle: 'ERROR AL VALIDAR ARRIENDO', messageButton: 'VOLVER', returnPath: 'html/detail-premium-movie.html'});
                                                    mode = 'message';
                                                },
                                                error: function(xhr, errorType, error){
                                                    console.log('Error:' + error + ':' + xhr.responseText);
                                                }
                                        });
                                    }

                                });
                                }, {productId:sessionStorage.getItem("productId"), customerId:VTR.Account.customerId, cpeId:VTR.Account.cpeId});
                        }
                        if(VTR.Account.purchasePinSet == true) {
                            prePurchase();    
                        }
                        else {
                            $("body").animate({
                              opacity: 0,
                              scale:1.3,
                              translate3d: '0,-40px,0'
                            }, VTR.Properties.transitionTime, 'ease-in', function(){

                                $.ajax({
                                    url: 'html/error.html',
                                    success: function(data){
                                        $('body').html(data).animate({
                                            opacity:1,
                                            translate3d: '0,0,0'
                                        }, VTR.Properties.transitionTime, 'ease-out');
                                        VTR.UI.renderMessagePage({
                                            messageBody: '<div class="text-left">Para arrendar este contenido necesita crear un PIN DE COMPRA.<br/><br/>1. Salga de VOD presionando el botón EXIT de su control remoto.<br/>2. Presione el botón MENÚ dos veces.<br/>3. Seleccione COMPRAS, CREAR PIN y siga las instrucciones en pantalla.</div><br/><span class="leyend">Te recomendamos tomar una fotografía a esta pantalla para poder seguir las instrucciones al salir de VOD.</span>',
                                            messageTitle: 'CÓDIGO UI-2002',
                                            messageButton: 'ACEPTAR',
                                            returnPath: 'html/detail-premium-movie.html',
                                            preloadedCategory: 'gototitle'
                                        });
                                        mode = 'message';
                                    },
                                    error: function(xhr, errorType, error){
                                        console.log('Error:' + error + ':' + xhr.responseText);
                                    }
                                });
                            });  
                        }
                        break;

                }
                break;
        }
    }else if(mode == "rentPin"){
        switch(evt.keyCode){
            case KEYS.ONE:
            case KEYS.TWO:
            case KEYS.THREE:
            case KEYS.FOUR:
            case KEYS.FIVE:
            case KEYS.SIX:
            case KEYS.SEVEN:
            case KEYS.EIGHT:
            case KEYS.NINE:
            case KEYS.ZERO:
                var target = evt.srcElement;
                var maxLength = 0;
                if(target.type == "password") {
                    target.value = String.fromCharCode(evt.keyCode);
                    maxLength = parseInt(target.attributes["maxlength"].value, 10);
                }
                var myLength = target.value.length;
                if (myLength == maxLength) {
                    var next = target;
                    while (next = next.nextElementSibling) {
                        if (next == null) {
                            break;
                        }
                        if (next.tagName.toLowerCase() == "input") {
                            next.focus();
                            break;
                        }
                    }
                }
                evt.preventDefault();
                break;
            case KEYS.LEFT:
            case KEYS.REWIND:
                var target = evt.srcElement;
                var prev = target;
                while(prev = prev.previousElementSibling) {
                    if(prev == null) {
                        break;
                    }
                    if(prev.tagName.toLowerCase() == "input") {
                        if(prev.type == "password") {
                            prev.value = "";                    
                        }
                        prev.focus();
                        break;
                    }
                }
                evt.preventDefault();
                break;
            //----------TA-----------
            case KEYS.B:
            case KEYS.BLUE:
            case KEYS.BUTTON_B:
                localStorage.removeItem("term"+VTR.Account.cpeId);
                VTR.Utils.doNavigate('[SEARCH]','BUSCAR','','false');
                $("body").animate({
                  opacity: 0,
                  scale:1.3,
                  translate3d: '0,-40px,0'
                }, VTR.Properties.transitionTime, 'ease-in', function(){
                    $.ajax({
                        url: "html/search.html",
                        success: function(data){
                            $('body').html(data).animate({
                                opacity:1,
                                translate3d: '0,0,0'
                            }, VTR.Properties.transitionTime, 'ease-out');
                            VTR.UI.renderKeyboard();
                        },
                        error: function(xhr, errorType, error){
                            console.log('Error:' + error + ':' + xhr.responseText);
                        }
                    });
                });
                mode = 'search'; 
                evt.preventDefault();
                break;
            //----------TA-----------
            case KEYS.EXIT:
            case KEYS.BACK:
            case KEYS.LAST:
            case KEYS.BUTTON_C:
                //Load new page with Ajax
                sessionStorage.removeItem("searchHasResults");
                var titleId = sessionStorage.getItem("titleId");
                var categoryName = sessionStorage.getItem("categoryName");
                var returnUrl = "";
                if(pintype == "rent") {
                    returnUrl = "html/detail-premium-movie.html#"+titleId;
                    mode = 'detailMovie';
                }
                else {
                    returnUrl = "index.html";
                    mode = "carrousels";
                    navi.navigate.pop();
                }
                //navi.navigate.pop();
                $("body").animate({
                  opacity: 0,
                  scale:1.3,
                  translate3d: '0,-40px,0'
                }, VTR.Properties.transitionTime, 'ease-in', function(){

                    $.ajax({
                        url: returnUrl,
                        success: function(data){
                            $('body').html(data).animate({
                                opacity:1,
                                translate3d: '0,0,0'
                            }, VTR.Properties.transitionTime, 'ease-out');
                            if(pintype == "rent"){
                                VTR.UI.renderTitleDetail({titleId: titleId, categoryName: categoryName});                        
                                // VTR.UI.renderTitleOptions({titleId: titleId});
                            }
                        },
                        error: function(xhr, errorType, error){
                            console.log('Error:' + error + ':' + xhr.responseText);
                        }
                    });
                });
                evt.preventDefault();
                break;

            case KEYS.ENTER:
            case KEYS.OK:
                //Load new page with Ajax
                var inputs = document.querySelectorAll('input[type=password]');
                var pwd = "";
                for(var i = 0; i<inputs.length; i++) {
                  pwd += inputs[i].value;
                }
                if(pwd.length < 4) {
                    $().toastmessage('showToast', {
                        text:'Debe ingresar los 4 dígitos de su PIN.<br><br> <strong>ACEPTAR</strong>',
                        type     : 'none',
                        stayTime : 8000
                    });
                }
                else {
                    if(pintype == 'rent') {
                        av.sessionMgr.sendPIN(pwd, VTR.STB.pinSent, VTR.PIN.Purchase);
                    }
                    else if(pintype == 'adult') {
                        av.sessionMgr.sendPIN(pwd, VTR.STB.pinSent, VTR.PIN.Parental);
                    }
                }
                mode = 'rentPin';
                break;
        }
    }else if(mode == 'message'){
        var ulNavDetail = document.querySelector('ul.nav-detail');
        var lastNavDetail = document.querySelector('ul.nav-detail>li:last-child');
        var firstNavDetail = document.querySelector('ul.nav-detail>li');
        switch(evt.keyCode){
            case KEYS.UP:
                ulNavDetail.insertBefore(lastNavDetail,firstNavDetail);
                evt.preventDefault();
                break;
            case KEYS.DOWN:
                ulNavDetail.appendChild(firstNavDetail);
                evt.preventDefault();
                break;
            case KEYS.EXIT:
            case KEYS.BACK:
            case KEYS.LAST:
            case KEYS.RED:
            case KEYS.BUTTON_C:
                var rk = localStorage.getItem('error_concurrencia');
                var url = "";
                sessionStorage.removeItem("searchHasResults");
                if (VTR.Properties.titlesMenu == "BUSCAR"){
//                  sessionStorage.setItem("debugInfo","search");
                    url = "html/search.html";
                    mode = 'search';
                } else {
                    if(pintype == 'adult') {
                        url = 'html/pin-parental.html';
                        mode = 'rentPin';
                    }
                    else {
                        if(navi.navigate.length > 1 && navi.navigate[0].categoryName != "MI VOD"){
                            if((navi.navigate.length == 3) && (navi.navigate[0].categoryName==VTR.Properties.titleMenuPremium)) {
                                localStorage.setItem("thirdLevelFlag", 1);
                            }else{
                                localStorage.setItem("thirdLevelFlag", 0);
                            }
                            url = "index.html";
                            mode = 'carrousels';
                            navi.navigate.pop();
                        }
                        if (rk == 'error'){
                            url = "html/detail-premium-movie.html";
                            localStorage.removeItem('error_concurrencia');
                        }
                        else{
                            sessionStorage.setItem("debugInfo","carrousels");
                            url = "index.html";    
                            VTR.Properties.titlesMenu = "";
                            navi = {"navigate":[]};
                            mode = 'carrousels';
                    }
                    }
                }
                
//              navi.navigate.pop();
                $("body").animate({
                  opacity: 0,
                  scale:1.3,
                  translate3d: '0,-40px,0'
                }, VTR.Properties.transitionTime, 'ease-in', function(){
                    $.ajax({
                        url: url,
                        success: function(data){
                            $('body').html(data).animate({
                                opacity:1,
                                translate3d: '0,0,0'
                            }, VTR.Properties.transitionTime, 'ease-out');

                            if (VTR.Properties.titlesMenu == "BUSCAR"){
                                VTR.UI.renderKeyboard();
                                VTR.UI.renderListSearchResults({firstCarrousel: true, isExact: false, size: VTR.Properties.lienzoSize});
                            }else if (rk == "error"){
                                if (localStorage.getItem('isSeries_concurrencia') == "true") {
                                    VTR.UI.renderTitleDetailSeries({categoryId: localStorage.getItem('primariId'), categoryName: localStorage.getItem('categoryName_concurencia'), isSeries: localStorage.getItem('isSeries_concurrencia'), selSeason: localStorage.getItem('selSeason_concurrencia'), selEpisode: localStorage.getItem('selEpisode_concurrencia'), isCarrusel: true});
                                    mode = 'detailMovie'; 
                                    localStorage.removeItem("titleId_concurrencia");
                                    localStorage.removeItem("categoryName_concurencia");
                                    localStorage.removeItem("titleName_concurencia");
                                    localStorage.removeItem("selEpisode_concurrencia");
                                    localStorage.removeItem("selSeason_concurrencia");
                                    localStorage.removeItem("isSeries_concurrencia"); 
                            } else {
//                                            sessionStorage.setItem('titleId', localStorage('titleId_concurrencia'));
//                                            sessionStorage.setItem('categoryName_concurencia', localStorage('categoryName_concurencia'));
                                    VTR.UI.renderTitleDetail({titleId: localStorage.getItem('titleId_concurrencia'), categoryName: localStorage.getItem('categoryName_concurencia')});
                                    mode = 'detailMovie';
                                    localStorage.removeItem("titleId_concurrencia");
                                    localStorage.removeItem("categoryName_concurencia");
                                    localStorage.removeItem("titleName_concurencia");
                                    localStorage.removeItem("selEpisode_concurrencia");
                                    localStorage.removeItem("selSeason_concurrencia");
                                    localStorage.removeItem("isSeries_concurrencia");      
                            }
                            }
                        },
                        error: function(xhr, errorType, error){
                            console.log('Error:' + error + ':' + xhr.responseText);
                        }
                    });
                });
                evt.preventDefault();
                break;
            case KEYS.ENTER:
            case KEYS.OK:
                var returnPath = $('section#section-options ul > li:nth-child(2)').data('return-path');
                var extraParam = $('section#section-options ul > li:nth-child(2)').data('extra-param');
                $("body").animate({
                  opacity: 0,
                  scale:1.3,
                  translate3d: '0,-40px,0'
                }, VTR.Properties.transitionTime, 'ease-in', function(){
                    $.ajax({
                        url: returnPath,
                        success: function(data){
                            $('body').html(data).animate({
                                opacity:1,
                                translate3d: '0,0,0'
                            }, VTR.Properties.transitionTime, 'ease-out');
                            if(VTR.Utils.isset(extraParam)){
                                if(extraParam == 'message2') {
                                    $.ajax({
                                        url: 'html/error.html',
                                        success: function(data){
                                            $('body').html(data).animate({
                                                opacity:1,
                                                translate3d: '0,0,0'
                                            }, VTR.Properties.transitionTime, 'ease-out');
                                            VTR.UI.renderMessagePage({
                                                messageBody: '<div class="text-left">Para acceder a este contenido necesita crear un PIN CONTROL FAMILIAR.<br/><br/>1. Salga de VOD presionando el botón EXIT de su control remoto.<br/>2. Presione el botón MENÚ dos veces.<br/>3. Seleccione CONTROL FAMILIAR, CREAR PIN y siga las instrucciones en pantalla.</div><br/><span class="leyend">Te recomendamos tomar una fotografía a esta pantalla para poder seguir las instrucciones al salir de VOD.</span>',
                                                messageTitle: 'CÓDIGO UI-2005',
                                                messageButton: 'ACEPTAR',
                                                returnPath: 'index.html'
                                            });
                                            mode = 'message';
                                            navi = {"navigate":[]};
                                        },
                                        error: function(xhr, errorType, error){
                                            console.log('Error:' + error + ':' + xhr.responseText);
                                        }
                                    });

                                }
                                else if(extraParam == 'gototitle') {
                                    VTR.UI.renderTitleDetail({titleId: sessionStorage.getItem('titleId'), categoryName: sessionStorage.getItem('categoryName')});
                                    mode = 'detailMovie';
                                }
                                else if(extraParam == 'concurrence'){
                                    if (localStorage.getItem('isSeries_concurrencia') == "true") {
                                            VTR.UI.renderTitleDetailSeries({categoryId: localStorage.getItem('primariId'), categoryName: localStorage.getItem('categoryName_concurencia'), isSeries: localStorage.getItem('isSeries_concurrencia'), selSeason: localStorage.getItem('selSeason_concurrencia'), selEpisode: localStorage.getItem('selEpisode_concurrencia'), isCarrusel: true});
                                            mode = 'detailMovie'; 
                                            localStorage.removeItem("titleId_concurrencia");
                                            localStorage.removeItem("categoryName_concurencia");
                                            localStorage.removeItem("titleName_concurencia");
                                            localStorage.removeItem("selEpisode_concurrencia");
                                            localStorage.removeItem("selSeason_concurrencia");
                                            localStorage.removeItem("isSeries_concurrencia"); 
                                    } else {
//                                            sessionStorage.setItem('titleId', localStorage('titleId_concurrencia'));
//                                            sessionStorage.setItem('categoryName_concurencia', localStorage('categoryName_concurencia'));
                                            VTR.UI.renderTitleDetail({titleId: localStorage.getItem('titleId_concurrencia'), categoryName: localStorage.getItem('categoryName_concurencia')});
                                            mode = 'detailMovie';
                                            localStorage.removeItem("titleId_concurrencia");
                                            localStorage.removeItem("categoryName_concurencia");
                                            localStorage.removeItem("titleName_concurencia");
                                            localStorage.removeItem("selEpisode_concurrencia");
                                            localStorage.removeItem("selSeason_concurrencia");
                                            localStorage.removeItem("isSeries_concurrencia");      
                                    }
                                }
                                else {
                                    //VTR.Utils.doNavigate(extraParam, 'ADULTOS', '', 'false');
                                    //VTR.UI.renderListSubMenu({categoryId: extraParam, categoryName: 'ADULTOS', isSeries: '', isCarrusel: true});
                                    $('nav .mask ul').removeClass('active');
                                    $('section#frame-carrousels ul').addClass('active');
                                    $('div.foco').show();
                                    //document.getElementById('focusEdge').style.width = "0px";
                                    mode = 'carrousels';                                
                                }
                            }
                            else {
                                if(returnPath == "index.html" || !VTR.Utils.isset(returnPath)) {
                                    navi = {"navigate":[]};
                                    $("body").animate({
                                      opacity: 0,
                                      scale:1.3,
                                      translate3d: '0,-40px,0'
                                    }, VTR.Properties.transitionTime, 'ease-in', function(){
                                        $.ajax({
                                            url: returnPath,
                                            success: function(data){
                                                $('body').html(data).animate({
                                                    opacity:1,
                                                    translate3d: '0,0,0'
                                                }, VTR.Properties.transitionTime, 'ease-out');
                                                mode = "carrousels";
                                            }
                                        });
                                    });
								}
								else {
									if(pintype == 'rent') {
                                        if(returnPath == "html/detail-rent-pin.html") {
                                            VTR.UI.renderPartialTitle({titleId: sessionStorage.getItem('titleId'), categoryName: sessionStorage.getItem('categoryName')});
                                            mode = 'rentPin';
                                        }
                                        else {
                                            VTR.UI.renderTitleDetail({titleId: sessionStorage.getItem('titleId'), categoryName: sessionStorage.getItem('categoryName')});
                                            mode = 'detailMovie';                                
                                        }
									}
									else {
                                        mode = "rentPin";
									}
								}
							}
						},
						error: function(xhr, errorType, error){
							console.log('Error:' + error + ':' + xhr.responseText);
						}
                    });
                });
                evt.preventDefault();
                break;
        }
    }else if(mode == 'search'){//-----SEARCH TA--------
         switch(evt.keyCode){
            case KEYS.BACK:
            case KEYS.LAST:
            case KEYS.RED:
            case KEYS.BUTTON_C:
                var categoryIdName = navi.navigate[navi.navigate.length-1];
                if(categoryIdName.categoryId == '[SEARCH]') {
                    navi.navigate.pop();
                }
                $("body").animate({
                  opacity: 0,
                  scale:1.3,
                  translate3d: '0,-40px,0'
                }, VTR.Properties.transitionTime, 'ease-in', function(){
                    $.ajax({
                        url: "index.html",
                        success: function(data){
                            $('body').html(data).animate({
                                opacity:1,
                                translate3d: '0,0,0'
                            }, VTR.Properties.transitionTime, 'ease-out');
                        }
                    });
                });
                localStorage.removeItem("term"+VTR.Account.cpeId); 
                console.log("Removing session variable searchHasResults...");
                sessionStorage.removeItem("searchHasResults");
                mode = "carrousels";
                evt.preventDefault();
                break;
            case KEYS.B:
            case KEYS.BUTTON_B:
            case KEYS.BLUE:
                setTerm();
                var termSearch = localStorage.getItem("term"+VTR.Account.cpeId);
                if (VTR.Utils.isset(termSearch)){
                    VTR.UI.renderListSearchResults({firstCarrousel: true, isExact: false, size: VTR.Properties.lienzoSize});
                    mode = 'carrousels';
                    // carruselfocus = true;
                    var kb = document.getElementById('keyboardHolder');
                    kb.blur();
                    evt.preventDefault();
                }
                break;
            case KEYS.REWIND:
                 $('#AVKeyboard0p0k28').focus();
                 keyboard.backspace();
                 keyboard.focus(true);
                 evt.preventDefault();
                 evt.stopPropagation();
                 break;
            case KEYS.LEFT:
                 evt.preventDefault();
                 evt.stopPropagation();
                 break;
            case KEYS.RIGHT:
                 var lastButton = keyboard.lastKey.id;
                 if(keyboard.lastKey.navRight == 'button0'){
                     var hasR = sessionStorage.getItem("searchHasResults");
                        if(hasR == 'true') {
                            mode="carrousels";
                            $('.focoRepository').show();
                        }
                     else {
                         keyboard.focus(true);
                     }
                 }
                 evt.preventDefault();
                 evt.stopPropagation();
                 break;
                 
         }
    } //--- FIN SEARCH TA -----
}
var timeoutToast = null;

window.addEventListener('keydown', onKeyDown);

//the called function should trigger a reset on an app-wide timeout
//handleKey
var handleKey = function (evt){
    resetTimeout();
}

//resetTimeout: Manages timeout
//belongs in top-level page. you will also want to trigger this upon onDomReady
var resetTimeout = function () {
    clearTimeout(av.global.timeout); // clear scene timeout
    if(timeoutToast != null) {
        $().toastmessage('removeToast', timeoutToast);
    }
    av.global.timeout = setTimeout(function timeoutWarning() {
        timeoutToast = $().toastmessage('showToast', {
            text     : 'Hemos notado que has dejado de usar VOD, por lo tanto se cerrará dentro de 30 segundos. <br> ¿Desea permanecer en VOD? <br><br> <strong>Sí, permanecer en VOD</strong>',
            sticky   : false,
            type     : 'none',
            stayTime : 30000,
            close    : function () {console.log("toast is closed ...");window.close();VTR.Utils.sessionExit();}
        });
        //INSTEAD of going to a timeout warning page, you may bypass a warning screen altogether and just exit by calling an Exit function (in this example, "exitApp();"
    }, av.config.timeoutWarning);
}

//on any screen for which you would like to detect keypresses, you will have an eventlistener:
window.addEventListener("keydown",handleKey);

$(document).on('ajaxBeforeSend', function(e, xhr, options){
//    xhr.setRequestHeader("Set-Cookie", 'load-balancer-token=7932');
//    options.withCredentials = true;
//    $.cookie('load-balancer-token','7932', {path: ''});
//    av.require('storage.cookies');
        
    //Attempt to retrieve an existing cookie
//    var retrieveCookie;
//    try{
//        retrieveCookie=av.storage.cookies.get("load-balancer-token");
//    }catch(err){
//        console.log("Error getting cookie: "+err.message);
//        retrieveCookie={};
//    };
    
//    var myCookie = av.storage.cookies.set("load-balancer-token","load-balancer-token=6666");
//    
//    console.log(myCookie);
});

$(document).on('ajaxSend', function() {
    $('#loading-text').text('Un momento por favor...');
});

$(document).on('ajaxComplete', function() {
    $('#loading-text').text('');
//    var c = document.cookie;
//    console.log('cookiez:'+c);
});

$(document).on('ajaxStop', function(){

    $('section#frame-carrousels div.foco div.progress').hide();

    var cuantosLi = 0;
    $("nav ul > li").each(function(index) {
        cuantosLi = cuantosLi+1;

    });

    if(cuantosLi < 6){
        $('nav ul').addClass('hide-arrow');
    }
    /* Force to initiate the timer once the app starts, without pressing any button */
    handleKey();
//    console.log(av.path);

switch(mode) {
 case 'carrousels':
//    var naviLength = navi.navigate.length;
//    if(navi.navigate.length == 0 || navi.navigate[naviLength-1].categoryName == "MI VOD" || navi.navigate[naviLength-1].categoryName == "MI CUENTA") {
//        $(VTR.Properties.htmlMyRecommendations).insertAfter("#frame-carrousels > ul > div");
//        $(VTR.Properties.htmlMyWishlist).insertAfter("#frame-carrousels > ul > div");
//        $(VTR.Properties.htmlKeepWatching).insertAfter("#frame-carrousels > ul > div");
//    }
    $("#continua-viendo").insertBefore("#te-recomendamos");
    $("#mi-lista").insertBefore("#te-recomendamos");
    // Marks the first carousel (horizontal) with the class "first" to know when to move to "nav"
    if(!$("#frame-carrousels").hasClass("repository")) {
        $('#frame-carrousels ul.carrousels.active > li:nth-child(2)').addClass('first');
    }
    $('.play-element-fix').css('display','none');
    var playCarrousel = $('section#frame-carrousels ul.carrousels li ul.carrousel > li .play-element').attr('class');
    var continuaViendo = $('section#frame-carrousels ul.carrousels li').attr('id');
    if(playCarrousel == 'play-element' && continuaViendo == 'continua-viendo'){
        $('.play-element-fix').show();
    }
    else {
        $('.play-element-fix').hide();
    }
    progress = $('ul.carrousels > li:nth-child(2) ul li:nth-child(2)').data('progress');
    if(progress == null) {
        progress = $('ul.carrousels > li:nth-child(2) ul li').data('progress');
    }
    if(!VTR.Utils.isset(progress)) {
        $('section#frame-carrousels div.foco div.progress').hide();
    }
    else {
        $('section#frame-carrousels div.foco div.progress').show();
        $('section#frame-carrousels div.foco div.progress').css('width', progress+'%')                    
    }

    /**
     * For lists with less than 8 items, do some cloning
     */
        
     $(function() {
        for(var i=2; i<=7; i++){
            //console.log($('.items'+i));
            var listsWithN = document.querySelectorAll('.items'+i);
            //a list with the class "item1" or "item2" etc
            for(var L=0; L<listsWithN.length; L++){
                var ul = listsWithN[L];
                ul.style.display = 'none';

                var items = ul.querySelectorAll('ul>li');
                var viewportWidth = 0;
                if(VTR.UI.screenFormat == 'HD') {
                    if($("#frame-carrousels").hasClass("repository")) {
                        viewportWidth = 83+(175+10)*i;
                    }
                    else {
                        viewportWidth = 83+(190+20)*i;
                    }

                    if (viewportWidth <= 1280) {
                        ul.parentNode.style.width = viewportWidth+"px";
                    }
                }
                else {
                    if($("#frame-carrousels").hasClass("repository")) {
                        viewportWidth = 42+(103+5)*i;
                    }
                    else {
                        viewportWidth = 42+(112+10)*i;
                    }

                    if (viewportWidth <= 640) {
                        ul.parentNode.style.width = viewportWidth+"px";
                    }
                }
                //we need to duplicate the items so that they
                //are the place holders

                //We need (a) enough clones to fill up 2 spots in front
                //and (b) a multiple of the current number of cells
                //so that we have a clean repeating sequence without skipping any
                //and 1 spot after
                //so Extras >= 3
                //so N*i >= 3
                //so N >= 3/i
                var numClonesNeeded = Math.ceil(3/i);

                var lastItem = items[items.length-1];

                for(var p=0; p<numClonesNeeded*items.length; p++){
                    var item = items[p % items.length];
                    ul.appendChild(item.cloneNode(true));
                }

                //move last 2 to the beginning for animation to have intial place holders
                var firstItem = ul.querySelector('ul>li:first-child');
                var lastItem = ul.querySelector('ul>li:last-child');
                ul.insertBefore(lastItem, firstItem);

                var firstItem = ul.querySelector('ul>li:first-child');
                var lastItem = ul.querySelector('ul>li:last-child');
                ul.insertBefore(lastItem, firstItem);

                console.log(i, "Started with " + items.length + ", and now we have " + ul.querySelectorAll('ul>li').length);

                ul.style.display = null;
            }


        }

    });

    // Duplicar carruseles cuando hay tres o menos carruseles
    $(function ()
    {
        // Obtener todos los carruseles
        var carrousels = document.querySelectorAll (".carrousels > li");
        // Verificar límite
        if (carrousels.length >= 4 || carrousels.length <= 1) { // Parche para el carrusel del buscador
            return; 
        }

        // Duplicar todos
        var contenedor = document.querySelector (".carrousels");
        for (i = 0; i < carrousels.length; i++)
        {
            var item = carrousels [i];
            contenedor.appendChild(item.cloneNode(true));
        }
    });
        
    if(sessionStorage.getItem("searchHasResults") == "true") {
        mode = "search";
    }
    break;

    case 'detailMovie':
    case 'message':
        // Duplicar ítems en barra de navegación detalle de película cuándo hay 8 o menos elementos
        $(function() {
            // Obtener todos los carruseles
            var carrousels = document.querySelectorAll (".nav-detail > li");
            console.log(carrousels);
            
            // Añadir clase para mascara
            if(carrousels.length == 2){
                $(".nav-detail").addClass('nav-2-items')
            }; 
            if(carrousels.length == 3){
                $(".nav-detail").addClass('nav-3-items')
            }; 
            if(carrousels.length == 4){
                $(".nav-detail").addClass('nav-4-items')
            }; 
            if(carrousels.length == 5){
                $(".nav-detail").addClass('nav-5-items')
            }; 
            if(carrousels.length == 6){
                $(".nav-detail").addClass('nav-6-items')
            }; 

            // Verificar límite
            if (carrousels.length >= 8)
                return;
            // Duplicar todos
            var contenedor = document.querySelector (".nav-detail");
            for (i = 0; i < carrousels.length; i++)
            {
                var item = carrousels [i];
                contenedor.appendChild(item.cloneNode(true));
            };
        });
        break;
        
    case 'skipMovieDetail':
        mode = "detailMovie";
        break;
    
    case 'search':
//        keyboard.focus();
        break;
    case 'rentPin':
        break;
}

});
