/*
	NAME: VTR.Messages
	DESCRIPTION:
*/

VTR.Messages = {
    code0000: {code: '0000', type: 'Success', msg: 'Operacion ejecutada correctamente', detail: 'Operation has been successful'},

    //documentado
    //OLD code1000
	//code1000: {code: '1000', type: 'Error', msg: 'Su d BOX presenta problemas por favor llamar al 600 800 9000. (Código AD-2005)', detail: 'Customer Info not available'},
    //new code1000
    code1000: {code: '1000', type: 'Excepción', msg: '<span class="tittle">CÓDIGO AD-2005</span><br><br>No fue posible arrendar este contenido, por favor reintente. Si persiste el problema llame al 600 800 9000 e indique el código AD-2005. Disculpe las molestias. ', detail: 'No se obtuvo información de cliente, requerida para efectuar arriendo.'},

    //documentado
    //OLD code1001
	//{code: '1001', type: 'Error', msg: 'Su d BOX presenta problemas por favor llamar al 600 800 9000. (Código AD-2006)', detail: 'OfferId not available'},
    //new code1001
    code1001: {code: '1001', type: 'Excepción', msg: '<span class="tittle">CÓDIGO AD-2006</span><br><br>No fue posible ver este contenido, por favor intente más tarde o llame al 600 800 9000 e indique el código AD-2006. Disculpe las molestias.', detail: 'No se encontró oferta para el contenido.'},

    //documentado
    //OLD code1002
	//code1002: {code: '1002', type: 'Error', msg: 'Su d BOX presenta problemas por favor llamar al 600 800 9000. (Código AD-2000)', detail: 'Cliente se encuentra en Cobranza. IsBarred = true'},
	//new code1002
    code1002: {code: '1002', type: 'Excepción', msg: '<span class="tittle">CÓDIGO AD-2000</span><br><br>Estimado cliente su cuenta presenta problemas, por favor ingrese a Sucursal Virtual a través de www.vtr.com.', detail: 'Cliente se encuentra en Cobranza. (Validación isBarred = true).'},

    //documentado
    //OLD code1003
    //code1003: {code: '1003', type: 'Error', msg: 'Su d BOX presenta problemas por favor llamar al 600 800 9000. (Código AD-2001)', detail: 'No se ha podido realizar el arriendo. Expenditure Exceeded'},
    //NEW code1003
    code1003: {code: '1003', type: 'Excepción', msg: '<span class="tittle">CÓDIGO AD-2001</span><br><br>No es posible realizar arriendos desde su d-BOX, por favor llame al 600 800 9000 opción 2 e indique el código AD-2001. ', detail: 'Cliente no tiene cupo suficiente. (Expenditure Exceeded).'},

    //documentado
    //OLD code1004
    // code1004: {code: '1004', type: 'Error', msg: 'Su d BOX presenta problemas por favor llamar al 600 800 9000. (Código AD-2007)', detail: 'Caja no provisionada en Adrenalin. Invalid STB Id'},
    //NEW code1004
    code1004: {code: '1004', type: 'Excepción', msg: '<span class="tittle">CÓDIGO AD-2007</span><br><br>Se ha producido un error en nuestro sistema. Por favor llame al 600 800 9000 e indique el código AD-2007. Disculpe las molestias.', detail: 'Caja no provisionada en Adrenalin. (Invalid STB Id).'},

    //documentado
    //OLD code1005
    //code1005: {code: '1005', type: 'Error', msg: 'Su d BOX presenta problemas por favor llamar al 600 800 9000. (Código AD-3002)', detail: 'Error en la llamada a Traxis.'},
    //NEW code1005
    code1005: {code: '1005', type: 'Error', msg: '<span class="tittle">CÓDIGO AD-3002</span><br><br>Se ha producido un error en nuestro sistema, por favor inténtelo nuevamente. Si el error se mantiene llame al 600 800 9000 e indique el código AD-3002. Disculpe las molestias.', detail: 'Error se produjo en plataforma Adrenalin, recuperando información de categorías.'},


    //documentado
    //OLD code1006
    //code1006: {code: '1006', type: 'Error', msg: 'Su d BOX presenta problemas por favor llamar al 600 800 9000. (Código UI-10000)', detail: 'Error no especificado.'},
    //NEW code1006
    code1006: {code: '1006', type: 'Error', msg: '<span class="tittle">CÓDIGO UI-10000</span><br><br> Se ha producido un error en nuestro sistema, por favor ingrese más tarde. Disculpe las molestias.', detail: 'No es posible determinar la causa.'},
    code1019: {code: '1019', type: 'Error', msg: '<span class="tittle">CÓDIGO UI-10001</span><br><br>Se ha producido un problema al cargar el catalogo. Por favor llamar al 600 800 9000.', detail: 'No se encuentra recurso buscado (no existe categroía o título).'},
    
    
    //Mensajes nuevos para instanciar y que están en el documento de ERRORES Y EXCEPCIONES UI AVNV2.1

    //EXCEPCIONES CONTROLADAS [2000]
    code1007: {code: '1007', type: 'Excepción', msg: 'Su PIN de arriendo no se encuentra configurado. (Código UI-2002)', detail: 'Rent PIN no seteado en STB.'},
    code1008: {code: '1008', type: 'Excepción', msg: '<span class="tittle">CÓDIGO UI-2003</span><br><br>El PIN DE COMPRA ingresado no es correcto. Por favor ingréselo nuevamente. ', detail: 'Rent PIN incorrecto.'},
    code1009: {code: '1009', type: 'Excepción', msg: '<span class="tittle">CÓDIGO UI-2004</span><br><br>El PIN CONTROL FAMILIAR ingresado no es correcto. Por favor inténtelo nuevamente.', detail: 'Adult PIN incorrecto.'},
    code1018: {code: '1018', type: 'Excepción', msg: '<span class="tittle">Código UI-2008</span><br><br>Este contenido ya fue arrendado. Para poder verlo vuelva a ingresar a la ficha.', detail: 'Product already Entitled.'},

    //ERROR PLATAFORMA ADRENALIN [3000]
    code1010: {code: '1010', type: 'Error', msg: '<span class="tittle">CÓDIGO AD-3000</span><br><br>Se ha producido un error en nuestro sistema, por favor inténtelo nuevamente. Si el error se mantiene llame al 600 800 9000 e indique el código AD-3000. Disculpe las molestias.', detail: 'Error se produjo en plataforma Adrenalin, recuperando información de CPE. (sesión).'},
    code1011: {code: '1011', type: 'Error', msg: '<span class="tittle">CÓDIGO AD-3001</span><br><br>Se ha producido un error en nuestro sistema, por favor inténtelo nuevamente. Si el error se mantiene llame al 600 800 9000 e indique el código AD-3001. Disculpe las molestias.', detail: 'Error se produjo en plataforma Adrenalin, recuperando información de contenido. (ficha).'},
    code1012: {code: '1012', type: 'Error', msg: '<span class="tittle">CÓDIGO AD-3003</span><br><br>No se ha podido agregar el contenido a MI LISTA. Por favor vuelva a intentarlo más tarde. Si el error persiste llame al 600 800 9000 e indique el código AD-3003. Disculpe las molestias.', detail: 'Error se produjo al intentar agregar o quitar contenido a Mi lista.'},
    code1013: {code: '1013', type: 'Error', msg: '<span class="tittle">CÓDIGO AD-3004</span><br><br>No es posible arrendar el contenido seleccionado. Por favor vuelva a intentarlo más tarde. Si persiste llame al 600 800 9000 e indique el código AD-3004. Disculpe las molestias.', detail: 'Error se produjo al Arrendar contenido.'},

    code1020: {code: '1020', type: 'Error', msg: 'No fue posible reproducir este contenido...<br><br>1. Verifique si se encuentra en reproducción en otros d-BOX de su hogar, para verlo aquí debe detener una de ellas.<br><br>2. De lo contrario, por favor intente reproduciendo el contenido desde MI VOD/MI CUENTA/MIS ARRIENDOS o llame al 600 800 9000 e indique código AD-3005.', detail: 'Error de concurrencia.'},

    code1021: {code: '1021', type: 'Error', msg: 'Se ha producido un error al intentar validar el PIN, por favor ingréselo nuevamente. Si persiste el error llame al 600 800 9000 e informe el error UI-5000. Disculpe las molestias.', detail: 'Falla en la comunicación entre AVN UI y STB.'},

    //ERROR PLATAFORMA THINK ANALYTICS [4000]
    code1014: {code: '1014', type: 'Error', msg: '<span class="tittle">CÓDIGO TA-4000</span><br><br>Se ha producido un error en la búsqueda, por favor vuelva a intentarlo más tarde. Disculpe las molestias.', detail: 'Error se produjo en plataforma Think Analytics.'},
    code1015: {code: '1015', type: 'Error', msg: '<span class="tittle">CÓDIGO TA-4001</span><br><br>Se ha producido un error al intentar cargar las recomendaciones, por favor vuelva a intentarlo más tarde. Disculpe las molestias.', detail: 'Error se produjo en plataforma Think Analytics.'},
    code1016: {code: '1016', type: 'Error', msg: '<span class="tittle">CÓDIGO TA-4002</span><br><br>Se ha producido un error en nuestro sistema, por favor ingrese más tarde. Disculpe las molestias.', detail: 'Error se produjo en plataforma Think Analytics al grabar learn action.'},

    //ERROR PLATAFORMA STB [5000]
    code1017: {code: '1017', type: 'Error', msg: '<span class="tittle">CÓDIGO UI-5000</span><br><br>Se ha producido un error al intentar validar el PIN, por favor ingréselo nuevamente. Si persiste el error llame al 600 800 9000 e informe el error UI-5000. Disculpe las molestias.', detail: 'Falla en la comunicación entre AVN UI y STB.'}

}

