/*
	NAME: VTR.Catalog
	DESCRIPTION:

	options: {customerId: VTR.Account.customerId,	cpeId: VTR.Account.cpeId, profileId: VTR.Account.profileId,	categoryId: "", titleId: "", isCarrusel: true, position: 1}
*/

VTR.Catalog = {
	parentCategories:[],
	filteredCategories:[],
	childCategories:[],
	contentCategories:[],
	contentByCategory:[]
}
/* 
    Function to get top menu from root categories grabbing the category called AVN
*/
VTR.Catalog.getListMenu = function(callback, options){
	var urlGetParentCategories  = VTR.Properties.traxisProxy + '/' + VTR.Traxis.urlBodyRequest;
	var output = {"listmenu":[]};
	var bodyReq = "";
	bodyReq += "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
	bodyReq += "<Request xmlns=\"urn:eventis:traxisweb:1.0\">";
	bodyReq += "  <RootRelationQuery relationName=\"RootCategories\">";
//	bodyReq += "    <Options>";
//	bodyReq += "      <Option type=\"Limit\">100</Option>";
//	bodyReq += "    </Options>";
	bodyReq += "    <SubQueries>";
	bodyReq += "      <SubQuery relationName=\"ChildCategories\">";
	bodyReq += "        <Options>";
	bodyReq += "		  <Option type=\"filter\">Name^AVN</Option>";
	bodyReq += "        </Options>";
	bodyReq += "        <SubQueries>";
	bodyReq += "          <SubQuery relationName=\"ChildCategories\">";
	bodyReq += "            <Options>";
	bodyReq += "      	 	  <Option type=\"Props\">Name,TitleCount,IsAdult,ShortSynopsis,CustomProperties</Option>";
	bodyReq += "      	 	  <Option type=\"Sort\">Ordinal</Option>";
	bodyReq += "      	 	  <Option type=\"Filter\">Name!=Nigel</Option>";
	bodyReq += "            </Options>";
	bodyReq += "          </SubQuery>";
	bodyReq += "        </SubQueries>";
	bodyReq += "      </SubQuery>";
	bodyReq += "    </SubQueries>";
	bodyReq += "  </RootRelationQuery>";
	bodyReq += "</Request>";
    $.post(urlGetParentCategories, bodyReq, function(data, status, xhr){
		eval("VTR.Catalog.parentCategories = " + JSON.stringify(data));
        try {
            $.each(VTR.Catalog.parentCategories, function(i1, d1){
                $.each(d1.Category, function(i2, d2){
                    $.each(d2.ChildCategories.Category, function(i3, d3){
                        $.each(d3.ChildCategories.Category, function(i4, d4) {
                            output.listmenu.push({
                                'id': d4.id,
                                'name': d4.Name.toUpperCase(),
                                'childCategories': d4.ChildCategoryCount,
                                'isAdult': d4.IsAdult,
                                //'isSeries': (VTR.Utils.isset(d4.ShortSynopsis) ? d4.ShortSynopsis : "")
                                'isSeries': (VTR.Utils.isset(d4.CustomProperties) ? VTR.Utils.getHrefCustomProperty(d4.CustomProperties, VTR.Properties.seriesHrefCustomProperty) : "")
                            });					
                        });
                    });
                });
            });
            callback(output);
        }
        catch (err) {
            console.log('Error AVN API: '+err.message);
        }
    }).fail(function(xhr, errorType, error){
        VTR.Utils.handleErrorFromTraxis(xhr.response);
    	console.log('xhr:' + JSON.stringify(xhr.response) + ' - ' + 'error:' + error);
    }).done(function(data, status, xhr){
    	console.log('data:' + data + ' - ' + 'status:' + status);
        var cookie = document.cookie;
        console.log(decodeURI(cookie));
    });
}

/* 
    Function to get top menu from root categories using softlink for AVN
*/
VTR.Catalog.getListMenu1 = function(callback, options){
	var urlGetParentCategories  = VTR.Properties.traxisProxy + '/' + VTR.Traxis.urlBodyRequest;
	var output = {"listmenu":[]};
	var bodyReq = "";
	bodyReq += "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
	bodyReq += "<Request xmlns=\"urn:eventis:traxisweb:1.0\">";
	bodyReq += "  <RootRelationQuery relationName=\"RootCategories\">";
	bodyReq += "    <Options>";
	bodyReq += "      <Option type=\"props\" resourceType=\"Category\">SoftLinks</Option>";
	bodyReq += "    </Options>";
	bodyReq += "  </RootRelationQuery>";
	bodyReq += "</Request>";
    var idAlias = "";
    $.post(urlGetParentCategories, bodyReq, function(data, status, xhr){
        try {
            $.each(data.Categories.Category, function(ix,dx){
                $.each(dx.SoftLinks.SoftLink, function(i0,d0){
                    if(d0.qualifier == 'AVN_Store') {
                        idAlias = d0.id;
                    }
                })
            });
        }
        catch (err) {
            console.log('Error AVN API: '+err.message);
        }
        var bodyReq2 = "";
        bodyReq2 += "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n";
        bodyReq2 += "<Request xmlns=\"urn:eventis:traxisweb:1.0\">\n";
        bodyReq2 += "  <ResourceQuery resourceType=\"Category\" resourceId=\""+idAlias+"\" aliasType=\"VodBackOfficeId\">\n";
        bodyReq2 += "    <Options>\n";
        bodyReq2 += "      <Option type=\"props\">Name</Option>\n";
        bodyReq2 += "    </Options>\n";
        bodyReq2 += "    <SubQueries>\n";
        bodyReq2 += "      <SubQuery relationName=\"ChildCategories\">\n";
        bodyReq2 += "        <Options>\n";
        bodyReq2 += "          <Option type=\"sort\">Ordinal</Option>\n";
//        bodyReq2 += "          <Option type=\"filter\">ContainsContentViewableOnCpe==true</Option>\n";
        bodyReq2 += "          <Option type=\"props\">Name,TitleCount,IsAdult,ShortSynopsis,CustomProperties</Option>\n";
        bodyReq2 += "        </Options>\n";
        bodyReq2 += "      </SubQuery>\n";
        bodyReq2 += "    </SubQueries>\n";
        bodyReq2 += "  </ResourceQuery>\n";
        bodyReq2 += "</Request>\n";

        $.post(urlGetParentCategories, bodyReq2, function(d1, status, xhr){
            try {
                $.each(d1.Category.ChildCategories.Category, function(i2, d2) {
                    output.listmenu.push({
                        'id': d2.id,
                        'name': d2.Name.toUpperCase(),
                        'childCategories': d2.ChildCategoryCount,
                        'isAdult': d2.IsAdult,
                        //'isSeries': (VTR.Utils.isset(d2.ShortSynopsis) ? d2.ShortSynopsis : "")
                        'isSeries': (VTR.Utils.isset(d2.CustomProperties) ? VTR.Utils.getHrefCustomProperty(d2.CustomProperties, VTR.Properties.seriesHrefCustomProperty) : "")
                    });					
                });
                callback(output);
            }
            catch (err) {
                console.log('Error AVN API: '+err.message);
            }
            
        }).fail(function(xhr, errorType, error){
            VTR.Utils.handleErrorFromTraxis(xhr.response);
            console.log('xhr:' + JSON.stringify(xhr.response) + ' - ' + 'error:' + error);
        }).done(function(data, status, xhr){
            console.log('data:' + data + ' - ' + 'status:' + status);
        });
    }).fail(function(xhr, errorType, error){
        VTR.Utils.handleErrorFromTraxis(xhr.response);
    	console.log('xhr:' + JSON.stringify(xhr.response) + ' - ' + 'error:' + error);
    }).done(function(data, status, xhr){
    	console.log('data:' + data + ' - ' + 'status:' + status);
        var cookie = document.cookie;
        console.log(decodeURI(cookie));
    });
}

VTR.Catalog.getListCategories = function(callback, options){
	var urlGetChildCategories = VTR.Properties.traxisProxy + '/' + VTR.Traxis.urlBodyRequest;
    //urlGetChildCategories = urlGetChildCategories.replace('{{CATEGORY_ID}}', VTR.Utils.replaceAll(options.categoryId, "/", "~~2F" ));
	var output = {"listcategories":[]};

	var bodyReq = "";
	bodyReq += "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
	bodyReq += "<Request xmlns=\"urn:eventis:traxisweb:1.0\">";
//	bodyReq += "  <Identity>";
//	bodyReq += "    <CpeId>"+VTR.Account.cpeId+"</CpeId>";
//	bodyReq += "  </Identity>";
	bodyReq += "  <RelationQuery resourceType=\"Category\" resourceId=\"" + options.categoryId + "\" relationName=\"ChildCategories\">";
	bodyReq += "    <Options>";
//	bodyReq += "      <Option type=\"Limit\">100</Option>";
	bodyReq += "      <Option type=\"Props\">Name,TitleCount,IsAdult,ShortSynopsis,CustomProperties</Option>";
	bodyReq += "	  <Option type=\"filter\">ContainsContentViewableOnCpe==true</Option>";
	bodyReq += "	  <Option type=\"Sort\">Name</Option>";
	bodyReq += "    </Options>";
	bodyReq += "  </RelationQuery>";
	bodyReq += "</Request>";
	$.post(urlGetChildCategories, bodyReq, function(data, text, xhr){
        try {
            eval("VTR.Catalog.childCategories = " + JSON.stringify(data));
            $.each(VTR.Catalog.childCategories.Categories.Category, function(i, d){
                output.listcategories.push({
                    'id': d.id,
                    'name': d.Name.toUpperCase(),
                    'titlesCount': d.TitleCount,
                    'childCategoryCount': d.ChildCategoryCount,
                    'isAdult': d.IsAdult,
                    //'isSeries': (VTR.Utils.isset(d.ShortSynopsis) ? d.ShortSynopsis : "")
                    'isSeries': (VTR.Utils.isset(d.CustomProperties) ? VTR.Utils.getHrefCustomProperty(d.CustomProperties, VTR.Properties.seriesHrefCustomProperty) : "")
                });					
            });
            callback(output);
//            console.log('all-headers:'+xhr.getAllResponseHeaders());
//            console.log('cookie:'+xhr.getResponseHeader('Cookie'));
//            console.log('set-cookie:'+xhr.getResponseHeader('Set-Cookie'));
        }
        catch(err) {
            console.log('Error AVN API: '+err.message);
        }
    }).fail(function(xhr, errorType, error){
        VTR.Utils.handleErrorFromTraxis(xhr.response);
    	console.log('xhr:' + JSON.stringify(xhr.response) + ' - ' + 'error:' + error);
    }).done(function(data, status, xhr){
    	console.log('data:' + data + ' - ' + 'status:' + status);
	});
}

VTR.Catalog.getTitlesAndChildrenByCategory = function(callback, options){
	var urlContentByCategory = VTR.Properties.traxisProxy + '/' + VTR.Traxis.urlBodyRequest;

	var bodyReq = "";
	var output = {categoryId: options.categoryId ,"categoryName": options.categoryName, "titlesCount": options.titlesCount, isSeries: options.isSeries, "listtitleschildren":[]};
	bodyReq += "<Request xmlns=\"urn:eventis:traxisweb:1.0\">\n";
	bodyReq += "  <Identity>\n";
	bodyReq += "    <CpeId>"+VTR.Account.cpeId+"</CpeId>\n";
	bodyReq += "  </Identity>\n";
	bodyReq += "  <ResourceQuery resourceType=\"category\" resourceId=\""+options.categoryId+"\">\n";
	bodyReq += "    <Options>\n";
	bodyReq += "      <Option type=\"props\">Name,ChildCategories,TitleCount,IsAdult,ShortSynopsis</Option>\n";
	bodyReq += "    </Options>\n";
	bodyReq += "    <SubQueries>\n";
	bodyReq += "      <SubQuery relationName=\"titles\">\n";
	bodyReq += "        <Options>\n";
	bodyReq += "          <Option type=\"filter\">Contents.ProductCount&gt;0&amp;&amp;IsPreview==false&amp;&amp;IsViewableOnCpe==true&amp;&amp;Contents&gt;0</Option>\n";
	bodyReq += "          <Option type=\"sort\">Name</Option>\n";
	bodyReq += "          <Option type=\"limit\">"+options.size+"</Option>\n";
	bodyReq += "          <Option type=\"props\">Name,Categories,Pictures,ShortName,Contents,ContentCount,SeriesCount,Bookmark,DurationInSeconds</Option>\n";
	bodyReq += "        </Options>\n";
	bodyReq += "        <SubQueries>\n";
	bodyReq += "          <SubQuery relationName=\"contents\">\n";
	bodyReq += "            <Options>\n";
	bodyReq += "              <Option type=\"filter\">ProductCount&gt;0&amp;&amp;FirstAvailability&lt;=now()&amp;&amp;LastAvailability&gt;=now()</Option>\n";
	bodyReq += "              <Option type=\"props\">Aliases,IsHD,Is3D</Option>\n";
	bodyReq += "            </Options>\n";
	bodyReq += "            <SubQueries>\n";
	bodyReq += "              <SubQuery relationName=\"products\">\n";
	bodyReq += "                <Options>\n";
	bodyReq += "                  <Option type=\"props\">Type,EntitlementState,EntitlementEnd</Option>\n";
	bodyReq += "                </Options>\n";
	bodyReq += "              </SubQuery>\n";
	bodyReq += "            </SubQueries>\n";
	bodyReq += "          </SubQuery>\n";
	bodyReq += "        </SubQueries>\n";
	bodyReq += "      </SubQuery>\n";
	bodyReq += "      <SubQuery relationName=\"childcategories\">\n";
	bodyReq += "        <Options>\n";
	bodyReq += "          <Option type=\"sort\">Name</Option>\n";
	bodyReq += "          <Option type=\"props\">Name,ChildCategories,TitleCount,IsAdult,ShortSynopsis</Option>\n";
	bodyReq += "        </Options>\n";
	bodyReq += "        <SubQueries>\n";
	bodyReq += "          <SubQuery relationName=\"titles\">\n";
	bodyReq += "            <Options>\n";
	bodyReq += "              <Option type=\"filter\">Contents.ProductCount&gt;0&amp;&amp;IsPreview==false&amp;&amp;IsViewableOnCpe==true&amp;&amp;Contents&gt;0</Option>\n";
	bodyReq += "              <Option type=\"props\">Name,Categories,Pictures,ShortName,Contents,ContentCount,SeriesCount,Bookmark,DurationInSeconds</Option>\n";
	bodyReq += "              <Option type=\"limit\">1</Option>\n";
	bodyReq += "            </Options>\n";
	bodyReq += "            <SubQueries>\n";
	bodyReq += "              <SubQuery relationName=\"contents\">\n";
	bodyReq += "                <Options>\n";
	bodyReq += "                  <Option type=\"filter\">ProductCount&gt;0&amp;&amp;FirstAvailability&lt;=now()&amp;&amp;LastAvailability&gt;=now()</Option>\n";
	bodyReq += "                  <Option type=\"props\">Aliases,IsHD,Is3D</Option>\n";
	bodyReq += "                </Options>\n";
	bodyReq += "                <SubQueries>\n";
	bodyReq += "                  <SubQuery relationName=\"products\">\n";
	bodyReq += "                    <Options>\n";
	bodyReq += "                      <Option type=\"props\">Type,EntitlementState,EntitlementEnd</Option>\n";
	bodyReq += "                    </Options>\n";
	bodyReq += "                  </SubQuery>\n";
	bodyReq += "                </SubQueries>\n";
	bodyReq += "              </SubQuery>\n";
	bodyReq += "            </SubQueries>\n";
	bodyReq += "          </SubQuery>\n";
//	bodyReq += "          <SubQuery relationName=\"childcategories\">\n";
//	bodyReq += "            <Options>\n";
//	bodyReq += "              <Option type=\"sort\">Name</Option>\n";
//	bodyReq += "              <Option type=\"props\">Name,TitleCount,IsAdult,ShortSynopsis</Option>\n";
//	bodyReq += "            </Options>\n";
//	bodyReq += "            <SubQueries>\n";
//	bodyReq += "              <SubQuery relationName=\"titles\">\n";
//	bodyReq += "                <Options>\n";
//	bodyReq += "                  <Option type=\"filter\">IsPreview==false&amp;&amp;IsViewableOnCpe==true&amp;&amp;Contents&gt;0</Option>\n";
//	bodyReq += "                  <Option type=\"props\">Name,Categories,Pictures,ShortName,Contents,ContentCount,SeriesCount,Bookmark,DurationInSeconds</Option>\n";
//	bodyReq += "                </Options>\n";
//	bodyReq += "                <SubQueries>\n";
//	bodyReq += "                  <SubQuery relationName=\"contents\">\n";
//	bodyReq += "                    <Options>\n";
//	bodyReq += "                      <Option type=\"filter\">Products&gt;0</Option>\n";
//	bodyReq += "                      <Option type=\"props\">Aliases,IsHD,Is3D</Option>\n";
//	bodyReq += "                    </Options>\n";
//	bodyReq += "                    <SubQueries>\n";
//	bodyReq += "                      <SubQuery relationName=\"products\">\n";
//	bodyReq += "                        <Options>\n";
//	bodyReq += "                          <Option type=\"props\">Type,EntitlementState,EntitlementEnd</Option>\n";
//	bodyReq += "                        </Options>\n";
//	bodyReq += "                      </SubQuery>\n";
//	bodyReq += "                    </SubQueries>\n";
//	bodyReq += "                  </SubQuery>\n";
//	bodyReq += "                </SubQueries>\n";
//	bodyReq += "              </SubQuery>\n";
//	bodyReq += "            </SubQueries>\n";
//	bodyReq += "          </SubQuery>\n";
	bodyReq += "        </SubQueries>\n";
	bodyReq += "      </SubQuery>\n";
	bodyReq += "    </SubQueries>\n";
	bodyReq += "  </ResourceQuery>\n";
	bodyReq += "</Request>\n";
    
	$.post(urlContentByCategory, bodyReq, function(data){
		eval("VTR.Catalog.contentCategories = " + JSON.stringify(data));
        try {
//            $.each(data.Category.ChildCategories.Category, function(i1, d1){
                if(VTR.Utils.isset(data.Category.Titles)) {
                    $.each(data.Category.Titles.Title, function(i, d){
                        var isSeries = false;
                        var img = null;
                        var pics = (VTR.Utils.isset(d.Pictures) ? d.Pictures.Picture : "");
                        if (pics){
                            $.each(pics, function(ix,dx) {
                                if(dx.type == 'BoxCover') {
                                    img = dx.Value.replace("http://" + VTR.Properties.posterServerName + "/", "http://" + VTR.Properties.posterServer + "/");
                                    return false;
                               }
                                else {
                                    img = dx.Value.replace("http://" + VTR.Properties.posterServerName + "/", "http://" + VTR.Properties.posterServer + "/");
                                }
                            });
                        }
                        if (VTR.Utils.isset(d.SeriesCount)){
                            if (d.SeriesCount > 0){
                                isSeries = true;
                            }
                        }
                        output.listtitleschildren.push({
                            categoryId : 'CATEGORY_ID',
                            subcategoryId : 'SUB_CATEGORY_ID',
                            titleId : d.id,
                            name : (VTR.UI.screenFormat == "HD" ? d.ShortName.substring(0, 18) : d.ShortName.substring(0, VTR.Properties.titleMaxSize)),
                            is3D : d.Contents.Content[0].Is3D,
                            isHD : d.Contents.Content[0].IsHD,
                            pictureUri : img,
                            contentType : (VTR.Utils.isset(d.Contents.Content[0].Products) ? d.Contents.Content[0].Products.Product[0].Type : ''),
                            bookmark: (VTR.Utils.isset(d.Bookmark) ? d.Bookmark : "0"),
                            duration: d.DurationInSeconds,
                            assetId: d.Contents.Content[0].Aliases.Alias[0].Value,
                            LastViewDate: d.LastViewDate,
                            contentId: d.Contents.Content[0].id,
                            entitlementState: d.Contents.Content[0].Products.Product[0].EntitlementState,
                            entitlementEnd: d.Contents.Content[0].Products.Product[0].EntitlementEnd
                        });
                    });
                }
                var total = output.listtitleschildren.length;
                if(VTR.Utils.isset(data.Category.ChildCategories)) {
                    $.each(data.Category.ChildCategories.Category, function(ix, dx){
                        if(VTR.Utils.isset(dx.Titles)) {
                            $.each(dx.Titles.Title, function(i3, d3){
                                var isSeries = false;
                                var img = null;
                                var pics = d3.Pictures.Picture;
                                if (pics){
                                    $.each(pics, function(ix,dx) {
                                        if(dx.type == 'BoxCover') {
                                            img = dx.Value.replace("http://" + VTR.Properties.posterServerName + "/", "http://" + VTR.Properties.posterServer + "/");
                                            return false;
                                       }
                                        else {
                                            img = dx.Value.replace("http://" + VTR.Properties.posterServerName + "/", "http://" + VTR.Properties.posterServer + "/");
                                        }
                                    });
                                }
                                if (VTR.Utils.isset(d3.SeriesCount)){
                                    if (d3.SeriesCount > 0){
                                        isSeries = true;
                                    }
                                }
                                if(total < (VTR.Properties.carruselSize - 1)) {
                                    output.listtitleschildren.push({
                                        categoryId : 'CATEGORY_ID',
                                        subcategoryId : 'SUB_CATEGORY_ID',
                                        titleId : d3.id,
                                        name : (VTR.UI.screenFormat == "HD" ? d3.ShortName.substring(0, 18) : d3.ShortName.substring(0, VTR.Properties.titleMaxSize)),
                                        is3D : d3.Contents.Content[0].Is3D,
                                        isHD : d3.Contents.Content[0].IsHD,
                                        pictureUri : img,
                                        contentType : (VTR.Utils.isset(d3.Contents.Content[0].Products) ? d3.Contents.Content[0].Products.Product[0].Type : ''),
                                        bookmark: (VTR.Utils.isset(d3.Bookmark) ? d3.Bookmark : "0"),
                                        duration: d3.DurationInSeconds,
                                        assetId: d3.Contents.Content[0].Aliases.Alias[0].Value,
                                        LastViewDate: d3.LastViewDate,
                                        contentId: d3.Contents.Content[0].id,
                                        entitlementState: d3.Contents.Content[0].Products.Product[0].EntitlementState,
                                        entitlementEnd: d3.Contents.Content[0].Products.Product[0].EntitlementEnd
                                    }); 
                                    total++;
                                }
                            });
                        }
                    });
                }
//            });
        }
        catch (err) {
            console.log('Error AVN API: '+err.message);
        }
        callback(output);
    }).fail(function(xhr, errorType, error){
        VTR.Utils.handleErrorFromTraxis(xhr.response);
    	console.log('xhr:' + JSON.stringify(xhr.response) + ' - ' + 'error:' + error);
    }).done(function(data, status, xhr){
//    	console.log('data:' + data + ' - ' + 'status:' + status + ', h:'+xhr.getAllResponseHeaders());
	});
}

VTR.Catalog.getListCategoriesAndTitles = function(callback, options){
	var urlContentByCategory = VTR.Properties.traxisProxy + '/' + VTR.Traxis.urlBodyRequest;

	var bodyReq = "";
	var output = {categoryId: options.categoryId ,"categoryName": options.categoryName, "titlesCount": options.titlesCount, isSeries: options.isSeries, "cats":[]};
    var titlesCount = 0;
    var titlesCatCount = 0;
	bodyReq += "<Request xmlns=\"urn:eventis:traxisweb:1.0\">\n";
	bodyReq += "  <Identity>\n";
	bodyReq += "    <CpeId>"+VTR.Account.cpeId+"</CpeId>\n";
	bodyReq += "  </Identity>\n";
	bodyReq += "  <ResourceQuery resourceType=\"category\" resourceId=\""+options.categoryId+"\">\n";
	bodyReq += "    <Options>\n";
	bodyReq += "      <Option type=\"props\">Name,ChildCategories,ChildCategoryCount,TitleCount,IsAdult,ShortSynopsis,CustomProperties</Option>\n";
	bodyReq += "    </Options>\n";
	bodyReq += "    <SubQueries>\n";
	bodyReq += "      <SubQuery relationName=\"titles\">\n";
	bodyReq += "        <Options>\n";
	bodyReq += "          <Option type=\"filter\">Contents.ProductCount&gt;0&amp;&amp;IsPreview==false&amp;&amp;IsViewableOnCpe==true&amp;&amp;ContentCount&gt;0</Option>\n";
	bodyReq += "          <Option type=\"sort\">Name</Option>\n";
	bodyReq += "          <Option type=\"limit\">"+options.size+"</Option>\n";
	bodyReq += "          <Option type=\"props\">Name,Categories,Pictures,ShortName,Contents,ContentCount,SeriesCount,Bookmark,DurationInSeconds</Option>\n";
	bodyReq += "        </Options>\n";
	bodyReq += "        <SubQueries>\n";
	bodyReq += "          <SubQuery relationName=\"contents\">\n";
	bodyReq += "            <Options>\n";
	bodyReq += "              <Option type=\"filter\">ProductCount&gt;0&amp;&amp;FirstAvailability&lt;=now()&amp;&amp;LastAvailability&gt;=now()</Option>\n";
	bodyReq += "              <Option type=\"props\">Aliases,IsHD,Is3D</Option>\n";
	bodyReq += "            </Options>\n";
	bodyReq += "            <SubQueries>\n";
	bodyReq += "              <SubQuery relationName=\"products\">\n";
	bodyReq += "                <Options>\n";
	bodyReq += "                  <Option type=\"props\">Type,EntitlementState,EntitlementEnd</Option>\n";
	bodyReq += "                </Options>\n";
	bodyReq += "              </SubQuery>\n";
	bodyReq += "            </SubQueries>\n";
	bodyReq += "          </SubQuery>\n";
	bodyReq += "        </SubQueries>\n";
	bodyReq += "      </SubQuery>\n";
	bodyReq += "      <SubQuery relationName=\"childcategories\">\n";
	bodyReq += "        <Options>\n";
	bodyReq += "          <Option type=\"sort\">Name</Option>\n";
	bodyReq += "          <Option type=\"props\">Name,ChildCategories,TitleCount,IsAdult,ShortSynopsis,CustomProperties</Option>\n";
	bodyReq += "        </Options>\n";
	bodyReq += "        <SubQueries>\n";
	bodyReq += "          <SubQuery relationName=\"titles\">\n";
	bodyReq += "            <Options>\n";
	bodyReq += "              <Option type=\"filter\">Contents.ProductCount&gt;0&amp;&amp;IsPreview==false&amp;&amp;IsViewableOnCpe==true&amp;&amp;Contents&gt;0</Option>\n";
	bodyReq += "              <Option type=\"props\">Name,Categories,Pictures,ShortName,Contents,ContentCount,SeriesCount,Bookmark,DurationInSeconds</Option>\n";
	bodyReq += "              <Option type=\"limit\">"+options.size+"</Option>\n";
	bodyReq += "            </Options>\n";
	bodyReq += "            <SubQueries>\n";
	bodyReq += "              <SubQuery relationName=\"contents\">\n";
	bodyReq += "                <Options>\n";
	bodyReq += "                  <Option type=\"filter\">ProductCount&gt;0&amp;&amp;FirstAvailability&lt;=now()&amp;&amp;LastAvailability&gt;=now()</Option>\n";
	bodyReq += "                  <Option type=\"props\">Aliases,IsHD,Is3D</Option>\n";
	bodyReq += "                </Options>\n";
	bodyReq += "                <SubQueries>\n";
	bodyReq += "                  <SubQuery relationName=\"products\">\n";
	bodyReq += "                    <Options>\n";
	bodyReq += "                      <Option type=\"props\">Type,EntitlementState,EntitlementEnd</Option>\n";
	bodyReq += "                    </Options>\n";
	bodyReq += "                  </SubQuery>\n";
	bodyReq += "                </SubQueries>\n";
	bodyReq += "              </SubQuery>\n";
	bodyReq += "            </SubQueries>\n";
	bodyReq += "          </SubQuery>\n";
	bodyReq += "          <SubQuery relationName=\"childcategories\">\n";
	bodyReq += "            <Options>\n";
	bodyReq += "              <Option type=\"sort\">Name</Option>\n";
	bodyReq += "              <Option type=\"props\">Name,TitleCount,IsAdult,ShortSynopsis</Option>\n";
	bodyReq += "            </Options>\n";
	bodyReq += "            <SubQueries>\n";
	bodyReq += "              <SubQuery relationName=\"titles\">\n";
	bodyReq += "                <Options>\n";
	bodyReq += "                  <Option type=\"filter\">Contents.ProductCount&gt;0&amp;&amp;IsPreview==false&amp;&amp;IsViewableOnCpe==true&amp;&amp;Contents&gt;0</Option>\n";
	bodyReq += "                  <Option type=\"props\">Name,Categories,Pictures,ShortName,Contents,ContentCount,SeriesCount,Bookmark,DurationInSeconds</Option>\n";
	bodyReq += "                  <Option type=\"limit\">"+options.size+"</Option>\n";
	bodyReq += "                </Options>\n";
	bodyReq += "                <SubQueries>\n";
	bodyReq += "                  <SubQuery relationName=\"contents\">\n";
	bodyReq += "                    <Options>\n";
	bodyReq += "                      <Option type=\"filter\">ProductCount&gt;0&amp;&amp;FirstAvailability&lt;=now()&amp;&amp;LastAvailability&gt;=now()</Option>\n";
	bodyReq += "                      <Option type=\"props\">Aliases,IsHD,Is3D</Option>\n";
	bodyReq += "                    </Options>\n";
	bodyReq += "                    <SubQueries>\n";
	bodyReq += "                      <SubQuery relationName=\"products\">\n";
	bodyReq += "                        <Options>\n";
	bodyReq += "                          <Option type=\"props\">Type,EntitlementState,EntitlementEnd</Option>\n";
	bodyReq += "                        </Options>\n";
	bodyReq += "                      </SubQuery>\n";
	bodyReq += "                    </SubQueries>\n";
	bodyReq += "                  </SubQuery>\n";
	bodyReq += "                </SubQueries>\n";
	bodyReq += "              </SubQuery>\n";
	bodyReq += "              <SubQuery relationName=\"childcategories\">\n";
	bodyReq += "                <Options>\n";
	bodyReq += "                  <Option type=\"sort\">Name</Option>\n";
	bodyReq += "                  <Option type=\"props\">Name,TitleCount,IsAdult,ShortSynopsis</Option>\n";
	bodyReq += "                </Options>\n";
	bodyReq += "                <SubQueries>\n";
	bodyReq += "                  <SubQuery relationName=\"titles\">\n";
	bodyReq += "                    <Options>\n";
	bodyReq += "                      <Option type=\"filter\">Contents.ProductCount&gt;0&amp;&amp;IsPreview==false&amp;&amp;IsViewableOnCpe==true&amp;&amp;Contents&gt;0</Option>\n";
	bodyReq += "                      <Option type=\"props\">Name,Categories,Pictures,ShortName,Contents,ContentCount,SeriesCount,Bookmark,DurationInSeconds</Option>\n";
	bodyReq += "                      <Option type=\"limit\">"+options.size+"</Option>\n";
	bodyReq += "                    </Options>\n";
	bodyReq += "                    <SubQueries>\n";
	bodyReq += "                      <SubQuery relationName=\"contents\">\n";
	bodyReq += "                        <Options>\n";
	bodyReq += "                          <Option type=\"filter\">ProductCount&gt;0&amp;&amp;FirstAvailability&lt;=now()&amp;&amp;LastAvailability&gt;=now()</Option>\n";
	bodyReq += "                          <Option type=\"props\">Aliases,IsHD,Is3D</Option>\n";
	bodyReq += "                        </Options>\n";
	bodyReq += "                        <SubQueries>\n";
	bodyReq += "                          <SubQuery relationName=\"products\">\n";
	bodyReq += "                            <Options>\n";
	bodyReq += "                              <Option type=\"props\">Type,EntitlementState,EntitlementEnd</Option>\n";
	bodyReq += "                            </Options>\n";
	bodyReq += "                          </SubQuery>\n";
	bodyReq += "                        </SubQueries>\n";
	bodyReq += "                      </SubQuery>\n";
	bodyReq += "                    </SubQueries>\n";
	bodyReq += "                  </SubQuery>\n";
	bodyReq += "                </SubQueries>\n";
	bodyReq += "              </SubQuery>\n";
	bodyReq += "            </SubQueries>\n";
	bodyReq += "          </SubQuery>\n";
	bodyReq += "        </SubQueries>\n";
	bodyReq += "      </SubQuery>\n";
	bodyReq += "    </SubQueries>\n";
	bodyReq += "  </ResourceQuery>\n";
	bodyReq += "</Request>\n";
    
	$.post(urlContentByCategory, bodyReq, function(data){
		eval("VTR.Catalog.contentCategories = " + JSON.stringify(data));
        try {
            if(VTR.Utils.isset(data.Category.ChildCategories)) { 
                $.each(data.Category.ChildCategories.Category, function(i1, d1){
                    output.cats.push({
                        'categoryId': d1.id,
                        'categoryName': d1.Name.toUpperCase(),
                        'titlesCount': d1.TitleCount,
                        'childCategoryCount': d1.ChildCategoryCount,
                        'isAdult': d1.IsAdult,
                        //'isSeries': (VTR.Utils.isset(d.ShortSynopsis) ? d.ShortSynopsis : "")
                        'isSeries': (VTR.Utils.isset(d1.CustomProperties) ? VTR.Utils.getHrefCustomProperty(d1.CustomProperties, VTR.Properties.seriesHrefCustomProperty) : ""),
                        'listtitleschildren': []
                    });					

                    if(VTR.Utils.isset(d1.Titles)) {
                        $.each(d1.Titles.Title, function(i, d2){
                            var isSeries = false;
                            var img = null;
                            var pics = (VTR.Utils.isset(d2.Pictures) ? d2.Pictures.Picture : "");
                            if (pics){
                                $.each(pics, function(ix,dx) {
                                    if(dx.type == 'BoxCover') {
                                        img = dx.Value.replace("http://" + VTR.Properties.posterServerName + "/", "http://" + VTR.Properties.posterServer + "/");
                                        return false;
                                   }
                                    else {
                                        img = dx.Value.replace("http://" + VTR.Properties.posterServerName + "/", "http://" + VTR.Properties.posterServer + "/");
                                    }
                                });
                            }
                            if (VTR.Utils.isset(d2.SeriesCount)){
                                if (d2.SeriesCount > 0){
                                    isSeries = true;
                                }
                            }
                            output.cats[i1].listtitleschildren.push({
                                categoryId : 'CATEGORY_ID',
                                subcategoryId : 'SUB_CATEGORY_ID',
                                titleId : d2.id,
                                name : (VTR.UI.screenFormat == "HD" ? d2.ShortName.substring(0, 18) : d2.ShortName.substring(0, VTR.Properties.titleMaxSize)),
                                is3D : d2.Contents.Content[0].Is3D,
                                isHD : d2.Contents.Content[0].IsHD,
                                pictureUri : img,
                                contentType : (VTR.Utils.isset(d2.Contents.Content[0].Products) ? d2.Contents.Content[0].Products.Product[0].Type : ''),
                                bookmark: (VTR.Utils.isset(d2.Bookmark) ? d2.Bookmark : "0"),
                                duration: d2.DurationInSeconds,
                                assetId: d2.Contents.Content[0].Aliases.Alias[0].Value,
                                LastViewDate: d2.LastViewDate,
                                contentId: d2.Contents.Content[0].id,
                                entitlementState: d2.Contents.Content[0].Products.Product[0].EntitlementState,
                                entitlementEnd: d2.Contents.Content[0].Products.Product[0].EntitlementEnd
                            });
                            titlesCount++;
                            titlesCatCount++;
                        });
                    }
                    var total = output.cats[i1].listtitleschildren.length;
                    if(VTR.Utils.isset(d1.ChildCategories)) {
                        $.each(d1.ChildCategories.Category, function(i3, d3){
                            if(VTR.Utils.isset(d3.Titles)) {
                                $.each(d3.Titles.Title, function(i4, d4){
                                    var isSeries = false;
                                    var img = null;
                                    var pics = (VTR.Utils.isset(d4.Pictures) ? d4.Pictures.Picture : "");
                                    if (pics){
                                        $.each(pics, function(ix,dx) {
                                            if(dx.type == 'BoxCover') {
                                                img = dx.Value.replace("http://" + VTR.Properties.posterServerName + "/", "http://" + VTR.Properties.posterServer + "/");
                                                return false;
                                           }
                                            else {
                                                img = dx.Value.replace("http://" + VTR.Properties.posterServerName + "/", "http://" + VTR.Properties.posterServer + "/");
                                            }
                                        });
                                    }
                                    if (VTR.Utils.isset(d4.SeriesCount)){
                                        if (d4.SeriesCount > 0){
                                            isSeries = true;
                                        }
                                    }
                                    if(total < (VTR.Properties.carruselSize - 1)) {
                                        output.cats[i1].listtitleschildren.push({
                                            categoryId : 'CATEGORY_ID',
                                            subcategoryId : 'SUB_CATEGORY_ID',
                                            titleId : d4.id,
                                            name : (VTR.UI.screenFormat == "HD" ? d4.ShortName.substring(0, 18) : d4.ShortName.substring(0, VTR.Properties.titleMaxSize)),
                                            is3D : d4.Contents.Content[0].Is3D,
                                            isHD : d4.Contents.Content[0].IsHD,
                                            pictureUri : img,
                                            contentType : (VTR.Utils.isset(d4.Contents.Content[0].Products) ? d4.Contents.Content[0].Products.Product[0].Type : ''),
                                            bookmark: (VTR.Utils.isset(d4.Bookmark) ? d4.Bookmark : "0"),
                                            duration: d4.DurationInSeconds,
                                            assetId: d4.Contents.Content[0].Aliases.Alias[0].Value,
                                            LastViewDate: d4.LastViewDate,
                                            contentId: d4.Contents.Content[0].id,
                                            entitlementState: d4.Contents.Content[0].Products.Product[0].EntitlementState,
                                            entitlementEnd: d4.Contents.Content[0].Products.Product[0].EntitlementEnd
                                        }); 
                                        total++;
                                        titlesCount++;
                                        titlesCatCount++;
                                    }
                                });
                            }
                            if(VTR.Utils.isset(d3.ChildCategories)) {
                                $.each(d3.ChildCategories.Category, function(i5, d5){
                                    if(VTR.Utils.isset(d5.Titles)) {
                                        $.each(d5.Titles.Title, function(i6, d6){
                                            var isSeries = false;
                                            var img = null;
                                            var pics = (VTR.Utils.isset(d6.Pictures) ? d6.Pictures.Picture : "");
                                            if (pics){
                                                $.each(pics, function(iz,dz) {
                                                    if(dz.type == 'BoxCover') {
                                                        img = dz.Value.replace("http://" + VTR.Properties.posterServerName + "/", "http://" + VTR.Properties.posterServer + "/");
                                                        return false;
                                                   }
                                                    else {
                                                        img = dz.Value.replace("http://" + VTR.Properties.posterServerName + "/", "http://" + VTR.Properties.posterServer + "/");
                                                    }
                                                });
                                            }
                                            if (VTR.Utils.isset(d6.SeriesCount)){
                                                if (d5.SeriesCount > 0){
                                                    isSeries = true;
                                                }
                                            }
                                            if(total < (VTR.Properties.carruselSize - 1)) {
                                                output.cats[i1].listtitleschildren.push({
                                                    categoryId : 'CATEGORY_ID',
                                                    subcategoryId : 'SUB_CATEGORY_ID',
                                                    titleId : d6.id,
                                                    name : (VTR.UI.screenFormat == "HD" ? d6.ShortName.substring(0, 18) : d6.ShortName.substring(0, VTR.Properties.titleMaxSize)),
                                                    is3D : d6.Contents.Content[0].Is3D,
                                                    isHD : d6.Contents.Content[0].IsHD,
                                                    pictureUri : img,
                                                    contentType : (VTR.Utils.isset(d6.Contents.Content[0].Products) ? d6.Contents.Content[0].Products.Product[0].Type : ''),
                                                    bookmark: (VTR.Utils.isset(d6.Bookmark) ? d6.Bookmark : "0"),
                                                    duration: d6.DurationInSeconds,
                                                    assetId: d6.Contents.Content[0].Aliases.Alias[0].Value,
                                                    LastViewDate: d6.LastViewDate,
                                                    contentId: d6.Contents.Content[0].id,
                                                    entitlementState: d6.Contents.Content[0].Products.Product[0].EntitlementState,
                                                    entitlementEnd: d6.Contents.Content[0].Products.Product[0].EntitlementEnd
                                                }); 
                                                total++;
                                                titlesCount++;
                                                titlesCatCount++;
                                            }
                                        });
                                    }
                                });
                            }
                        });
                    }
                    output.cats[i1].titlesCount = titlesCatCount;
                    titlesCatCount = 0;
                });
                output.titlesCount = titlesCount;
            }
        }
        catch (err) {
            console.log('Error AVN API: '+err.message);
        }
        callback(output);
    }).fail(function(xhr, errorType, error){
        VTR.Utils.handleErrorFromTraxis(xhr.response);
    	console.log('xhr:' + JSON.stringify(xhr.response) + ' - ' + 'error:' + error);
    }).done(function(data, status, xhr){
//    	console.log('data:' + data + ' - ' + 'status:' + status + ', h:'+xhr.getAllResponseHeaders());
	});
}

VTR.Catalog.getListTitlesByCategory = function(callback, options){
	var fieldList = 'Name,Categories,Pictures,ShortName,Contents,ContentCount,SeriesCount,Bookmark,DurationInSeconds';
	var urlContentByCategory = VTR.Properties.traxisProxy + '/' + VTR.Traxis.urlBodyRequest;

	var bodyReq = "";
	bodyReq += "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n";
	bodyReq += "<Request xmlns=\"urn:eventis:traxisweb:1.0\">\n";
	bodyReq += "  <Identity>\n";
	bodyReq += "    <CpeId>"+VTR.Account.cpeId+"</CpeId>\n";
	bodyReq += "  </Identity>\n";
	bodyReq += "  <RelationQuery resourceType=\"Category\" resourceId=\"" + options.categoryId + "\" relationName=\"Titles\">\n";
	bodyReq += "    <Options>\n";
	bodyReq += "      <Option type=\"Limit\">"+options.size+"</Option>\n";
	bodyReq += "      <Option type=\"Props\">"+fieldList+"</Option>\n";
	bodyReq += "	  <Option type=\"filter\">Contents.ProductCount&gt;0&amp;&amp;IsPreview==false&amp;&amp;IsViewableOnCpe==true&amp;&amp;ContentCount&gt;0</Option>\n";
	bodyReq += "	  <Option type=\"Sort\">Name</Option>\n";
	bodyReq += "    </Options>\n";
	bodyReq += "    <SubQueries>\n";
	bodyReq += "      <SubQuery relationName=\"Contents\">\n";
	bodyReq += "        <Options>\n";
	bodyReq += "          <Option type=\"props\">Aliases,IsHD,Is3D</Option>\n";
	bodyReq += "          <Option type=\"filter\">ProductCount&gt;0&amp;&amp;FirstAvailability&lt;=now()&amp;&amp;LastAvailability&gt;=now()</Option>\n";
	bodyReq += "        </Options>\n";
	bodyReq += "        <SubQueries>\n";
	bodyReq += "          <SubQuery relationName=\"Products\">\n";
	bodyReq += "            <Options>\n";
	bodyReq += "              <Option type=\"props\">Type,EntitlementState,EntitlementEnd</Option>\n";
	bodyReq += "            </Options>\n";
	bodyReq += "          </SubQuery>\n";
	bodyReq += "        </SubQueries>\n";
	bodyReq += "      </SubQuery>\n";
	bodyReq += "    </SubQueries>\n";
	bodyReq += "  </RelationQuery>\n";
	bodyReq += "</Request>\n";
	var output = {categoryId: options.categoryId ,"categoryName": options.categoryName, "titlesCount": options.titlesCount, position: 'options.position', isSeries: options.isSeries, "listtitles":[]};
	$.post(urlContentByCategory, bodyReq, function(data){
		eval("VTR.Catalog.contentCategories = " + JSON.stringify(data));
        try {
            $.each(VTR.Catalog.contentCategories.Titles.Title, function(i, d){
                var isSeries = false;
                var img = null;
                var pics = (VTR.Utils.isset(this.Pictures) ? this.Pictures.Picture : false);
                if (pics){
                    $.each(pics, function(ix,dx) {
                        if(dx.type == 'BoxCover') {
                            img = dx.Value.replace("http://" + VTR.Properties.posterServerName + "/", "http://" + VTR.Properties.posterServer + "/");
                            return false;
                       }
                        else {
                            img = dx.Value.replace("http://" + VTR.Properties.posterServerName + "/", "http://" + VTR.Properties.posterServer + "/");
                        }
                    });
                }
                if (VTR.Utils.isset(this.SeriesCount)){
                    if (this.SeriesCount > 0){
                        isSeries = true;
                    }
                }
                output.listtitles.push({
                    categoryId : 'CATEGORY_ID',
                    subcategoryId : 'SUB_CATEGORY_ID',
                    titleId : d.id,
                    name : (VTR.UI.screenFormat == "HD" ? d.ShortName.substring(0, 18) : d.ShortName.substring(0, VTR.Properties.titleMaxSize)),
                    is3D : d.Contents.Content[0].Is3D,
                    isHD : d.Contents.Content[0].IsHD,
                    pictureUri : img,
                    contentType : (VTR.Utils.isset(d.Contents.Content[0].Products) ? d.Contents.Content[0].Products.Product[0].Type : ''),
                    bookmark: (VTR.Utils.isset(d.Bookmark) ? d.Bookmark : "0"),
                    duration: d.DurationInSeconds,
                    assetId: d.Contents.Content[0].Aliases.Alias[0].Value,
                    LastViewDate: d.LastViewDate,
                    contentId: d.Contents.Content[0].id,
                    entitlementState: d.Contents.Content[0].Products.Product[0].EntitlementState,
                    entitlementEnd: d.Contents.Content[0].Products.Product[0].EntitlementEnd
                });
            });
            console.log('listtitles:'+options.categoryName+'('+output.listtitles.length+')');
//            if(output.listtitles.length == 0) {
                var bodyReq2 = "";
                bodyReq2 += "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
                bodyReq2 += "<Request xmlns=\"urn:eventis:traxisweb:1.0\">";
                bodyReq2 += "  <Identity>";
                bodyReq2 += "    <CpeId>"+VTR.Account.cpeId+"</CpeId>";
                bodyReq2 += "  </Identity>";
                bodyReq2 += "  <RelationQuery resourceType=\"Category\" resourceId=\"" + options.categoryId + "\" relationName=\"ChildCategories\">";
                bodyReq2 += "    <Options>";
                bodyReq2 += "      <Option type=\"Limit\">"+options.size+"</Option>";
                bodyReq2 += "      <Option type=\"Props\">Titles</Option>";
                bodyReq2 += "      <Option type=\"filter\">TitleCount&gt;0</Option>";
                bodyReq2 += "    </Options>";
                bodyReq2 += "    <SubQueries>";
                bodyReq2 += "      <SubQuery relationName=\"Titles\">";
                bodyReq2 += "    <Options>";
                bodyReq2 += "      <Option type=\"Limit\">"+VTR.Properties.carruselSize+"</Option>";
                bodyReq2 += "      <Option type=\"Props\">Name,Categories,Pictures,ShortName,Contents,ContentCount,SeriesCount</Option>";
                bodyReq2 += "	  <Option type=\"filter\">Contents.ProductCount&gt;0&amp;&amp;IsPreview==false&amp;&amp;IsViewableOnCpe==true</Option>";
                bodyReq2 += "    </Options>";
                bodyReq2 += "    <SubQueries>";
                bodyReq2 += "      <SubQuery relationName=\"Contents\">";
                bodyReq2 += "        <Options>";
                bodyReq2 += "          <Option type=\"props\">Aliases,IsHD,Is3D</Option>";
	            bodyReq2 += "          <Option type=\"filter\">Products&gt;0&amp;&amp;FirstAvailability&lt;=now()&amp;&amp;LastAvailability&gt;=now()</Option>\n";
                bodyReq2 += "        </Options>";
                bodyReq2 += "        <SubQueries>";
                bodyReq2 += "          <SubQuery relationName=\"Products\">";
                bodyReq2 += "            <Options>";
                bodyReq2 += "              <Option type=\"props\">Type,EntitlementState,EntitlementEnd</Option>";
                bodyReq2 += "            </Options>";
                bodyReq2 += "          </SubQuery>";
                bodyReq2 += "        </SubQueries>";
                bodyReq2 += "      </SubQuery>";
                bodyReq2 += "    </SubQueries>";
                bodyReq2 += "      </SubQuery>";
                bodyReq2 += "    </SubQueries>";
                bodyReq2 += "  </RelationQuery>";
                bodyReq2 += "</Request>";

                $.post(urlContentByCategory, bodyReq2, function(data2){
                    eval("VTR.Catalog.contentCategories = " + JSON.stringify(data2));
                    $.each(VTR.Catalog.contentCategories.Categories.Category, function(i, d3){
                        try {
                            $.each(d3.Titles.Title, function(i2, d2) {
                                var isSeries = false;
                                var img = null;
                                var pics = (VTR.Utils.isset(this.Pictures) ? this.Pictures.Picture : false);
                                if (pics){
                                    $.each(pics, function(ix,dx) {
                                        if(dx.type == 'BoxCover') {
                                            img = dx.Value.replace("http://" + VTR.Properties.posterServerName + "/", "http://" + VTR.Properties.posterServer + "/");
                                            return false;
                                      }
                                        else {
                                            img = dx.Value.replace("http://" + VTR.Properties.posterServerName + "/", "http://" + VTR.Properties.posterServer + "/");
                                        }
                                    });
                                }
                                if (VTR.Utils.isset(this.SeriesCount)){
                                    if (this.SeriesCount > 0){
                                        isSeries = true;
                                    }
                                }				
                                output.listtitles.push({
                                    categoryId : 'CATEGORY_ID',
                                    subcategoryId : 'SUB_CATEGORY_ID',
                                    titleId : d2.id,
                                    name : (VTR.UI.screenFormat == "HD" ? d2.ShortName.substring(0, 18) : d2.ShortName.substring(0, VTR.Properties.titleMaxSize)),
                                    is3D : d2.Contents.Content[0].Is3D,
                                    isHD : d2.Contents.Content[0].IsHD,
                                    pictureUri : img,
                                    contentType : d2.Contents.Content[0].Products.Product[0].Type,
                                    bookmark: d2.Bookmark,
                                    duration: d2.DurationInSeconds,
                                    assetId: d2.Contents.Content[0].Aliases.Alias[0].Value,
                                    LastViewDate: d2.LastViewDate,
                                    contentId: d2.Contents.Content[0].id,
                                    entitlementState: d2.Contents.Content[0].Products.Product[0].EntitlementState,
                                    entitlementEnd: d2.Contents.Content[0].Products.Product[0].EntitlementEnd
                                });
                            });
                        }
                        catch (err) {
                            console.log('Error AVN API: '+err.message);
                        }
                    });
                    callback(output);
                });
//            }
        }
        catch (err) {
            console.log('Error AVN API: '+err.message);
        }
	}).fail(function(xhr, errorType, error){
        VTR.Utils.handleErrorFromTraxis(xhr.response);
    	console.log('xhr:' + JSON.stringify(xhr.response) + ' - ' + 'error:' + error);
    }).done(function(data, status, xhr){
    	console.log('data:' + data + ' - ' + 'status:' + status);
	});
}
