# reference VOD implementation

see: scripts/vod-player.js for details