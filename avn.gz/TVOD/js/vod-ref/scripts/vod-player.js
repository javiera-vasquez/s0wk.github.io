function VideoPlayer(videoElement, src) {
        var self = this;
        this.previous_play_speed = -10;

        this.videoElement = videoElement;
        this.node = this.videoElement.parentNode;
        this.playSpeedIndex = 4;  //values between 0-8, where 4 is play at normal speed, see the "playSpeed" array
        this.playSpeed = [
            {
                rate  : -60,
                state : 3
            },
            {
                rate  : -30,
                state : 3
            },
            {
                rate  : -15,
                state : 3
            },
            {
                rate  : -7.5,
                state : 3
            },
            {
                rate  : 1,
                state : 0
            },
            {
                rate  : 7.5,
                state : 2
            },
            {
                rate  : 15,
                state : 2
            },
            {
                rate  : 30,
                state : 2
            },
            {
                rate  : 60,
                state : 2
            }
        ]

        // initialize variables
        this.isPauseUpdate = false;
        this.isPlayingUpdate = false;
        this.isTrickUpdate = false;

        // video events
        videoElement.addEventListener("error", this.showError.bind(this));
        videoElement.addEventListener("timeupdate", this.evttimeupdate.bind(this));
        videoElement.addEventListener("durationchange", this.evtdurationchange.bind(this));
        videoElement.addEventListener("pause", this.updatePause.bind(this));
        videoElement.addEventListener("playing", this.updatePlaying.bind(this));
        videoElement.addEventListener("ended", this.updateEnd.bind(this));

		videoElement.addEventListener("loadstart", this.evtloadstart.bind(this));
		videoElement.addEventListener("loadedmetadata", this.evtloadedmetadata.bind(this));
		videoElement.addEventListener("loadeddata", this.evtloadeddata.bind(this));
		videoElement.addEventListener("progress", this.evtprogress.bind(this));
		videoElement.addEventListener("canplay", this.evtcanplay.bind(this));
		videoElement.addEventListener("canplaythrough", this.evtcanplaythrough.bind(this));
		videoElement.addEventListener("ratechange", this.evtratechange.bind(this));

        console.log("SRC:" + src);

        this.play(src);
	}
	
    VideoPlayer.prototype.evtloadstart = function evtloadstart(e) {
        console.log("evtloadstart()");
    }
    VideoPlayer.prototype.evtloadedmetadata = function evtloadedmetadata(e) {
        console.log("evtloadedmetadata()");
    }
    VideoPlayer.prototype.evtloadeddata = function evtloadeddata(e) {
        console.log("evtloadeddata()");
    }
    VideoPlayer.prototype.evtprogress = function evtprogress(e) {
        console.log("evtprogress()");
    }
    VideoPlayer.prototype.evtcanplay = function evtcanplay(e) {
        console.log("evtcanplay()");
    }
    VideoPlayer.prototype.evtcanplaythrough = function evtcanplaythrough(e) {
        console.log("evtcanplaythrough()");
    }
    VideoPlayer.prototype.evtratechange = function evtratechange(e) {
        console.log("evtratechange()");
        console.log("evtratechange(): playbackRate: " + this.videoElement.playbackRate);
    }

    VideoPlayer.prototype.updatePause = function updatePause(e) {
        console.log("evtPause()");
        this.isPauseUpdate = true;
        this.isPlayingUpdate = false;
    }

    VideoPlayer.prototype.updatePlaying = function updatePlaying(e) {
        console.log("evtPlaying()");
        this.isPlayingUpdate = true;
        this.isPauseUpdate = false;
    }

    VideoPlayer.prototype.updateEnd = function updateEnd(e) {
        localStorage.setItem('returnKey'+cpeId, 'end');
        console.log("evtEnd()"+cpeId);
        closeSession();
    }
    VideoPlayer.prototype.evttimeupdate = function evttimeupdate(e) {
        console.log("evttimeupdate()");
        console.log("evttimeupdate: current_time=" + e.target.currentTime);
        this.updateState(e);
    }
    VideoPlayer.prototype.evtdurationchange = function evtdurationchange(e) {
        console.log("evtdurationchange()");
        if (false == isNaN(e.target.duration)) {
          // idle timeout must be at least 30 seconds. add an extra 30 seconds for a margin of error
          var duration = Math.max(30, Math.ceil(e.target.duration)) + 30;
          // set the idle timeout to duration
          var xhrSetIdleTimeout = new XMLHttpRequest();
          xhrSetIdleTimeout.open("POST", "http://session/management/reset-timeout?timeout=" + duration.toString(), true);
          console.log("evtdurationchange: " + e.target.duration + " " + duration);
          xhrSetIdleTimeout.send(null);
        }
        this.updateState(e);
    }

	    //function called by video object event on duration and time update changes


    VideoPlayer.prototype.updateState = function updateState(e) {
        console.log("evtState()");
        // update the state of the progress bar
        var play_state        = this.playSpeed[this.playSpeedIndex].state;
        var start_time        = 0; //not sure when this will not be 0?  possibly dvr that started late?
        var duration          = e.target.duration;    //time in seconds
        var current_time      = e.target.currentTime; //time in seconds
        var display_duration  = 5; //how long do we keep the overlay active in seconds....
        var play_speed        = parseInt(this.playSpeed[this.playSpeedIndex].rate);

        var updateProgressBar = false;

        //log before altering logic
        console.log("updateState() - ENTER - play_state: " + play_state + "; pauseUpdate: " + this.isPauseUpdate + "; playingUpdate: " + this.isPlayingUpdate + "; current_time: " + current_time + "; play_speed: " + play_speed + "; bookmarkTime: " + bookmarkTime + "; playbackRate: " + this.videoElement.playbackRate + "; paused: " + this.videoElement.paused + " duration:" + duration + " obj.duration:" + this.videoElement.duration);

        if (isNaN(duration)) {
           return;
        }

        if (bookmarkTime != 0)
        {
          this.videoElement.currentTime = bookmarkTime;
          bookmarkTime  = 0;
          return;
        }
		
        if (current_time >= duration) {
            //reached the end of the video
            // videoPlayer.stop();
            console.log("reached the end");
            //return;
        }

        // if rewind and we are close to the beginning, switch from rewind to play
        if ((play_state == 3) && ((current_time + (play_speed * 2)) <= 0 || current_time >= duration)) {
            //at the begining of the video (during rewind)
            console.log("reached the beginning");
            this.play();
            this.videoElement.currentTime = 0;
            // force an update of the progress bar next time
            this.isPlayingUpdate = true;
            return;
        }

        //logic for calling BCP overlay at an interval
        //if (play_speed!=1){ // only have repeat calls to overlay if the system is in trick-play mode - deprecated
        if (play_speed!=1){ // only have repeat calls to overlay if the system is in trick-play mode
           display_duration = 14400; // time in seconds to display overlay - set a long time to display overlay so we do not hammer the network with messages
        }

        console.log("updateState() - BEFORE SENT - play_state: " + play_state + "; current_time: " + current_time + "; play_speed: " + play_speed + "; idleCount: " + idleCount);
        //reset some values if player just play/paused
        if (this.isPauseUpdate) {
            play_state = 1; //set overlay state to 1 = paused
            updateProgressBar = true; //force overlay update
            this.isPauseUpdate = false; //reset flag
        } else if (this.isPlayingUpdate) {
            if (play_state == 0) {
              updateProgressBar = true; //force overlay update
            }
            this.isPlayingUpdate = false; //reset flag
        } else if (this.isTrickUpdate) {
            updateProgressBar = true; //force overlay update
            this.isTrickUpdate = false;
        }
        // if user changes speed (eg started trickplay) force bcp overlay
        // or if interval to show again is ready
        if ((this.previous_play_speed != play_speed) || updateProgressBar){
            //log what is sent to client
            console.log("updateState() progressbar - play_state: " + play_state + "; duration: " +  duration+ "; current_time: " + current_time + "; display_duration: " + display_duration + "; play_speed: " + (Math.abs(play_speed) * 1000) + ";");

            //make call to bcp client - cannot spam, need to make sure enough time has passed
            this.sendDisplayProgress(displayProgressResponse, play_state, start_time, duration, current_time, display_duration, Math.abs(play_speed) * 1000);
            this.start_wait = new Date();
        }
        //keep track of play speed for next interval check

        this.previous_play_speed = play_speed;
    }
    
    VideoPlayer.prototype.play = function play(src) {
        console.log("play()");
        //plays video - loads new source if source is passed
        if (src){
            this.videoElement.src = src;
        }
        this.videoElement.play();
        this.reset();
        //this.isPaused=false;


        //control the rate of the video object
        this.videoElement.playbackRate = this.playSpeed[this.playSpeedIndex].rate;
    }

    VideoPlayer.prototype.pause = function pause(src) {
        console.log("pause()");
        //pauses video playback
        this.reset();
        //this.isPaused=true;
        if (this.videoElement.paused) {
           this.play();
           return false;
        } else {
           this.videoElement.pause();
           return true;
        }
    }

    VideoPlayer.prototype.reset = function reset() {
        console.log("reset()");
        //resets playback rate to 1
        this.playSpeedIndex = 4;
    }

    VideoPlayer.prototype.stop = function stop(src) {
        console.log("stop()");
        localStorage.setItem('returnKey'+cpeId, 'stop');
        //this.videoElement.pause();
        closeSession();
	}
	
    VideoPlayer.prototype.backward = function backward() {
        console.log("backward()");
        var playRate = this.videoElement.playbackRate;
        console.log("backward(): current playrate; " + playRate);
        this.playSpeedIndex--;
        if (this.playSpeedIndex<0 || this.playSpeedIndex>3){
            this.playSpeedIndex=3;
        }
        console.log("backward(): new playrate index; " + this.playSpeedIndex);

        //control the rate of the video object
        this.videoElement.playbackRate = this.playSpeed[this.playSpeedIndex].rate;
        console.log("backward(): new playrate: " + this.videoElement.playbackRate);

        // start playback if necessary
        if (this.videoElement.paused) {
           this.videoElement.play();
        }
    }

    VideoPlayer.prototype.forward = function forward() {
        console.log("forward()");
        this.playSpeedIndex++;
        if (this.playSpeedIndex<5 || this.playSpeedIndex>8){
            this.playSpeedIndex=5;
        }

        //control the rate of the video object
        this.videoElement.playbackRate = this.playSpeed[this.playSpeedIndex].rate;

        // start playback if necessary
        if (this.videoElement.paused) {
           this.videoElement.play();
        }
    }

    VideoPlayer.prototype.showError = function showError() {
        var message;
        switch (this.videoElement.error.code) {
            case 1:
                message = "aborted";
            break;
            case 2:
                message = "network error";
            break;
            case 3:
                message = "decode error";
            break;
            case 4:
                message = "source not supported";
            break;
            default: 
                message = "unexpected error";
                if (this.videoElement.hasAttribute("AVNErrorString")){
                    // AVNErrorString is a cloudtv specific error string with additinal information
                    message = this.videoElement.getAttribute("AVNErrorString");
                    var error = (/^.*=[0-9]*/.exec(message) || [""])[0];
                    message = message.substr(error.length);
                    // report error
                    console.log("report_event:" + JSON.stringify({"vod-error": error, "message": message}));
                    closeSession();
                } 
        }
            // create a simple error dialog
            var errorDialog = document.createElement("div");
            errorDialog.setAttribute("id", "error-dialog");
            errorMessage = document.createElement("p");
            errorMessage.textContent = message;
            errorDialog.appendChild(errorMessage);
            document.body.appendChild(errorDialog);
    }

    VideoPlayer.prototype.skipForward = function skipForward() {
        console.log("skipForward");
        if (this.videoElement.playbackRate > 1) {
           var new_currentTime = (Math.floor(this.videoElement.currentTime/900) + 1) * 900;
           if (new_currentTime < this.videoElement.duration) {
              // set the current time to the next 15 minute marker
              this.videoElement.currentTime = new_currentTime;
              this.isTrickUpdate = true;
           } else {
              // check if the current time is pass the last whole minute of the video
              new_currentTime = this.videoElement.duration - (this.videoElement.duration % 60);
              console.log("skipForward: old: " + this.videoElement.currentTime + " new: " + new_currentTime + " duration: " + this.videoElement.duration + " delta: " + (this.videoElement.duration % 60) );
              if (this.videoElement.currentTime < new_currentTime) {
                 // set the current time to the last whole minute 
                 this.videoElement.currentTime = new_currentTime;
                 this.isTrickUpdate = true;
              }
           }
        }
    }

    VideoPlayer.prototype.skipBackward = function skipBackward() {
        console.log("skipBackward");
        if (this.videoElement.playbackRate < 1) {
           var new_currentTime = Math.floor((this.videoElement.currentTime - 1)/900) * 900;
           if (new_currentTime <= 0) {
              this.videoElement.currentTime = 0;
              this.reset();
              // adjust the playback rate to normal
              this.videoElement.playbackRate = this.playSpeed[this.playSpeedIndex].rate;
              // force an update of the progress bar next time
              this.isPlayingUpdate = true;
           } else {
              // set the current time
              this.videoElement.currentTime = new_currentTime;
              this.isTrickUpdate = true;
           }
        }
    }

    VideoPlayer.prototype.showInfo = function showInfo() {
        // make sure the video is in the play/pause state
        if (this.videoElement.playbackRate == 1 || this.videoElement.paused) {
          // we have to manually update the progress bar since we do not know when the next timechange event will occur
          var play_state        = this.videoElement.paused? 1 : 0;
          var start_time        = 0; //not sure when this will not be 0?  possibly dvr that started late?
          var duration          = this.videoElement.duration;    //time in seconds
          var current_time      = this.videoElement.currentTime; //time in seconds
          var display_duration  = 5; //how long do we keep the overlay active in seconds....
          var play_speed        = this.videoElement.paused? 0 : 1;
          this.isPauseUpdate = false;
          this.isPlayingUpdate = false;
          this.isTrickUpdate = false;
          this.sendDisplayProgress(displayProgressResponse, play_state, start_time, duration, current_time, display_duration, Math.abs(play_speed) * 1000);
	}
    }

    VideoPlayer.prototype.sendDisplayProgress = function (cb, play_state, start_time, duration, current_time, display_duration, play_speed){
        console.log("sendDisplayProgress(): play_state:" + play_state + " start_time: " + start_time + " duration: " + duration + " current_time: " + current_time + " display_duration:" + display_duration + " play_speed:" + play_speed); 
        var buf = new ArrayBuffer(34);
        var u8s = new Uint8Array(buf);
        var dpprotocolid = 0x01;
        //Create the binary message
        //Message id ()
        u8s[0] = 1;

        //1st 8 bits include time_type, play_state, function_disabled, and reserved
        u8s[1] = 0;                             //time_type - The type of time referenced in the start_time field.  This effects if the progress bar should display a time of day or duration of time. 0 - The time fields represent a number of seconds.  1 - The time fields represent the number of seconds in a day.  (e.g. 0==12:00:00 AM, 1800==12:30:00 AM, 50400==2:00:00 PM) The timezone is UTC, so the client will need to convert to local time to display
        u8s[1] = (u8s[1] << 2) | play_state;    //play_state is current trick play state to use. 0=normal play, 1=paused, 2=trick forward, 3=trick rewind.
        u8s[1] = (u8s[1] << 1) | 0;             //function_disabled - Set to 1 if to disable trick play for current asset (e.g. advertisement)
        u8s[1] = (u8s[1] << 3) | 0;             //reserved for future features

        //Next 32 bits represent start_time
        u8s[2] = 0;
        u8s[3] = 0;
        u8s[4] = parseInt(start_time / 256);
        u8s[5] = parseInt(start_time % 256);

        //Next 32 bits represent duration
        u8s[6] = 0;
        u8s[7] = 0;

        u8s[8] = parseInt(duration / 256);
        u8s[9] = parseInt(duration % 256);

        //Next 32 bits represent current_time
        u8s[10] = 0;
        u8s[11] = 0;
        u8s[12] = parseInt(current_time / 256);
        u8s[13] = parseInt(current_time % 256);

        //Next 16 bits represent display_duration
        u8s[14] = parseInt(display_duration / 256);
        u8s[15] = parseInt(display_duration % 256);

        //Next 32 bits represent play_speed
        u8s[16] = 0;
        u8s[17] = 0;
        u8s[18] = parseInt(play_speed / 256);
        u8s[19] = parseInt(play_speed % 256);

        //Next 32 bits represent chapter_length (not used for this)
        u8s[20] = 0;
        u8s[21] = 0;
        u8s[22] = 0; //parseInt(chapter_length/256);
        u8s[23] = 0; //parseInt(chapter_length%256);

        //Next 32 bits represent timeshift_buffer_start (not used for this)
        u8s[24] = 0;
        u8s[25] = 0;
        u8s[26] = 0;
        u8s[27] = 0;

        //Next 32 bits represent timeshift_buffer_end (not used for this)
        u8s[28] = 0;
        u8s[29] = 0;
        u8s[30] = 0;
        u8s[31] = 0;

        //Next 16 bits represent function_disabled_duration (not used for this)
        u8s[32] = 0;
        u8s[33] = 1;

        console.log("sendDisplayProgress() - u8s: ", u8s);
        var retStr = String.fromCharCode.apply(null, new Uint8Array(buf));

        if (XMLHttpRequest.prototype.sendAsBinary === undefined) {
            XMLHttpRequest.prototype.sendAsBinary = function (string) {
                var bytes = Array.prototype.map.call(string, function (c){
                    return c.charCodeAt(0) & 0xff;
                });
                this.send(new Uint8Array(bytes).buffer);
            };
        }
        var xhr = new XMLHttpRequest;
        xhr.url = "http://session/client/send?protocolid=" + dpprotocolid;
        xhr.requestMsg = "xhr url: '" + xhr.url + "' - post('" + retStr + "')";
        xhr.onreadystatechange = function () {
            if (this.readyState == 4) {
                var tmpObj = {};
                tmpObj.request  = this.requestMsg;
                tmpObj.response = this.responseText;
                cb(tmpObj);
            }
        }
        xhr.open("post", xhr.url, true)
        xhr.sendAsBinary(retStr);
    }
    function displayProgressResponse(retObj) {
        console.dir({"displayProgressResponse()  - " : retObj});
    }

    VideoPlayer.prototype.showError = function showError() {
        switch (this.videoElement.error) {
            case 1: message = "aborted"; break;
            case 2: message = "network error"; break;
            case 3: message = "decode error"; break;
            case 4: message = "source not supported"; break;
            default: 
                message = "unexpected error";
                console.log('raw:'+this.videoElement.outerHTML);
                if (this.videoElement.hasAttribute("AVNErrorString")){
                    // AVNErrorString is a cloudtv specific error string with additinal information
                    message = this.videoElement.getAttribute("AVNErrorString");
                    var error = (/^.*=[0-9]*/.exec(message) || [""])[0];
                    message = message.substr(error.length);
                    // report error
                    console.log("report_event:" + JSON.stringify({"vod-error": error, "message": message}));
                    // do not report PAUSE response 405 errors to the application
                    if (message.indexOf("PAUSE response: 405") == -1)
                    {
                    localStorage.setItem('returnKey'+cpeId, 'error');
                    localStorage.setItem('returnMessage'+cpeId, message);
                    }
                    else
                    {
                    localStorage.setItem('returnKey'+cpeId, 'end');
                    console.log("evtPause405Error:"+cpeId);
                    }
                    closeSession();
                } 
        }

            // create a simple error dialog
            var errorDialog = document.createElement("div");
            errorDialog.setAttribute("id", "error-dialog");
            errorMessage = document.createElement("p");
            errorMessage.textContent = message;
            errorDialog.appendChild(errorMessage);
            document.body.appendChild(errorDialog);
    }

    function startIdleCount(){
        if (idleCount>pauseTimeout){
            //timeout exceeded, exit application
            //Exit
            console.log("pauseTimeout - xhr url: 'http://session/management/exit?reason=SessionIdleTimeout'");
            var xhr = new XMLHttpRequest;
            xhr.open("POST", "http://session/management/exit?reason=SessionIdleTimeout", false);
            xhr.send(null);

            //Last Channel
            try{
                //__openUrl__("tv:last");  // this works for tuning to last channel
            } catch(e){
                //not on CloudTV Platform
            }
            return;
        }
        idleCount+=500;
        idleTimer=setTimeout(startIdleCount,500);
    }

    function clearIdleCount() {
        clearTimeout(idleTimer);
        idleCount=0;
    }

    function getParamByName(name) {
        name = name.replace(/[\[]/,"\\[").replace(/[\]]/, "\\]");
        var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
            results = regex.exec(location.search);
        return results == null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
    }
    function closeSession() {
       // restore the idle timeout
       console.log("closeSession");
       var xhrResetTimeout = new XMLHttpRequest();
       xhrResetTimeout.open("POST", "http://session/management/reset-timeout", false);
       xhrResetTimeout.send(null);
       window.close();
    }

    VideoPlayer.prototype.lastChannel = function lastChannel() {
        console.log('lastChannel(tuners:last)');
        try{
            // this works for tuning to last channel
            var xhrLast = new XMLHttpRequest;
            xhrLast.open("POST", "http://session/client/tuners/1?channel=last", false);
            xhrLast.send(null);
        } catch(e){
            //not on CloudTV Platform
        }
    }
    var pauseTimeout = 5*60*1000; // 5 minutes - duration to remained paused before navigating to previous channel
    var idleCount=0;
    var idleTimer;
    var bookmarkTime=0;
    var cpeId = "";

    window.addEventListener("load", function(){
        var assetId = getParamByName("assetId"); //localStorage.getItem("playerUri");
        cpeId = getParamByName("cpeId");
        var bookmark = getParamByName("bookmark");

        // ignore invalid bookmark values
        if (bookmark != null) {
           if (isNaN(bookmark) == false) {
		bookmarkTime=bookmark;
           } else {
                console.log("WARN - invalid bookmark value: " + bookmark);
           }
        }
		
        var videoPlayer = new VideoPlayer(document.getElementsByTagName("video")[0], "vod:traxis/" + assetId + "?STBId=" + cpeId);
        localStorage.setItem('returnKey'+cpeId, '');
        
        //add key listeners for vod control
        document.addEventListener("keydown", function (e){
            console.log("keydown() - key: " + e.keyCode);
            switch (e.keyCode) {
                case 19: // pause
                    clearIdleCount();
                    if (videoPlayer.pause()) {
                       startIdleCount();
                    }
                    break;
                case 412: // rewind
                    clearIdleCount();
                    videoPlayer.backward();
                    break;
                case 413:  // stop
                case 4113: // C key
                case 1810:
                    e.preventDefault();
                    console.log('returnKey'+cpeId);
                    localStorage.setItem('returnKey'+cpeId, 'stop');
                    closeSession();
                    break;
                case 415:  // play
                case 1809: // play via sling
                case 1811:
                    clearIdleCount();
                    videoPlayer.play();
                    break;
                case 417: // fast forward
                    clearIdleCount();
                    videoPlayer.forward();
                    break;
                case 457: // info
                case 41: // sel
                case 13: // ok
                    videoPlayer.showInfo();
                    break;
                case 37: // left - skip backward if in rwd mode
                    videoPlayer.skipBackward();
                    break;
                case 39: // right - skip forward if in ffwd mode
                    videoPlayer.skipForward();
                    break;
                case 8: // last - this is handled by the client
                    e.preventDefault();
                    localStorage.setItem('returnKey'+cpeId, '');
                    videoPlayer.lastChannel();
                    break;
                default:
                break;
            }
        });                
    });


    // set a key filter so that the numeric keys can be passed directly to Rovi
    var xhrKeyFilter = new XMLHttpRequest();
    xhrKeyFilter.open("GET", "http://session/client/keyfilter?process=local&keycode=VK_0&keycode=VK_1&keycode=VK_2&keycode=VK_3&keycode=VK_4&keycode=VK_5&keycode=VK_6&keycode=VK_7&keycode=VK_8&keycode=VK_9", true);
    localStorage.setItem('returnKey'+cpeId, '');
    xhrKeyFilter.send("");
