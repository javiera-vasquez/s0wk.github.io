function VideoPlayer(videoElement, src) {
        var self = this;
        this.previous_play_speed = -10;
        this.time_passed=true;

        this.videoElement = videoElement;
        this.node = this.videoElement.parentNode;
        this.playSpeedIndex = 3;  //values between 0-6, where 3 is play at normal speed, see the "playSpeed" array
        this.playSpeed = [
            {
                rate: 4,
                icon: 3
            },
            {
                rate: 3,
                icon: 3
            },
            {
                rate: 2,
                icon: 3
            },
            {
                rate: 1,
                icon: 0
            },
            {
                rate: 2,
                icon: 2
            },
            {
                rate: 3,
                icon: 2
            },
            {
                rate: 4,
                icon: 2
            }
        ]

        // initialize variables
        this.isPauseUpdate = false;
        this.isPlayingUpdate = false;

        // video events
        videoElement.addEventListener("error", this.showError.bind(this));
        videoElement.addEventListener("timeupdate", this.updateState.bind(this));
        videoElement.addEventListener("durationchange", this.updateState.bind(this));
        videoElement.addEventListener("pause", this.updatePause.bind(this));
        videoElement.addEventListener("playing", this.updatePlaying.bind(this));
        videoElement.addEventListener("ended", this.updateEnd.bind(this));

        console.log("SRC:" + src);

        this.play(src);
}

    VideoPlayer.prototype.updatePause = function updatePause(e) {
        console.log("updatePause()");
        this.isPauseUpdate = true;
        this.isPlayingUpdate = false;
    }
    VideoPlayer.prototype.updatePlaying = function updatePlaying(e) {
        console.log("updatePlaying()");
        this.isPlayingUpdate = true;
        this.isPauseUpdate = false;
    }
    VideoPlayer.prototype.updateEnd = function updateEnd(e) {
        console.log("updateEnd()");
        window.close();
    }

    VideoPlayer.prototype.updateState = function updateState(e) {
        console.log("updateState()");
        // update the state of the progress bar
        var play_speed = this.playSpeed[this.playSpeedIndex].rate;
        var current_icon = this.playSpeed[this.playSpeedIndex].icon;
        var start_time = 0; //not sure when this will not be 0?  possibly dvr that started late?
        var duration = e.target.duration;
        var current_time = e.target.currentTime;
        var display_duration = 5; //how long do we keep the overlay active - supposed to be the number of seconds...
        var updateProgressBar = false;
        console.log("updateState" + ": current_time " + current_time + "; play_speed: " + play_speed + "; current_icon: " + current_icon + "; pauseUpdate: " + this.isPauseUpdate + "; playingUpdate: " + this.isPlayingUpdate);

        //logic for calling BCP overlay at an interval
        if (play_speed!=1){ // only have repeat calls to overlay if the system is in trickplay mode
            if (!this.time_passed){
                this.check_in_wait = new Date().getMilliseconds();
                if ((this.check_in_wait - this.start_wait)>=3500){
                    this.time_passed=true;
                }
            }
        }

        if (this.isPauseUpdate) {
            this.isPauseUpdate = false;
            current_icon = 1;
            updateProgressBar = true;
        } else if (this.isPlayingUpdate) {
            this.isPlayingUpdate = false;
            current_icon = 0;
            updateProgressBar = true;
        } 

        // if user changes speed (eg started trickplay) force bcp overlay
        // or if interval to show again is ready
        if ((this.previous_play_speed != play_speed) || (this.time_passed) || updateProgressBar){

            //make call to bcp client - cannot spam, need to make sure enough time has passed
            this.sendDisplayProgress(displayProgressResponse, current_icon, start_time, duration, current_time, display_duration, play_speed);
            this.time_passed = false;
            this.start_wait = new Date().getMilliseconds();
        }

        this.previous_play_speed = play_speed;

    }
    
    VideoPlayer.prototype.play = function play(src) {
        console.log("play()");
        //plays video - loads new source if source is passed
        if (src){
            this.videoElement.src = src;
        }
        this.videoElement.play();
        this.reset();
        //this.isPaused=false;

        //set properties of html elements
        var play_speed = this.playSpeed[this.playSpeedIndex].rate;
        this.node.setAttribute("data-speed", Math.abs(play_speed));
        this.videoElement.playbackRate = play_speed;
    }

    VideoPlayer.prototype.pause = function pause(src) {
        console.log("pause()");
        //pauses video playback
        //this.reset();
        //this.isPaused=true;
        this.videoElement.pause();
    }

    VideoPlayer.prototype.reset = function reset() {
        console.log("reset()");
        //resets playback rate to 1
        this.playSpeedIndex=3;
    }

    VideoPlayer.prototype.backward = function backward() {
        console.log("backward()");
        var playRate = this.videoElement.playbackRate;
        this.playSpeedIndex--;
        if (this.playSpeedIndex<0){
            this.playSpeedIndex=0;
        }
        // this.isPaused=false;

        //set properties of html elements
        var play_speed = this.playSpeed[this.playSpeedIndex].rate;
        this.node.setAttribute("data-speed", Math.abs(play_speed));
        this.videoElement.playbackRate = -play_speed;
    }

    VideoPlayer.prototype.forward = function forward() {
        console.log("forward()");
        this.playSpeedIndex++;
        if (this.playSpeedIndex>6){
            this.playSpeedIndex=6;
        }
        // this.isPaused=false;

        //set properties of html elements
        var play_speed = this.playSpeed[this.playSpeedIndex].rate;
        this.node.setAttribute("data-speed", Math.abs(play_speed));
        this.videoElement.playbackRate = play_speed;
    }

    VideoPlayer.prototype.skip = function skip(e, minutes, type) {
        console.log("skip("+minutes+"/"+type+")");
        var oneMinute = 60;
        if(type == "left") {
            e.target.currentTime = -minutes*oneMinute;
        }
        else {
            e.target.currentTime = minutes*oneMinute;
        }
    }

    VideoPlayer.prototype.sendDisplayProgress = function (cb, current_icon, start_time, duration, current_time, display_duration, play_speed){
        console.log("sendDisplayProgress()");
        var buf = new ArrayBuffer(34);
        var u8s = new Uint8Array(buf);

        //current_icon is current trick play icon to use. value between  -3 and 3.  0=play, -3 rw max, 3 ff max.

        var dpmessage_id = 1;
        //var protocolid = 0x10;//16;
        var dpprotocolid = 0x01;
        var reserved = 0;


        // Message id ()
        u8s[0] = dpmessage_id;
        var time_type = 0;//0.toString(2);

        //1st 8 bits include time_type, play_state, function_disabled, and reserved
        u8s[1] = time_type;
        u8s[1] = (u8s[1] << 2) | current_icon;
        u8s[1] = (u8s[1] << 1) | 0;
        u8s[1] = (u8s[1] << 3) | reserved;

        //Next 32 bits represent start_time
        u8s[2] = 0;
        u8s[3] = 0;
        //var start_time = displayArray[0].choices[displayArray[0].selected];
        u8s[4] = parseInt(start_time / 256);
        u8s[5] = parseInt(start_time % 256);

        //Next 32 bits represent duration
        u8s[6] = 0;
        u8s[7] = 0;
        //var duration = displayArray[1].choices[displayArray[1].selected];
        u8s[8] = parseInt(duration / 256);
        u8s[9] = parseInt(duration % 256);

        //Next 32 bits represent current_time
        u8s[10] = 0;
        u8s[11] = 0;
        //var current_time = displayArray[2].choices[displayArray[2].selected];
        u8s[12] = parseInt(current_time / 256);
        u8s[13] = parseInt(current_time % 256);

        //Next 16 bits represent display_duration
        //var display_duration = displayArray[4].choices[displayArray[4].selected];
        u8s[14] = parseInt(display_duration / 256);
        u8s[15] = parseInt(display_duration % 256);
        //Next 32 bits represent play_speed
        u8s[16] = 0;
        u8s[17] = 0;
        //var play_speed = displayArray[3].choices[displayArray[3].selected];
        u8s[18] = parseInt(play_speed / 256);
        u8s[19] = parseInt(play_speed % 256);

        //Next 32 bits represent chapter_length
        u8s[20] = 0;
        u8s[21] = 0;
        //var chapter_length=displayArray[4].choices[displayArray[4].selected];
        u8s[22] = 0; //parseInt(chapter_length/256);
        u8s[23] = 0; //parseInt(chapter_length%256);

        //Next 32 bits represent timeshift_buffer_start
        u8s[24] = 0;
        u8s[25] = 0;
        u8s[26] = 0;
        u8s[27] = 0;

        //Next 32 bits represent timeshift_buffer_end
        u8s[28] = 0;
        u8s[29] = 0;
        u8s[30] = 0;
        u8s[31] = 0;

        //Next 16 bits represent function_disabled_duration
        u8s[32] = 0;
        u8s[33] = 1;

        console.log("sendDisplayProgress() - u8s: ", u8s);
        var retStr = String.fromCharCode.apply(null, new Uint8Array(buf));

        if (XMLHttpRequest.prototype.sendAsBinary === undefined) {
            XMLHttpRequest.prototype.sendAsBinary = function (string) {
                var bytes = Array.prototype.map.call(string, function (c){
                    return c.charCodeAt(0) & 0xff;
                });
                this.send(new Uint8Array(bytes).buffer);
            };
        }
        var xhr = new XMLHttpRequest;
        xhr.url = "http://session/client/send?protocolid=" + dpprotocolid;
        xhr.requestMsg = "xhr url: '" + xhr.url + "' - post('" + retStr + "')";
        xhr.onreadystatechange = function () {
            if (this.readyState == 4) {
                var retText = xhr.responseText;
                var tmpObj = {};
                tmpObj.request  = this.requestMsg;
                tmpObj.response = this.responseText;
                cb(tmpObj);
            }
        }
        xhr.open("post", xhr.url, true)
        xhr.sendAsBinary(retStr);
    }

    function displayProgressResponse(retObj) {
        console.dir({"displayProgressResponse()  - " : retObj});
    }


    VideoPlayer.prototype.showError = function showError() {
        switch (this.videoElement.error) {
            case 1: message = "aborted"; 
                break;
            case 2: message = "network error"; 
                break;
            case 3: message = "decode error"; 
                break;
            case 4: message = "source not supported"; 
                break;
            default: 
                message = "unexpected error";
                if (this.videoElement.hasAttribute("AVNErrorString")){
                    // AVNErrorString is a cloudtv specific error string with additinal information
                    message = this.videoElement.getAttribute("AVNErrorString");
                    var error = (/^.*=[0-9]*/.exec(message) || [""])[0];
                    message = message.substr(error.length);
                    // report error
                    console.log("report_event:" + JSON.stringify({"vod-error": error, "message": message}));
                }
                break;
        }

        // create a simple error dialog
        // var errorDialog = document.createElement("div");
        // errorDialog.setAttribute("id", "error-dialog");
        // errorMessage = document.createElement("p");
        // errorMessage.textContent = message;
        // errorDialog.appendChild(errorMessage);
        // document.body.appendChild(errorDialog);
        //console.log(message);
        localStorage.setItem('playerToDetail', JSON.stringify({'status': 'error', 'message': message, 'titleId': '', 'categoryName': ''}));
        window.close();
    }

    function startIdleCount(){
        if (idleCount>pauseTimeout){
            //timeout exceeded, exit application

            //Exit
            console.log("pauseTimeout - xhr url: 'http://session/management/exit'");
            var xhr = new XMLHttpRequest;
            xhr.open("POST", "http://session/management/exit", false);
            var retText = xhr.responseText;
            xhr.send(null);


            //Last Channel
            try{
                //__openUrl__("tv:last");  // this works for tuning to last channel
            } catch(e){
                //not on CloudTV Platform
            }
            return;
        }
        idleCount+=500;
        idleTimer=setTimeout(startIdleCount,500);
    }

    function clearIdleCount() {
        clearTimeout(idleTimer);
        idleCount=0;

    }

    function getParamByName(name) {
        name = name.replace(/[\[]/,"\\[").replace(/[\]]/, "\\]");
        var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
            results = regex.exec(location.search);
        return results == null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
    }
    /*function setCookie(status, message, titleId, assetId) {
        //Use the storage.cookies library
        av.require('storage.cookies');
        
        //Calculate a cookie expiration date (set to current date + 30 days)
        var d=new Date();
        d.setDate(d.getDate()+30);
        // console.log(d);
        
        //Set the new cookie value
        var myCookie = av.storage.cookies.set("VtrAvnCookie",JSON.stringify({'status':status, 'message':message, 'titleId': titleId, 'assetId': assetId}), d);
        return myCookie;
    }*/
    function getCookie() {
        //Use the storage.cookies library
        av.require('storage.cookies');
        
        //Attempt to retrieve an existing cookie
        var retrieveCookie;
        try{
            retrieveCookie=av.storage.cookies.get("VtrAvnCookie");
        }catch(err){
            console.log("Error getting cookie: "+err.message);
            retrieveCookie={};
        };
        return retrieveCookie;
    }
    VideoPlayer.prototype.lastChannel = function lastChannel() {
        console.log('lastChannel()');
        try{
            window.__openUrl__("tv:last");  // this works for tuning to last channel
        } catch(e){
            //not on CloudTV Platform
        }
    }
    VideoPlayer.prototype.addChannel = function addChannel(keyCode) {
        console.log('addChannel()');
        tunedChannel += String.fromCharCode(keyCode);
        if(tunedChannel.length == 3) {
            VideoPlayer.prototype.tuneChannel(tunedChannel);
        }
    }
    VideoPlayer.prototype.tuneChannel = function tuneChannel(channel) {
        console.log('tuneChannel('+channel+')');
        try{
            localStorage.setItem('playerToDetail','');
            window.__openUrl__("tv:"+channel);  
        } catch(e){
            //not on CloudTV Platform
        }
    }
    var pauseTimeout = 5*60*1000; //10 minutes - duration to remained paused before navigating to previous channel
    var idleCount=0;
    var idleTimer;
    var tunedChannel = "";
    var titleId = '';

    window.addEventListener("load", function(){
        var assetId = getParamByName("assetId"); //localStorage.getItem("playerUri");
        var cpeId = getParamByName("cpeId");
        //var bookmark = getParamByName("bookmark");
        /*var cookie = getCookie();
        var c = document.cookie;
        console.log(c);
        if(cookie != '') {
            console.log(cookie);
            cookie = JSON.parse(cookie);
            titleId = cookie.titleId;
        }*/
        var t = localStorage.getItem('playerToDetail');
        console.log('playerToDetail:'+t);
        var videoPlayer = new VideoPlayer(document.getElementsByTagName("video")[0], "vod:traxis/" + assetId + "?STBId=" + cpeId);
        //var videoPlayer = new VideoPlayer(document.getElementsByTagName("video")[0], "vod:traxis/" + assetId + "?STBId=" + cpeId + "&Bookmark=" + bookmark);

        //add key listeners for vod control
        document.addEventListener("keydown", function (e){
            console.log("keydown() - key: " + e.keyCode);
            switch (e.keyCode) {
                case 19:
                    //pause
                    videoPlayer.pause();
                    startIdleCount();
                    break;
                case 412:
                    //rewind
                    videoPlayer.backward();
                    clearIdleCount();
                    break;
                case 413:
                case 4113:
                case 1810:
                    //???? stop
                    //videoPlayer.close();
                    e.preventDefault();
                    window.close();
                    break;
                case 415:
                case 1809:
                case 1811:
                    //play
                    videoPlayer.play();
                    clearIdleCount();
                    break;
                case 417:
                    //fast forward
                    videoPlayer.forward();
                    clearIdleCount();
                    break;
                case 37:
                    //skip minutes forward
                    videoPlayer.currentTime += 900;
                    videoPlayer.play();
                    clearIdleCount();
                    break;
                case 39:
                    //skip minutes backward
                    videoPlayer.currentTime -= 900;
                    videoPlayer.play();
                    clearIdleCount();
                    break;
                case 8:
                    videoPlayer.lastChannel();
                    break;
                case 457:
                    videoPlayer.updateState(e);
                    break;
                case 48:
                case 49:
                case 50:
                case 51:
                case 52:
                case 53:
                case 54:
                case 55:
                case 56:
                case 57:
                case 58:
                    videoPlayer.addChannel(e.keyCode);
                    break;
                case 13:
                case 41:
                    if (tunedChannel != '') {
                        videoPlayer.tuneChannel(tunedChannel);                        
                    };
                    localStorage.setItem('playerToDetail','');
                    break;
                default:
                    console.log("keydown() - ignore event:" + e.keyCode + ",currentTime:" + videoPlayer.currentTime);
                break;
            }
        });                
    });