/*
	NAME: VTR.Properties
	DESCRIPTION:
*/

VTR.Properties = {
	carruselSize: 8,
	lienzoSize: 400,
        traxisServer: '192.168.56.171',
	traxisServerName: 'traxis.dawn-test.vtr.net',
	traxisProxy2: 'js/traxis.php?',
        traxisProxy: 'http://192.168.56.171',
	posterServer: '192.168.56.171',
	posterServerName: 'poster.dawn-test.vtr.net',
	vodplayer: '/TVOD/js/vod-ref/index.html',
	defaultRootCategory: 'AVN', //'DAWN_Store',
	canvasSize: 6,
	canvasSizeSD: 5,
	canvasSearchSize: 4,
	notAvailable: 'NO DISPONIBLE',
	historyDaysLimit: 60,
	titleMaxSize: 16,
	debugInfo: 1,
	debugDetailMovie:1,
	transitionTime: 80,
	titlesMenu: '',
	titleMenu1stLevel: '',
	titleMenu2ndLevel: '',
	titleMenu3rdLevel: '',
	titleMenu4rdLevel: '',
        titleMenuPremium: 'PREMIUM',
        titleMenuKids: 'KIDS GRATIS',
        titleMenuClub: 'CLUB GRATIS',
        premiumChannelCatSeries: 'SERIES',
        premiumChannelCatMovies: 'PEL�CULAS',
	assetId: '',
	vodImage: './img/poster-vod.png', //'img/vod.png',
	thinkAnalyticsServer: 'http://192.168.56.170:8080',
    userAgent: '',
    secondsLearnAction: 10,
    inactivityTimeout: 300000, // 5 minutes
    carruselPosterHDWidth: 180,
    carruselPosterHDHeight: 260,
    carruselPosterSDWidth: 104,
    carruselPosterSDHeight: 150,
    canvasPosterHDWidth: 165,
    canvasPosterHDHeight: 238,
    canvasPosterSDWidth: 90,
    canvasPosterSDHeight: 130,
    fichaPosterHDWidth: 222,
    fichaPosterHDHeight: 320,
    fichaPosterSDWidth: 104,
    fichaPosterSDHeight: 150,
    seriesHrefCustomProperty: 'AvnCatWithSeries',
    //seriesFlagValue: 'ContainsSeries',
    seriesFlagValue: 'true',
    SDTitleMaxLenght: 14,
    	HDTitleMaxLenght: 16,
    	seriesLibertyGlobalCustomProperty: 'libertyglobal:RenderingHintsCS:2013',
   	carruselMixedSize: 4
}

VTR.ActionType = {
    played: 10,
    like: 15,
    dislike: 16,
    favourite: 5
}


