/*
    NAME: VTR.UI
    DESCRIPTION: Métodos para interacción con FrontEnd.
*/

VTR.UI = {
    renderOptions:{
        customerId: VTR.Account.customerId,
        cpeId: VTR.Account.cpeId,
        profileId: VTR.Account.profileId,
        categoryId: "",
        titleId: "",
        isCarrusel: true,
        position: 1
    },
    screenFormat: 'SD',
    firstCarrousel: true,
    titleMaxLenght: '0'
}

VTR.UI.renderHtmlBase = function() {
    var outUL = "<ul class='carrousels active'><div class='foco'><a href='' class='play-element-fix' style='display: none;'></a><div class='progress' style='display: none;'></div></div></ul>";
    $("#frame-carrousels").html(outUL);
}

VTR.UI.renderListMenu = function(){
    var rk = localStorage.getItem('returnKey'+VTR.Account.cpeId);
    var rd = localStorage.getItem('returnData'+VTR.Account.cpeId);
    var rm = localStorage.getItem('returnMessage'+VTR.Account.cpeId);
    console.log('returnKey'+VTR.Account.cpeId+':'+rk+',returnData'+VTR.Account.cpeId+':'+JSON.stringify(rd)+',returnMessage'+VTR.Account.cpeId+':'+rm);
	
    if(rk != '' && VTR.Utils.isset(rk) && rd != '') {
        try {
            var rd = JSON.parse(rd);
        }
        catch(err) {
            console.log("Error APIN AVN:"+err.message);
            VTR.Utils.handleErrorFromTraxis('{"Error":{"InternalError":"UnknownError"}}');
            localStorage.setItem('returnData'+VTR.Account.cpeId,'');
            return;
        }

        $("body").animate({
          opacity: 0,
          scale:1.3,
          translate3d: '0,-40px,0'
        }, VTR.Properties.transitionTime, 'ease-in', function(){
            $.ajax({
                url: "html/detail-premium-movie.html",
                success: function(data){
                    $('body').html(data).animate({
                        opacity:1,
                        translate3d: '0,0,0'
                    }, VTR.Properties.transitionTime, 'ease-out');
                    
                    if(rd.isSerie){
                        VTR.UI.renderTitleDetailSeries({categoryId: rd.categoryId, categoryName: rd.categoryName, isSeries: rd.isSerie, selSeason: rd.selSeason, selEpisode: rd.selEpisode, isCarrusel: true});
                    }else{
                    	VTR.UI.renderTitleDetail({titleId: rd.titleId, categoryName: rd.categoryName, backPlayer: true});
                    	VTR.TA.learnActionForTA({titleId: rd.titleId, action: VTR.ActionType.played});
//                        navi.navigate.pop();
                    }
                    navi.navigate = rd.navi;

                    if(rk == 'error') {
                        $().toastmessage('showToast', {
                            text     : rm + "<br><br> <strong>ACEPTAR</strong>",
                            sticky   : false,
                            type     : 'none',
                            stayTime : 8000
                        });
                    }
                }
            });
        });
        mode = "detailMovie";
        localStorage.setItem('returnKey'+VTR.Account.cpeId,'');
        localStorage.setItem('returnData'+VTR.Account.cpeId,'');
        localStorage.setItem('returnMessage'+VTR.Account.cpeId,'');
    }
    else {
        if(navi.navigate.length == 1) {
            if(navi.navigate[0].categoryName == 'MI VOD'){
                navi.navigate.pop();
//				localStorage.setItem('subCategoryName'+VTR.Account.cpeId, '');
                sessionStorage.setItem("categoryName", '');
            }
        }
        if(navi.navigate.length == 0) {
            VTR.Catalog.getListMenu(function(result){
                $(".load-nav nav").append("<div class='arrow'></div>");
                $(".load-nav nav").append("<div id='focusEdge' class='focusEdge'></div>")

                VTR.UI.renderMyWishList({firstCarrousel: false, size: VTR.Properties.carruselSize});
                VTR.UI.renderMyViewings({firstCarrousel: false, isAdult: false, size: VTR.Properties.carruselSize});
                VTR.UI.renderMyRecommendations({firstCarrousel: false, size: VTR.Properties.carruselSize});

                $.each(result.listmenu, function(id, data){
                    $(".load-nav nav ul").append("<li data-crid='" + data.id + "' data-name='" + data.name + "' data-isadult='" + data.isAdult + "' data-isseries='" + data.isSeries + "'>" + data.name + "</li>");
                    idc2.menuId.push({
			'categoryId': data.id
                    });
                    
                    if (id == 0) {
                        //VTR.UI.renderListCarrusel({categoryId: data.id, categoryName: data.name, isCarrusel: true, hasFirst: false, size: VTR.Properties.carruselSize});
                        VTR.UI.renderListCarruselsWithTitles({categoryId: data.id, categoryName: data.name, isCarrusel: true, hasFirst: false, size: VTR.Properties.carruselSize});
                    }
                });
                $('#exit-button').show();
                $('#back-button').hide();
                VTR.Utils.debug(result);
            },
            VTR.UI.renderOptions);
        }
        else {
            var categoryIdName = navi.navigate[navi.navigate.length-1];
            var isDetailMovie = categoryIdName.isDetailMovie;
            if(isDetailMovie == 'true') {
                $("body").animate({
                  opacity: 0,
                  scale:1.3,
                  translate3d: '0,-40px,0'
                }, VTR.Properties.transitionTime, 'ease-in', function(){
                    $.ajax({
                        url: "html/detail-premium-movie.html",
                        success: function(data){
                            $('body').html(data).animate({
                                opacity:1,
                                translate3d: '0,0,0'
                            }, VTR.Properties.transitionTime, 'ease-out');
                            VTR.UI.renderTitleDetail({titleId: categoryIdName.categoryId, categoryName: categoryIdName.categoryName});
                        }
                    });
                });
                mode = "detailMovie";
                navi.navigate.pop();
            }
            else if(categoryIdName.categoryId == '[SEARCH]') {
                $("body").animate({
                  opacity: 0,
                  scale:1.3,
                  translate3d: '0,-40px,0'
                }, VTR.Properties.transitionTime, 'ease-in', function(){
                    $.ajax({
                        url: "html/search.html",
                        success: function(data){
                            $('body').html(data).animate({
                                opacity:1,
                                translate3d: '0,0,0'
                            }, VTR.Properties.transitionTime, 'ease-out');
                            VTR.UI.renderKeyboard();
                            VTR.UI.renderListSearchResults({firstCarrousel: true, isExact: false, size: VTR.Properties.lienzoSize});
                        },
                        error: function(xhr, errorType, error){
                            console.log('Error:' + error + ':' + xhr.responseText);
                        }
                    });
                }); 
                mode = 'search';
				var categoryIdNameNav = navi.navigate[navi.navigate.length-1];
                if(navi.navigate.length > 1 && categoryIdNameNav.categoryId == '[SEARCH]') {
                    navi.navigate.pop();
                }
                //navi.navigate.pop();
				
				
            }
            else {
                if (categoryIdName.categoryName == "MI CUENTA" || categoryIdName.categoryName == "MI VOD") {
                    VTR.Properties.titleMenu1stLevel = categoryIdName.categoryName;
                    VTR.Properties.titleMenu2ndLevel = ""
                    VTR.Properties.titleMenu3rdLevel = "";
                } else {
                    if (navi.navigate.length > 0) {
                        if(VTR.Properties.titleMenu1stLevel.toString().length == 0 || VTR.Properties.titleMenu1stLevel == navi.navigate[0].categoryName) {
                            VTR.Properties.titleMenu1stLevel = navi.navigate[0].categoryName;
                        }
                    }
                    if (navi.navigate.length > 1) {
                        if(VTR.Properties.titleMenu2ndLevel.toString().length == 0 || VTR.Properties.titleMenu2ndLevel == navi.navigate[1].categoryName) { 
                            VTR.Properties.titleMenu2ndLevel = navi.navigate[1].categoryName;
                        }
                    }
                    if (navi.navigate.length > 2) {
                        if(VTR.Properties.titleMenu3rdLevel.toString().length == 0 || VTR.Properties.titleMenu3rdLevel == navi.navigate[2].categoryName){
                            VTR.Properties.titleMenu3rdLevel = navi.navigate[2].categoryName;
                        }
                    }
                }
//                navi.navigate.pop();
                VTR.Properties.titlesMenu = VTR.Utils.concatenateTitlesMenu(VTR.Properties.titleMenu1stLevel, VTR.Properties.titleMenu2ndLevel, VTR.Properties.titleMenu3rdLevel);
                switch (categoryIdName.categoryName) {
                    case "MI VOD":
                        VTR.UI.renderMyVOD();
                        break;
                    case "MI CUENTA":
                        VTR.UI.renderListSubMenu({categoryId: categoryIdName.categoryId, categoryName: categoryIdName.categoryName, isSeries: categoryIdName.isSeries, isCarrusel: true});
                        VTR.UI.renderMyAccount();
                        break;
                    case "CONTINUA VIENDO":
                        $('nav .mask ul').empty();
                        VTR.UI.renderCanvasMyViewings({firstCarrousel: true, isAdult: false, isCarrusel: false, size: VTR.Properties.lienzoSize});
                        mode = 'carrousels';
                        break;
                    case "MI LISTA":
                        $('nav .mask ul').empty();
                        VTR.UI.renderCanvasMyWishList({firstCarrousel: true, isCarrusel: false, size: VTR.Properties.lienzoSize});
                        break;
                    case "MI HISTORIAL":
                        $('nav .mask ul').empty();
                        VTR.UI.renderCanvasMyHistory({firstCarrousel: true, isCarrusel: false, size: VTR.Properties.lienzoSize});
                        break;
                    case "TE RECOMENDAMOS ":
                        $('nav .mask ul').empty();
                        VTR.UI.renderCanvasMyRecommendations({firstCarrousel: true, isCarrusel: false, size: VTR.Properties.lienzoSize});
                        break;
                    case "RECOMENDACIONES":
                        $('nav .mask ul').empty();
                        VTR.UI.renderRecommendations({firstCarrousel: true, isCarrusel: false, 'titleId': sessionStorage.getItem('titleId')});
                        break;
                    case "SIMILARES":
                        $('nav .mask ul').empty();
                        VTR.UI.renderCanvasSearchRelatedRecommendations({'titleId': sessionStorage.getItem('titleId'), size: VTR.Properties.lienzoSize});
                        break;
                    case "MIS ARRIENDOS":
                        $('nav .mask ul').empty();
                        VTR.UI.renderCanvasMyPurchasedProducts({firstCarrousel: true, isCarrusel: false, size: VTR.Properties.lienzoSize});
                        break;
                    case "INICIO":
                        VTR.UI.renderListCarruselsWithTitles({categoryId: categoryIdName.categoryId, categoryName: categoryIdName.categoryName, isCarrusel: true, size: VTR.Properties.carruselSize});
                        break;
                    default:
    //                    VTR.UI.renderListSubMenu({categoryId: categoryIdName.categoryId, categoryName: categoryIdName.categoryName, isSeries: categoryIdName.isSeries, isCarrusel: true});
                        if(categoryIdName.categoryName == 'ADULTOS') {
                            VTR.UI.renderMyViewings({firstCarrousel: true, isAdult: true, size: VTR.Properties.carruselSize});
                        }
//                        if (categoryIdName.isSeries != "ContainsSeries") {
//                            VTR.UI.renderListSubMenuWithCarrouselsAndTitles({categoryId: categoryIdName.categoryId, categoryName: categoryIdName.categoryName, isCarrusel: true, hasFirst: true, size: VTR.Properties.carruselSize});
//    //                        VTR.UI.renderCanvas({categoryId: categoryIdName.categoryId, categoryName: categoryIdName.categoryName, isCarrusel: true, hasFirst: true, size: VTR.Properties.lienzoSize});
//                        }
                        if (categoryIdName.isSeries != true) {
                                if (((VTR.Properties.titleMenu1stLevel == 'KIDS') || (VTR.Properties.titleMenu1stLevel == 'CLUB GRATIS')) && navi.navigate.length > 1) {
                                    VTR.UI.renderCanvas({categoryId: categoryIdName.categoryId, categoryName: categoryIdName.categoryName, isCarrusel: false, size: VTR.Properties.lienzoSize});
                                } else {
                                    if ((VTR.Properties.titleMenu1stLevel == 'PREMIUM') && (VTR.Properties.titleMenu2ndLevel != '') && (localStorage.getItem("thirdLevelFlag") != 1)) {                    
                                        VTR.UI.renderCanvas({categoryId: categoryIdName.categoryId, categoryName: categoryIdName.categoryName, isCarrusel: false, size: VTR.Properties.lienzoSize});
                                    } else {
                                        VTR.UI.renderListSubMenuWithCarrouselsAndTitles({categoryId: categoryIdName.categoryId, categoryName: categoryIdName.categoryName, isSeries: categoryIdName.isSeries, isCarrusel: true, size: VTR.Properties.carruselSize});
                                        //VTR.UI.renderListSubMenu({categoryId: $(firstNav).data("crid"), categoryName: $(firstNav).data("name"), isSeries: $(firstNav).data("isseries"), isCarrusel: true});
                                        //VTR.UI.renderListCarruselsWithTitles({categoryId: $(firstNav).data("crid"), categoryName: $(firstNav).data("name"), isCarrusel: true, size: VTR.Properties.carruselSize});
                                    }
                                }
                            } else {
                                $("body").animate({
                                  opacity: 0,
                                  scale:1.3,
                                  translate3d: '0,-40px,0'
                                }, VTR.Properties.transitionTime, 'ease-in', function(){
                                    $.ajax({
                                        url: "html/detail-premium-movie.html",
                                        success: function(data){
                                            $('body').html(data).animate({
                                                opacity:1,
                                                translate3d: '0,0,0'
                                            }, VTR.Properties.transitionTime, 'ease-out');

                                            //var catId   = $(firstNav).data("crid");
                                            //var catNam  = $(firstNav).data("name");
                                            //var serFlag = $(firstNav).data("isseries");
                                            //var selSeason = $(firstNav).data("selseason");
                                            
                                            var catId   = categoryIdName.categoryId;
                                            var catNam  = categoryIdName.categoryName;
                                            var serFlag = categoryIdName.isSeries;
                                            var selSeason = categoryIdName.selSeason;
                                            
                                            VTR.UI.renderTitleDetailSeries({categoryId: catId, categoryName: catNam, isSeries: serFlag, selSeason: selSeason, selEpisode: 0, isCarrusel: true});
                                        },
                                        error: function(xhr, errorType, error){
                                            console.log('Error:' + error + ':' + xhr.responseText);
                                        }
                                    });
                                });
                                mode = 'navseries';
                                
                            }

                        break;
                }
                $('#exit-button').hide();
                $('#back-button').show();
                if (categoryIdName.isSeries != true) {
                    $('nav .mask ul').removeClass('active');
                    $('section#frame-carrousels ul').addClass('active');
                    mode = "carrousels";
                } else {
                    mode = "navseries";
                }
            }
        }
    }
}

VTR.UI.renderListSubMenu = function(options){
    sessionStorage.removeItem('submenucategoryid');

    $(".load-nav nav").empty();
    VTR.Catalog.getListCategories(function(result){
        if ((result.listcategories.length == 0) && (options.categoryName == "MI VOD")) {
            return;
        }

        if (result.listcategories.length != 0) {
            sessionStorage.removeItem('listcategories');
            sessionStorage.setItem('listcategories', JSON.stringify(result.listcategories));
            sessionStorage.setItem('submenucategoryid', result.listcategories[0].id);
        } else {
            sessionStorage.setItem('submenucategoryid', options.categoryId);
        }

        var itemMenu = "";
        itemMenu += "<h5 id='category-name'>{{CATEGORY_NAME}}</h5>\n";
        itemMenu += "<span id='legend-button'>MENÚ <span class='button-yellow'>A</span></span>\n";
        itemMenu += "<span class='mask'>\n";
        itemMenu += "<ul class='category-menu'>\n";

        if (options.categoryName == "MI CUENTA") {
            VTR.Properties.titleMenu1stLevel = options.categoryName;
            VTR.Properties.titleMenu2ndLevel = ""
            VTR.Properties.titleMenu3rdLevel = "";
        } else {
            if ((VTR.Properties.titleMenu1stLevel.toString().length == 0 || VTR.Properties.titleMenu1stLevel == navi.navigate[0].categoryName) && navi.navigate.length > 0) {
                VTR.Properties.titleMenu1stLevel = navi.navigate[0].categoryName;
            }
            if ((VTR.Properties.titleMenu2ndLevel.toString().length == 0 || VTR.Properties.titleMenu2ndLevel == navi.navigate[1].categoryName) && navi.navigate.length > 1) {
                VTR.Properties.titleMenu2ndLevel = navi.navigate[1].categoryName;
            }
            if ((VTR.Properties.titleMenu3rdLevel.toString().length == 0 || VTR.Properties.titleMenu3rdLevel == navi.navigate[2].categoryName) && navi.navigate.length > 2) {
                VTR.Properties.titleMenu3rdLevel = navi.navigate[2].categoryName;
            }
        }
        VTR.Properties.titlesMenu = VTR.Utils.concatenateTitlesMenu(VTR.Properties.titleMenu1stLevel, VTR.Properties.titleMenu2ndLevel, VTR.Properties.titleMenu3rdLevel);

            itemMenu = itemMenu.replace("{{CATEGORY_NAME}}", VTR.Properties.titlesMenu);


        //itemMenu = itemMenu.replace("{{CATEGORY_NAME}}", options.categoryName);
        if (result.listcategories.length != 0){
            itemMenu += "<li data-crid='" + options.categoryId + "' data-name='" + options.categoryName + "' data-isseries='" + options.isSeries + "'>INICIO</li>\n";
        }

        if (result.listcategories.length != 0) {
            $.each(result.listcategories, function(id, data){
                itemMenu += "<li data-crid='" + data.id + "' data-name='" + data.name + "' data-isseries='" + ((options.isSeries != true) ? data.isSeries : options.isSeries) + "'>" + data.name + "</li>\n";
            });
        } else {
            /*var listcategories = JSON.parse(sessionStorage.getItem('listcategories'));
            if ((listcategories != null) && (options.categoryName != "MI CUENTA")) {
                itemMenu += "<li data-crid='" + options.categoryId + "' data-name='" + options.categoryName + "' data-isseries='" + options.isSeries + "'>" + options.categoryName + "</li>\n";
                $.each(listcategories, function(id, data){
                    if (options.categoryId != data.id) {
                        itemMenu += "<li data-crid='" + data.id + "' data-name='" + data.name + "' data-isseries='" + ((options.isSeries != true) ? data.isSeries : options.isSeries) + "'>" + data.name + "</li>\n";
                    }
                });
            }*/
        }
        $(".load-nav nav").append("<div class='arrowSub'></div>");
        $(".load-nav nav").append("<div id='focusEdge' class='focusEdgeSub'></div>")
        if (options.categoryName == "MI CUENTA") {
            itemMenu += "<li data-crid='" + options.categoryId + "' data-name='MI CUENTA'>INICIO</li>\n";
            itemMenu += "<li data-crid='CONTINUA-VIENDO' data-name='CONTINUA VIENDO'>CONTINUA VIENDO</li>\n";
            itemMenu += "<li data-crid='MI-LISTA' data-name='MI LISTA'>MI LISTA</li>\n";
            itemMenu += "<li data-crid='MI-HISTORIAL' data-name='MI HISTORIAL'>MI HISTORIAL</li>\n";
            itemMenu += "<li data-crid='MIS-ARRIENDOS' data-name='MIS ARRIENDOS'>MIS ARRIENDOS</li>\n";
        }
        itemMenu += "</ul></span>\n";
        $(".load-nav nav").append(itemMenu);
        $('nav .mask ul').removeClass('active');
        $('section#frame-carrousels ul').addClass('active');
        
        var widthSub = 0;
        $.each($("span.mask .category-menu").children(), function(ix,dx) {
            widthSub += dx.offsetWidth;
        });
        if(widthSub >= $('span.mask').width()-100) {
            $(".arrowSub").show();
        }
        else {
            $(".arrowSub").hide();
        }  
        VTR.Utils.debug(result);
    }, options);
}

VTR.UI.renderListSubMenuWithCarrouselsAndTitles = function(options){
    sessionStorage.removeItem('submenucategoryid');

    $(".load-nav nav").empty();
    VTR.Series.getListCategoriesAndTitles(function(result){
        if ((result.cats.length == 0) && (options.categoryName == "MI VOD")) {
            return;
        }

        if (result.cats.length != 0) {
            sessionStorage.removeItem('listcategories');
            sessionStorage.setItem('listcategories', JSON.stringify(result.cats));
            sessionStorage.setItem('submenucategoryid', result.cats[0].id);
        } else {
            sessionStorage.setItem('submenucategoryid', options.categoryId);
        }

        var itemMenu = "";
        itemMenu += "<h5 id='category-name'>{{CATEGORY_NAME}}</h5>\n";
        itemMenu += "<span id='legend-button'>MENÚ <span class='button-yellow'>A</span></span>\n";
        itemMenu += "<span class='mask'>\n";
        itemMenu += "<ul class='category-menu'>\n";

        if (options.categoryName == "MI CUENTA") {
            VTR.Properties.titleMenu1stLevel = options.categoryName;
            VTR.Properties.titleMenu2ndLevel = ""
            VTR.Properties.titleMenu3rdLevel = "";
        } else {
            if ((VTR.Properties.titleMenu1stLevel.toString().length == 0 || VTR.Properties.titleMenu1stLevel == navi.navigate[0].categoryName) && navi.navigate.length > 0) {
                VTR.Properties.titleMenu1stLevel = navi.navigate[0].categoryName;
            }
            if ((VTR.Properties.titleMenu2ndLevel.toString().length == 0 || VTR.Properties.titleMenu2ndLevel == navi.navigate[1].categoryName) && navi.navigate.length > 1) {
                VTR.Properties.titleMenu2ndLevel = navi.navigate[1].categoryName;
            }
            if ((VTR.Properties.titleMenu3rdLevel.toString().length == 0 || VTR.Properties.titleMenu3rdLevel == navi.navigate[2].categoryName) && navi.navigate.length > 2) {
                VTR.Properties.titleMenu3rdLevel = navi.navigate[2].categoryName;
            }
        }
        VTR.Properties.titlesMenu = VTR.Utils.concatenateTitlesMenu(VTR.Properties.titleMenu1stLevel, VTR.Properties.titleMenu2ndLevel, VTR.Properties.titleMenu3rdLevel);

        itemMenu = itemMenu.replace("{{CATEGORY_NAME}}", VTR.Properties.titlesMenu);

        if ((result.cats.length != 0) && (options.isSeries != true)){
            itemMenu += "<li data-crid='" + options.categoryId + "' data-name='" + options.categoryName + "' data-isseries='" + options.isSeries + "'>INICIO</li>\n";
        }

        $(".load-nav nav").append("<div class='arrowSub'></div>");
        $(".load-nav nav").append("<div id='focusEdge' class='focusEdgeSub'></div>")
        if (options.categoryName == "MI CUENTA") {
            itemMenu += "<li data-crid='" + options.categoryId + "' data-name='MI CUENTA'>INICIO</li>\n";
            itemMenu += "<li data-crid='CONTINUA-VIENDO' data-name='CONTINUA VIENDO'>CONTINUA VIENDO</li>\n";
            itemMenu += "<li data-crid='MI-LISTA' data-name='MI LISTA'>MI LISTA</li>\n";
            itemMenu += "<li data-crid='MI-HISTORIAL' data-name='MI HISTORIAL'>MI HISTORIAL</li>\n";
            itemMenu += "<li data-crid='MIS-ARRIENDOS' data-name='MIS ARRIENDOS'>MIS ARRIENDOS</li>\n";
        }
        else {
            if (result.cats.length != 0) {
                $.each(result.cats, function(id, data){
                    if(data.titlesCount > 0) {
                        itemMenu += "<li data-crid='" + data.categoryId + "' data-name='" + data.categoryName + "' data-isseries='" + ((options.isSeries != true) ? data.isSeries : options.isSeries) + "'>" + data.categoryName + "</li>\n";
                    }
                });
            } else {
                /*var listcategories = JSON.parse(sessionStorage.getItem('listcategories'));
                if ((listcategories != null) && (options.categoryName != "MI CUENTA")) {
                    itemMenu += "<li data-crid='" + options.categoryId + "' data-name='" + options.categoryName + "' data-isseries='" + options.isSeries + "'>" + options.categoryName + "</li>\n";
                    $.each(listcategories, function(id, data){
                        if (options.categoryId != data.id) {
                            itemMenu += "<li data-crid='" + data.id + "' data-name='" + data.name + "' data-isseries='" + ((options.isSeries != true) ? data.isSeries : options.isSeries) + "'>" + data.name + "</li>\n";
                        }
                    });
                }*/
            }
        }
        itemMenu += "</ul></span>\n";
        $(".load-nav nav").append(itemMenu);
        if (options.isSeries != true){
            $('nav .mask ul').removeClass('active');
            $('section#frame-carrousels ul').addClass('active');
        }

        if (result.cats.length != 0) {
            var itemTPL = "";
            (options.hasFirst ? first = true : first = false);
            $.each(result.cats, function(id, data){
                if(data.listtitleschildren.length > 0) {
                        itemTPL += "<li id='mi-categoria' data-crid='" + data.categoryId + "' " + ((options.firstCarrousel) ? "class='first'" : "") + "><h2>{{CATEGORY_NAME}}</h2><ul class='carrousel items" + data.listtitleschildren.length + "'>\n";
                        itemTPL = itemTPL.replace("{{CATEGORY_NAME}}", data.categoryName);
                        if (data.titlesCount >= VTR.Properties.carruselSize && data.listtitleschildren.length == VTR.Properties.carruselSize) {
                            itemTPL += "<li class='view-all' href='{{CATEGORY_ID}}' data-crid='{{MOVIE_URL}}'>\n";
                            itemTPL += "  <p>VER TODO</p>\n";
                            itemTPL += "  <h3></h3>\n";
                            itemTPL += "</li>\n";
        //                    itemTPL = itemTPL.replace("{{CATEGORY_NAME}}", result.categoryName);
                            itemTPL = itemTPL.replace("{{CATEGORY_ID}}", data.categoryId);
                        }
                        $.each(data.listtitleschildren, function(i2, d2){
                            itemTPL += "<li class='movieLink' href='{{MOVIE_URL}}' data-is-series='{{SERIES}}' data-hd='{{MOVIE_HD}}' data-3d='{{MOVIE_3D}}' data-content-type='{{CONTENT_TYPE}}' data-crid='{{MOVIE_URL}}' data-bookmark='{{BOOKMARK}}'>\n";
                            itemTPL += "  <span style='background:url(\"{{MOVIE_IMG_URL}}\")'></span>\n";
                            if(d2.isHD) {
                                itemTPL += "<div class='tag-hd'><p>HD</p></div>\n";
                            }
                            if(d2.is3D) {
                                itemTPL += "<div class='tag-3d'><p>3D</p></div>\n";
                            }
                            if(d2.contentType == "Free") {
                                itemTPL += "<div class='tag-free'>GRATIS</div>\n";
                            }
                            else if(d2.contentType == "Subscription") {
                                itemTPL += "<div class='tag-subscription'>SUSCRIPCIÓN</div>\n";
                            }
                            else if(d2.contentType == "Transaction") {
                                itemTPL += "<div class='tag-rent'>ARRIENDA</div>\n";
                            }

                            itemTPL += "  <h3>{{MOVIE_TITLE}}</h3>\n";
                            itemTPL += "</li>\n";
                            itemTPL = itemTPL.replace("{{MOVIE_TITLE}}", ((d2.name.length >= VTR.UI.titleMaxLenght) ? $.trim(d2.name.substring(0,VTR.UI.titleMaxLenght))+"..." : d2.name));
                            itemTPL = itemTPL.replace("{{MOVIE_IMG_URL}}", (VTR.Utils.isset(d2.pictureUri) === false ? VTR.Properties.vodImage : d2.pictureUri) + (VTR.UI.screenFormat == "HD" ? '?w='+VTR.Properties.carruselPosterHDWidth+'&h='+VTR.Properties.carruselPosterHDHeight+'&mode=stretch' : '?w='+VTR.Properties.carruselPosterSDWidth+'&h='+VTR.Properties.carruselPosterSDHeight+'&mode=stretch'));
                            itemTPL = itemTPL.replace(/{{MOVIE_URL}}/g, d2.titleId);
                            itemTPL = itemTPL.replace("{{MOVIE_HD}}", (d2.isHD ? "hd" : ""));
                            itemTPL = itemTPL.replace("{{MOVIE_3D}}", (d2.is3D ? "3d" : ""));
                            itemTPL = itemTPL.replace("{{CONTENT_TYPE}}", d2.contentType);
                            itemTPL = itemTPL.replace("{{SERIES}}", d2.isSeries);
                            itemTPL = itemTPL.replace("{{BOOKMARK}}", d2.bookmark);
                        });

                        itemTPL += "</li></ul></li>\n";
                        $("#frame-carrousels > ul").append(itemTPL);
                        itemTPL = "";
//                    first = false;
                }
            });
            if(result.titlesCount == 0) {
                $.ajax({
                    url: 'html/error.html',
                    success: function(d){
                        $('body').html(d).animate({
                            opacity:1,
                            translate3d: '0,0,0'
                        }, VTR.Properties.transitionTime, 'ease-out');
                        navi.navigate.pop();
                        var myCateg = navi.navigate[navi.navigate.length-1];
                        VTR.UI.renderMessagePage({messageBody: 'ADVERTENCIA<br>La categoría no dispone de títulos.' , messageTitle: 'CATEGORIA SIN CONTENIDO', messageButton: 'ACEPTAR', returnPath: 'index.html', preloadedCategory: myCateg.categoryId});
                        mode = 'message';
                    },
                    error: function(xhr, errorType, error){
                        console.log('Error:' + error + ':' + xhr.responseText);
                    }
                });
            }

        } else {
            if(options.categoryName != "MI VOD") {
                options.size = VTR.Properties.lienzoSize;
                VTR.UI.renderCanvas(options);
            }
        }
        var widthSub = 0;
        $.each($("span.mask .category-menu").children(), function(ix,dx) {
            widthSub += dx.offsetWidth;
        });
        if(widthSub >= $('span.mask').width()-100) {
            $(".arrowSub").show();
        }
        else {
            $(".arrowSub").hide();
        }
        VTR.Utils.debug(result);
    }, options);
}

VTR.UI.renderListRecomMenu = function(options){
    //VTR.Catalog.getListCategories(function(result){

        $(".load-nav nav").empty();
        var itemMenu = "";
        itemMenu += "<h5 id='category-name'>RECOMENDACIONES</h5>\n";
        itemMenu += "<span id='legend-button'>MENÚ <span class='button-yellow'>A</span></span>\n";
        itemMenu += "<span class='mask'>\n";
        itemMenu += "<ul class='category-menu'>\n";
        itemMenu += "<li data-crid='" + options.categoryId + "' data-name='RECOMENDACIONES'>INICIO</li>\n";
        itemMenu += "<li data-crid='RECOM-SIMILARES' data-name='SIMILARES'>SIMILARES</li>\n";
        if(options.relations.length > 0) {
            $.each(options.relations, function(i,d) {
                itemMenu += "<li data-crid='"+d.id+"' data-name='"+d.Name+"'>" + d.Name + "</li>\n";
            });
        }
        itemMenu += "</ul></span>\n";
        $(".load-nav nav").append(itemMenu);
        $('nav .mask ul').removeClass('active');
        $('section#frame-carrousels ul').addClass('active');
        $(".load-nav nav").append("<div class='arrowSub'></div>");
        $(".load-nav nav").append("<div id='focusEdge' class='focusEdgeSub'></div>")
		
		var widthSub = 0;
		$.each($("span.mask .category-menu").children(), function(ix,dx) {
			widthSub += dx.offsetWidth;
		});
		if(widthSub >= $('span.mask').width()) {
			$(".arrowSub").show();
		}
		else {
			$(".arrowSub").hide();
		}

        //VTR.Utils.debug(result);
    //}, options);
}

VTR.UI.renderListCarruselsWithTitles = function(options){
    VTR.Series.getListCategoriesAndTitles(function(result){
        if (result.cats.length != 0) {
            var itemTPL = "";
            (options.hasFirst ? first = true : first = false);
            $.each(result.cats, function(id, data){
                if(data.listtitleschildren.length > 0) {
                        itemTPL += "<li id='mi-categoria' data-crid='" + data.categoryId + "' " + ((options.firstCarrousel) ? "class='first'" : "") + "><h2>{{CATEGORY_NAME}}</h2><ul class='carrousel items" + data.listtitleschildren.length + "'>\n";
                        itemTPL = itemTPL.replace("{{CATEGORY_NAME}}", data.categoryName);
                        if (data.titlesCount >= VTR.Properties.carruselSize && data.listtitleschildren.length == VTR.Properties.carruselSize) {
                            itemTPL += "<li class='view-all' href='{{CATEGORY_ID}}' data-crid='{{MOVIE_URL}}'>\n";
                            itemTPL += "  <p>VER TODO</p>\n";
                            itemTPL += "  <h3></h3>\n";
                            itemTPL += "</li>\n";
        //                    itemTPL = itemTPL.replace("{{CATEGORY_NAME}}", result.categoryName);
                            itemTPL = itemTPL.replace("{{CATEGORY_ID}}", data.categoryId);
                        }
                        $.each(data.listtitleschildren, function(i2, d2){
                            itemTPL += "<li class='movieLink' href='{{MOVIE_URL}}' data-is-series='{{SERIES}}' data-hd='{{MOVIE_HD}}' data-3d='{{MOVIE_3D}}' data-content-type='{{CONTENT_TYPE}}' data-crid='{{MOVIE_URL}}' data-bookmark='{{BOOKMARK}}'>\n";
                            itemTPL += "  <span style='background:url(\"{{MOVIE_IMG_URL}}\")'></span>\n";
                            if(d2.isHD) {
                                itemTPL += "<div class='tag-hd'><p>HD</p></div>\n";
                            }
                            if(d2.is3D) {
                                itemTPL += "<div class='tag-3d'><p>3D</p></div>\n";
                            }
                            if(d2.contentType == "Free") {
                                itemTPL += "<div class='tag-free'>GRATIS</div>\n";
                            }
                            else if(d2.contentType == "Subscription") {
                                itemTPL += "<div class='tag-subscription'>SUSCRIPCIÓN</div>\n";
                            }
                            else if(d2.contentType == "Transaction") {
                                itemTPL += "<div class='tag-rent'>ARRIENDA</div>\n";
                            }

                            itemTPL += "  <h3>{{MOVIE_TITLE}}</h3>\n";
                            itemTPL += "</li>\n";
                            itemTPL = itemTPL.replace("{{MOVIE_TITLE}}", ((d2.name.length >= VTR.UI.titleMaxLenght) ? $.trim(d2.name.substring(0,VTR.UI.titleMaxLenght))+"..." : d2.name));
                            itemTPL = itemTPL.replace("{{MOVIE_IMG_URL}}", (VTR.Utils.isset(d2.pictureUri) === false ? VTR.Properties.vodImage : d2.pictureUri) + (VTR.UI.screenFormat == "HD" ? '?w='+VTR.Properties.carruselPosterHDWidth+'&h='+VTR.Properties.carruselPosterHDHeight+'&mode=stretch' : '?w='+VTR.Properties.carruselPosterSDWidth+'&h='+VTR.Properties.carruselPosterSDHeight+'&mode=stretch'));

                            itemTPL = itemTPL.replace(/{{MOVIE_URL}}/g, d2.titleId);
                            itemTPL = itemTPL.replace("{{MOVIE_HD}}", (d2.isHD ? "hd" : ""));
                            itemTPL = itemTPL.replace("{{MOVIE_3D}}", (d2.is3D ? "3d" : ""));
                            itemTPL = itemTPL.replace("{{CONTENT_TYPE}}", d2.contentType);
                            itemTPL = itemTPL.replace("{{SERIES}}", d2.isSeries);
                            itemTPL = itemTPL.replace("{{BOOKMARK}}", d2.bookmark);
                        });

                        itemTPL += "</li></ul></li>\n";
                        $("#frame-carrousels > ul").append(itemTPL);
                        itemTPL = "";
//                    first = false;
                }
            });
            if(result.titlesCount == 0) {
//                VTR.UI.renderMessageContent({messageBody: 'ADVERTENCIA: La categoría no dispone de títulos.', messageTitle: 'CATEGORIA SIN CONTENIDO', messageButton: 'VOLVER AL HOME', returnPath: 'index.html', preloadedCategory: options.categoryId});
                /*$().toastmessage('showToast', {
                                text     : 'Categoría sin contenido.',
                                sticky   : true,
                                type     : 'error'
                });
                $('nav .mask ul').addClass('active');
                $('#focusEdge').css('width', $('nav .mask ul>li').css('width'));
                $('section#frame-carrousels ul').removeClass('active');
                $('div.foco').hide();
                mode = 'nav';*/

                $.ajax({
                    url: 'html/error.html',
                    success: function(d){
                        $('body').html(d).animate({
                            opacity:1,
                            translate3d: '0,0,0'
                        }, VTR.Properties.transitionTime, 'ease-out');
                        navi.navigate.pop();
                        var myCateg = navi.navigate[navi.navigate.length-1];
                        VTR.UI.renderMessagePage({messageBody: 'ADVERTENCIA<br>La categoría no dispone de títulos.' , messageTitle: 'CATEGORIA SIN CONTENIDO', messageButton: 'ACEPTAR', returnPath: 'index.html', preloadedCategory: myCateg.categoryId});
                        mode = 'message';
                    },
                    error: function(xhr, errorType, error){
                        console.log('Error:' + error + ':' + xhr.responseText);
                    }
                });
            }

        } else {
            if(options.categoryName != "MI VOD") {
                options.size = VTR.Properties.lienzoSize;
                VTR.UI.renderCanvas(options);
            }
        }
        VTR.Utils.debug(result);
    }, options);
}

/* BORRAR VTR.UI.renderListTitlesAndChildren */
VTR.UI.renderListTitlesAndChildren = function(options){
    var itemTPL = "";
    VTR.Catalog.getTitlesAndChildrenByCategory(function(result){
        if (result.listtitleschildren.length != 0) {
//            $.each(result.listcategories.Category, function(id, data){
                itemTPL += "<li id='mi-categoria' data-crid='" + result.categoryId + "' " + ((options.firstCarrousel) ? "class='first'" : "") + "><h2>{{CATEGORY_NAME}}</h2><ul class='carrousel items" + result.listtitleschildren.length + "'>\n";
                itemTPL = itemTPL.replace("{{CATEGORY_NAME}}", result.categoryName);
                $.each(result.listtitleschildren, function(i2, d2){
                    itemTPL += "<li class='movieLink' href='{{MOVIE_URL}}' data-is-series='{{SERIES}}' data-hd='{{MOVIE_HD}}' data-3d='{{MOVIE_3D}}' data-content-type='{{CONTENT_TYPE}}' data-crid='{{MOVIE_URL}}' data-bookmark='{{BOOKMARK}}'>\n";
                    itemTPL += "  <span style='background:url(\"{{MOVIE_IMG_URL}}\")'></span>\n";
                    if(d2.isHD) {
                        itemTPL += "<div class='tag-hd'><p>HD</p></div>\n";
                    }
                    if(d2.is3D) {
                        itemTPL += "<div class='tag-3d'><p>3D</p></div>\n";
                    }
                    if(d2.contentType == "Free") {
                        itemTPL += "<div class='tag-free'>GRATIS</div>\n";
                    }
                    else if(d2.contentType == "Subscription") {
                        itemTPL += "<div class='tag-subscription'>SUSCRIPCIÓN</div>\n";
                    }
                    else if(d2.contentType == "Transaction") {
                        itemTPL += "<div class='tag-rent'>ARRIENDA</div>\n";
                    }

                    itemTPL += "  <h3>{{MOVIE_TITLE}}</h3>\n";
                    itemTPL += "</li>\n";
                    itemTPL = itemTPL.replace("{{MOVIE_TITLE}}", ((d2.name.length >= VTR.UI.titleMaxLenght) ? $.trim(d2.name.substring(0,VTR.UI.titleMaxLenght))+"..." : d2.name));
                    itemTPL = itemTPL.replace("{{MOVIE_IMG_URL}}", (VTR.Utils.isset(d2.pictureUri) === false ? VTR.Properties.vodImage : d2.pictureUri) + (VTR.UI.screenFormat == "HD" ? '?w='+VTR.Properties.carruselPosterHDWidth+'&h='+VTR.Properties.carruselPosterHDHeight+'&mode=stretch' : '?w='+VTR.Properties.carruselPosterSDWidth+'&h='+VTR.Properties.carruselPosterSDHeight+'&mode=stretch'));
                    itemTPL = itemTPL.replace(/{{MOVIE_URL}}/g, d2.titleId);
                    itemTPL = itemTPL.replace("{{MOVIE_HD}}", (d2.isHD ? "hd" : ""));
                    itemTPL = itemTPL.replace("{{MOVIE_3D}}", (d2.is3D ? "3d" : ""));
                    itemTPL = itemTPL.replace("{{CONTENT_TYPE}}", d2.contentType);
                    itemTPL = itemTPL.replace("{{SERIES}}", d2.isSeries);
                    itemTPL = itemTPL.replace("{{BOOKMARK}}", d2.bookmark);
                });

                if (result.titlesCount >= VTR.Properties.carruselSize && result.listtitleschildren.length == VTR.Properties.carruselSize) {
                    itemTPL += "<li class='view-all' href='{{CATEGORY_ID}}' data-crid='{{MOVIE_URL}}'>\n";
                    itemTPL += "  <p>VER TODO</p>\n";
                    itemTPL += "  <h3></h3>\n";
                    itemTPL += "</li>\n";
//                    itemTPL = itemTPL.replace("{{CATEGORY_NAME}}", result.categoryName);
                    itemTPL = itemTPL.replace("{{CATEGORY_ID}}", result.categoryId);
                }
                itemTPL += "</li></ul></li>\n";
                $("#frame-carrousels > ul").append(itemTPL);
                itemTPL = "";
//            });
        }
        VTR.Utils.debug(result);
    },
    options);
}

/* BORRAR VTR.UI.renderListTitlesByCategory */
VTR.UI.renderListTitlesByCategory = function(options){
    var itemTPL = "";
    //$("#frame-carrousels > ul").empty();
    VTR.Series.getListTitlesByCategory(function(result) {
        itemTPL += "<li id='mi-categoria' data-crid='" + result.categoryId + "' " + ((options.firstCarrousel) ? "class='first'" : "") + "><h2>{{CATEGORY_NAME}}</h2><ul class='carrousel items" + result.listtitles.length + "'>\n";
        itemTPL = itemTPL.replace("{{CATEGORY_NAME}}", result.categoryName);
        $.each(result.listtitles, function(id, data){
            itemTPL += "<li class='movieLink' href='{{MOVIE_URL}}' data-is-series='{{SERIES}}' data-hd='{{MOVIE_HD}}' data-3d='{{MOVIE_3D}}' data-content-type='{{CONTENT_TYPE}}' data-crid='{{MOVIE_URL}}' data-bookmark='{{BOOKMARK}}'>\n";
            itemTPL += "  <span style='background:url(\"{{MOVIE_IMG_URL}}\")'></span>\n";
            if(data.isHD) {
                itemTPL += "<div class='tag-hd'><p>HD</p></div>\n";
            }
            if(data.is3D) {
                itemTPL += "<div class='tag-3d'><p>3D</p></div>\n";
            }
            if(data.contentType == "Free") {
                itemTPL += "<div class='tag-free'>GRATIS</div>\n";
            }
            else if(data.contentType == "Subscription") {
                itemTPL += "<div class='tag-subscription'>SUSCRIPCIÓN</div>\n";
            }
            else if(data.contentType == "Transaction") {
                itemTPL += "<div class='tag-rent'>ARRIENDA</div>\n";
            }

            itemTPL += "  <h3>{{MOVIE_TITLE}}</h3>\n";
            itemTPL += "</li>\n";
            itemTPL = itemTPL.replace("{{MOVIE_TITLE}}", ((data.name.length >= VTR.UI.titleMaxLenght) ? $.trim(data.name.substring(0,VTR.UI.titleMaxLenght))+"..." : data.name));
            itemTPL = itemTPL.replace("{{MOVIE_IMG_URL}}", (VTR.Utils.isset(data.pictureUri) === false ? VTR.Properties.vodImage : data.pictureUri) + (VTR.UI.screenFormat == "HD" ? '?w='+VTR.Properties.carruselPosterHDWidth+'&h='+VTR.Properties.carruselPosterHDHeight+'&mode=stretch' : '?w='+VTR.Properties.carruselPosterSDWidth+'&h='+VTR.Properties.carruselPosterSDHeight+'&mode=stretch'));
            itemTPL = itemTPL.replace(/{{MOVIE_URL}}/g, data.titleId);
            itemTPL = itemTPL.replace("{{MOVIE_HD}}", (data.isHD ? "hd" : ""));
            itemTPL = itemTPL.replace("{{MOVIE_3D}}", (data.is3D ? "3d" : ""));
            itemTPL = itemTPL.replace("{{CONTENT_TYPE}}", data.contentType);
            itemTPL = itemTPL.replace("{{SERIES}}", data.isSeries);
            itemTPL = itemTPL.replace("{{BOOKMARK}}", data.bookmark);
        });

        if (result.titlesCount >= VTR.Properties.carruselSize && result.listtitles.length == VTR.Properties.carruselSize) {
            itemTPL += "<li class='view-all' href='{{CATEGORY_ID}}' data-crid='{{MOVIE_URL}}'>\n";
            itemTPL += "  <p>VER TODO</p>\n";
            itemTPL += "  <h3></h3>\n";
            itemTPL += "</li>\n";
//            itemTPL = itemTPL.replace("{{CATEGORY_NAME}}", result.categoryName);
            itemTPL = itemTPL.replace("{{CATEGORY_ID}}", result.categoryId);
        }
        itemTPL += "</li></ul></li>\n";
        $("#frame-carrousels > ul").append(itemTPL);
        itemTPL = "";
        VTR.Utils.debug(result);
    },
    options);
}

VTR.UI.renderCanvas = function(options){
    VTR.Series.getListTitlesByCategory(function(result) {
        if(result.listtitles.length != 0) {
            var itemTPL = "";
            var rowCount = 0;
            var categoryName = "";
            categoryName = (VTR.Utils.isset(result.categoryName) ? result.categoryName.toString().toUpperCase() : "");
            $(".load-nav nav").empty();
            itemTPL += "<li id='my-canvas' " + ((options.firstCarrousel) ? "class='first'" : "") + " data-categoryid='{{CATEGORY_ID}}'  data-categoryname='{{CATEGORY_NAME}}'>\n";
            itemTPL = itemTPL.replace("{{CATEGORY_ID}}", result.categoryId);
            itemTPL = itemTPL.replace("{{CATEGORY_NAME}}", result.categoryName);

            //VTR.Properties.titleMenu2ndLevel = categoryName;
            if (navi.navigate.length > 0) {
                if(VTR.Properties.titleMenu1stLevel.toString().length == 0 || VTR.Properties.titleMenu1stLevel == navi.navigate[0].categoryName) {
                    VTR.Properties.titleMenu1stLevel = navi.navigate[0].categoryName;
                }
            }
            if (navi.navigate.length > 1) {
                if(VTR.Properties.titleMenu2ndLevel.toString().length == 0 || VTR.Properties.titleMenu2ndLevel == navi.navigate[1].categoryName) {
                    VTR.Properties.titleMenu2ndLevel = navi.navigate[1].categoryName;
                }
            }
            if (navi.navigate.length > 2) {
                if(VTR.Properties.titleMenu3rdLevel.toString().length == 0 || VTR.Properties.titleMenu3rdLevel == navi.navigate[2].categoryName){
                    VTR.Properties.titleMenu3rdLevel = navi.navigate[2].categoryName;
                }
            }
            VTR.Properties.titlesMenu = VTR.Utils.concatenateTitlesMenu(VTR.Properties.titleMenu1stLevel, VTR.Properties.titleMenu2ndLevel, VTR.Properties.titleMenu3rdLevel);
            if($("#category-name").length == 0){
                $("nav.wrapper").prepend("<h5 id='category-name'>"+VTR.Properties.titlesMenu+"</h5>");
            }
            else {
                $("#category-name").html(VTR.Properties.titlesMenu);
            }
            itemTPL += "<ul class='carrousel items{{ITEMS_SIZE}}'>\n";
            /*
            VTR.UI.firstCarrousel = true;
            itemTPL += "<li id='mi-categoria' " + ((VTR.UI.firstCarrousel) ? "class='first'" : "") + "><ul class='carrousel'>\n";
            $("#category-name").html(categoryName);*/
            $.each(result.listtitles, function(id, data){
                itemTPL += "<li class='movieLink' href='{{MOVIE_URL}}' data-hd='{{MOVIE_HD}}' data-is-series='{{SERIES}}' data-3d='{{MOVIE_3D}}' data-content-type='{{CONTENT_TYPE}}' data-bookmark='{{BOOKMARK}}' data-crid='{{MOVIE_URL}}'>\n";
                itemTPL += "  <span style='background:url(\"{{MOVIE_IMG_URL}}\")'></span>\n";
                if(data.isHD) {
                    itemTPL += "<div class='tag-hd'><p>HD</p></div>\n";
                }
                if(data.is3D) {
                    itemTPL += "<div class='tag-3d'><p>3D</p></div>\n";
                }
                if(data.contentType == "Free") {
                    itemTPL += "<div class='tag-free'>GRATIS</div>\n";
                }
                else if(data.contentType == "Subscription") {
                    itemTPL += "<div class='tag-subscription'>SUSCRIPCIÓN</div>\n";
                }
                else if(data.contentType == "Transaction") {
                    itemTPL += "<div class='tag-rent'>ARRIENDA</div>\n";
                }
                itemTPL += "  <h3>{{MOVIE_TITLE}}</h3>\n";
                itemTPL += "</li>\n";
                itemTPL = itemTPL.replace("{{MOVIE_TITLE}}", ((data.name.length >= VTR.UI.titleMaxLenght) ? $.trim(data.name.substring(0,VTR.UI.titleMaxLenght))+"..." : data.name));
                itemTPL = itemTPL.replace("{{MOVIE_IMG_URL}}", (VTR.Utils.isset(data.pictureUri) === false ? VTR.Properties.vodImage : data.pictureUri) + (VTR.UI.screenFormat == "HD" ? '?w='+VTR.Properties.canvasPosterHDWidth+'&h='+VTR.Properties.canvasPosterHDHeight+'&mode=stretch' : '?w='+VTR.Properties.canvasPosterSDWidth+'&h='+VTR.Properties.canvasPosterSDHeight+'&mode=stretch'));
                itemTPL = itemTPL.replace(/{{MOVIE_URL}}/g, data.titleId);
                itemTPL = itemTPL.replace("{{MOVIE_HD}}", (data.isHD ? "hd" : ""));
                itemTPL = itemTPL.replace("{{MOVIE_3D}}", (data.is3D ? "3d" : ""));
                itemTPL = itemTPL.replace("{{CONTENT_TYPE}}", data.contentType);
                itemTPL = itemTPL.replace("{{SERIES}}", data.isSeries);
                itemTPL = itemTPL.replace("{{BOOKMARK}}", data.bookmark);
                //itemTPL = itemTPL.replace("{{COVER_SIZE}}", (VTR.UI.screenFormat == 'HD' ? '190px 253px' : '115px 153px'));

                if ((id + 1) % (VTR.UI.screenFormat == 'HD' ? VTR.Properties.canvasSize : VTR.Properties.canvasSizeSD) == 0) {
                    rowCount++;
                    itemTPL = itemTPL.replace("{{ITEMS_SIZE}}", (VTR.UI.screenFormat == 'HD' ? VTR.Properties.canvasSize : VTR.Properties.canvasSizeSD));
                    if((id + 1) != result.listtitles.length) {
                        itemTPL += "</ul>\n";
                        itemTPL += "</li>\n";
                        itemTPL += "<li id='my-canvas'>\n";
                        itemTPL += "<ul class='carrousel items{{ITEMS_SIZE}}'>";
                    }
                }
            });
            itemTPL += "</ul>\n";
            itemTPL += "</li>\n";
            itemTPL = itemTPL.replace("{{ITEMS_SIZE}}", (result.listtitles.length - ((VTR.UI.screenFormat == 'HD' ? VTR.Properties.canvasSize : VTR.Properties.canvasSizeSD) * rowCount)));
            $("#frame-carrousels > ul").append(itemTPL);
            $("#frame-carrousels").addClass("repository");
            VTR.Utils.debug(result);
        }
        else {
            $.ajax({
                url: 'html/error.html',
                success: function(d){
                    $('body').html(d).animate({
                        opacity:1,
                        translate3d: '0,0,0'
                    }, VTR.Properties.transitionTime, 'ease-out');
                    navi.navigate.pop();
                    var myCateg = null;
                    if(navi.navigate.length>0){
                        myCateg = navi.navigate[navi.navigate.length-1].categoryId;
                    }
                    VTR.UI.renderMessagePage({messageBody: 'ADVERTENCIA<br>La categoría no dispone de títulos.' , messageTitle: 'CATEGORIA SIN CONTENIDO', messageButton: 'ACEPTAR', returnPath: 'index.html', preloadedCategory: myCateg});
                    mode = 'message';
                },
                error: function(xhr, errorType, error){
                    console.log('Error:' + error + ':' + xhr.responseText);
                }
            });
        }
    },
    options);
}

VTR.UI.renderCanvasMyWishList = function(options){
    VTR.Account.getMyWishList(function(result){
        if(result.mywishlist.length > 0) {
            var itemTPL = "";
            var rowCount = 0;
            itemTPL += "<li id='my-canvas-wishlist' " + ((options.firstCarrousel) ? "class='first'" : "") + ">\n";
    //        VTR.Properties.titleMenu2ndLevel = "MI LISTA";
            VTR.Properties.titlesMenu = VTR.Utils.concatenateTitlesMenu(VTR.Properties.titleMenu1stLevel, VTR.Properties.titleMenu2ndLevel, VTR.Properties.titleMenu3rdLevel);
            if($("#category-name").length == 0){
                $("nav.wrapper").prepend("<h5 id='category-name'>"+VTR.Properties.titlesMenu+"</h5>");
            }
            else {
                $("#category-name").html(VTR.Properties.titlesMenu);
            }
            itemTPL += "<ul class='carrousel items{{ITEMS_SIZE}}'>\n";
            $.each(result.mywishlist, function(id, data){
                itemTPL += "<li class='movieLink' href='{{MOVIE_URL}}' data-hd='{{MOVIE_HD}}' data-3d='{{MOVIE_3D}}' data-content-type='{{CONTENT_TYPE}}' data-bookmark='{{BOOKMARK}}' data-crid='{{MOVIE_URL}}'>\n";
                itemTPL += "  <span style='background:url(\"{{MOVIE_IMG_URL}}\") no-repeat;'></span>\n";
                if(data.isHD) {
                    itemTPL += "<div class='tag-hd'><p>HD</p></div>\n";
                }
                if(data.is3D) {
                    itemTPL += "<div class='tag-3d'><p>3D</p></div>\n";
                }
                if(data.contentType == "Free") {
                    itemTPL += "<div class='tag-free'>GRATIS</div>\n";
                }
                else if(data.contentType == "Subscription") {
                    itemTPL += "<div class='tag-subscription'>SUSCRIPCIÓN</div>\n";
                }
                else if(data.contentType == "Transaction") {
                    itemTPL += "<div class='tag-rent'>ARRIENDA</div>\n";
                }
                itemTPL += "  <h3>{{MOVIE_TITLE}}</h3>\n";
                itemTPL += "</li>\n";
                itemTPL = itemTPL.replace("{{MOVIE_TITLE}}", ((data.name.length >= VTR.UI.titleMaxLenght) ? $.trim(data.name.substring(0,VTR.UI.titleMaxLenght))+"..." : data.name));
                itemTPL = itemTPL.replace("{{MOVIE_IMG_URL}}", (VTR.Utils.isset(data.pictureUri) === false ? VTR.Properties.vodImage : data.pictureUri) + (VTR.UI.screenFormat == "HD" ? '?w='+VTR.Properties.canvasPosterHDWidth+'&h='+VTR.Properties.canvasPosterHDHeight+'&mode=stretch' : '?w='+VTR.Properties.canvasPosterSDWidth+'&h='+VTR.Properties.canvasPosterSDHeight+'&mode=stretch'));
                itemTPL = itemTPL.replace(/{{MOVIE_URL}}/g, data.titleId);
                itemTPL = itemTPL.replace("{{MOVIE_HD}}", (data.isHD ? "hd" : ""));
                itemTPL = itemTPL.replace("{{MOVIE_3D}}", (data.is3D ? "3d" : ""));
                itemTPL = itemTPL.replace("{{CONTENT_TYPE}}", data.contentType);
                itemTPL = itemTPL.replace("{{BOOKMARK}}", data.bookmark);
    //            itemTPL = itemTPL.replace("{{COVER_SIZE}}", (VTR.UI.screenFormat == 'HD' ? '190px 253px' : '115px 153px'));

                if ((id + 1) % (VTR.UI.screenFormat == 'HD' ? VTR.Properties.canvasSize : VTR.Properties.canvasSizeSD) == 0) {
                    rowCount++;
                    itemTPL = itemTPL.replace("{{ITEMS_SIZE}}", (VTR.UI.screenFormat == 'HD' ? VTR.Properties.canvasSize : VTR.Properties.canvasSizeSD));
                    if((id + 1) != result.mywishlist.length) {
                        itemTPL += "</ul>\n";
                        itemTPL += "</li>\n";
                        itemTPL += "<li id='my-canvas-wishlist'>\n";
                        itemTPL += "<ul class='carrousel items{{ITEMS_SIZE}}'>";
                    }
                }
            });
            itemTPL += "</ul>\n";
            itemTPL += "</li>\n";
            itemTPL = itemTPL.replace("{{ITEMS_SIZE}}", (result.mywishlist.length - ((VTR.UI.screenFormat == 'HD' ? VTR.Properties.canvasSize : VTR.Properties.canvasSizeSD) * rowCount)));
            $("#frame-carrousels > ul").append(itemTPL);
            $("#frame-carrousels").addClass("repository");
            VTR.Utils.debug(result);
        }
    },
    options);
}

VTR.UI.renderMyWishList = function(options){
    var itemTPL = "";
    var entState = "";
    VTR.Account.getMyWishList(function(result){
        if(result.mywishlist.length > 0) {
            itemTPL += "<li id='mi-lista'" + ((options.firstCarrousel) ? "class='first'" : "") + "><h2>MI LISTA</h2><ul class='carrousel items" + result.mywishlist.length + "'>\n";
            if (result.mywishlist.length >= VTR.Properties.carruselSize && result.mywishlist.length == VTR.Properties.carruselSize) {
                itemTPL += "<li class='view-all' href='{{CATEGORY_ID}}' data-crid='{{MOVIE_URL}}'>\n";
                itemTPL += "  <p>VER TODO</p>\n";
                itemTPL += "  <h3></h3>\n";
                itemTPL += "</li>\n";
            }
            $.each(result.mywishlist, function(id, data){
                itemTPL += "<li class='movieLink' href='{{MOVIE_URL}}' data-type='{{MOVIE_HD}}' data-crid='{{MOVIE_URL}}'>\n";
                itemTPL += "  <span style='background:url(\"{{MOVIE_IMG_URL}}\")'></span>\n";
                if(data.isHD) {
                    itemTPL += "<div class='tag-hd'><p>HD</p></div>\n";
                }
                if(data.is3D) {
                    itemTPL += "<div class='tag-3d'><p>3D</p></div>\n";
                }
                if(data.contentType == "Free") {
                    itemTPL += "<div class='tag-free'>GRATIS</div>\n";
                }
                else if(data.contentType == "Subscription") {
                    itemTPL += "<div class='tag-subscription'>SUSCRIPCIÓN</div>\n";
                }
                else if(data.contentType == "Transaction") {
                    itemTPL += "<div class='tag-rent'>ARRIENDA</div>\n";
                }
                itemTPL += "  <h3>{{MOVIE_TITLE}}</h3>\n";
                itemTPL = itemTPL.replace("{{MOVIE_TITLE}}", ((data.name.length >= VTR.UI.titleMaxLenght) ? $.trim(data.name.substring(0,VTR.UI.titleMaxLenght))+"..." : data.name));
                itemTPL = itemTPL.replace("{{MOVIE_IMG_URL}}", (VTR.Utils.isset(data.pictureUri) === false ? VTR.Properties.vodImage : data.pictureUri) + (VTR.UI.screenFormat == "HD" ? '?w='+VTR.Properties.carruselPosterHDWidth+'&h='+VTR.Properties.carruselPosterHDHeight+'&mode=stretch' : '?w='+VTR.Properties.carruselPosterSDWidth+'&h='+VTR.Properties.carruselPosterSDHeight+'&mode=stretch'));
                itemTPL = itemTPL.replace(/{{MOVIE_URL}}/g, data.titleId);
                itemTPL = itemTPL.replace("{{MOVIE_HD}}", (data.isHD ? "HD" : "SD"));
//                itemTPL = itemTPL.replace("{{COVER_SIZE}}", (VTR.UI.screenFormat == 'HD' ? '190px 253px' : '115px 153px'));
            });
//            itemTPL = itemTPL.replace("{{CATEGORY_NAME}}", "MI LISTA");
            itemTPL += "</li></ul></li>\n";
            VTR.Properties.htmlMyWishlist = itemTPL;
//            $(itemTPL).insertAfter("#frame-carrousels > ul > div");
            VTR.Utils.debug(result);
        }
    },
    options);
}


VTR.UI.renderTitleDetail = function(options){
    VTR.Content.getTitleDetail(function(result) {
        var itemTPL = "";
        if (VTR.UI.screenFormat == "HD") {
            itemTPL += "<article>"
            itemTPL += "    <div class='continue' style='display:none;'>\n";
            itemTPL += "       <a class='play-element-fix' style='display:block;top:180px;'></a>\n";
            itemTPL += "       <div class='progress' style='max-width:{{BOOKMARK}}%'>\n";
            itemTPL += "       </div>\n";
            itemTPL += "    </div>\n";
            itemTPL += "<span><img src='{{IMAGE_URL}}'></span>\n";
//            itemTPL += "  <div class='name-rating button'></div>\n";
            itemTPL += "  <small id='last-availability'></small>\n";
            itemTPL += "</article><article>"
            itemTPL += "  <h1><span id='title-name'>{{NAME}}</span> ";
            itemTPL += "{{RATING}}";
            itemTPL += "</h1>\n";
            itemTPL += "     <ul>\n";
            itemTPL += "        <li><strong>Género:</strong> {{GENRE}}</li>\n";
            itemTPL += "        <li><strong>Duración:</strong> {{DURATION}}</li>\n";
            itemTPL += "        <li><strong>Año:</strong> {{YEAR}}</li>\n";
            itemTPL += "     </ul>\n";
            itemTPL += " <p>{{SYNOPSIS}}</p>\n";
            itemTPL += " <ul>\n";
//            itemTPL += "<li id='lang'></li>\n";
//            itemTPL += " <li id='subtitles'></li>\n";
            itemTPL += " <li><strong>Director:</strong> <span id='director'>{{DIRECTOR}}</span></li>\n";
            itemTPL += " <li><strong>Actores:</strong> <span id='actors'>{{ACTORS}}</span></li></ul>\n";
            itemTPL += "</article>"
        }
        else {
            itemTPL += "<article>"
            itemTPL += "    <div class='continue' style='display:none;'>\n";
	        itemTPL += "       <a class='play-element-fix' style='display:block;top:60px;'></a>\n";
            itemTPL += "       <div class='progress' style='max-width:{{BOOKMARK}}%'>\n";
            itemTPL += "       </div>\n";
            itemTPL += "    </div>\n";
            itemTPL += "<span><img src='{{IMAGE_URL}}'></span>\n";
            itemTPL += "<div class='rating-content'>\n";
            /*itemTPL += "     <fieldset id='rating' class='star3'>\n";
            itemTPL += "        <input type='radio' id='star5' name='rating' value='5' /><label for='star5' class='star5'>5 stars</label>\n";
            itemTPL += "        <input type='radio' id='star4' name='rating' value='4' /><label for='star4' class='star4'>4 stars</label>\n";
            itemTPL += "        <input type='radio' id='star3' name='rating' value='3' checked='checked'/><label for='star3' class='star3'>3 stars</label>\n";
            itemTPL += "        <input type='radio' id='star2' name='rating' value='2' /><label for='star2' class='star2'>2 stars</label>\n";
            itemTPL += "        <input type='radio' id='star1' name='rating' value='1' /><label for='star1' class='star1'>1 star</label>\n";
            itemTPL += "     </fieldset>\n";*/
            itemTPL += "   {{RATING}} \n";
            itemTPL += "   <ul>\n";
			// itemTPL += "      <li>{{YEAR}}</li> \n";
			// itemTPL += "      <li>{{DURATION}}</li></ul>\n";
            itemTPL += "</div>\n";
            itemTPL += "<small id='last-availability'></small>\n";
            itemTPL += "</article><article>"
		            itemTPL += "     <ul style='margin-top: 2px;'>\n";
		            itemTPL += "        <li><strong>Género:</strong> <span>{{GENRE}}</span></li>\n";
		            itemTPL += "        <li><strong>Duración:</strong> <span>{{DURATION}}</span></li>\n";
		            itemTPL += "        <li><strong>Año:</strong> <span>{{YEAR}}</span></li>\n";
		            itemTPL += "     </ul>\n";
		            itemTPL += "<p class='truncate-length'>{{SYNOPSIS}}</p>\n";
			itemTPL += "     <ul style='margin-top: 2px;'>\n";
//            itemTPL += "        <li id='lang'></li>\n";
//            itemTPL += "        <li id='subtitles'></li>\n";
            itemTPL += "        <li><strong>Director:</strong> <span>{{DIRECTOR}}</span></li>\n";
            itemTPL += "        <li><strong>Actores:</strong> <span>{{ACTORS}}</span></li>\n";
			itemTPL += "     </ul>\n";
            itemTPL += "</article>"
        }
        $.each(result.titledetail, function(id, data){
            if (VTR.UI.screenFormat == 'SD') {
                var SDtitle = "<h1 class='wrapper' style='margin-bottom: 10px;'><span id='title-name'>{{NAME}}</span></h1>";
                SDtitle = SDtitle.replace("{{NAME}}", data.name);
                $(SDtitle).insertBefore("section#detail-rent-movie");
            }
            if ((VTR.Properties.titleMenu1stLevel.toString().length == 0) && (navi.navigate.length > 0)) {
                VTR.Properties.titleMenu1stLevel = navi.navigate[0].categoryName;
            } 
            if ((VTR.Properties.titleMenu2ndLevel.toString().length == 0) && (navi.navigate.length > 1)) {
                VTR.Properties.titleMenu2ndLevel = navi.navigate[1].categoryName;
            } 
            if ((VTR.Properties.titleMenu3rdLevel.toString().length == 0) && (navi.navigate.length > 2)) {
                VTR.Properties.titleMenu3rdLevel = navi.navigate[2].categoryName;
            }
            VTR.Properties.titlesMenu = VTR.Utils.concatenateTitlesMenu(VTR.Properties.titleMenu1stLevel, VTR.Properties.titleMenu2ndLevel, VTR.Properties.titleMenu3rdLevel);
            var categoryName = "";
            categoryName = (VTR.Utils.isset(data.categoryName) ? data.categoryName.toUpperCase() : "");
            if(VTR.Properties.titlesMenu == "MI VOD" && VTR.Utils.isset(localStorage.getItem('subCategoryName'+VTR.Account.cpeId))) {
                VTR.Properties.titlesMenu += " / "+ localStorage.getItem('subCategoryName'+VTR.Account.cpeId);  
            }
            if(VTR.Utils.isset(options.backPlayer) && options.backPlayer === true && options.categoryName != "CONTINUA VIENDO"){     
                VTR.Properties.titlesMenu = options.categoryName;
            }
            var categoryIdName = navi.navigate[navi.navigate.length-1];
            if(categoryIdName.categoryId == '[SEARCH]') {
                VTR.Properties.titlesMenu = categoryIdName.categoryName;
            }
            $("#category-name").html((VTR.Properties.titlesMenu == "" ? categoryName : VTR.Properties.titlesMenu));

            var progress = 0;
            progress = Math.round(data.bookmark * 100 / data.duration);
            itemTPL = itemTPL.replace("{{NAME}}", data.name);
            itemTPL = itemTPL.replace("{{GENRE}}", data.genre);
            itemTPL = itemTPL.replace("{{DURATION}}", (data.duration/60) + (VTR.UI.screenFormat == 'SD' ? " min." : " minutos"));
            itemTPL = itemTPL.replace("{{YEAR}}", data.year);
            //itemTPL = itemTPL.replace("{{LAST_AVAILABILITY}}", data.lastAvailability);
            itemTPL = itemTPL.replace("{{ACTORS}}", data.actors);
            itemTPL = itemTPL.replace("{{DIRECTOR}}", data.director);
            itemTPL = itemTPL.replace("{{IMAGE_URL}}", (VTR.Utils.isset(data.poster) === false ? VTR.Properties.vodImage : data.poster) + (VTR.UI.screenFormat == "HD" ? '?w='+VTR.Properties.fichaPosterHDWidth+'&h='+VTR.Properties.fichaPosterHDHeight+'&mode=stretch' : '?w='+VTR.Properties.fichaPosterSDWidth+'&h='+VTR.Properties.fichaPosterSDHeight+'&mode=stretch'));
            itemTPL = itemTPL.replace("{{SYNOPSIS}}", (VTR.UI.screenFormat == 'SD' ? data.shortSynopsis : data.synopsis));
            itemTPL = itemTPL.replace("{{RATING}}", (data.rating != '' ? "<p class='calificacion'>"+data.rating+"</p>" : ""));
            itemTPL = itemTPL.replace("{{BOOKMARK}}", (progress == 0 ? 1 : progress));
            $("section#detail-rent-movie").append(itemTPL);
            //$("#description-detail").append(it2)
            $("section#detail-rent-movie").data("crid", data.id);
            sessionStorage.setItem('titledetail', JSON.stringify(data));
			entState = data.entitlementState;
        });

        var itemTPL = "";
        var itemSubscription = "";
        var isOnWishlist = "";
        var entitlementState = "";
        var bookmark = "";
        var VodType = "";
        var entitlementEnd = "";
        var playMessage = "";
        var price = 0.0;
        var lastViewDate = "";
        var myViewingsFlag = "0";
        
        isOnWishlist = result.IsOnWishlist;
        bookmark = result.Bookmark;
        lastViewDate = result.LastViewDate;
        itemTPL += " <article id='title-options'>\n";
        itemTPL += "    {{RENTAL_PERIOD}}<nav>\n";
        itemTPL += "       <span class='border-menu'></span>\n";
        itemTPL += "       <ul class='nav-detail' tabindex='-1'>\n";
        itemTPL += "          <li id='recommendations' data-crid='" + result.pricesformats[0].titleId + "'>RECOMENDACIONES</li>\n";


        $.each(result.pricesformats, function(id, data){
            VTR.Properties.assetId = data.assetId;
            entitlementState = data.EntitlementState;
            entitlementEnd = data.EntitlementEnd;
            VodType = data.Type;

            if(bookmark != null && isNaN(bookmark) == false && bookmark > 0 && (entitlementState == 'Entitled') && (lastViewDate != "0")){
                playMessage = "CONTINUA VIENDO";
                myViewingsFlag = "1";
            }
            else {
                playMessage = "VER AHORA";
            }
            switch(data.Type) {
                case 'Subscription':
                case 'Free':
                    if(myViewingsFlag =="1"){
                        itemTPL += "          <li id='player' href='#' data-crid='" + data.titleId + "' data-asset-id='" + data.assetId + "' data-bookmark='"+result.Bookmark+"'>" + playMessage + " "+(data.isHD ? 'EN HD' : '')+"</li>\n";
                        itemTPL += "          <li id='player' href='#' data-crid='" + data.titleId + "' data-asset-id='" + data.assetId + "' data-bookmark='0'>VER DESDE EL INICIO</li>\n";
                    }else{
                        itemTPL += "          <li id='player' href='#' data-crid='" + data.titleId + "' data-asset-id='" + data.assetId + "' data-bookmark='0'>" + playMessage + " "+(data.isHD ? 'EN HD' : '')+"</li>\n";
                    }
                    itemTPL = itemTPL.replace("{{RENTAL_PERIOD}}", "");
                    break;
                case 'Transaction':
                        sessionStorage.setItem("productId",data.productId);
                        sessionStorage.setItem("assetId",data.assetId);
                        if(entitlementState == 'Entitled') {                            
                            if(myViewingsFlag =="1"){
                                itemTPL += "          <li id='player' href='#' data-crid='" + data.titleId + "' data-asset-id='" + data.assetId + "' data-bookmark='"+result.Bookmark+"'>" + playMessage + " "+(data.isHD ? 'EN HD' : '')+"</li>\n";
                                itemTPL += "          <li id='player' href='#' data-crid='" + data.titleId + "' data-asset-id='" + data.assetId + "' data-bookmark='0'>VER DESDE EL INICIO</li>\n";
                            }else{
                                itemTPL += "          <li id='player' href='#' data-crid='" + data.titleId + "' data-asset-id='" + data.assetId + "' data-bookmark='0'>" + playMessage + " "+(data.isHD ? 'EN HD' : '')+"</li>\n";
                            }
                            var today = new Date();
                            var end = new Date(entitlementEnd);
                            var milisecsValid = Math.abs(end - today);
                            var oneHour = 1000*60*60;
                            var hoursValid = Math.round(milisecsValid/oneHour);
                            if(hoursValid > 0) {
                                itemTPL = itemTPL.replace("{{RENTAL_PERIOD}}", "<h2>Arriendo válido por "+(hoursValid<2 ? hoursValid+" hora" : hoursValid+" horas")+"</h2>");
                            }
                            else {
                                var minutesValid = Math.round(milisecsValid/60000);
                                itemTPL = itemTPL.replace("{{RENTAL_PERIOD}}", "<h2>Arriendo válido por "+(minutesValid<2 ? minutesValid+" min." : minutesValid+" min.")+"</h2>");
                            }
                        }
                        else {
                            price = Number(data.ListPrice);
                            if (data.isHD) {
                                itemTPL += "          <li id='rent'>ARRENDAR HD POR $" + price.formatMoney(0,'.',',') + "</li>\n";
                            } else {
                                itemTPL += "          <li id='rent'>ARRENDAR POR $" + price.formatMoney(0,'.',',') + "</li>\n";
                            }
                            itemTPL = itemTPL.replace("{{RENTAL_PERIOD}}","    <h2>Arrienda por " + (data.RentalPeriod / 60) + " Horas</h2>\n");

                        }
                    //}
                    break;
            }
            
            if(myViewingsFlag == "1"){
                $(".continue").show();
            }
            else {
                $(".continue").hide();
            }
        });
        if(result.pricesformats.length > 0) {
            if(result.pricesformats[0].previewCount>0) {
                itemTPL += "          <li id='trailer' data-crid='" + result.pricesformats[0].titleId + "' data-asset-id='" + result.pricesformats[0].trailerAssetId + "'>VER TRAILER</li>\n";
            }
        }
        if(result.titledetail[0].genre != "ADULTO" || result.titledetail[0].genre != "ADULT" || result.titledetail[0].isAdult == false) {
            itemTPL += "          <li id='{{WISHLIST_ID}}' href='{{TITLE_ID}}'>{{WISHLIST_OPTION}}</li>\n";
            itemTPL = itemTPL.replace("{{TITLE_ID}}", options.titleId);
            itemTPL = itemTPL.replace("{{WISHLIST_OPTION}}", (isOnWishlist == true ? "QUITAR DE MI LISTA" : "AGREGAR A MI LISTA"));
            itemTPL = itemTPL.replace("{{WISHLIST_ID}}", (isOnWishlist == true ? "wishlist-del" : "wishlist-add"));
        }
//        itemTPL += "          <li id='calification'>\n";
//        itemTPL += "             <div id='title-calification'>CALIFICAR</div>\n";
//        itemTPL += "             <div id='ratingsection'>\n";
//        itemTPL += "                <fieldset id='rating-menu' class='star3' alt='3'>\n";
//        itemTPL += "                      <input type='radio' id='star3' name='rating' value='3' />\n";
//        itemTPL += "                      <input type='radio' id='star2' name='rating' value='2' />\n";
//        itemTPL += "                      <input type='radio' id='star1' name='rating' value='1' checked='checked'/>\n";
//        itemTPL += "                </fieldset>\n";
//        itemTPL += "                <div class='name-rating'>SIN CALIFICAR</div>\n";
//        itemTPL += "             </div>\n";
//        itemTPL += "          </li>\n";
        itemTPL += "       </ul>\n";
        itemTPL += "    </nav>\n";
        itemTPL += " </article>\n";

        if(entitlementState == "Entitled" || VodType == 'Transaction') {
            $("section#detail-rent-movie").append(itemTPL);
        }
        else {
            itemSubscription += "        <article>\n";
            itemSubscription += "            <div id='subscribe-box'> \n";
            itemSubscription += "               <h4>{{SUBSCRIPTION_NAME}}</h4>\n";
            itemSubscription += "               <p>{{SUBSCRIPTION_PRICE}}</p>\n";
            itemSubscription += "               <p>{{SUBSCRIPTION_HOW}}</p>\n";
            itemSubscription += "            </div><!--fin subscribe-->\n";
            itemSubscription += "         </article>\n";
//            var sPrice = Number(result.pricesformats[0].ListPrice);
            var sName = result.pricesformats[0].Name;
            var arrName = sName.split('*');
            if(arrName.length == 3) {
                itemSubscription = itemSubscription.replace('{{SUBSCRIPTION_PRICE}}', arrName[1]);
                itemSubscription = itemSubscription.replace('{{SUBSCRIPTION_NAME}}', arrName[0]);
                itemSubscription = itemSubscription.replace('{{SUBSCRIPTION_HOW}}', arrName[2]);
            }
            else {
                itemSubscription = itemSubscription.replace('{{SUBSCRIPTION_PRICE}}', "");
                itemSubscription = itemSubscription.replace('{{SUBSCRIPTION_NAME}}', "Paquete Sin Suscripción");
                itemSubscription = itemSubscription.replace('{{SUBSCRIPTION_HOW}}', "");                
            }
            $("section#detail-rent-movie").append(itemSubscription);
        }
        var availDate = "";
        if(result.pricesformats.length > 0) {
            availDate = new Date(result.pricesformats[0].LastAvailability);
            var day = availDate.getDate();
            var month = availDate.getMonth()+1;
            var year = availDate.getFullYear();
            var mydate = '' + (day <= 9 ? '0' + day : day) + '/' + (month<=9 ? '0'+month : month) + '/' + year;
            $("#last-availability").text("Disponible hasta: " + mydate);
//            if(result.pricesformats[0].languages != "") {
            $("#lang").html("<strong>Idioma:</strong> "+result.pricesformats[0].languages);
//                if(result.pricesformats[0].subtitles != "") {
            $("#subtitles").html("<strong>Subtítulos:</strong> "+result.pricesformats[0].subtitles);
//                }
//            }
        }

        VTR.Utils.debug(result);
    },
    options);

}

VTR.UI.renderCanvasMyViewings = function(options){
    VTR.Account.getMyViewings(function(result){
        if(result.myviewings.length > 0) {
            var itemTPL = "";
            var rowCount = 0;
            itemTPL += "<li id='my-canvas-continuaviendo' " + ((options.firstCarrousel) ? "class='first'" : "") + ">\n";
    //        VTR.Properties.titleMenu2ndLevel = "CONTINUA VIENDO";
            VTR.Properties.titlesMenu = VTR.Utils.concatenateTitlesMenu(VTR.Properties.titleMenu1stLevel, VTR.Properties.titleMenu2ndLevel, VTR.Properties.titleMenu3rdLevel);
            if($("#category-name").length == 0){
                $("nav.wrapper").prepend("<h5 id='category-name'>"+VTR.Properties.titlesMenu+"</h5>");
            }
            else {
                $("#category-name").html(VTR.Properties.titlesMenu);
            }
            itemTPL += "<ul class='carrousel items{{ITEMS_SIZE}}'>\n";
            $.each(result.myviewings, function(id, data){
                itemTPL += "<li class='movieLink' href='{{MOVIE_URL}}' data-hd='{{MOVIE_HD}}' data-3d='{{MOVIE_3D}}' data-content-type='{{CONTENT_TYPE}}' data-bookmark='{{BOOKMARK}}' data-crid='{{MOVIE_URL}}'>\n";
                itemTPL += "  <span style='background:url(\"{{MOVIE_IMG_URL}}\") no-repeat;'></span>\n";
                if(data.isHD) {
                    itemTPL += "<div class='tag-hd'><p>HD</p></div>\n";
                }
                if(data.is3D) {
                    itemTPL += "<div class='tag-3d'><p>3D</p></div>\n";
                }
                if(data.contentType == "Free") {
                    itemTPL += "<div class='tag-free'>GRATIS</div>\n";
                }
                else if(data.contentType == "Subscription") {
                    itemTPL += "<div class='tag-subscription'>SUSCRIPCIÓN</div>\n";
                }
                else if(data.contentType == "Transaction") {
                    itemTPL += "<div class='tag-rent'>ARRIENDA</div>\n";
                }
    //            itemTPL += "  <a href class='play-element'></a>\n";
                itemTPL += "  <h3>{{MOVIE_TITLE}}</h3>\n";
                itemTPL += "</li>\n";
                itemTPL = itemTPL.replace("{{MOVIE_TITLE}}", ((data.name.length >= VTR.UI.titleMaxLenght) ? $.trim(data.name.substring(0,VTR.UI.titleMaxLenght))+"..." : data.name));
                itemTPL = itemTPL.replace("{{MOVIE_IMG_URL}}", (VTR.Utils.isset(data.pictureUri) === false ? VTR.Properties.vodImage : data.pictureUri) + (VTR.UI.screenFormat == "HD" ? '?w='+VTR.Properties.canvasPosterHDWidth+'&h='+VTR.Properties.canvasPosterHDHeight+'&mode=stretch' : '?w='+VTR.Properties.canvasPosterSDWidth+'&h='+VTR.Properties.canvasPosterSDHeight+'&mode=stretch'));
                itemTPL = itemTPL.replace(/{{MOVIE_URL}}/g, data.titleId);
                itemTPL = itemTPL.replace("{{MOVIE_HD}}", (data.isHD ? "hd" : ""));
                itemTPL = itemTPL.replace("{{MOVIE_3D}}", (data.is3D ? "3d" : ""));
                itemTPL = itemTPL.replace("{{CONTENT_TYPE}}", data.contentType);
                itemTPL = itemTPL.replace("{{BOOKMARK}}", data.bookmark);
    //            itemTPL = itemTPL.replace("{{COVER_SIZE}}", (VTR.UI.screenFormat == 'HD' ? '190px 253px' : '115px 153px'));

                if ((id + 1) % (VTR.UI.screenFormat == 'HD' ? VTR.Properties.canvasSize : VTR.Properties.canvasSizeSD) == 0) {
                    rowCount++;
                    itemTPL = itemTPL.replace("{{ITEMS_SIZE}}", (VTR.UI.screenFormat == 'HD' ? VTR.Properties.canvasSize : VTR.Properties.canvasSizeSD));
                    if((id + 1) != result.myviewings.length) {
                        itemTPL += "</ul>\n";
                        itemTPL += "</li>\n";
                        itemTPL += "<li id='my-canvas-wishlist'>\n";
                        itemTPL += "<ul class='carrousel items{{ITEMS_SIZE}}'>";
                    }
                }
            });
            itemTPL += "</ul>\n";
            itemTPL += "</li>\n";
            itemTPL = itemTPL.replace("{{ITEMS_SIZE}}", (result.myviewings.length - ((VTR.UI.screenFormat == 'HD' ? VTR.Properties.canvasSize : VTR.Properties.canvasSizeSD) * rowCount)));
            $("#frame-carrousels > ul").append(itemTPL);
            $("#frame-carrousels").addClass("repository");
            VTR.Utils.debug(result);
        }
    },
    options);
}

VTR.UI.renderMyViewings = function(options){
    //$("#frame-carrousels > ul").empty();
    var itemTPL = "";
    VTR.Account.getMyViewings(function(result){
        if(result.myviewings.length > 0) {
            itemTPL += "<li id='continua-viendo'><h2>CONTINUA VIENDO</h2><ul class='carrousel rent items" + result.myviewings.length + "'>\n";
            if (result.myviewings.length >= VTR.Properties.carruselSize && result.myviewings.length == VTR.Properties.carruselSize) {
                itemTPL += "<li class='view-all' href='{{CATEGORY_ID}}' data-crid='{{MOVIE_URL}}'>\n";
                itemTPL += "  <p>VER TODO</p>\n";
                itemTPL += "  <h3></h3>\n";
                itemTPL += "</li>\n";
            }
            $.each(result.myviewings, function(i, data){
                itemTPL += "<li class='movieLink' href='{{MOVIE_URL}}' data-hd='{{MOVIE_HD}}' data-3d='{{MOVIE_3D}}' data-content-type='{{CONTENT_TYPE}}' data-bookmark='{{BOOKMARK}}' data-progress='{{PROGRESS}}' data-crid='{{MOVIE_URL}}' data-assetid='{{ASSET_ID}}'>\n";
                itemTPL += "  <span style='background:url(\"{{MOVIE_IMG_URL}}\")'></span>\n";
                itemTPL += "  <a href class='play-element' style='display:none;'></a>\n";
                itemTPL += "  <h3>{{MOVIE_TITLE}}</h3>\n";
                itemTPL += "  <div class='tag-valid-for'>{{VALID_FOR}}</div>\n";
                if(data.entitlementState == 'Entitled' && data.contentType == 'Transaction') {
                    var today = new Date();
                    var end = new Date(data.entitlementEnd);
                    var milisecsValid = Math.abs(end - today);
                    var oneHour = 1000*60*60;
                    var hoursValid = Math.round(milisecsValid/oneHour);
                    if(hoursValid > 0) {
                        itemTPL = itemTPL.replace("{{VALID_FOR}}", '<p>válido x '+(hoursValid < 2 ? hoursValid+' hora' : hoursValid+' hrs')+'</p>');
                    }
                    else {
                        var minutesValid = Math.round(milisecsValid/60000);
                        itemTPL = itemTPL.replace("{{VALID_FOR}}", '<p>válido x '+(minutesValid < 2 ? minutesValid+' min.' : minutesValid+' min.')+'</p>');
                    }
                }
                else {
                    itemTPL = itemTPL.replace("{{VALID_FOR}}", '');
                    if(data.contentType == "Free") {
                        itemTPL += "<div class='tag-free'>GRATIS</div>\n";
                    }
                    else if(data.contentType == "Subscription") {
                        itemTPL += "<div class='tag-subscription'>SUSCRIPCIÓN</div>\n";
                    }
                    else if(data.contentType == "Transaction") {
                        itemTPL += "<div class='tag-rent'>ARRIENDA</div>\n";
                    }
                }
                if(data.isHD) {
                    itemTPL += "<div class='tag-hd'><p>HD</p></div>\n";
                }
                if(data.is3D) {
                    itemTPL += "<div class='tag-3d'><p>3D</p></div>\n";
                }
                var progress = 0;
                progress = Math.round(data.bookmark * 100 / data.duration);
                itemTPL = itemTPL.replace("{{MOVIE_TITLE}}", ((data.name.length >= VTR.UI.titleMaxLenght) ? $.trim(data.name.substring(0,VTR.UI.titleMaxLenght))+"..." : data.name));
                itemTPL = itemTPL.replace("{{MOVIE_IMG_URL}}", (VTR.Utils.isset(data.pictureUri) === false ? VTR.Properties.vodImage : data.pictureUri) + (VTR.UI.screenFormat == "HD" ? '?w='+VTR.Properties.carruselPosterHDWidth+'&h='+VTR.Properties.carruselPosterHDHeight+'&mode=stretch' : '?w='+VTR.Properties.carruselPosterSDWidth+'&h='+VTR.Properties.carruselPosterSDHeight+'&mode=stretch'));
                itemTPL = itemTPL.replace(/{{MOVIE_URL}}/g, data.titleId);
                itemTPL = itemTPL.replace("{{MOVIE_HD}}", (data.isHD ? "hd" : ""));
                itemTPL = itemTPL.replace("{{MOVIE_3D}}", (data.is3D ? "3d" : ""));
                itemTPL = itemTPL.replace("{{CONTENT_TYPE}}", data.contentType);
                itemTPL = itemTPL.replace("{{PROGRESS}}", (progress == 0 ? 1 : progress));
                itemTPL = itemTPL.replace("{{BOOKMARK}}", data.bookmark);
                itemTPL = itemTPL.replace("{{ASSET_ID}}", data.assetId);
//                itemTPL = itemTPL.replace("{{COVER_SIZE}}", (VTR.UI.screenFormat == 'HD' ? '190px 253px' : '115px 153px'));
            });
//            itemTPL = itemTPL.replace("{{CATEGORY_NAME}}", "CONTINUA VIENDO");
            itemTPL += "</li></ul></li>\n";
            VTR.Properties.htmlKeepWatching = itemTPL;
//            $(itemTPL).insertAfter("#frame-carrousels > ul > div");
            VTR.Utils.debug(result);
        }
    },
    options);
}

VTR.UI.renderCanvasMyHistory = function(options){
    VTR.Account.getMyHistory(function(result){
        if(result.myhistory.length > 0) {
            var itemTPL = "";
            var rowCount = 0;
            itemTPL += "<li id='mi-categoria' " + ((options.firstCarrousel) ? "class='first'" : "") + ">\n";
            VTR.Properties.titleMenu2ndLevel = "MI HISTORIAL";
            VTR.Properties.titlesMenu = VTR.Utils.concatenateTitlesMenu(VTR.Properties.titleMenu1stLevel, VTR.Properties.titleMenu2ndLevel, VTR.Properties.titleMenu3rdLevel);
            if($("#category-name").length == 0){
                $("nav.wrapper").prepend("<h5 id='category-name'>"+VTR.Properties.titlesMenu+"</h5>");
            }
            else {
                $("#category-name").html(VTR.Properties.titlesMenu);
            }
            itemTPL += "<ul class='carrousel items{{ITEMS_SIZE}}'>\n";
            $.each(result.myhistory, function(id, data){
                itemTPL += "<li class='movieLink' href='{{MOVIE_URL}}' data-hd='{{MOVIE_HD}}' data-3d='{{MOVIE_3D}}' data-content-type='{{CONTENT_TYPE}}' data-bookmark='{{BOOKMARK}}' data-crid='{{MOVIE_URL}}'>\n";
                itemTPL += "  <span style='background:url(\"{{MOVIE_IMG_URL}}\") no-repeat;'></span>\n";
                if(data.isHD) {
                    itemTPL += "<div class='tag-hd'><p>HD</p></div>\n";
                }
                if(data.is3D) {
                    itemTPL += "<div class='tag-3d'><p>3D</p></div>\n";
                }
                if(data.contentType == "Free") {
                    itemTPL += "<div class='tag-free'>GRATIS</div>\n";
                }
                else if(data.contentType == "Subscription") {
                    itemTPL += "<div class='tag-subscription'>SUSCRIPCIÓN</div>\n";
                }
                else if(data.contentType == "Transaction") {
                    itemTPL += "<div class='tag-rent'>ARRIENDA</div>\n";
                }
                itemTPL += "  <h3>{{MOVIE_TITLE}}</h3>\n";
                itemTPL += "</li>\n";
                itemTPL = itemTPL.replace("{{MOVIE_TITLE}}", ((data.name.length >= VTR.UI.titleMaxLenght) ? $.trim(data.name.substring(0,VTR.UI.titleMaxLenght))+"..." : data.name));
                itemTPL = itemTPL.replace("{{MOVIE_IMG_URL}}", (VTR.Utils.isset(data.pictureUri) === false ? VTR.Properties.vodImage : data.pictureUri) + (VTR.UI.screenFormat == "HD" ? '?w='+VTR.Properties.canvasPosterHDWidth+'&h='+VTR.Properties.canvasPosterHDHeight+'&mode=stretch' : '?w='+VTR.Properties.canvasPosterSDWidth+'&h='+VTR.Properties.canvasPosterSDHeight+'&mode=stretch'));
                itemTPL = itemTPL.replace(/{{MOVIE_URL}}/g, data.titleId);
                itemTPL = itemTPL.replace("{{MOVIE_HD}}", (data.isHD ? "hd" : ""));
                itemTPL = itemTPL.replace("{{MOVIE_3D}}", (data.is3D ? "3d" : ""));
                itemTPL = itemTPL.replace("{{CONTENT_TYPE}}", data.contentType);
    //            itemTPL = itemTPL.replace("{{COVER_SIZE}}", (VTR.UI.screenFormat == 'HD' ? '190px 253px' : '115px 153px'));

                if ((id + 1) % (VTR.UI.screenFormat == 'HD' ? VTR.Properties.canvasSize : VTR.Properties.canvasSizeSD) == 0) {
                    rowCount++;
                    itemTPL = itemTPL.replace("{{ITEMS_SIZE}}", (VTR.UI.screenFormat == 'HD' ? VTR.Properties.canvasSize : VTR.Properties.canvasSizeSD));
                    if((id + 1) != result.myhistory.length) {
                        itemTPL += "</ul>\n";
                        itemTPL += "</li>\n";
                        itemTPL += "<li id='my-canvas-wishlist'>\n";
                        itemTPL += "<ul class='carrousel items{{ITEMS_SIZE}}'>";
                    }
                }
            });
            itemTPL += "</ul>\n";
            itemTPL += "</li>\n";
            itemTPL = itemTPL.replace("{{ITEMS_SIZE}}", (result.myhistory.length - ((VTR.UI.screenFormat == 'HD' ? VTR.Properties.canvasSize : VTR.Properties.canvasSizeSD) * rowCount)));
            $("#frame-carrousels > ul").append(itemTPL);
            $("#frame-carrousels").addClass("repository");
            VTR.Utils.debug(result);
        }
    },
    options);
}

VTR.UI.renderMyHistory = function(options){
    var itemTPL = "";
    VTR.Account.getMyHistory(function(result) {
        if(result.myhistory.length > 0) {
            itemTPL += "<li id='mi-categoria' " + ((options.firstCarrousel) ? "class='first'" : "") + "><h2>MI HISTORIAL</h2><ul class='carrousel items" + result.myhistory.length + "'>\n";
            if (result.myhistory.length >= VTR.Properties.carruselSize && result.myhistory.length == VTR.Properties.carruselSize) {
                itemTPL += "<li class='view-all' href='{{CATEGORY_ID}}' data-crid='{{MOVIE_URL}}'>\n";
                itemTPL += "  <p>VER TODO</p>\n";
                itemTPL += "  <h3></h3>\n";
                itemTPL += "</li>\n";
            }
            $.each(result.myhistory, function(i, data){
                itemTPL += "<li class='movieLink' href='{{MOVIE_URL}}' data-type='{{MOVIE_HD}}' data-crid='{{MOVIE_URL}}'>\n";
                itemTPL += "  <span style='background:url(\"{{MOVIE_IMG_URL}}\")'></span>\n";
                if(data.isHD) {
                    itemTPL += "<div class='tag-hd'><p>HD</p></div>\n";
                }
                if(data.is3D) {
                    itemTPL += "<div class='tag-3d'><p>3D</p></div>\n";
                }
                if(data.contentType == "Free") {
                    itemTPL += "<div class='tag-free'>GRATIS</div>\n";
                }
                else if(data.contentType == "Subscription") {
                    itemTPL += "<div class='tag-subscription'>SUSCRIPCIÓN</div>\n";
                }
                else if(data.contentType == "Transaction") {
                    itemTPL += "<div class='tag-rent'>ARRIENDA</div>\n";
                }
                itemTPL += "  <h3>{{MOVIE_TITLE}}</h3>\n";
                itemTPL = itemTPL.replace("{{MOVIE_TITLE}}", ((data.name.length >= VTR.UI.titleMaxLenght) ? $.trim(data.name.substring(0,VTR.UI.titleMaxLenght))+"..." : data.name));
                    itemTPL = itemTPL.replace("{{MOVIE_IMG_URL}}", (VTR.Utils.isset(data.pictureUri) === false ? VTR.Properties.vodImage : data.pictureUri) + (VTR.UI.screenFormat == "HD" ? '?w='+VTR.Properties.carruselPosterHDWidth+'&h='+VTR.Properties.carruselPosterHDHeight+'&mode=stretch' : '?w='+VTR.Properties.carruselPosterSDWidth+'&h='+VTR.Properties.carruselPosterSDHeight+'&mode=stretch'));
                itemTPL = itemTPL.replace(/{{MOVIE_URL}}/g, data.titleId);
                itemTPL = itemTPL.replace("{{MOVIE_HD}}", (data.isHD ? "HD" : "SD"));
    //            itemTPL = itemTPL.replace("{{COVER_SIZE}}", (VTR.UI.screenFormat == 'HD' ? '190px 253px' : '115px 153px'));
            });
    //        itemTPL = itemTPL.replace("{{CATEGORY_NAME}}", "MI HISTORIAL");
            itemTPL += "</li></ul></li>\n";
            $("#frame-carrousels > ul").append(itemTPL);
            VTR.Utils.debug(result);
        }
    },
    options);
}

VTR.UI.renderCanvasMyPurchasedProducts = function(options){
    VTR.Account.getMyPurchasedProducts(function(result) {
        var itemTPL = "";
        var rowCount = 0;
        itemTPL += "<li id='mi-categoria' " + ((options.firstCarrousel) ? "class='first'" : "") + ">\n";
//        VTR.Properties.titleMenu2ndLevel = "MIS ARRIENDOS";
        VTR.Properties.titlesMenu = VTR.Utils.concatenateTitlesMenu(VTR.Properties.titleMenu1stLevel, VTR.Properties.titleMenu2ndLevel, VTR.Properties.titleMenu3rdLevel);
        if($("#category-name").length == 0){
            $("nav.wrapper").prepend("<h5 id='category-name'>"+VTR.Properties.titlesMenu+"</h5>");
        }
        else {
            $("#category-name").html(VTR.Properties.titlesMenu);
        }
        itemTPL += "<ul class='carrousel items{{ITEMS_SIZE}}'>\n";
        $.each(result.mypurchasedprod, function(id, data){
            itemTPL += "<li class='movieLink' href='{{MOVIE_URL}}' data-hd='{{MOVIE_HD}}' data-3d='{{MOVIE_3D}}' data-content-type='{{CONTENT_TYPE}}' data-bookmark='{{BOOKMARK}}' data-crid='{{MOVIE_URL}}'>\n";
            itemTPL += "  <span style='background:url(\"{{MOVIE_IMG_URL}}\") no-repeat;'></span>\n";
            if(data.isHD) {
                itemTPL += "<div class='tag-hd'><p>HD</p></div>\n";
            }
            if(data.is3D) {
                itemTPL += "<div class='tag-3d'><p>3D</p></div>\n";
            }
            if(data.contentType == "Free") {
                itemTPL += "<div class='tag-free'>GRATIS</div>\n";
            }
            else if(data.contentType == "Subscription") {
                itemTPL += "<div class='tag-subscription'>SUSCRIPCIÓN</div>\n";
            }
            else if(data.contentType == "Transaction") {
                itemTPL += "<div class='tag-rent'>ARRIENDA</div>\n";
            }
            itemTPL += "  <h3>{{MOVIE_TITLE}}</h3>\n";
            itemTPL += "</li>\n";
            if(data.genre == "ADULTO" || data.genre == "ADULT" || data.isAdult == true) {
                itemTPL = itemTPL.replace("{{MOVIE_TITLE}}", "Contenido VOD");
                itemTPL = itemTPL.replace("{{MOVIE_IMG_URL}}", VTR.Properties.vodImage);
            }
            else {
                itemTPL = itemTPL.replace("{{MOVIE_TITLE}}", ((data.name.length >= VTR.UI.titleMaxLenght) ? $.trim(data.name.substring(0,VTR.UI.titleMaxLenght))+"..." : data.name));
                itemTPL = itemTPL.replace("{{MOVIE_IMG_URL}}", (VTR.Utils.isset(data.pictureUri) === false ? VTR.Properties.vodImage : data.pictureUri) + (VTR.UI.screenFormat == "HD" ? '?w='+VTR.Properties.canvasPosterHDWidth+'&h='+VTR.Properties.canvasPosterHDHeight+'&mode=stretch' : '?w='+VTR.Properties.canvasPosterSDWidth+'&h='+VTR.Properties.canvasPosterSDHeight+'&mode=stretch'));
            }
            itemTPL = itemTPL.replace(/{{MOVIE_URL}}/g, data.titleId);
            itemTPL = itemTPL.replace("{{MOVIE_HD}}", (data.isHD ? "hd" : ""));
            itemTPL = itemTPL.replace("{{MOVIE_3D}}", (data.is3D ? "3d" : ""));
            itemTPL = itemTPL.replace("{{CONTENT_TYPE}}", data.contentType);
//            itemTPL = itemTPL.replace("{{COVER_SIZE}}", (VTR.UI.screenFormat == 'HD' ? '190px 253px' : '115px 153px'));

            if ((id + 1) % (VTR.UI.screenFormat == 'HD' ? VTR.Properties.canvasSize : VTR.Properties.canvasSizeSD) == 0) {
                rowCount++;
                itemTPL = itemTPL.replace("{{ITEMS_SIZE}}", (VTR.UI.screenFormat == 'HD' ? VTR.Properties.canvasSize : VTR.Properties.canvasSizeSD));
                if((id + 1) != result.mypurchasedprod.length) {
                    itemTPL += "</ul>\n";
                    itemTPL += "</li>\n";
                    itemTPL += "<li id='my-canvas-wishlist'>\n";
                    itemTPL += "<ul class='carrousel items{{ITEMS_SIZE}}'>";
                }
            }
        });
        itemTPL += "</ul>\n";
        itemTPL += "</li>\n";
        itemTPL = itemTPL.replace("{{ITEMS_SIZE}}", (result.mypurchasedprod.length - ((VTR.UI.screenFormat == 'HD' ? VTR.Properties.canvasSize : VTR.Properties.canvasSizeSD) * rowCount)));
        $("#frame-carrousels > ul").append(itemTPL);
        $("#frame-carrousels").addClass("repository");
        VTR.Utils.debug(result);
    },
    options);
}

VTR.UI.renderMyRecommendations = function(options){
    VTR.TA.getMyRecommendations(function(result) {
        if(result.myrecommendations.length > 0) {
        var itemTPL = "";
        itemTPL += "<li id='te-recomendamos' " + ((options.firstCarrousel) ? "class='first'" : "") + "><h2>TE RECOMENDAMOS </h2><ul class='carrousel items" + result.myrecommendations.length + "'>\n";
        if (result.myrecommendations.length >= VTR.Properties.carruselSize && result.myrecommendations.length == VTR.Properties.carruselSize) {
            itemTPL += "<li class='view-all' href='{{CATEGORY_ID}}' data-crid='{{MOVIE_URL}}'>\n";
            itemTPL += "  <p>VER TODO</p>\n";
            itemTPL += "  <h3></h3>\n";
            itemTPL += "</li>\n";
        }
        $.each(result.myrecommendations, function(i, data){
            itemTPL += "<li class='movieLink' href='{{MOVIE_URL}}' data-type='{{MOVIE_HD}}' data-crid='{{MOVIE_URL}}'>\n";
            itemTPL += "  <span style='background:url(\"{{MOVIE_IMG_URL}}\")'></span>\n";
            if(data.isHD) {
                itemTPL += "<div class='tag-hd'><p>HD</p></div>\n";
            }
            if(data.is3D) {
                itemTPL += "<div class='tag-3d'><p>3D</p></div>\n";
            }
            if(data.contentType == "Free") {
                itemTPL += "<div class='tag-free'>GRATIS</div>\n";
            }
            else if(data.contentType == "Subscription") {
                itemTPL += "<div class='tag-subscription'>SUSCRIPCIÓN</div>\n";
            }
            else if(data.contentType == "Transaction") {
                itemTPL += "<div class='tag-rent'>ARRIENDA</div>\n";
            }
            itemTPL += "  <h3>{{MOVIE_TITLE}}</h3>\n";
            itemTPL = itemTPL.replace("{{MOVIE_TITLE}}", ((data.name.length >= VTR.UI.titleMaxLenght) ? $.trim(data.name.substring(0,VTR.UI.titleMaxLenght))+"..." : data.name));
            itemTPL = itemTPL.replace("{{MOVIE_IMG_URL}}", (VTR.Utils.isset(data.pictureUri) === false ? VTR.Properties.vodImage : data.pictureUri) + (VTR.UI.screenFormat == "HD" ? '?w='+VTR.Properties.carruselPosterHDWidth+'&h='+VTR.Properties.carruselPosterHDHeight+'&mode=stretch' : '?w='+VTR.Properties.carruselPosterSDWidth+'&h='+VTR.Properties.carruselPosterSDHeight+'&mode=stretch'));
            itemTPL = itemTPL.replace(/{{MOVIE_URL}}/g, data.titleId);
            itemTPL = itemTPL.replace("{{MOVIE_HD}}", (data.isHD ? "HD" : "SD"));
        });
//        itemTPL = itemTPL.replace("{{CATEGORY_NAME}}", "TE RECOMENDAMOS ");
        itemTPL += "</li></ul></li>\n";
        VTR.Properties.htmlMyRecommendations = itemTPL;
//        $(itemTPL).insertAfter("#frame-carrousels > ul > div");
        VTR.Utils.debug(result);
        }
    },
    options);
}

VTR.UI.renderCanvasMyRecommendations = function(options){
    VTR.TA.getMyRecommendations(function(result){
        var itemTPL = "";
        var rowCount = 0;
        itemTPL += "<li id='mi-categoria' " + ((options.firstCarrousel) ? "class='first'" : "") + ">\n";
//        VTR.Properties.titleMenu2ndLevel = "TE RECOMENDAMOS ";
        VTR.Properties.titlesMenu = VTR.Utils.concatenateTitlesMenu(VTR.Properties.titleMenu1stLevel, VTR.Properties.titleMenu2ndLevel, VTR.Properties.titleMenu3rdLevel);
        if($("#category-name").length == 0){
            $("nav.wrapper").prepend("<h5 id='category-name'>"+VTR.Properties.titlesMenu+"</h5>");
        }
        else {
            $("#category-name").html(VTR.Properties.titlesMenu);
        }
        itemTPL += "<ul class='carrousel items{{ITEMS_SIZE}}'>\n";
        $.each(result.myrecommendations, function(id, data){
            itemTPL += "<li class='movieLink' href='{{MOVIE_URL}}' data-hd='{{MOVIE_HD}}' data-3d='{{MOVIE_3D}}' data-content-type='{{CONTENT_TYPE}}' data-bookmark='{{BOOKMARK}}' data-crid='{{MOVIE_URL}}'>\n";
            itemTPL += "  <span style='background:url(\"{{MOVIE_IMG_URL}}\")'></span>\n";
            if(data.isHD) {
                itemTPL += "<div class='tag-hd'><p>HD</p></div>\n";
            }
            if(data.is3D) {
                itemTPL += "<div class='tag-3d'><p>3D</p></div>\n";
            }
            if(data.contentType == "Free") {
                itemTPL += "<div class='tag-free'>GRATIS</div>\n";
            }
            else if(data.contentType == "Subscription") {
                itemTPL += "<div class='tag-subscription'>SUSCRIPCIÓN</div>\n";
            }
            else if(data.contentType == "Transaction") {
                itemTPL += "<div class='tag-rent'>ARRIENDA</div>\n";
            }
            itemTPL += "  <h3>{{MOVIE_TITLE}}</h3>\n";
            itemTPL += "</li>\n";
            itemTPL = itemTPL.replace("{{MOVIE_TITLE}}", ((data.name.length >= VTR.UI.titleMaxLenght) ? $.trim(data.name.substring(0,VTR.UI.titleMaxLenght))+"..." : data.name));
            itemTPL = itemTPL.replace("{{MOVIE_IMG_URL}}", (VTR.Utils.isset(data.pictureUri) === false ? VTR.Properties.vodImage : data.pictureUri) + (VTR.UI.screenFormat == "HD" ? '?w='+VTR.Properties.canvasPosterHDWidth+'&h='+VTR.Properties.canvasPosterHDHeight+'&mode=stretch' : '?w='+VTR.Properties.canvasPosterSDWidth+'&h='+VTR.Properties.canvasPosterSDHeight+'&mode=stretch'));
            itemTPL = itemTPL.replace(/{{MOVIE_URL}}/g, data.titleId);
            itemTPL = itemTPL.replace("{{MOVIE_HD}}", (data.isHD ? "hd" : ""));
            itemTPL = itemTPL.replace("{{MOVIE_3D}}", (data.is3D ? "3d" : ""));
            itemTPL = itemTPL.replace("{{CONTENT_TYPE}}", data.contentType);

            if ((id + 1) % (VTR.UI.screenFormat == 'HD' ? VTR.Properties.canvasSize : VTR.Properties.canvasSizeSD) == 0) {
                rowCount++;
                itemTPL = itemTPL.replace("{{ITEMS_SIZE}}", (VTR.UI.screenFormat == 'HD' ? VTR.Properties.canvasSize : VTR.Properties.canvasSizeSD));
                if((id + 1) != result.myrecommendations.length) {
                    itemTPL += "</ul>\n";
                    itemTPL += "</li>\n";
                    itemTPL += "<li id='my-canvas-wishlist'>\n";
                    itemTPL += "<ul class='carrousel items{{ITEMS_SIZE}}'>";
                }
            }
        });
        itemTPL += "</ul>\n";
        itemTPL += "</li>\n";
        itemTPL = itemTPL.replace("{{ITEMS_SIZE}}", (result.myrecommendations.length - ((VTR.UI.screenFormat == 'HD' ? VTR.Properties.canvasSize : VTR.Properties.canvasSizeSD) * rowCount)));
        $("#frame-carrousels > ul").append(itemTPL);
        $("#frame-carrousels").addClass("repository");
        VTR.Utils.debug(result);
    },
    options);
}
// RENDER SEARCH TA
VTR.UI.renderListSearchResults = function(options){
    VTR.TA.getSearch(function(result){
        var counterResults = 0;
        var rowCount = 0;
        var itemTPL = "";
        counterResults = result.searchResults.length;
        $("#search").empty();
        if (result.searchResults.length != 0) {
            VTR.Properties.titlesMenu = "BUSCAR";
            $("#category-name").html(VTR.Properties.titlesMenu);
            itemTPL += "<h3 class='search-result'>{{TOTAL_RESULTS}} TÍTULOS DISPONIBLES PARA TU BÚSQUEDA</h3>\n";
            itemTPL += " <section id='frame-carrousels' class='search'>\n";
            itemTPL += "<ul class='carrousels active'>\n";
            itemTPL += "<div class='focoRepository'>\n";
            itemTPL += "<a href='' class='play-element-fix'></a>\n";
            itemTPL += "<div class='progress'></div>\n";
            itemTPL += "</div>\n";
            itemTPL += "<li id='my-search' " + ((options.firstCarrousel) ? "class='first'" : "") + ">\n";
            itemTPL+= "<ul class='carrousel items{{ITEMS_SIZE}}'>\n";
            itemTPL = itemTPL.replace("{{TOTAL_RESULTS}}", counterResults);

            $.each(result.searchResults, function(id, data){
                var img = null;

                itemTPL += "<li class='movieLink' href='{{MOVIE_URL}}' data-is-series='{{SERIES}}' data-crid='{{TITLE_ID}}' data-hd='{{MOVIE_HD}}' data-3d='{{MOVIE_3D}}' data-content-type='{{CONTENT_TYPE}}'>\n";
                itemTPL += "  <span style='background:url(\"{{MOVIE_IMG_URL}}\")'></span>\n";
                if(data.isHD) {
                    itemTPL += "<div class='tag-hd'><p>HD</p></div>\n";
                }
                if(data.is3D) {
                    itemTPL += "<div class='tag-3d'><p>3D</p></div>\n";
                }
                if(data.contentType == "Free") {
                    itemTPL += "<div class='tag-free'>GRATIS</div>\n";
                }
                else if(data.contentType == "Subscription") {
                    itemTPL += "<div class='tag-subscription'>SUSCRIPCIÓN</div>\n";
                }
                else if(data.contentType == "Transaction") {
                    itemTPL += "<div class='tag-rent'>ARRIENDA</div>\n";
                }
                itemTPL += "  <h3>{{MOVIE_TITLE}}</h3>\n";
                itemTPL += "</li>\n";

                itemTPL = itemTPL.replace("{{MOVIE_TITLE}}", ((data.name.length >= VTR.UI.titleMaxLenght) ? $.trim(data.name.substring(0,VTR.UI.titleMaxLenght))+"..." : data.name));
                itemTPL = itemTPL.replace("{{MOVIE_IMG_URL}}", (VTR.Utils.isset(data.pictureUri) === false ? VTR.Properties.vodImage : data.pictureUri) + (VTR.UI.screenFormat == "HD" ? '?w='+VTR.Properties.canvasPosterHDWidth+'&h='+VTR.Properties.canvasPosterHDHeight+'&mode=stretch' : '?w='+VTR.Properties.canvasPosterSDWidth+'&h='+VTR.Properties.canvasPosterSDHeight+'&mode=stretch'));
                itemTPL = itemTPL.replace(/{{MOVIE_URL}}/g, data.titleId);
                itemTPL = itemTPL.replace("{{TITLE_ID}}", data.titleId);
                itemTPL = itemTPL.replace("{{MOVIE_HD}}", (data.isHD ? "hd" : ""));
                itemTPL = itemTPL.replace("{{MOVIE_3D}}", (data.is3D ? "3d" : ""));
                itemTPL = itemTPL.replace("{{CONTENT_TYPE}}", data.contentType);
                itemTPL = itemTPL.replace("{{SERIES}}", data.isSeries);

                if((id + 1) % VTR.Properties.canvasSearchSize == 0){
                    rowCount++;
                    itemTPL = itemTPL.replace("{{ITEMS_SIZE}}", VTR.Properties.canvasSearchSize);
                    if((id + 1) != result.searchResults.length){
                        itemTPL += "</ul>\n";
                        itemTPL += "</li>\n";
                        itemTPL += "<li id='my-search'>\n";
                        itemTPL += "<ul class='carrousel items{{ITEMS_SIZE}}'>";
                    }
                }
            });
            itemTPL += "</ul>\n";
            itemTPL += "</li>\n";
            itemTPL += "</section>\n";
            itemTPL = itemTPL.replace("{{ITEMS_SIZE}}", (result.searchResults.length - (VTR.Properties.canvasSearchSize * rowCount)));
            //$("#frame-carrousels").append(itemTPL);
            $("#search").append(itemTPL);
            $("#frame-carrousels").addClass("repository");
            sessionStorage.setItem("searchHasResults", "true");
//            keyboard.navRight = "button0";
            mode = "carrousels";
//            $('[id*=p0k]').blur();
//            $('.focoRepository').show();
//            carruselfocus = true;
            VTR.Utils.debug(result);
        } else {
            itemTPL += "<h3 class='search-result'>NO HAY TÍTULOS DISPONIBLES PARA TU BÚSQUEDA</h3>\n";
            $("#search").append(itemTPL);
            //var kb = document.getElementById('AVKeyboard0p0k0');
            //kb.focus();
//            keyboard.focus();
//            keyboard.moveCursorToBeginning();
            sessionStorage.setItem("searchHasResults", "false");
            mode = "search";
        }
        var sTerm = (VTR.Utils.isset(localStorage.getItem("term"+VTR.Account.cpeId)) ? localStorage.getItem("term"+VTR.Account.cpeId) : "");
        sTerm = sTerm.replace(/\+/g, " ");
        keyboard.setText(sTerm);
    },
    options);
}

VTR.UI.renderMyPurchasedProducts = function(options){
    VTR.Account.getMyPurchasedProducts(function(result) {
        var itemTPL = "";
        itemTPL += "<li id='mi-categoria' " + ((options.firstCarrousel) ? "class='first'" : "") + "><h2>MIS ARRIENDOS</h2><ul class='carrousel items" + result.mypurchasedprod.length + "'>\n";
        if (result.mypurchasedprod.length >= VTR.Properties.carruselSize && result.mypurchasedprod.length == VTR.Properties.carruselSize) {
            itemTPL += "<li class='view-all' href='{{CATEGORY_ID}}' data-crid='{{MOVIE_URL}}'>\n";
            itemTPL += "  <p>VER TODO</p>\n";
            itemTPL += "  <h3></h3>\n";
            itemTPL += "</li>\n";
        }
        $.each(result.mypurchasedprod, function(i, data){
            itemTPL += "<li class='movieLink' href='{{MOVIE_URL}}' data-type='{{MOVIE_HD}}' data-crid='{{MOVIE_URL}}'>\n";
            itemTPL += "  <span style='background:url(\"{{MOVIE_IMG_URL}}\") no-repeat;'></span>\n";
            if(data.isHD) {
                itemTPL += "<div class='tag-hd'><p>HD</p></div>\n";
            }
            if(data.is3D) {
                itemTPL += "<div class='tag-3d'><p>3D</p></div>\n";
            }
            if(data.contentType == "Free") {
                itemTPL += "<div class='tag-rent'>GRATIS</div>\n";
            }
            else if(data.contentType == "Subscription") {
                itemTPL += "<div class='tag-rent'>SUSCRIPCIÓN</div>\n";
            }
            else if(data.contentType == "Transaction") {
                itemTPL += "<div class='tag-rent'>ARRIENDA</div>\n";
            }
            itemTPL += "  <h3>{{MOVIE_TITLE}}</h3>\n";
            itemTPL = itemTPL.replace("{{MOVIE_TITLE}}", ((data.name.length >= VTR.UI.titleMaxLenght) ? $.trim(data.name.substring(0,VTR.UI.titleMaxLenght))+"..." : data.name));
            itemTPL = itemTPL.replace("{{MOVIE_IMG_URL}}", (VTR.Utils.isset(data.pictureUri) === false ? VTR.Properties.vodImage : data.pictureUri) + (VTR.UI.screenFormat == "HD" ? '?w='+VTR.Properties.carruselPosterHDWidth+'&h='+VTR.Properties.carruselPosterHDHeight+'&mode=stretch' : '?w='+VTR.Properties.carruselPosterSDWidth+'&h='+VTR.Properties.carruselPosterSDHeight+'&mode=stretch'));
            itemTPL = itemTPL.replace(/{{MOVIE_URL}}/g, data.titleId);
            itemTPL = itemTPL.replace("{{MOVIE_HD}}", (data.isHD ? "HD" : "SD"));
//            itemTPL = itemTPL.replace("{{COVER_SIZE}}", (VTR.UI.screenFormat == 'HD' ? '190px 253px' : '115px 153px'));
        });
//        itemTPL = itemTPL.replace("{{CATEGORY_NAME}}", "MIS ARRIENDOS");
        itemTPL += "</li></ul></li>\n";
        $("#frame-carrousels > ul").append(itemTPL);
        VTR.Utils.debug(result);
    },
    options);
}

VTR.UI.renderSetMyWishList = function(options){
    VTR.Content.setWishList(function(result) {
        $('[id^="wishlist"]').attr('id','wishlist-del').html('QUITAR DE MI LISTA');
    },
    options);
//    $().toastmessage('showNoticeToast', 'Título agregado a Mi Lista');
}

VTR.UI.renderDeleteMyWishList = function(options){
    VTR.Content.deleteWishList(function(result) {
        $('[id^="wishlist"]').attr('id','wishlist-add').html('AGREGAR A MI LISTA');
    },
    options);
//    $().toastmessage('showNoticeToast', 'Título eliminado de Mi Lista');
}

VTR.UI.renderMessagePage = function(options){
    $('#message-title').html(options.messageTitle);
    $('#message-body').html(options.messageBody);
    $('#message-button').html(options.messageButton);
    $('#message-button').data("return-path", options.returnPath);
    $('#message-button').data("extra-param", options.preloadedCategory);
    if(!VTR.Utils.isset(options.messageButton2)) {
        $("#message-button2").remove();
    }
    else {
        $('#message-button2').data("return-path", options.returnPath2);
        $('#message-button2').data("extra-param", options.preloadedCategory2);
        $('#message-button2').html(options.messageButton2);
    }
}

/* BORRAR VTR.UI.renderMessageContent */
VTR.UI.renderMessageContent = function(options){
    if (options.categoryName != "MI VOD") {
        var itemTPL = "";
        $("#frame-carrousels > ul").empty();
        itemTPL += "<section id='section-options' class='wrapper'>\n";
        itemTPL += "<h4 id='message-body'>{{MESSAGE_MESSAGE}}</h4>\n";
        itemTPL += "<ul class='nav-detail'>\n";
        itemTPL += "<li id='message-button' data-return-path='{{RETURN_PATH}}'>{{MESSAGE_BUTTON}}</li>\n";
        itemTPL += "</ul></section>\n";
        itemTPL = itemTPL.replace("{{MESSAGE_MESSAGE}}", options.messageBody);
        itemTPL = itemTPL.replace("{{RETURN_PATH}}", options.returnPath);
        itemTPL = itemTPL.replace("{{MESSAGE_BUTTON}}", options.messageButton);
        mode = "message";
        $("#frame-carrousels > ul").prepend(itemTPL);
    }
}

VTR.UI.renderPartialTitle = function(options){
    var itemTPL = "";
    if (VTR.UI.screenFormat == "HD") {
        itemTPL += "<article>\n"
        itemTPL += "<span><img src='{{IMAGE_URL}}'></span>\n";
        itemTPL += "</article>\n";
        itemTPL += "<article id='detail-pin'>\n";
        itemTPL += "    <h1>{{NAME}}</h1>\n";// <p class='calificacion'>{{RATING}}</p>
        itemTPL += "    <h2>Arrendar {{HD}} por {{LIST_PRICE}} por {{RENTAL_PERIOD}}</h2>  \n";
        itemTPL += "    <h3>Introduzca su PIN de ARRIENDO</h3> \n";
        itemTPL += "    <div class='container'> \n";
        itemTPL += "        <input type='password' maxlength='1' value='' autofocus>\n";
        itemTPL += "        <input type='password' maxlength='1' value=''>\n";
        itemTPL += "        <input type='password' maxlength='1' value=''>\n";
        itemTPL += "        <input type='password' maxlength='1' value=''>\n";
        itemTPL += "        <br class='clear' />\n";
        itemTPL += "        <input class='go-to-movie' href='movie.html' type='submit' value='CONTINUAR'>\n";
        itemTPL += "    </div>\n";
        itemTPL += "</article>    \n";
    }
    else {
        itemTPL += "<article>\n"
        itemTPL += "<span><img src='{{IMAGE_URL}}'></span>\n";
        itemTPL += "</article>\n"
        itemTPL += "<article id='detail-pin'>\n";
        itemTPL += "    <h1>{{NAME}}</h1>\n";// <p class='calificacion'>{{RATING}}</p>
        itemTPL += "    <h2>Arrendar por {{LIST_PRICE}} por {{RENTAL_PERIOD}}</h2>  \n";
        itemTPL += "    <h3>Introduzca su PIN de ARRIENDO</h3> \n";
        itemTPL += "    <div class='container'> \n";
        itemTPL += "        <input type='password' maxlength='1' value='' autofocus>\n";
        itemTPL += "        <input type='password' maxlength='1' value=''>\n";
        itemTPL += "        <input type='password' maxlength='1' value=''>\n";
        itemTPL += "        <input type='password' maxlength='1' value=''>\n";
        itemTPL += "        <br class='clear' />\n";
        itemTPL += "        <input class='go-to-movie' href='movie.html' type='submit' value='CONTINUAR'>\n";
        itemTPL += "    </div>\n";
        itemTPL += "</article>    \n";
    }
    // var data = JSON.parse(sessionStorage.getItem('titledetail'));
    VTR.Content.getTitleDetail(function(result) {
    $.each(result.titledetail, function(id, data){
        if (VTR.UI.screenFormat == 'SD') {
            var SDtitle = "<h1 class='wrapper' style='margin-bottom: 10px;'>{{NAME}}</h1>";
            SDtitle = SDtitle.replace("{{NAME}}", data.name);
            $(SDtitle).insertBefore("section#detail-rent-movie");
        }
        var categoryName = "";
        categoryName = (VTR.Utils.isset(data.categoryName) ? data.categoryName.toUpperCase() : "");
        $("#category-name").html(categoryName);

        itemTPL = itemTPL.replace("{{NAME}}", data.name);
        itemTPL = itemTPL.replace("{{GENRE}}", data.genre);
        itemTPL = itemTPL.replace("{{DURATION}}", data.duration + " minutos");
        itemTPL = itemTPL.replace("{{YEAR}}", data.year);
        itemTPL = itemTPL.replace("{{LAST_AVAILABILITY}}", data.lastAvailability);
        itemTPL = itemTPL.replace("{{ACTORS}}", data.actors);
        itemTPL = itemTPL.replace("{{DIRECTOR}}", data.director);
        itemTPL = itemTPL.replace("{{IMAGE_URL}}", data.poster)
        itemTPL = itemTPL.replace("{{SYNOPSIS}}", data.synopsis);
        itemTPL = itemTPL.replace("{{RATING}}", data.rating);
    });
    $.each(result.pricesformats, function(i, d) {
        var price = Number(d.ListPrice);
        itemTPL = itemTPL.replace("{{LIST_PRICE}}", "$" + price.formatMoney(0,'.',','));
        itemTPL = itemTPL.replace("{{RENTAL_PERIOD}}", (d.RentalPeriod / 60) + " Horas");
        
        if (VTR.UI.screenFormat == "HD" && d.isHD) {
            itemTPL = itemTPL.replace("{{HD}}", "HD");
        } else {
            itemTPL = itemTPL.replace("{{HD}}", "");
        }

    });
    $("section#detail-rent-movie").append(itemTPL);
    //$("#description-detail").append(it2)
    // $("section#detail-rent-movie").data("crid", data.id);
    //VTR.Utils.debug(result);
    }, options);
}

VTR.UI.renderRelatedRecommendations = function(options){
    var itemTPL = "";
    VTR.TA.getRelatedRecommendations(function(result) {
        if(result.relatedrecom.length > 0) {
            itemTPL += "<li id='mi-categoria' " + ((options.firstCarrousel) ? "class='first'" : "") + "><h2>SIMILARES</h2><ul class='carrousel items" + result.relatedrecom.length + "'>\n";
            if (result.relatedrecom.length >= VTR.Properties.carruselSize) {
                itemTPL += "<li class='view-all' href='{{CATEGORY_ID}}' data-crid='{{MOVIE_URL}}'>\n";
                itemTPL += "  <p>VER TODO</p>\n";
                itemTPL += "  <h3></h3>\n";
                itemTPL += "</li>\n";
            }
            $.each(result.relatedrecom, function(i, data){
                itemTPL += "<li class='movieLink' href='{{MOVIE_URL}}' data-type='{{MOVIE_HD}}' data-crid='{{MOVIE_URL}}'>\n";
                itemTPL += "  <span style='background:url(\"{{MOVIE_IMG_URL}}\")'></span>\n";
                if(data.isHD) {
                    itemTPL += "<div class='tag-hd'><p>HD</p></div>\n";
                }
                if(data.is3D) {
                    itemTPL += "<div class='tag-3d'><p>3D</p></div>\n";
                }
                if(data.contentType == "Free") {
                    itemTPL += "<div class='tag-free'>GRATIS</div>\n";
                }
                else if(data.contentType == "Subscription") {
                    itemTPL += "<div class='tag-subscription'>SUSCRIPCIÓN</div>\n";
                }
                else if(data.contentType == "Transaction") {
                    itemTPL += "<div class='tag-rent'>ARRIENDA</div>\n";
                }
                itemTPL += "  <h3>{{MOVIE_TITLE}}</h3>\n";
                itemTPL = itemTPL.replace("{{MOVIE_TITLE}}", ((data.name.length >= VTR.UI.titleMaxLenght) ? $.trim(data.name.substring(0,VTR.UI.titleMaxLenght))+"..." : data.name));
                itemTPL = itemTPL.replace("{{MOVIE_IMG_URL}}", (VTR.Utils.isset(data.pictureUri) === false ? VTR.Properties.vodImage : data.pictureUri) + (VTR.UI.screenFormat == "HD" ? '?w='+VTR.Properties.carruselPosterHDWidth+'&h='+VTR.Properties.carruselPosterHDHeight+'&mode=stretch' : '?w='+VTR.Properties.carruselPosterSDWidth+'&h='+VTR.Properties.carruselPosterSDHeight+'&mode=stretch'));
                itemTPL = itemTPL.replace(/{{MOVIE_URL}}/g, data.titleId);
                itemTPL = itemTPL.replace("{{MOVIE_HD}}", (data.isHD ? "HD" : "SD"));
            });
    //        itemTPL = itemTPL.replace("{{CATEGORY_NAME}}", "SIMILARES");
            itemTPL += "</li></ul></li>\n";
            $("#frame-carrousels > ul").append(itemTPL);
            VTR.Utils.debug(result);
        }
    },
    options);
}

VTR.UI.renderSearchRelatedRecommendations = function(options){
    var itemTPL = "";
    VTR.TA.getSearch(function(result) {
        if(result.searchResults.length > 0) {
            itemTPL += "<li id='search-related-recom' " + ((options.firstCarrousel) ? "class='first'" : "") + "><h2>"+options.term.toUpperCase()+"</h2><ul class='carrousel items" + result.searchResults.length + "'>\n";
            if (result.searchResults.length >= VTR.Properties.carruselSize) {
                itemTPL += "<li class='view-all' href='{{CATEGORY_ID}}' data-crid='{{MOVIE_URL}}'>\n";
                itemTPL += "  <p>VER TODO</p>\n";
                itemTPL += "  <h3></h3>\n";
                itemTPL += "</li>\n";
            }
            $.each(result.searchResults, function(i, data){
                itemTPL += "<li class='movieLink' href='{{MOVIE_URL}}' data-type='{{MOVIE_HD}}' data-crid='{{MOVIE_URL}}'>\n";
                itemTPL += "  <span style='background:url(\"{{MOVIE_IMG_URL}}\")'></span>\n";
                if(data.isHD) {
                    itemTPL += "<div class='tag-hd'><p>HD</p></div>\n";
                }
                if(data.is3D) {
                    itemTPL += "<div class='tag-3d'><p>3D</p></div>\n";
                }
                if(data.contentType == "Free") {
                    itemTPL += "<div class='tag-free'>GRATIS</div>\n";
                }
                else if(data.contentType == "Subscription") {
                    itemTPL += "<div class='tag-subscription'>SUSCRIPCIÓN</div>\n";
                }
                else if(data.contentType == "Transaction") {
                    itemTPL += "<div class='tag-rent'>ARRIENDA</div>\n";
                }
                itemTPL += "  <h3>{{MOVIE_TITLE}}</h3>\n";
                itemTPL = itemTPL.replace("{{MOVIE_TITLE}}", ((data.name.length >= VTR.UI.titleMaxLenght) ? $.trim(data.name.substring(0,VTR.UI.titleMaxLenght))+"..." : data.name));
                itemTPL = itemTPL.replace("{{MOVIE_IMG_URL}}", (VTR.Utils.isset(data.pictureUri) === false ? VTR.Properties.vodImage : data.pictureUri) + (VTR.UI.screenFormat == "HD" ? '?w='+VTR.Properties.carruselPosterHDWidth+'&h='+VTR.Properties.carruselPosterHDHeight+'&mode=stretch' : '?w='+VTR.Properties.carruselPosterSDWidth+'&h='+VTR.Properties.carruselPosterSDHeight+'&mode=stretch'));
                itemTPL = itemTPL.replace(/{{MOVIE_URL}}/g, data.titleId);
                itemTPL = itemTPL.replace("{{MOVIE_HD}}", (data.isHD ? "HD" : "SD"));
            });
    //        itemTPL = itemTPL.replace("{{CATEGORY_NAME}}", options.term.toUpperCase());
            itemTPL = itemTPL.replace("{{CATEGORY_ID}}", "RECOM_"+options.term.toUpperCase());
            itemTPL += "</li></ul></li>\n";
            $("#frame-carrousels > ul").append(itemTPL);
            VTR.Utils.debug(result);
        }
    },
    options);
}

VTR.UI.renderCanvasSearchRelatedRecommendations = function(options){
    VTR.TA.getRelatedRecommendations(function(result){
        var itemTPL = "";
        var rowCount = 0;
        $(".load-nav nav").empty();
        itemTPL += "<li id='search-related-recom' " + ((options.firstCarrousel) ? "class='first'" : "") + ">\n";
//        VTR.Properties.titleMenu2ndLevel = "TE RECOMENDAMOS ";
        VTR.Properties.titlesMenu = VTR.Utils.concatenateTitlesMenu(VTR.Properties.titleMenu1stLevel, VTR.Properties.titleMenu2ndLevel, VTR.Properties.titleMenu3rdLevel);
//        $("#category-name").html(VTR.Properties.titlesMenu);
        if($("#category-name").length == 0){
            $("nav.wrapper").prepend("<h5 id='category-name'>SIMILARES</h5>");
        }
        else {
            $("#category-name").html("SIMILARES");
        }
        itemTPL += "<ul class='carrousel items{{ITEMS_SIZE}}'>\n";
        $.each(result.relatedrecom, function(id, data){
            itemTPL += "<li class='movieLink' href='{{MOVIE_URL}}' data-hd='{{MOVIE_HD}}' data-3d='{{MOVIE_3D}}' data-content-type='{{CONTENT_TYPE}}' data-bookmark='{{BOOKMARK}}' data-crid='{{MOVIE_URL}}'>\n";
            itemTPL += "  <span style='background:url(\"{{MOVIE_IMG_URL}}\")'></span>\n";
            if(data.isHD) {
                itemTPL += "<div class='tag-hd'><p>HD</p></div>\n";
            }
            if(data.is3D) {
                itemTPL += "<div class='tag-3d'><p>3D</p></div>\n";
            }
            if(data.contentType == "Free") {
                itemTPL += "<div class='tag-free'>GRATIS</div>\n";
            }
            else if(data.contentType == "Subscription") {
                itemTPL += "<div class='tag-subscription'>SUSCRIPCIÓN</div>\n";
            }
            else if(data.contentType == "Transaction") {
                itemTPL += "<div class='tag-rent'>ARRIENDA</div>\n";
            }
            itemTPL += "  <h3>{{MOVIE_TITLE}}</h3>\n";
            itemTPL += "</li>\n";
            itemTPL = itemTPL.replace("{{MOVIE_TITLE}}", ((data.name.length >= VTR.UI.titleMaxLenght) ? $.trim(data.name.substring(0,VTR.UI.titleMaxLenght))+"..." : data.name));
            itemTPL = itemTPL.replace("{{MOVIE_IMG_URL}}", (VTR.Utils.isset(data.pictureUri) === false ? VTR.Properties.vodImage : data.pictureUri) + (VTR.UI.screenFormat == "HD" ? '?w='+VTR.Properties.canvasPosterHDWidth+'&h='+VTR.Properties.canvasPosterHDHeight+'&mode=stretch' : '?w='+VTR.Properties.canvasPosterSDWidth+'&h='+VTR.Properties.canvasPosterSDHeight+'&mode=stretch'));
            itemTPL = itemTPL.replace(/{{MOVIE_URL}}/g, data.titleId);
            itemTPL = itemTPL.replace("{{MOVIE_HD}}", (data.isHD ? "hd" : ""));
            itemTPL = itemTPL.replace("{{MOVIE_3D}}", (data.is3D ? "3d" : ""));
            itemTPL = itemTPL.replace("{{CONTENT_TYPE}}", data.contentType);

            if ((id + 1) % (VTR.UI.screenFormat == 'HD' ? VTR.Properties.canvasSize : VTR.Properties.canvasSizeSD) == 0) {
                rowCount++;
                itemTPL = itemTPL.replace("{{ITEMS_SIZE}}", (VTR.UI.screenFormat == 'HD' ? VTR.Properties.canvasSize : VTR.Properties.canvasSizeSD));
                if((id + 1) != result.relatedrecom.length) {
                    itemTPL += "</ul>\n";
                    itemTPL += "</li>\n";
                    itemTPL += "<li id='search-related-recom'>\n";
                    itemTPL += "<ul class='carrousel items{{ITEMS_SIZE}}'>";
                }
            }
        });
        itemTPL += "</ul>\n";
        itemTPL += "</li>\n";
        itemTPL = itemTPL.replace("{{ITEMS_SIZE}}", (result.relatedrecom.length - ((VTR.UI.screenFormat == 'HD' ? VTR.Properties.canvasSize : VTR.Properties.canvasSizeSD) * rowCount)));
        $("#frame-carrousels > ul").append(itemTPL);
        $("#frame-carrousels").addClass("repository");
        VTR.Utils.debug(result);
    },
    options);
}

VTR.UI.renderCanvasSearch = function(options){
    VTR.TA.getSearch(function(result){
        var itemTPL = "";
        var rowCount = 0;
        $(".load-nav nav").empty();
        itemTPL += "<li id='mi-categoria' " + ((options.firstCarrousel) ? "class='first'" : "") + ">\n";
        VTR.Properties.titleMenu2ndLevel = options.term.toUpperCase();
        VTR.Properties.titlesMenu = VTR.Utils.concatenateTitlesMenu(VTR.Properties.titleMenu1stLevel, VTR.Properties.titleMenu2ndLevel, VTR.Properties.titleMenu3rdLevel);
        if($("#category-name").length == 0){
            $("nav.wrapper").prepend("<h5 id='category-name'>"+options.term.toUpperCase()+"</h5>");
        }
        else {
            $("#category-name").html(options.term.toUpperCase());
        }
        itemTPL += "<ul class='carrousel items{{ITEMS_SIZE}}'>\n";
        $.each(result.searchResults, function(id, data){
            itemTPL += "<li class='movieLink' href='{{MOVIE_URL}}' data-hd='{{MOVIE_HD}}' data-3d='{{MOVIE_3D}}' data-content-type='{{CONTENT_TYPE}}' data-bookmark='{{BOOKMARK}}' data-crid='{{MOVIE_URL}}'>\n";
            itemTPL += "  <span style='background:url(\"{{MOVIE_IMG_URL}}\")'></span>\n";
            if(data.isHD) {
                itemTPL += "<div class='tag-hd'><p>HD</p></div>\n";
            }
            if(data.is3D) {
                itemTPL += "<div class='tag-3d'><p>3D</p></div>\n";
            }
            if(data.contentType == "Free") {
                itemTPL += "<div class='tag-free'>GRATIS</div>\n";
            }
            else if(data.contentType == "Subscription") {
                itemTPL += "<div class='tag-subscription'>SUSCRIPCIÓN</div>\n";
            }
            else if(data.contentType == "Transaction") {
                itemTPL += "<div class='tag-rent'>ARRIENDA</div>\n";
            }
            itemTPL += "  <h3>{{MOVIE_TITLE}}</h3>\n";
            itemTPL += "</li>\n";
            itemTPL = itemTPL.replace("{{MOVIE_TITLE}}", ((data.name.length >= VTR.UI.titleMaxLenght) ? $.trim(data.name.substring(0,VTR.UI.titleMaxLenght))+"..." : data.name));
            itemTPL = itemTPL.replace("{{MOVIE_IMG_URL}}", (VTR.Utils.isset(data.pictureUri) === false ? VTR.Properties.vodImage : data.pictureUri) + (VTR.UI.screenFormat == "HD" ? '?w='+VTR.Properties.canvasPosterHDWidth+'&h='+VTR.Properties.canvasPosterHDHeight+'&mode=stretch' : '?w='+VTR.Properties.canvasPosterSDWidth+'&h='+VTR.Properties.canvasPosterSDHeight+'&mode=stretch'));
            itemTPL = itemTPL.replace(/{{MOVIE_URL}}/g, data.titleId);
            itemTPL = itemTPL.replace("{{MOVIE_HD}}", (data.isHD ? "hd" : ""));
            itemTPL = itemTPL.replace("{{MOVIE_3D}}", (data.is3D ? "3d" : ""));
            itemTPL = itemTPL.replace("{{CONTENT_TYPE}}", data.contentType);

            if ((id + 1) % (VTR.UI.screenFormat == 'HD' ? VTR.Properties.canvasSize : VTR.Properties.canvasSizeSD) == 0) {
                rowCount++;
                itemTPL = itemTPL.replace("{{ITEMS_SIZE}}", (VTR.UI.screenFormat == 'HD' ? VTR.Properties.canvasSize : VTR.Properties.canvasSizeSD));
                if((id + 1) != result.searchResults.length) {
                    itemTPL += "</ul>\n";
                    itemTPL += "</li>\n";
                    itemTPL += "<li id='my-canvas-wishlist'>\n";
                    itemTPL += "<ul class='carrousel items{{ITEMS_SIZE}}'>";
                }
            }
        });
        itemTPL += "</ul>\n";
        itemTPL += "</li>\n";
        itemTPL = itemTPL.replace("{{ITEMS_SIZE}}", (result.searchResults.length - ((VTR.UI.screenFormat == 'HD' ? VTR.Properties.canvasSize : VTR.Properties.canvasSizeSD) * rowCount)));
        $("#frame-carrousels > ul").append(itemTPL);
        $("#frame-carrousels").addClass("repository");
        VTR.Utils.debug(result);
    },
    options);
}


VTR.UI.renderMyAccount = function(){
    //$("#frame-carrousels > ul").empty();
    VTR.UI.renderMyWishList({firstCarrousel: false, size: VTR.Properties.carruselSize});
    VTR.UI.renderMyViewings({firstCarrousel: false, isAdult: false, size: VTR.Properties.carruselSize});
    VTR.UI.renderMyHistory({firstCarrousel: false, size: VTR.Properties.carruselSize});
    VTR.UI.renderMyPurchasedProducts({firstCarrousel: false, size: VTR.Properties.carruselSize});
}

VTR.UI.renderMyVOD = function(){
    //$("#frame-carrousels > ul").empty();
    VTR.UI.renderMyWishList({firstCarrousel: false, size: VTR.Properties.carruselSize});
    VTR.UI.renderMyViewings({firstCarrousel: false, isAdult: false, size: VTR.Properties.carruselSize});
    VTR.UI.renderMyRecommendations({firstCarrousel: false, size: VTR.Properties.carruselSize});
}

VTR.UI.renderRecommendations = function(options){
    //$("#frame-carrousels > ul").empty();
    var director = sessionStorage.getItem('director');
    var optionsMenu = {'categoryId': options.titleId, relations: []};
    VTR.UI.renderRelatedRecommendations({firstCarrousel: false, isAdult: false, 'titleId': options.titleId, size: VTR.Properties.carruselSize});
    if(director.toUpperCase() != VTR.Properties.notAvailable) {
        var directors = $.trim(director.toUpperCase());
        var arr_dir = directors.split(',');
        if(arr_dir == null) {
            optionsMenu.relations.push({id: 'RECOM-DIRECTOR', Name: $.trim(directors.toUpperCase())});
            VTR.UI.renderSearchRelatedRecommendations({firstCarrousel: false, isAdult: false, 'term': $.trim(directors.toUpperCase()), isExact: true, size: VTR.Properties.carruselSize});
        }
        if(arr_dir.length > 0){
            optionsMenu.relations.push({id: 'RECOM-DIRECTOR', Name: $.trim(arr_dir[0].toUpperCase())});
            VTR.UI.renderSearchRelatedRecommendations({firstCarrousel: false, isAdult: false, 'term': $.trim(arr_dir[0].toUpperCase()), isExact: true, size: VTR.Properties.carruselSize});
        }
    }
    var actors = sessionStorage.getItem('actors');
    var arr_actors = actors.split(',');
    if(arr_actors.length >= 2) {
        for(var i=0; i<2; i++) {
            if(arr_actors[i].toUpperCase() != VTR.Properties.notAvailable) {
                var sTerm = $.trim(arr_actors[i].toUpperCase());
                VTR.UI.renderSearchRelatedRecommendations({firstCarrousel: false, isAdult: false, 'term': sTerm, isExact: true, size: VTR.Properties.carruselSize});
                optionsMenu.relations.push({id: 'RECOM-ACTOR', Name: $.trim(arr_actors[i].toUpperCase())});
            }
        }
    }
    VTR.UI.renderListRecomMenu(optionsMenu);
}

/* Function renderTransitionPlayer */
VTR.UI.renderTransitionPlayer = function(options){
    $("#title-name").html("VER " + options.categoryName + ": " + options.episodeName);
    $("section#section-options").empty();
    var itemTPL = "";
    itemTPL += "<ul class='nav-detail'>\n"
    itemTPL += "<li id='transitionplayer' href='#' data-crid='" + options.titleId + "' data-asset-id='" + options.assetId + "' data-isseries='" + options.isSeries + "' data-categoryid='" + options.categoryId + "' data-categoryname='" + options.categoryName + "' data-selseason='" + options.selSeason + "' data-selepisode='" + options.selEpisode + "' data-entitlement-state='" + options.entitlementState + "' data-bookmark='0'>VER DESDE EL INICIO</li>\n";    
    itemTPL += "<li id='transitionplayer' href='#' data-crid='" + options.titleId + "' data-asset-id='" + options.assetId + "' data-isseries='" + options.isSeries + "' data-categoryid='" + options.categoryId + "' data-categoryname='" + options.categoryName + "' data-selseason='" + options.selSeason + "' data-selepisode='" + options.selEpisode + "' data-entitlement-state='" + options.entitlementState + "' data-bookmark='" + options.bookmark + "'>CONTINUAR VIENDO</li>\n";    
    itemTPL += "</ul>\n"
    $("section#section-options").append(itemTPL);
}

/* Function renderChangeEpisodeDetail */
VTR.UI.renderChangeEpisodeDetail = function(options){
    $("#title-name").html(options.episode.name);
    $("#genero").html(options.episode.genre);
    $("#duracion").html((options.episode.duration/60) + " minutos");
    $("#ano").html(options.episode.year);
    $("#episode-synopsis").html(options.episode.synopsis);
    $("#director").html(options.episode.director);
    $("#actors").html(options.episode.actors);
    //$("#season-imagen").html(options.episode.poster + (VTR.UI.screenFormat == "HD" ? '?w='+VTR.Properties.fichaPosterHDWidth+'&h='+VTR.Properties.fichaPosterHDHeight+'&mode=stretch' : '?w='+VTR.Properties.fichaPosterSDWidth+'&h='+VTR.Properties.fichaPosterSDHeight+'&mode=stretch'));
    var availDate = "";
    availDate = new Date(options.episode.lastAvailability);
    var day = availDate.getDate();
    var month = availDate.getMonth()+1;
    var year = availDate.getFullYear();
    var mydate = '' + (day <= 9 ? '0' + day : day) + '/' + (month<=9 ? '0'+month : month) + '/' + year;
    $("#last-availability").text("Disponible hasta: " + mydate);
    //$("#last-availability").html("Disponible hasta: " + options.episode.lastAvailability);
}

/* Function renderTitleDetailSeries */
VTR.UI.renderTitleDetailSeries = function(options){
    VTR.Series.getListSeriesBySeasonAndTitles(function(result){
        if (result.cats.length != 0) {
            sessionStorage.removeItem('listcategories');
            sessionStorage.setItem('listcategories', JSON.stringify(result.cats));
            sessionStorage.setItem('submenucategoryid', result.cats[0].categoryId);

            $(".load-nav nav").empty();
            var itemMenu = "";
            itemMenu += "<h5 id='category-name'>{{CATEGORY_NAME}}</h5>\n";
            //itemMenu += "<span id='legend-button'>MENÚ <span class='button-yellow'>A</span></span>\n";
            itemMenu += "<span class='mask'>\n";
            itemMenu += "<ul class='category-menu'>\n";

            if (navi.navigate.length > 0) {
                if(VTR.Properties.titleMenu1stLevel.toString().length == 0 || VTR.Properties.titleMenu1stLevel == navi.navigate[0].categoryName) {
                    VTR.Properties.titleMenu1stLevel = navi.navigate[0].categoryName;
                }
            }
            if (navi.navigate.length > 1) {
                if(VTR.Properties.titleMenu2ndLevel.toString().length == 0 || VTR.Properties.titleMenu2ndLevel == navi.navigate[1].categoryName) { 
                    VTR.Properties.titleMenu2ndLevel = navi.navigate[1].categoryName;
                }
            }
            if (navi.navigate.length > 2) {
                if(VTR.Properties.titleMenu3rdLevel.toString().length == 0 || VTR.Properties.titleMenu3rdLevel == navi.navigate[2].categoryName){
                    VTR.Properties.titleMenu3rdLevel = navi.navigate[2].categoryName;
                }
            }
            //else
            //    VTR.Properties.titleMenu3rdLevel = result.categoryName;
                

            VTR.Properties.titlesMenu = VTR.Utils.concatenateTitlesMenu(VTR.Properties.titleMenu1stLevel, VTR.Properties.titleMenu2ndLevel, VTR.Properties.titleMenu3rdLevel);
            itemMenu = itemMenu.replace("{{CATEGORY_NAME}}", VTR.Properties.titlesMenu);

            itemMenu += "<li data-crid='" + result.categoryId + "' data-name='" + result.categoryName.toUpperCase() + "' data-isseries='" + result.isSeries + "' data-selseason='" + options.selSeason + "'>" + result.cats[options.selSeason].categoryName.toUpperCase() + "</li>\n";
            $.each(result.cats, function(id, data){
                if (options.selSeason != id) {
                    itemMenu += "<li data-crid='" + result.categoryId + "' data-name='" + result.categoryName.toUpperCase() + "' data-isseries='" + result.isSeries + "' data-selseason='" + id + "'>" + data.categoryName.toUpperCase() + "</li>\n";
                }
            });

            var widthSub = 0;
                $.each($("span.mask .category-menu").children(), function(ix,dx) {
                    widthSub += dx.offsetWidth;
                });
                if(widthSub >= $('span.mask').width()) {
                    $(".arrowSub").show();
                }
                else {
                    $(".arrowSub").hide();
                }
            
            //$(".load-nav nav").append("<div class='arrowSub'></div>");
            $(".load-nav nav").append("<div id='focusEdge' class='focusEdgeSub'></div>");
            itemMenu += "</ul></span>\n";
            $(".load-nav nav").append(itemMenu);

            if (options.isSeries != true){
                $('nav .mask ul').removeClass('active');
                $('section#frame-carrousels ul').addClass('active');
            }

            var itemTPL = "";
            if (VTR.UI.screenFormat == "HD") {
                itemTPL += "<article>"
                itemTPL += "    <div class='continue' style='display:none;'>\n";
                itemTPL += "       <a class='play-element-fix' style='display:block;top:180px;'></a>\n";
                itemTPL += "       <div class='progress' style='max-width:{{BOOKMARK}}%'>\n";
                itemTPL += "       </div>\n";
                itemTPL += "    </div>\n";
                itemTPL += "<span><img id='season-imagen' src='{{IMAGE_URL}}'></span>\n";
                itemTPL += "  <small id='last-availability'>Disponible hasta: {{LAST_AVAILABILITY}}</small>\n";
                itemTPL += "</article><article>"
                itemTPL += "  <h1><span id='serie-name' data-serieid='{{SERIE_ID}}'>{{SERIE_NAME}}</span></h1>\n";
                itemTPL += "  <h1><span id='title-name'>{{NAME}}</span> ";
                itemTPL += "{{RATING}}";
                itemTPL += "</h1>\n";
                itemTPL += "     <ul>\n";
                itemTPL += "        <li><strong>Género:</strong><span id='genero'>{{GENRE}}</span></li>\n";
                itemTPL += "        <li><strong>Duración:</strong><span id='duracion'>{{DURATION}}</span></li>\n";
                itemTPL += "        <li><strong>Año:</strong><span id='ano'>{{YEAR}}</span></li>\n";
                itemTPL += "     </ul>\n";
                itemTPL += " <p id='episode-synopsis'>{{SYNOPSIS}}</p>\n";
                itemTPL += " <ul><li><strong>Director:</strong><span id='director'>{{DIRECTOR}}</span></li>\n";
                itemTPL += " <li><strong>Actores:</strong><span id='actors'>{{ACTORS}}</span></li></ul>\n";
                itemTPL += "</article>"
            } else {
                itemTPL += "<article>"
                itemTPL += "    <div class='continue' style='display:none;'>\n";
                itemTPL += "       <a class='play-element-fix' style='display:block;top:60px;'></a>\n";
                itemTPL += "       <div class='progress' style='max-width:{{BOOKMARK}}%'>\n";
                itemTPL += "       </div>\n";
                itemTPL += "    </div>\n";
                itemTPL += "<span><img id='season-imagen' src='{{IMAGE_URL}}'></span>\n";
                itemTPL += "<div class='rating-content'>\n";
                itemTPL += "   {{RATING}} \n";
                itemTPL += "   <ul>\n";
                itemTPL += "</div>\n";
                itemTPL += "<small id='last-availability'>Disponible hasta: {{LAST_AVAILABILITY}}</small>\n";
                itemTPL += "</article><article>"
                itemTPL += "     <ul style='margin-top: 2px;'>\n";
                itemTPL += "        <li><strong>Género:</strong><span id='genero'>{{GENRE}}</span></li>\n";
                itemTPL += "        <li><strong>Duración:</strong><span id='duracion'>{{DURATION}}</span></li>\n";
                itemTPL += "        <li><strong>Año:</strong><span id='ano'>{{YEAR}}</span></li>\n";
                itemTPL += "     </ul>\n";
                itemTPL += "<p class='truncate-length' id='episode-synopsis'>{{SYNOPSIS}}</p>\n";
                itemTPL += " <ul><li><strong>Director:</strong><span id='director'>{{DIRECTOR}}</span></li>\n";
                itemTPL += "<li><strong>Actores:</strong> <span id='actors'>{{ACTORS}}</span></li></ul>\n";
                itemTPL += "</article>"
            }

            if ((result.cats[options.selSeason].titledetail.length > 0) && (options.selEpisode > 0)) {
                var titledetail = result.cats[options.selSeason].titledetail;
                var pricesformats = result.cats[options.selSeason].pricesformats;

                var idx = 1;
                var idy = options.selEpisode;
		for (j = options.selEpisode; j < (options.selEpisode + result.cats[options.selSeason].titledetail.length); j++) {	
                    result.cats[options.selSeason].titledetail[idx] = titledetail[idy];
                    result.cats[options.selSeason].pricesformats[idx] = pricesformats[idy];

                    idy = (idy < result.cats[options.selSeason].titledetail.length-1) ? idy+1 : 0;
                    idx = (idx < result.cats[options.selSeason].titledetail.length-1) ? idx+1 : 0;
                }
            }

            //$.each(result.cats[0].titledetail, function(id, data){
            if (result.cats[options.selSeason].titledetail.length != 0) {
                data = result.cats[options.selSeason].titledetail[(result.cats[options.selSeason].pricesformats.length > 1 ? 1 : 0)];
                if (VTR.UI.screenFormat == 'SD') {
                    var SDtitle = "";
                    SDtitle += "<h1 class='wrapper' style='margin-bottom: 10px;'><span id='serie-name'>{{SERIE_NAME}}</span></h1>";
                    SDtitle += "<h1 class='wrapper' style='margin-bottom: 10px;'><span id='title-name'>{{NAME}}</span></h1>";
                    SDtitle = SDtitle.replace("{{SERIE_NAME}}", result.categoryName);
                    SDtitle = SDtitle.replace("{{NAME}}", data.name.toUpperCase());
                    $(SDtitle).insertBefore("section#detail-rent-movie");
                }
                var categoryName = "";
                //categoryName = (VTR.Utils.isset(data.categoryName) ? data.categoryName.toUpperCase() : "");
                //$("#category-name").html((VTR.Properties.titlesMenu == "" ? categoryName : VTR.Properties.titlesMenu));
                //$("#category-name").html(categoryName);
                //var progress = 0;
                //progress = Math.round(data.bookmark * 100 / data.duration);
                var imageSeason = (VTR.Utils.isset(result.cats[options.selSeason].poster) && result.cats[options.selSeason].poster != "" ? result.cats[options.selSeason].poster : VTR.Properties.vodImage);
                itemTPL = itemTPL.replace("{{SERIE_ID}}", result.categoryId);
                itemTPL = itemTPL.replace("{{SERIE_NAME}}", result.categoryName);
                itemTPL = itemTPL.replace("{{NAME}}", data.name.toUpperCase());
                itemTPL = itemTPL.replace("{{GENRE}}", data.genre);
                itemTPL = itemTPL.replace("{{DURATION}}", (data.duration/60) + (VTR.UI.screenFormat == 'SD' ? " min." : " minutos"));
                itemTPL = itemTPL.replace("{{YEAR}}", data.year);
                //itemTPL = itemTPL.replace("{{LAST_AVAILABILITY}}", data.lastAvailability);
                itemTPL = itemTPL.replace("{{ACTORS}}", data.actors);
                itemTPL = itemTPL.replace("{{DIRECTOR}}", data.director);
                itemTPL = itemTPL.replace("{{IMAGE_URL}}", imageSeason + (VTR.UI.screenFormat == "HD" ? '?w='+VTR.Properties.fichaPosterHDWidth+'&h='+VTR.Properties.fichaPosterHDHeight+'&mode=stretch' : '?w='+VTR.Properties.fichaPosterSDWidth+'&h='+VTR.Properties.fichaPosterSDHeight+'&mode=stretch'));
                itemTPL = itemTPL.replace("{{SYNOPSIS}}", data.synopsis);
                itemTPL = itemTPL.replace("{{RATING}}", (data.rating != '' ? "<p class='calificacion'>" + data.rating + "</p>" : ""));
                //itemTPL = itemTPL.replace("{{BOOKMARK}}", (progress == 0 ? 1 : progress));
                $("section#detail-rent-movie").append(itemTPL);
                //$("#description-detail").append(it2)
                $("section#detail-rent-movie").data("crid", data.id);
                //if(data.bookmark > 0) {
                //    $(".continue").show();
                //} else {
                //    $(".continue").hide();
                //}
                sessionStorage.setItem('titledetail', JSON.stringify(data));
            }
            //});

            var itemTPL = "";
            var itemSubscription = "";
            var isOnWishlist = "";
            var entitlementState = "";
            var bookmark = "";
            var VodType = "";
            var entitlementEnd = "";
            var playMessage = "";
            var price = 0.0;
            var name = "";
            isOnWishlist = result.cats[options.selSeason].IsOnWishlist;
            bookmark = result.cats[options.selSeason].Bookmark;
            itemTPL += " <article id='title-options'>\n";
            itemTPL += "    {{RENTAL_PERIOD}}<nav>\n";
            itemTPL += "       <span class='border-menu'></span>\n";
            itemTPL += "       <ul class='nav-detail' tabindex='-1'>\n";

            $.each(result.cats[options.selSeason].pricesformats, function(id, data){
                VTR.Properties.assetId = data.assetId;
                entitlementState = data.EntitlementState;
                entitlementEnd = data.EntitlementEnd;
                VodType = data.Type;
                data2 = result.cats[options.selSeason].titledetail[id];
                data2.lastAvailability = data.LastAvailability;
                name = (VTR.UI.screenFormat == "HD" ? data2.name.substring(0, 18) : data2.name.substring(0, VTR.Properties.titleMaxSize));
                switch(data.Type) {
                    case 'Subscription':
                    case 'Free':
                        if(data2.bookmark > 0){
                            itemTPL += "      <li id='player' href='#' data-crid='" + data.titleId + "' data-asset-id='" + data.assetId + "' data-isseries='" + result.isSeries + "' data-selseason='" + options.selSeason + "' data-selepisode='" + id + "' data-entitlement-state='" + entitlementState + "' data-episode='" + JSON.stringify(data2) + "' data-bookmark='" + data2.bookmark + "'>" + name + " " + (data.isHD ? 'EN HD' : '') + "<div class='progres-episode'><span style='width:" + Math.round(data2.bookmark * 100 / data2.duration) + "%'></span></div></li>\n";    
                        } else {
                            itemTPL += "      <li id='player' href='#' data-crid='" + data.titleId + "' data-asset-id='" + data.assetId + "' data-isseries='" + result.isSeries + "' data-selseason='" + options.selSeason + "' data-selepisode='" + id + "' data-entitlement-state='" + entitlementState + "' data-episode='" + JSON.stringify(data2) + "' data-bookmark='" + data2.bookmark + "'>" + name + " " + (data.isHD ? 'EN HD' : '') + "</li>\n";        
                        }
                        itemTPL = itemTPL.replace("{{RENTAL_PERIOD}}", "");
                        sessionStorage.setItem("assetId",data.assetId);
                        break;
                    case 'Transaction':
                        sessionStorage.setItem("productId",data.productId);
                        sessionStorage.setItem("assetId",data.assetId);
                        if (entitlementState == 'Entitled') {
                            if(data2.bookmark > 0){
                                itemTPL += "      <li id='player' href='#' data-crid='" + data.titleId + "' data-asset-id='" + data.assetId + "' data-isseries='" + result.isSeries + "' data-selseason='" + options.selSeason + "' data-selepisode='" + id + "' data-entitlement-state='" + entitlementState + "' data-episode='" + JSON.stringify(data2) + "' data-bookmark='" + data2.bookmark + "'>" + name + " " + (data.isHD ? 'EN HD' : '') + "<div class='progres-episode'><span style='width:" + Math.round(data2.bookmark * 100 / data2.duration) + "%'></span></div></li>\n";    
                            } else {
                                itemTPL += "      <li id='player' href='#' data-crid='" + data.titleId + "' data-asset-id='" + data.assetId + "' data-isseries='" + result.isSeries + "' data-selseason='" + options.selSeason + "' data-selepisode='" + id + "' data-entitlement-state='" + entitlementState + "' data-episode='" + JSON.stringify(data2) + "' data-bookmark='" + data2.bookmark + "'>" + name + " " + (data.isHD ? 'EN HD' : '') + "</li>\n";        
                            }
                            var today = new Date();
                            var end = new Date(entitlementEnd);
                            var milisecsValid = Math.abs(end - today);
                            var oneHour = 1000*60*60;
                            var hoursValid = Math.round(milisecsValid/oneHour);
                            if (hoursValid > 0) {
                                itemTPL = itemTPL.replace("{{RENTAL_PERIOD}}", "<h2>Arriendo válido por "+(hoursValid<2 ? hoursValid+" hora" : hoursValid+" horas")+"</h2>");
                            } else {
                                var minutesValid = Math.round(milisecsValid/60000);
                                itemTPL = itemTPL.replace("{{RENTAL_PERIOD}}", "<h2>Arriendo válido por "+(minutesValid<2 ? minutesValid+" minuto" : minutesValid+" minutos")+"</h2>");
                            }
                        } else {
                            price = Number(data.ListPrice);
                            if (data.isHD) {
                                itemTPL += "          <li id='rent'" + "' data-episode='" + JSON.stringify(data2) +"'>ARRENDAR HD POR $" + price.formatMoney(0,'.',',') + "</li>\n";
                            } else {
                                itemTPL += "          <li id='rent'" + "' data-episode='" + JSON.stringify(data2) +"'>ARRENDAR POR $" + price.formatMoney(0,'.',',') + "</li>\n";
                            }
                            itemTPL = itemTPL.replace("{{RENTAL_PERIOD}}","    <h2>Arrienda por " + (data.RentalPeriod / 60) + " Horas</h2>\n");
                        }
                        break;
                }
            });

            itemTPL += "          <li id='recommendations' data-crid='" + result.cats[options.selSeason].pricesformats[0].titleId + "'>RECOMENDACIONES</li>\n";
            itemTPL += "       </ul>\n";
            itemTPL += "    </nav>\n";
            itemTPL += " </article>\n";

            if(entitlementState == "Entitled" || VodType == 'Transaction') {
                $("section#detail-rent-movie").append(itemTPL);
            } else {
                itemSubscription += "        <article>\n";
                itemSubscription += "            <div id='subscribe-box'> \n";
                itemSubscription += "               <h4>Contrata {{SUBSCRIPTION_NAME}}</h4>\n";
                itemSubscription += "               <p>${{SUBSCRIPTION_PRICE}} mensuales</p>\n";
                itemSubscription += "               <p>Llamando al 600 800 9000</p>\n";
                itemSubscription += "            </div><!--fin subscribe-->\n";
                itemSubscription += "         </article>\n";
                var sPrice = Number(result.cats[options.selSeason].pricesformats[0].ListPrice);
                itemSubscription = itemSubscription.replace('{{SUBSCRIPTION_PRICE}}', sPrice.formatMoney(0,'.',','));
                itemSubscription = itemSubscription.replace('{{SUBSCRIPTION_NAME}}', result.cats[options.selSeason].pricesformats[0].Name);
                $("section#detail-rent-movie").append(itemSubscription);
            
            }
            var availDate = "";
            if(result.cats[options.selSeason].pricesformats.length > 0) {
                availDate = new Date(result.cats[options.selSeason].pricesformats[0].LastAvailability);
                var day = availDate.getDate();
                var month = availDate.getMonth()+1;
                var year = availDate.getFullYear();
                var mydate = '' + (day <= 9 ? '0' + day : day) + '/' + (month<=9 ? '0'+month : month) + '/' + year;
                $("#last-availability").text("Disponible hasta: " + mydate);

                if(result.cats[options.selSeason].pricesformats[0].languages != "") {
                    $("#lang").html("<strong>Idioma:</strong> " + result.cats[options.selSeason].pricesformats[0].languages);
                    if(result.cats[options.selSeason].pricesformats[0].subtitles != "") {
                        $("#subtitles").html("<strong>Subtítulos:</strong> " + result.cats[options.selSeason].pricesformats[0].subtitles);
                    }
                }
            }
            $("section#detail-rent-movie").data('is-series', options.isSeries);
            VTR.Utils.debug(result);
        } else {
            sessionStorage.setItem('submenucategoryid', options.categoryId);
        }
    }, options);
}

/*Added an array of videos*/
var keyboard;
var topMenu;
var cookie_get; //The cookie url object
var cookieList; //Cookie DOM list



VTR.UI.renderKeyboard = function(){
    window.addEventListener('message', handleWebRemoteMessage);

    //Instantiate the global variables
    topMenu = document.getElementById('thumbStrip');
    keyboardHolder = document.getElementById('keyboardHolder');
    pauseDiv = document.getElementById('pauseDiv');
    allButtons = new Array();
    currentFocusNum = 0;
    largeVideoSource = "";
    isPlaying = false; //Used for the play/pausebutton
    cookie_get; //The cookie url object
    cookieList; //Cookie DOM list

    function getRelativeValues(valueToFind){
        if(window.innerWidth >= 1280){
            if(valueToFind == "height"){
                return 350;
            }
            else if(valueToFind == "keySize"){
                return 48;
            }
            else if(valueToFind == "keyMod"){
                return 3;
            }
            else{
                return 270;
            }
        }
        else{
            if(valueToFind == "height"){
                return 300;
            }
            else if(valueToFind == "keySize"){
                return 32;
            }
            else if(valueToFind == "keyMod"){
                return 2;
            }
            else{
                return 170;
            }
        }
    }
    var createOneButton = function(){
        var fbutton = document.createElement('button');
        fbutton.id = 'button0';
        // fbutton.style.verticalAlign="bottom";
        // fbutton.style.top = "bottom";
        // fbutton.style.color = "#ffffff";
        // fbutton.style.textShadow = "2px 2px 1px black";
        //fbutton = searchControl(fbutton);
        topMenu.appendChild(fbutton);
    }

    var setRecentSubmit = function(){
        setAsRecent(keyboard.getValue());
        window.open(keyboard.getValue());
    //    createRecentList();
    }

    var handleWebRemoteMessage = function(evt){
        var url = evt.data;
        if(typeof(url) == 'string' && url){
            url = url.indexOf('http') !== 0 ? 'http://' + url : url;
            console.log("Going to set to " + url)
            keyboard.setText(url);
            setRecentSubmit();
        }
    }

    var startSearch = function() {
        if($('#button0').text().length >= 4) {
             setTerm();
             var termSearch = localStorage.getItem("term"+VTR.Account.cpeId);
            if (VTR.Utils.isset(termSearch)){
                VTR.UI.renderListSearchResults({firstCarrousel: true, isExact: false, size: VTR.Properties.lienzoSize});
            }
        }
    }
    
    var deleteSearch = function() {
        setTerm();
        var termSearch = localStorage.getItem("term"+VTR.Account.cpeId);
        if (VTR.Utils.isset(termSearch)){
            if(termSearch.length >= 3) {
                VTR.UI.renderListSearchResults({firstCarrousel: true, isExact: false, size: VTR.Properties.lienzoSize});
            }
            else {
                $("#search").empty();
            }
        }
    }
    //INIT
    var init = function(){
        av.require('storage.cookies');
        cookieList = document.getElementById("cookieList");
        createOneButton();

        var config = av.mergeObjects(
            av.keyboard.loadTemplate('text'),
            {
                height  : getRelativeValues("height"),
                width   : getRelativeValues("width"),
                keyHeight : getRelativeValues("keySize"),
                keyWidth : getRelativeValues("keySize"),
                holder  : 'keyboardHolder',
                target  : 'button0',
                padding : (VTR.UI.screenFormat == 'HD' ? '10' : '6'),
                navRight    : 'button0',
                'functions':{submit : setRecentSubmit,cancel: function(){
                    selectCookieList();
                }},
                panels : [
                 //Panel 1
                 {
                     name   : 'alpha',
                     shiftStates        : ["^shift","CAPS","lower"],
                     keys   : [
                        {value:'a',isDefault:true},'b','c','d','e','f','g','h','i','j','k','l','m','n','ñ','o','p','q','r','s','t','u','v','w','x','y','z',
                        {label:'ESPACIO',value:' ',width:(getRelativeValues("keySize")*2),keyClass:'space',noShift:true},
                        {label:'',uses:'backspace',width:(getRelativeValues("keySize")*1), keyClass:'delete'},
                        '1','2','3','4','5','6','7','8','9','0',
                     ]
                 },
                ]
            }
            );
        keyboard = av.keyboard.create(config);
        keyboard.show();
        keyboard.focus();
        var sTerm = localStorage.getItem("term"+VTR.Account.cpeId);
        if(VTR.Utils.isset(sTerm)) {
            sTerm = sTerm.replace(/\+/gi, " ");
            localStorage.setItem("term"+VTR.Account.cpeId, sTerm);
        }
        else {
            keyboard.focus();
        }
        keyboard.setText(VTR.Utils.isset(localStorage.getItem("term"+VTR.Account.cpeId)) ? localStorage.getItem("term"+VTR.Account.cpeId) : "");

        keyboard.addEventListener('afteradd', startSearch, true);
        keyboard.addEventListener('afterdelete', deleteSearch, true);

    }

    init();
    $( ".AVB32x32" ).wrapInner( "<span class='box'></span>" );
    $( ".AVB64x32" ).wrapInner( "<span class='box'></span>" );
    $( ".AVB48x48" ).wrapInner( "<span class='box'></span>" );
    $( ".AVB64x64" ).wrapInner( "<span class='box'></span>" );
    $( ".AVB96x48" ).wrapInner( "<span class='box'></span>" );
    $( ".AVB128x64" ).wrapInner( "<span class='box'></span>" );
}
