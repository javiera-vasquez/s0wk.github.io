/*
	NAME: VTR.TA
	DESCRIPTION: ThinkAnalytics

*/

VTR.TA = {
    
}


/* Function to get My Recommendations from ThinkAnalytics */
VTR.TA.getMyRecommendations = function(callback, options){
	// var fieldList = 'Name,Categories,Pictures,ShortName,Bookmark';
	var urlGetMyRecommendations =  VTR.Properties.traxisProxy + '/' + VTR.Traxis.urlBodyRequest;
	// urlGetMyRecommendations     =  urlGetMyRecommendations.replace('{{FIELD_LIST}}', fieldList);
	// urlGetMyRecommendations     =  urlGetMyRecommendations.replace('{{CUSTOMER_ID}}',options.customerId);
    var output = {"myrecommendations":[]};
    var bodyReq = "";
	var urlGetRecomTA = VTR.Properties.thinkAnalyticsServer + '/' + VTR.Traxis.urlGetSuggestionsForYou;
	var pId = VTR.Account.profileId.replace('~~', '%');
	urlGetRecomTA = urlGetRecomTA.replace('{{PROFILE_ID}}', pId);
    if(VTR.UI.screenFormat == 'SD' && options.size === VTR.Properties.carruselSize){
         urlGetRecomTA = urlGetRecomTA.replace('{{CARRUSEL_SIZE}}', VTR.Properties.lienzoSize);
    } else {
        urlGetRecomTA = urlGetRecomTA.replace('{{CARRUSEL_SIZE}}', options.size);
    }
    console.log(urlGetRecomTA);
    try {
        $.get(urlGetRecomTA, function(recom) {
            if(VTR.Utils.isset(recom)) {
            bodyReq += "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
            bodyReq += "<Request xmlns=\"urn:eventis:traxisweb:1.0\">";
            bodyReq += "  <Identity>";
            bodyReq += "    <CpeId>"+VTR.Account.cpeId+"</CpeId>";
            bodyReq += "  </Identity>";
            bodyReq += "  <ResourcesQuery resourceType=\"Title\">";
            bodyReq += "    <ResourceIds>";
//            parser=new DOMParser();
//            xmlDoc=parser.parseFromString(recom,"text/xml");
            var json = XMLObjectifier.xmlToJSON(recom);
//            console.log(JSON.stringify(json.recommendations));
//            console.log(Object.keys(json.recommendations).length);
            if(JSON.stringify(json.recommendations) != '[{}]'){
                if(json.recommendations.length > 0) {
                    $.each(json.recommendations[0].recommendation, function(ix, dx) {
                       bodyReq += "    	<ResourceId>" + VTR.Utils.replaceAll(dx.contentItemId[0].Text, "/", "~~2F") + "</ResourceId>";
                    });
                }
            }
            bodyReq += "    </ResourceIds>";
            bodyReq += "    <Options>";
            bodyReq += "      <Option type=\"Props\">Name,Categories,Pictures,ShortName,ContentCount</Option>";
            //bodyReq += "      <Option type=\"filter\">ContentCount&gt;0</Option>";
            bodyReq += "    </Options>";
            bodyReq += "    <SubQueries>";
            bodyReq += "      <SubQuery relationName=\"Contents\">";
            bodyReq += "        <Options>";
            bodyReq += "          <Option type=\"props\">Aliases,IsHD,Is3D,EntitlementState,EntitlementEnd</Option>";
            bodyReq += "          <Option type=\"filter\">ProductCount&gt;0</Option>";
            bodyReq += "        </Options>";
            bodyReq += "        <SubQueries>";
            bodyReq += "          <SubQuery relationName=\"Products\">";
            bodyReq += "            <Options>";
            bodyReq += "              <Option type=\"props\">Type,EntitlementState</Option>";
            bodyReq += "            </Options>";
            bodyReq += "          </SubQuery>";
            bodyReq += "        </SubQueries>";
            bodyReq += "      </SubQuery>";
            bodyReq += "    </SubQueries>";
            bodyReq += "  </ResourcesQuery>";
            bodyReq += "</Request>";
            }
        }).then(function() {

            $.post(urlGetMyRecommendations, bodyReq, function(data) {
                
               if(VTR.UI.screenFormat == 'SD'){
                   
                   //manejar el caso lienzo                   
                   if(options.size === VTR.Properties.carruselSize) {
                       
                       var countTitleCarrusel = 0;
                       
                       $.each(data.Titles.Title, function(i,d){
                            if(d.ContentCount>0) {
                                
                                
                                if(countTitleCarrusel < VTR.Properties.carruselSize)
                                {
                                    if(VTR.Utils.isset(d.Contents)) {
                                        var IsHD = VTR.Utils.isset(d.Contents) ? d.Contents.Content[0].IsHD : false;

                                        if(!IsHD) {

                                            var img = null;
                                            var pics = (VTR.Utils.isset(d.Pictures) ? d.Pictures.Picture : null);

                                            if (pics){
                                                $.each(pics, function(ix,dx) {
                                                    if(dx.type == 'BoxCover') {
                                                        img = dx.Value.replace("http://" + VTR.Properties.posterServerName + "/", "http://" + VTR.Properties.posterServer + "/");
                                                        return false;
                                                    }
                                                    else {
                                                        img = dx.Value.replace("http://" + VTR.Properties.posterServerName + "/", "http://" + VTR.Properties.posterServer + "/");
                                                    }
                                                });
                                            }

                                            output.myrecommendations.push({
                                                categoryId : d.Categories,
                                                subcategoryId : 'SUB_CATEGORY_ID',
                                                titleId : d.id,
                                                //name : d.ShortName,
                                                name : ((VTR.Utils.isset(d.ShortName) ? d.ShortName : d.Name)),
                                                is3D : (VTR.Utils.isset(d.Contents) ? d.Contents.Content[0].Is3D : false),
                                                isHD : (VTR.Utils.isset(d.Contents) ? d.Contents.Content[0].IsHD : false),
                                                pictureUri : img,
                                                contentType : (VTR.Utils.isset(d.Contents) ? d.Contents.Content[0].Products.Product[0].Type : 'CONTENT_TYPE')

                                            });

                                            countTitleCarrusel++;
                                        }
                                    }
                                }
                                else {
                                
                                    return false;
                                
                                }                                 
                                    
                            } 
                        });
                       
                   } 
                   //manejar caso carrusel
                   else {
                       
                     
                       
                       $.each(data.Titles.Title, function(i,d){
                            if(d.ContentCount>0) {
                                
                                if(VTR.Utils.isset(d.Contents)) {
                                    var IsHD = VTR.Utils.isset(d.Contents) ? d.Contents.Content[0].IsHD : false;

                                    if(!IsHD) {

                                        var img = null;
                                        var pics = (VTR.Utils.isset(d.Pictures) ? d.Pictures.Picture : null);

                                        if (pics){
                                            $.each(pics, function(ix,dx) {
                                                if(dx.type == 'BoxCover') {
                                                    img = dx.Value.replace("http://" + VTR.Properties.posterServerName + "/", "http://" + VTR.Properties.posterServer + "/");
                                                    return false;
                                                }
                                                else {
                                                    img = dx.Value.replace("http://" + VTR.Properties.posterServerName + "/", "http://" + VTR.Properties.posterServer + "/");
                                                }
                                            });
                                        }

                                        output.myrecommendations.push({
                                            categoryId : d.Categories,
                                            subcategoryId : 'SUB_CATEGORY_ID',
                                            titleId : d.id,
                                            //name : d.ShortName,
                                            name : ((VTR.Utils.isset(d.ShortName) ? d.ShortName : d.Name)),
                                            is3D : (VTR.Utils.isset(d.Contents) ? d.Contents.Content[0].Is3D : false),
                                            isHD : (VTR.Utils.isset(d.Contents) ? d.Contents.Content[0].IsHD : false),
                                            pictureUri : img,
                                            contentType : (VTR.Utils.isset(d.Contents) ? d.Contents.Content[0].Products.Product[0].Type : 'CONTENT_TYPE')

                                        });
                                        
                                        countTitleCarrusel++;
                                    }
                                }
                            } 
                        });
                       
                   }
                   
                   
               
                } 
                
                //HD
                else {                  
    
                    $.each(data.Titles.Title, function(i,d){
                        if(d.ContentCount>0) {
                            var img = null;
                            var pics = (VTR.Utils.isset(d.Pictures) ? d.Pictures.Picture : null);

                            if (pics){
                                $.each(pics, function(ix,dx) {
                                    if(dx.type == 'BoxCover') {
                                        img = dx.Value.replace("http://" + VTR.Properties.posterServerName + "/", "http://" + VTR.Properties.posterServer + "/");
                                        return false;
                                    }
                                    else {
                                        img = dx.Value.replace("http://" + VTR.Properties.posterServerName + "/", "http://" + VTR.Properties.posterServer + "/");
                                    }
                                });
                            }
                            if(VTR.Utils.isset(d.Contents)) {
                                    output.myrecommendations.push({
                                    categoryId : d.Categories,
                                    subcategoryId : 'SUB_CATEGORY_ID',
                                    titleId : d.id,
                                    //name : d.ShortName,
                                    name : ((VTR.Utils.isset(d.ShortName) ? d.ShortName : d.Name)),
                                    is3D : (VTR.Utils.isset(d.Contents) ? d.Contents.Content[0].Is3D : false),
                                    isHD : (VTR.Utils.isset(d.Contents) ? d.Contents.Content[0].IsHD : false),
                                    pictureUri : img,
                                    contentType : (VTR.Utils.isset(d.Contents) ? d.Contents.Content[0].Products.Product[0].Type : 'CONTENT_TYPE')
                                });
                            }
                        }
                    });
                }
                callback(output);
            }).fail(function(xhr, errorType, error){
                console.log('xhr:' + xhr + ' - ' + 'error:' + error);
            }).done(function(data, status, xhr){
                console.log('data:' + data + ' - ' + 'status:' + status);
            });
        }).fail(function(xhr, errorType, error){
            console.log('Error AVN API:' + JSON.stringify(xhr) + ' - ' + 'error:' + error);
        }).done(function(data, status, xhr){
            console.log('data:' + data + ' - ' + 'status:' + status);
        });
    }
    catch(err) {
        console.log('Error AVN API: '+err.message);
    }

}


//Search TA API Function
VTR.TA.getSearch = function(callback, options){
	var urlGetSearchResults =  VTR.Properties.traxisProxy + '/' + VTR.Traxis.urlBodyRequest;
	var output = {"searchResults":[]};
	var bodyReq = "";
	var searchKey = (VTR.Utils.isset(localStorage.getItem("term"+VTR.Account.cpeId)) ? localStorage.getItem("term"+VTR.Account.cpeId) : options.term);
	var urlGetSearchTA = VTR.Properties.thinkAnalyticsServer + '/' + VTR.Traxis.urlGetSearch;
	var pId = VTR.Account.profileId.replace('~~', '%');
    console.log('searchKey:'+searchKey);
	urlGetSearchTA = urlGetSearchTA.replace('{{PROFILE_ID}}', pId);
    searchKey = decodeURIComponent(searchKey);
    searchKey = searchKey.replace(/\s/gi, "+");

    if(options.isExact == true) {
        searchKey = '"'+searchKey+'"';
    }
	urlGetSearchTA = urlGetSearchTA.replace('{{SEARCH_KEY}}', searchKey);
    //urlGetSearchTA = urlGetSearchTA.replace('{{PAGE_SIZE}}', options.size);
//	urlGetSearchTA = urlGetSearchTA.replace('{{TIME_WINDOW_1}}', '1420502400');
//	urlGetSearchTA = urlGetSearchTA.replace('{{TIME_WINDOW_2}}', '1421280000');

    if(VTR.UI.screenFormat == 'SD' && options.size === VTR.Properties.carruselSize){
        urlGetSearchTA = urlGetSearchTA.replace('{{PAGE_SIZE}}', VTR.Properties.lienzoSize);
    } else {
        urlGetSearchTA = urlGetSearchTA.replace('{{PAGE_SIZE}}', options.size);
    }
    
    console.log(urlGetSearchTA);
	try {
        $.get(urlGetSearchTA, function(search) {
            bodyReq += "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
            bodyReq += "<Request xmlns=\"urn:eventis:traxisweb:1.0\">";
            bodyReq += "  <Identity>";
            bodyReq += "    <CpeId>"+VTR.Account.cpeId+"</CpeId>";
            bodyReq += "  </Identity>";
            bodyReq += "  <ResourcesQuery resourceType=\"Title\">";
            bodyReq += "    <ResourceIds>";
            parser=new DOMParser();
//            xmlDoc=parser.parseFromString(search,"text/xml");
            var json = XMLObjectifier.xmlToJSON(search);
//            console.log(JSON.stringify(json.recommendations));
//            console.log(Object.keys(json.recommendations).length);
            if(JSON.stringify(json.recommendations) != '[{}]'){
                if(json.recommendations.length > 0) {
                    $.each(json.recommendations[0].recommendation, function(ix, dx) {
                        bodyReq += "    	<ResourceId>" + VTR.Utils.replaceAll(dx.contentItemId[0].Text, "/", "~~2F") + "</ResourceId>";
                    });	
                }
            }
            bodyReq += "    </ResourceIds>";
            bodyReq += "    <Options>";
            bodyReq += "      <Option type=\"Props\">Name,Categories,Pictures,ShortName</Option>";
            bodyReq += "    </Options>";
            bodyReq += "    <SubQueries>";
            bodyReq += "      <SubQuery relationName=\"Contents\">";
            bodyReq += "        <Options>";
            bodyReq += "          <Option type=\"props\">Aliases,IsHD,Is3D,EntitlementState,EntitlementEnd</Option>";
            bodyReq += "        </Options>";
            bodyReq += "        <SubQueries>";
            bodyReq += "          <SubQuery relationName=\"Products\">";
            bodyReq += "            <Options>";
            bodyReq += "              <Option type=\"props\">Type,EntitlementState</Option>";
            bodyReq += "            </Options>";
            bodyReq += "          </SubQuery>";
            bodyReq += "        </SubQueries>";
            bodyReq += "      </SubQuery>";
            bodyReq += "    </SubQueries>";
            bodyReq += "  </ResourcesQuery>";
            bodyReq += "</Request>";
        }).then(function() {
            $.post(urlGetSearchResults, bodyReq, function(data) {
            if(VTR.UI.screenFormat == 'SD'){ 
                
                
                 //manejar el caso lienzo                   
                   if(options.size === VTR.Properties.carruselSize) {
                       
                       var countTitleCarrusel = 0;
                       
                       $.each(data.Titles.Title, function(i,d){
                            //if(d.ContentCount>0) {
                                
                                
                                if(countTitleCarrusel < VTR.Properties.carruselSize)
                                {
                                    if(VTR.Utils.isset(d.Contents)) {
                                        if(VTR.Utils.isset(d.Contents.Content[0].Products)) {
                                            var IsHD = VTR.Utils.isset(d.Contents) ? d.Contents.Content[0].IsHD : false;

                                            if(!IsHD) {

                                                var img = null;
                                                var pics = (VTR.Utils.isset(d.Pictures) ? d.Pictures.Picture : null);

                                                if (pics){
                                                    $.each(pics, function(ix,dx) {
                                                        if(dx.type == 'BoxCover') {
                                                            img = dx.Value.replace("http://" + VTR.Properties.posterServerName + "/", "http://" + VTR.Properties.posterServer + "/");
                                                            return false;
                                                        }
                                                        else {
                                                            img = dx.Value.replace("http://" + VTR.Properties.posterServerName + "/", "http://" + VTR.Properties.posterServer + "/");
                                                        }
                                                    });
                                                }

                                                output.searchResults.push({
                                                    //categoryId : d.Categories,
                                                   // subcategoryId : 'SUB_CATEGORY_ID',
                                                    titleId : d.id,
                                                    //name : d.ShortName,
                                                    name : ((VTR.Utils.isset(d.ShortName) ? d.ShortName : d.Name)),
                                                    is3D : (VTR.Utils.isset(d.Contents) ? d.Contents.Content[0].Is3D : false),
                                                    isHD : (VTR.Utils.isset(d.Contents) ? d.Contents.Content[0].IsHD : false),
                                                    pictureUri : img,
                                                    contentType : (VTR.Utils.isset(d.Contents) ? d.Contents.Content[0].Products.Product[0].Type : 'CONTENT_TYPE'),
                                                    isSeries: ""

                                                });

                                                countTitleCarrusel++;
                                            }
                                        }
                                    }
                                }
                                else {
                                
                                    return false;
                                
                                }                                 
                                    
                            //} 
                        });
                       
                   } 
                   //manejar caso carrusel
                   else {
                       
                     
                       
                       $.each(data.Titles.Title, function(i,d){
                            //if(d.ContentCount>0) {
                                
                                if(VTR.Utils.isset(d.Contents)) {
                                    if(VTR.Utils.isset(d.Contents.Content[0].Products)) {
                                        var IsHD = VTR.Utils.isset(d.Contents) ? d.Contents.Content[0].IsHD : false;

                                        if(!IsHD) {

                                            var img = null;
                                            var pics = (VTR.Utils.isset(d.Pictures) ? d.Pictures.Picture : null);

                                            if (pics){
                                                $.each(pics, function(ix,dx) {
                                                    if(dx.type == 'BoxCover') {
                                                        img = dx.Value.replace("http://" + VTR.Properties.posterServerName + "/", "http://" + VTR.Properties.posterServer + "/");
                                                        return false;
                                                    }
                                                    else {
                                                        img = dx.Value.replace("http://" + VTR.Properties.posterServerName + "/", "http://" + VTR.Properties.posterServer + "/");
                                                    }
                                                });
                                            }

                                            output.searchResults.push({
                                                //categoryId : d.Categories,
                                                // subcategoryId : 'SUB_CATEGORY_ID',
                                                titleId : d.id,
                                                //name : d.ShortName,
                                                name : ((VTR.Utils.isset(d.ShortName) ? d.ShortName : d.Name)),
                                                is3D : (VTR.Utils.isset(d.Contents) ? d.Contents.Content[0].Is3D : false),
                                                isHD : (VTR.Utils.isset(d.Contents) ? d.Contents.Content[0].IsHD : false),
                                                pictureUri : img,
                                                contentType : (VTR.Utils.isset(d.Contents) ? d.Contents.Content[0].Products.Product[0].Type : 'CONTENT_TYPE'),
                                                isSeries: ""

                                            });

                                            countTitleCarrusel++;
                                        }
                                    }
                                }
                            //} 
                        });
                       
                   }
                
            }
            else
            {
                $.each(data.Titles.Title, function(i,d){
                if(VTR.Utils.isset(d.Contents)) {
                    if(VTR.Utils.isset(d.Contents.Content[0].Products)) {
                        var img = null;
                        var pics = d.Pictures;

                        if (pics){
                          img =  pics.Picture[0].Value.replace("http://" + VTR.Properties.posterServerName + "/", "http://" + VTR.Properties.posterServer + "/");
                        }
                        output.searchResults.push({
                            titleId : d.id,
                            name : ((VTR.Utils.isset(d.ShortName) ? d.ShortName : d.Name)),
                            is3D : (VTR.Utils.isset(d.Contents) ? d.Contents.Content[0].Is3D : false),
                            isHD : (VTR.Utils.isset(d.Contents) ? d.Contents.Content[0].IsHD : false),
                            pictureUri : img,
                            contentType : (VTR.Utils.isset(d.Contents) ? d.Contents.Content[0].Products.Product[0].Type : 'CONTENT_TYPE'),
                            isSeries: ""
                        });
                    }
                }
            });
            }
            
                callback(output);
            }).fail(function(xhr, errorType, error){
                console.log('xhr:' + JSON.stringify(xhr.response) + ' - ' + 'error:' + error);
            }).done(function(data, status, xhr){
                console.log('data:' + data + ' - ' + 'status:' + status);
            });
        });
    }
    catch (err) {
        console.log('Error AVN API: '+err.message);
    }
}

VTR.TA.learnActionForTA = function(options) { 
    var fieldList = 'Contents,Bookmark';
    var urlGetTitle = VTR.Properties.traxisProxy + '/' + VTR.Traxis.urlTitleDetail;
    urlGetTitle = urlGetTitle.replace('{{TITLE_ID}}', options.titleId);
    urlGetTitle = urlGetTitle.replace('{{CPE_ID}}', VTR.Account.cpeId);
    urlGetTitle = urlGetTitle.replace('{{FIELD_LIST}}', fieldList);
    $.getJSON(urlGetTitle, function(d) {
        try {
            console.log('Bookmark:'+d.Title.Bookmark);
            if(options.action == VTR.ActionType.played) {
                if(d.Title.Bookmark <= VTR.Properties.secondsLearnAction) {
                    return;
                }
            }
            var contentId = d.Title.Contents.Content[0].id;
            var instanceId = contentId.split(",");
            var urlLearnActionTA = VTR.Properties.thinkAnalyticsServer + '/' + VTR.Traxis.urlSetLearnAction;
            var pId = VTR.Account.profileId.replace('~~', '%');
            var iId = instanceId[1].replace(/~~2F/g, '/');
            var tId = options.titleId.replace(/~~2F/g, '/');
            var unixTime = VTR.Utils.convertDateToUnixTime(new Date());
            urlLearnActionTA = urlLearnActionTA.replace('{{PROFILE_ID}}', pId);
            urlLearnActionTA = urlLearnActionTA.replace('{{ACTION_TYPE}}', options.action);
            urlLearnActionTA = urlLearnActionTA.replace('{{TITLE_ID}}', encodeURIComponent(tId));
            urlLearnActionTA = urlLearnActionTA.replace('{{INSTANCE_ID}}', encodeURIComponent(iId));
            urlLearnActionTA = urlLearnActionTA.replace('{{TIME}}', unixTime);
            console.log(urlLearnActionTA);
            $.get(urlLearnActionTA, function(data) {
                console.log('learnAction('+options.action+'):['+data+']');
            });
        }
        catch(err) {
            console.log('Error AVN API: '+err.message);
        }
    }).fail(function(xhr, errorType, error){
        console.log('xhr:' + JSON.stringify(xhr.response) + ' - ' + 'error:' + error);
    }).done(function(data, status, xhr){
        console.log('data:' + data + ' - ' + 'status:' + status);
    });             
}

/* Function to get my recommendations from ThinkAnalytics */
VTR.TA.getRelatedRecommendations = function(callback, options){
	// var fieldList = 'Name,Categories,Pictures,ShortName,Bookmark';
	var urlGetRelatedRecommendations =  VTR.Properties.traxisProxy + '/' + VTR.Traxis.urlBodyRequest;
	// urlGetRelatedRecommendations     =  urlGetRelatedRecommendations.replace('{{FIELD_LIST}}', fieldList);
	// urlGetRelatedRecommendations     =  urlGetRelatedRecommendations.replace('{{CUSTOMER_ID}}',options.customerId);
    var output = {"relatedrecom":[]};
    var bodyReq = "";
	var urlGetRelatedRecomTA = VTR.Properties.thinkAnalyticsServer + '/' + VTR.Traxis.urlGetRelatedRecommendation;
	var pId = VTR.Account.profileId.replace('~~', '%');
    var tId = options.titleId.replace(/~~2F/g, '/');
    var unixTime1 = VTR.Utils.convertDateToUnixTime(new Date());
    var today = new Date();
    var futureDay = new Date(today);
    futureDay.setDate(today.getDate() + 7);
    var unixTime2 = VTR.Utils.convertDateToUnixTime(futureDay);
	urlGetRelatedRecomTA = urlGetRelatedRecomTA.replace('{{PROFILE_ID}}', pId);
    //urlGetRelatedRecomTA = urlGetRelatedRecomTA.replace('{{CARRUSEL_SIZE}}', options.size);
    
    if(VTR.UI.screenFormat == 'SD' && options.size === VTR.Properties.carruselSize){
         urlGetRelatedRecomTA = urlGetRelatedRecomTA.replace('{{CARRUSEL_SIZE}}', VTR.Properties.lienzoSize);
    } else {
        urlGetRelatedRecomTA = urlGetRelatedRecomTA.replace('{{CARRUSEL_SIZE}}', options.size);
    }
	urlGetRelatedRecomTA = urlGetRelatedRecomTA.replace('{{TITLE_ID}}', encodeURIComponent(tId));
	urlGetRelatedRecomTA = urlGetRelatedRecomTA.replace('{{TIME_WINDOW_1}}', unixTime1);
	urlGetRelatedRecomTA = urlGetRelatedRecomTA.replace('{{TIME_WINDOW_2}}', unixTime2);
    console.log(urlGetRelatedRecomTA);
    try {
        $.get(urlGetRelatedRecomTA, function(recom) {
            bodyReq += "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
            bodyReq += "<Request xmlns=\"urn:eventis:traxisweb:1.0\">";
            bodyReq += "  <Identity>";
            bodyReq += "    <CpeId>"+VTR.Account.cpeId+"</CpeId>";
            bodyReq += "  </Identity>";
            bodyReq += "  <ResourcesQuery resourceType=\"Title\">";
            bodyReq += "    <ResourceIds>";
            parser=new DOMParser();
//            xmlDoc=parser.parseFromString(recom,"text/xml");
            var json = XMLObjectifier.xmlToJSON(recom);
//            console.log(JSON.stringify(json.recommendations));
//            console.log(Object.keys(json.recommendations).length);
            if(JSON.stringify(json.recommendations) != '[{}]'){
                if(json.recommendations.length > 0) {
                    $.each(json.recommendations[0].recommendation, function(ix, dx) {
                        bodyReq += "    	<ResourceId>" + VTR.Utils.replaceAll(dx.contentItemId[0].Text, "/", "~~2F") + "</ResourceId>";
                    });	
                }
            }
            bodyReq += "    </ResourceIds>";
            bodyReq += "    <Options>";
            bodyReq += "      <Option type=\"Props\">Name,Categories,Pictures,ShortName</Option>";
            //bodyReq += "      <Option type=\"filter\">Contents&gt;0</Option>";
            bodyReq += "    </Options>";
            bodyReq += "    <SubQueries>";
            bodyReq += "      <SubQuery relationName=\"Contents\">";
            bodyReq += "        <Options>";
            bodyReq += "          <Option type=\"props\">Aliases,IsHD,Is3D,EntitlementState,EntitlementEnd</Option>";
            bodyReq += "        </Options>";
            bodyReq += "        <SubQueries>";
            bodyReq += "          <SubQuery relationName=\"Products\">";
            bodyReq += "            <Options>";
            bodyReq += "              <Option type=\"props\">Type,EntitlementState</Option>";
            bodyReq += "            </Options>";
            bodyReq += "          </SubQuery>";
            bodyReq += "        </SubQueries>";
            bodyReq += "      </SubQuery>";
            bodyReq += "    </SubQueries>";
            bodyReq += "  </ResourcesQuery>";
            bodyReq += "</Request>";
        }).then(function() {
            $.post(urlGetRelatedRecommendations, bodyReq, function(data) {
                 if(VTR.UI.screenFormat == 'SD'){
                     
                     //manejar el caso lienzo                   
                    if(options.size === VTR.Properties.carruselSize) {
                       
                       var countTitleCarrusel = 0;
                       
                       $.each(data.Titles.Title, function(i,d){
                            if(d.ContentCount>0) {
                                
                                
                                if(countTitleCarrusel < VTR.Properties.carruselSize)
                                {
                                    if(VTR.Utils.isset(d.Contents)) {
                                        var IsHD = VTR.Utils.isset(d.Contents) ? d.Contents.Content[0].IsHD : false;

                                        if(!IsHD) {

                                            var img = null;
                                            var pics = (VTR.Utils.isset(d.Pictures) ? d.Pictures.Picture : null);

                                            if (pics){
                                                $.each(pics, function(ix,dx) {
                                                    if(dx.type == 'BoxCover') {
                                                        img = dx.Value.replace("http://" + VTR.Properties.posterServerName + "/", "http://" + VTR.Properties.posterServer + "/");
                                                        return false;
                                                    }
                                                    else {
                                                        img = dx.Value.replace("http://" + VTR.Properties.posterServerName + "/", "http://" + VTR.Properties.posterServer + "/");
                                                    }
                                                });
                                            }

                                            output.myrecommendations.push({
                                                categoryId : d.Categories,
                                                subcategoryId : 'SUB_CATEGORY_ID',
                                                titleId : d.id,
                                                //name : d.ShortName,
                                                name : ((VTR.Utils.isset(d.ShortName) ? d.ShortName : d.Name)),
                                                is3D : (VTR.Utils.isset(d.Contents) ? d.Contents.Content[0].Is3D : false),
                                                isHD : (VTR.Utils.isset(d.Contents) ? d.Contents.Content[0].IsHD : false),
                                                pictureUri : img,
                                                contentType : (VTR.Utils.isset(d.Contents) ? d.Contents.Content[0].Products.Product[0].Type : 'CONTENT_TYPE')

                                            });

                                            countTitleCarrusel++;
                                        }
                                    }
                                }
                                else {
                                
                                    return false;
                                
                                }                                 
                                    
                            } 
                        });
                       
                   } 
                   //manejar caso carrusel
                   else {
                       
                     
                       
                       $.each(data.Titles.Title, function(i,d){
                            if(d.ContentCount>0) {
                                
                                if(VTR.Utils.isset(d.Contents)) {
                                    var IsHD = VTR.Utils.isset(d.Contents) ? d.Contents.Content[0].IsHD : false;

                                    if(!IsHD) {

                                        var img = null;
                                        var pics = (VTR.Utils.isset(d.Pictures) ? d.Pictures.Picture : null);

                                        if (pics){
                                            $.each(pics, function(ix,dx) {
                                                if(dx.type == 'BoxCover') {
                                                    img = dx.Value.replace("http://" + VTR.Properties.posterServerName + "/", "http://" + VTR.Properties.posterServer + "/");
                                                    return false;
                                                }
                                                else {
                                                    img = dx.Value.replace("http://" + VTR.Properties.posterServerName + "/", "http://" + VTR.Properties.posterServer + "/");
                                                }
                                            });
                                        }

                                        output.myrecommendations.push({
                                            categoryId : d.Categories,
                                            subcategoryId : 'SUB_CATEGORY_ID',
                                            titleId : d.id,
                                            //name : d.ShortName,
                                            name : ((VTR.Utils.isset(d.ShortName) ? d.ShortName : d.Name)),
                                            is3D : (VTR.Utils.isset(d.Contents) ? d.Contents.Content[0].Is3D : false),
                                            isHD : (VTR.Utils.isset(d.Contents) ? d.Contents.Content[0].IsHD : false),
                                            pictureUri : img,
                                            contentType : (VTR.Utils.isset(d.Contents) ? d.Contents.Content[0].Products.Product[0].Type : 'CONTENT_TYPE')

                                        });
                                        
                                        countTitleCarrusel++;
                                    }
                                }
                            } 
                        });
                       
                   }
                     
                 }                 
                  //HD
                 else {
                     
                    $.each(data.Titles.Title, function(i,d){
                    
                        var img = null;
                        var pics = (VTR.Utils.isset(d.Pictures) ? d.Pictures.Picture : null);

                        if (pics){
                            $.each(pics, function(ix,dx) {
                                if(dx.type == 'BoxCover') {
                                    img = dx.Value.replace("http://" + VTR.Properties.posterServerName + "/", "http://" + VTR.Properties.posterServer + "/");
                                    return false;
                                }
                                else {
                                    img = dx.Value.replace("http://" + VTR.Properties.posterServerName + "/", "http://" + VTR.Properties.posterServer + "/");
                                }
                            });
                        }
                        if(VTR.Utils.isset(d.Contents)) {
                            if(VTR.Utils.isset(d.Contents)) {
                                if(VTR.Utils.isset(d.Contents.Content[0].Products)) {
                                    output.relatedrecom.push({
                                        categoryId : d.Categories,
                                        subcategoryId : 'SUB_CATEGORY_ID',
                                        titleId : d.id,
                                        name : ((VTR.Utils.isset(d.ShortName) ? d.ShortName : d.Name)),
                                        is3D : (VTR.Utils.isset(d.Contents) ? d.Contents.Content[0].Is3D : false),
                                        isHD : (VTR.Utils.isset(d.Contents) ? d.Contents.Content[0].IsHD : false),
                                        pictureUri : img,
                                        contentType : (VTR.Utils.isset(d.Contents) ? d.Contents.Content[0].Products.Product[0].Type : 'CONTENT_TYPE')
                                    });
                                }
                            }
                        }
                    });
                 
                }
                callback(output);
            }).fail(function(xhr, errorType, error){
                VTR.Utils.handleErrorFromTraxis(xhr.response);
                console.log('xhr:' + JSON.stringify(xhr.response) + ' - ' + 'error:' + error);
            }).done(function(data, status, xhr){
                console.log('data:' + data + ' - ' + 'status:' + status);
            });
        });
    }
    catch (err) {
        console.log('Error AVN API: '+err.message);
    }
}

