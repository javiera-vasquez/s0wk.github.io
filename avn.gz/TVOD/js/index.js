/*Added an array of videos*/
var keyboard;
var topMenu;
var cookie_get; //The cookie url object
var cookieList; //Cookie DOM list

document.addEventListener('DOMContentLoaded',function(){
    window.addEventListener('message', handleWebRemoteMessage);

    //Instantiate the global variables
    topMenu = document.getElementById('thumbStrip');
    keyboardHolder = document.getElementById('keyboardHolder');
    pauseDiv = document.getElementById('pauseDiv');
    allButtons = new Array();
    currentFocusNum = 0;
    largeVideoSource = "";
    isPlaying = false; //Used for the play/pausebutton
    cookie_get; //The cookie url object
    cookieList; //Cookie DOM list

function getRelativeValues(valueToFind){
    if(window.innerWidth >= 1280){
        if(valueToFind == "height"){
            return 500;
        }
        else if(valueToFind == "keySize"){
            return 64;
        }
        else if(valueToFind == "keyMod"){
            return 3;
        }
        else{
            return 330;
        }
    }
    else{
        if(valueToFind == "height"){
            return 500;
        }
        else if(valueToFind == "keySize"){
            return 64;
        }
        else if(valueToFind == "keyMod"){
            return 2;
        }
        else{
            return 320;
        }
    }
}

    //INIT
    var init = function(){
        av.require('storage.cookies');
        cookieList = document.getElementById("cookieList");
        createOneButton();

        var config = av.mergeObjects(
            av.keyboard.loadTemplate('text'),
            {
                height  : getRelativeValues("height"),
                width   : getRelativeValues("width"),
                keyHeight : getRelativeValues("keySize"),
                keyWidth : getRelativeValues("keySize"),
                holder  : 'keyboardHolder',
                target  : 'button0',
                navRight    : 'button0',
                'functions':{submit : setRecentSubmit,cancel: function(){
                    selectCookieList();
                }},
                panels : [
                 //Panel 1
                 {
                     name   : 'alpha',
                     shiftStates        : ["^shift","CAPS","lower"],
                     keys   : [
                                                {value:'a',isDefault:true},'b','c','d','e','f','g','h','i','j','k','l','m','n','ñ','o','p','q','r','s','t','u','v','w','x','y','z',
                                                {label:'ESPACIO',value:' ',width:(getRelativeValues("keySize")*2),keyClass:'medium',noShift:true},
                                                {label:'&#171;',uses:'backspace',width:(getRelativeValues("keySize")*1), keyClass:'medium'},
                                                '1','2','3','4','5','6','7','8','9','0',
                     ]
                 },
                ]
            }
            );
        keyboard = av.keyboard.create(config);
        keyboard.show();
        keyboard.focus();
        //keyboardHolder.focus();
        keyboard.addText("");
            createRecentList();
    }

    init();

}, true);

var createOneButton = function(){
    var fbutton = document.createElement('button');
    fbutton.id = 'button0';
    // fbutton.style.verticalAlign="bottom";
    // fbutton.style.top = "bottom";
    // fbutton.style.color = "#ffffff";
    // fbutton.style.textShadow = "2px 2px 1px black";
    fbutton = searchControl(fbutton);
    topMenu.appendChild(fbutton);
}

var setRecentSubmit = function(){
    setAsRecent(keyboard.getValue());
    window.open(keyboard.getValue());
    createRecentList();
}

var handleWebRemoteMessage = function(evt){
    var url = evt.data;
    if(typeof(url) == 'string' && url){
        url = url.indexOf('http') !== 0 ? 'http://' + url : url;
        console.log("Going to set to " + url)
        keyboard.setText(url);
        setRecentSubmit();
    }
}

$(window).ready(function() {
    $( ".AVB64x64" ).wrapInner( "<span class='box'></span>" );
    $( ".AVB128x64" ).wrapInner( "<span class='box'></span>" );
});
