/**
 * 
 */
//all this syntax does is attach a new instance of this to av, so that av.settings = this, and throughout the inner of hte function "av" is in a known scope
(function(av){
	av.require('dom');
	
	//defined as an annonymous function to ensure only 1 instance of settings is created
	var settings = function(){
		var self = this;
		
		self.version = '1.0.0';
		self.debug = true;
		self.fileName = 'settings.js';
		self.animate = av.getConfigValue('settings.animate',0);
		
		self.settingsMenu = {
				'General' : {
					'pairing'	: 'Web Remote',
					'navi'			: 'Navi',
				},
				'About' : {
					'about'			: 'About',
					'why'			: 'Why?',
					'check_out'		: 'Check it out!!!',
					//'about2'			: 'About',
					//'why2'			: 'Why?',
					//'check_out2'		: 'Check it out!!!',
				},
				'3rd Party' : {
					'facebook'		: 'Facebook',
				},
		}
		
		//var av.dom.get = function(id){return typeof(id) == 'string' ? self.doc.getElementById(id) : id;}
	
		//Would be nice to load from a cookie or some other setting!
		self.language = av.getConfigValue('av.language','en');
		
		self.helpers ={};
		
		
		self.languages = {
				en :{
						'LOADING_TEXT':'Loading...',
						'ERROR_LOADING':'Unable to load file for requested settings:'
				},
				es :{
					'LOADING_TEXT':'Cargando...',
					'ERROR_LOADING':'No se puede cargar el archivo de configuración solicitada:'
				}
		}
		
		self.lang = typeof(self.languages[self.language]) != 'undefined' ? self.languages[self.language] : self.languages['en'];
		
		self.menuItemHeightSD = 16;
		self.menuItemHeightHD = 16;
		
		self.path = '';
		self.parentFocus = '';
		
		self.defaultSettingsToShow = 'about';
		
		self.show = function(settingsToShow){
			self.language = av.getConfigValue('av.language','en');
			settingsToShow = typeof(settingsToShow) == 'undefined' ? self.defaultSettingsToShow : settingsToShow;
			av.log.debug('show() - settingsToShow = ' + settingsToShow);
			self.state = 'visible';
			//1. get elements by tagname "video", and for each that style.visibility == 'visible' or is 'undefined', get the current state.
				//pausing and/or hiding each
			av.dom.toggleVideos('off');
			//2. Take a screenshot, and WHEN we have the image, load that into a DIV called "_settings"
			av.log.debug("Width: " + av.width + " height="+av.height);
			var dataURL = window.hasOwnProperty('toDataURL') ? window.toDataURL ("image/jpeg", 0, 0, av.width, av.height) : '';
			
			//3. Show the "_settings" div on top of everything (z-index = 1000)
			var finishUp = function(){
				var settingsCss = av.themePath+"settings.css";
				av.log.debug('finishUp() - ' + settingsCss);
				av.html.loadCss(settingsCss);
				
				var outterStyle, container, 
					cssSuffix=av.ishd?'HD':'SD', 
					menuItemHeight = av.ishd ? self.menuItemHeightHD : self.menuItemHeightSD;
				var settingsElementToFocus='', firstMenuItem = '';
				
				//outterStyle = 'position:absolute; width: WIDTHpx; height:HEIGHTpx; left:LEFTpx; top:TOPpx; background-repeat:no-repeat;';
				//av.log.debug('Setting outterStyle=' + av.string.populateTemplate(outterStyle,{'WIDTH':self.width,'HEIGHT':self.height,'TOP':0,'LEFT':0}));
				
				
				//Full UI, with screenshot background of current window
				var ui = av.dom.create('div','AVSettingsUI','AVSettingsUI '+addSuffix('AVSettingsUI'), {'z-index':3000});
				ui.addEventListener('keydown', self.onkeydown,true);
				
	
				//Container within the UI that will hold the 	
				var bgImage = "url('"+av.themePath+"images/" + (av.issd ? 'sd' : 'hd') + (self.animate ? "-anim.png" : ".png") + "')";
				var container = av.dom.create('div','AVSettingsContainer',
									'AVSettingsContainer '+addSuffix('AVSettingsContainer'),
									{'background-image':bgImage}
							);
				var icontainer = av.dom.create('div','AVSettingsInnerContainer','AVSettingsContainer '+addSuffix('AVSettingsContainer'),{'visibility':(self.animate?'hidden':'visible'),'background-color':'transparent'});
				container.appendChild(icontainer);
				//LEFT menu
				var leftMenu = av.dom.create('div','AVSettingsLeftMenu','AVSettingsLeftMenu '+addSuffix('AVSettingsLeftMenu'));
				//leftMenu.appendChild(self.doc.createTextNode('I am the left menu'));
				
				//RIGHT side content area
				var contentArea = av.dom.create('div','AVSettingsContent','AVSettingsContent '+addSuffix('AVSettingsContent'));//document.createElement('div');
				var loadingText = av.dom.create('p','AVSettingsLoading','AVSettingsLoading',{top:0,left:0, width:'320px', height:'320px'})
					loadingText.innerHTML = self.lang.LOADING_TEXT;
				contentArea.appendChild(loadingText);
				
				
				icontainer.appendChild(contentArea);//put the contentArea in the inner container
				ui.appendChild(container);//put the container in the UI
				
				
						  //ui.setAttribute('style',	outterStyle + " background-position:0px 0px; z-index:0;")
						  
						  //@TODO this is currently NOT working, although it does work from within E:\avnetworks\perforce\AVApplications\AMG\_Examples\aved\screen_capture
						  //I have to assume that we WILL be able to get this going, so for now leave alone but know it needs attention
						  //ui.style.backgroundImage = "url("+dataURL+")";
						  av.log.debug('Set outter bg to: ' + dataURL);
					  
				
				//containerStyle = av.string.populateTemplate(outterStyle,{'WIDTH':av.dom.putOnGrid(self.width*.6),'HEIGHT':av.dom.putOnGrid(self.height*.6),'TOP':av.dom.putOnGrid(self.height*0.2),'LEFT':av.dom.putOnGrid(self.width*0.2)}) + ' background-color:red; opacity:0.6; z-index:0;'
				//av.log.debug('Container Style= '+containerStyle);
				//container.setAttribute('style',containerStyle);
						  
				
				
				//Generate the Left Menu
				var menuIndex = 0;
				var previousMenuItem = '';
				var previousMenuNode = '';
				for(var section in self.settingsMenu){
					var s = self.settingsMenu[section],
						sectionId = section.replace(/ /g,'_');
					
					//Put a <P> into place with the section title
					av.log.debug('sectionTitle='+section);
					var sectionTitle = av.dom.create('p','AVSettingsMenuItem'+sectionId,'AVSettingsLeftMenuItem  '+addSuffix('AVSettingsLeftMenuItem'),{'top':(menuIndex*menuItemHeight)+'px',})
						sectionTitle.innerHTML = section;
					
					menuIndex++;
					
					//Nest child items inside of a div that contains them all
					var childHolder = av.dom.create('div','AVSettingsLeftChildMenuHolder'+sectionId,'AVSettingsLeftChildMenuHolder  '+addSuffix('AVSettingsLeftChildMenuHolder'),{'top':(menuIndex*menuItemHeight)+'px',})
					var childIndex = 0;
					for(settingId in s){
						var settingTitle = s[settingId];
						var type = 'simple';//load HTML
						
						var onClick = '';
						if(typeof(settingTitle) != 'string'){
							
							onClick = settingTitle.click;
							settingTitle = settingTitle.title;
							
							type = 'function';//execute a given function on click instead of retrieving a settings page, currently just used to close() display
							//av.log.debug("close() - setting settingTitle.click to " + settingTitle)
							//av.log.debug(onClick);
							
						}
						
						var settingChildId = 'AVSettingsLeftChildMenuItem'+sectionId + settingId;
						
						av.log.debug('settingsTitle #'+childIndex+' = ' + settingTitle);
						var child = av.dom.create('p',settingChildId,'AVSettingsLeftChildMenuItem  '+addSuffix('AVSettingsLeftChildMenuItem'),{'top':(childIndex*menuItemHeight)+'px','nav-up':previousMenuItem!='' ? previousMenuItem : 'AVSettingsClose', height:menuItemHeight+'px'})
							child.innerHTML = settingTitle;
							child.addEventListener('focus',self.focusMenuItem, true);
							child.addEventListener('click',self.clickMenuItem, true);
							child.addEventListener('keydown',self.onChildKeyDown, true);
							
							av.dom.createRollover(child, av.themePath+"images/chaser.png", 'none', false)
							
							child.settingId = settingId;
							child.clickType = type;
							child.clickMethod = onClick;
						//Should we keep track of this one to focus on?
						if(settingId == settingsToShow) settingsElementToFocus = child;
						if(!firstMenuItem && onClick === ''){
							firstMenuItem = child;
						}
							
						//update that child's nav-down to me
						if(previousMenuItem != ''){
							previousMenuNode.style.navDown = settingChildId;
						}
						previousMenuItem = settingChildId;
						previousMenuNode = child;
						
						childIndex++;
						menuIndex++;
						childHolder.appendChild(child);
						//av.log.debug('Done with ' + settingTitle);
					}
					childHolder.style.height = (childIndex*menuItemHeight) + 'px';
					
					//Append the section title and child container to the left menu 
					av.log.debug("Adding to the left menu section title=\n" + sectionTitle.outerHTML + "\n\nand childHolder=\n"+childHolder.outerHTML);
					leftMenu.appendChild(sectionTitle);
					leftMenu.appendChild(childHolder);
					
					
				}
				
				var close = av.dom.create('img','AVSettingsClose','AVSettingsClose '+addSuffix('AVSettingsClose'),{'nav-down':'#'+firstMenuItem.id},false);	
				close.src = av.themePath+'images/btn_close_d.png';
				
				av.dom.createRollover(close, close.src.replace('_d.png','_f.png'), close.src, true)
				//av.dom.createRollover(close, av.path+"resources/images/chaser.png", 'none', false)
				
				close.addEventListener('click',function(evt){
					av.log.debug('Closing settings screen');
					self.close();
				},true)
				
				
				//YAY - this DOESN'T WORK!!!
				var settingsCSS = " .AVSettingsUI button{background-image:url('"+av.themePath+"images/btn_d.png'); }"
								+ " .AVSettingsUI button:focus{background-image:url('"+av.themePath+"images/btn_f.png');}"
								+ ".AVSettingsLeftMenuItem:focus, .AVSettingsLeftChildMenuItem:focus{background-image:url('"+av.themePath+"/images/chaser.png');}"								
				av.log.debug("Loading CSS: \n\n"+settingsCSS);	
				av.html.loadGlobalCss(settingsCSS);
				
				
				icontainer.appendChild(close);
				icontainer.appendChild(leftMenu);
					
				
				//Center content area
				
				av.log.debug("Settings: \n"+ui.outerHTML);
				
				av.doc.body.appendChild(ui);
				if(self.animate > 0){
					setTimeout(function(){
						av.dom.setStyle(container, {backgroundImage:container.style.backgroundImage.replace('-anim','')});
						av.dom.setStyle(icontainer, {visibility:'visible'})
						
					},self.animate)
				}
				//DEBUG styles derived from CSS
				//av.log.debug('Sizes of elements: AVSettingsContent ('+uneval(av.dom.get('AVSettingsContent').className)+') = '+av.dom.get('AVSettingsContent').style.width+'x'+av.dom.get('AVSettingsContent').style.height);
				
				//Focus on the default settings screen
				av.log.debug(settingsElementToFocus);
				if(settingsElementToFocus == ''){
					av.log.debug("Focusing whole UI in general: " + firstMenuItem);
					self.loadSetting(firstMenuItem.settingId);
					firstMenuItem.focus();
					
					//ui.focus();
					//document.getElementsByClassName('AVSettingsLeftChildMenuItem').item(0).focus();
				}else{
					av.log.debug("Focusing "+settingsElementToFocus.id)
					settingsElementToFocus.focus();
					self.loadSetting(settingsToShow);
					
					
					//Load the content for that item
					
				}
				//Delay so that the lightbox can be drawn in HD prior to having to populate the background image, allows for considerable
				//usability improvements in HD, and introduces only a slight flicker in SD
				if(av.ishd) setTimeout(function(){ui.style.backgroundImage = "url("+dataURL+")"},1);
				else ui.style.backgroundImage = "url("+dataURL+")";
				
				//av.log.debug('bgsetting');
				//ui.style.backgroundImage = "url("+dataURL+")";
			}
			
			//setTimeout(finishUp,25);
			finishUp();
			
		}
		
		self.close = function(){
			//var ui = av.dom.get('AVSettingsUI');
			self.reset();
		}
		
		self.clickMenuItem = function(evt){
			var settingId = typeof(evt) == 'string' ? evt : evt.currentTarget.settingId;
			self.currentSetting = evt.currentTarget;//clicking updates the global reference to "what setting is showing in the contentArea"
			
			if(typeof(evt) == 'string' || evt.currentTarget.clickType == 'simple'){
				av.log.debug("clickMenuItem() - simple menu item");
				self.loadSetting(settingId);
			}else{
				av.log.debug("clickMenuItem() - function based menu item");
				av.log.debug(evt.currentTarget);
				evt.currentTarget.clickMethod();
			}
		}
		
		self.focusMenuItem = function(evt){
			av.log.debug("Menu item focused: " + evt.currentTarget.id);
			self.currentItem = evt.currentTarget;//focusing updates the global reference to "what child setting menu item was last focused"
		}
		
		self.keypressMenuItem = function(evt){
			//focusMenu
		}
		
		self.onChildKeyDown = function(evt){
			//nothing for now
			if(evt.keyIdentifier == 'Right'){
				//focusSettings?
				if(typeof(self.curSetting.focus) == 'function'){
					av.log.debug("Focusing " + self.curSetting);
					self.curSetting.focus();
				}
			}
		}
	
		/**
		 * Completely remove ourselves from site, we're 100% gone in terms of DOM
		 */
		self.close = function(){
			self.state = 'hidden';
			av.dom.toggleVideos('on');
			
			var opnr = av.dom.get(self.parentFocus);
			av.log.debug(opnr instanceof HTMLElement);
			opnr.focus();
			
			self.reset();
		}
		
		self.onkeydown = function(evt){
			av.log.debug('keydown: ' + evt.keyCode);
			
			switch(evt.keyIdentifier){
				case 'Right':
					//self.focusSettings();
					break;
				default:
					//self.close();
					break;
			}
		}
		
		self.toggle = function(curFocusedElement, settingsToShow){
			av.log.debug('self.toggle('+curFocusedElement+')');
			self.setParentFocus(curFocusedElement);
			
			self[self.state == 'visible' ? 'close' : 'show'](settingsToShow);
		}
		
		self.setParentFocus = function(curFocusedElement){
			self.parentFocus = curFocusedElement;
		}
		
		self.takeScreenshot = function(left, top, width, heigh){
			left 	= typeof(left) == 'undefined' ? 0 : left;
			top 	= typeof(top) == 'undefined' ? 0 : top;
			width 	= typeof(width) == 'undefined' ? self.width : width;
			height 	= typeof(height) == 'undefined' ? self.height : height;
			
			av.log.debug('Screen capture left='+left+', top='+top+', width='+width+', height='+height);
			
			var dataURL = window.toDataURL ("image/jpeg", left, top, width, height);
			self.sendMessage('screenshot',dataURL);
		}
		
		
		
		self.focusMenu = function(){
			av.dom.get(self.currentItem).focus();
		}
		
		self.focusSettings = function(){
			//var cur = self.idPrefix + self.currentItem;
			self.types[self.currentItem].focus();//call the current settings object's 'focus()' method, let it do the focus
		}
		
		
		
		
		self.reattach = function(currentDocument){
			self.doc = currentDocument;
			
		}
		
		self.setLanguage = function(lang){
			self.language = lang;
		}
		
		/**
		 * Reset everything that is per-showing of the settings screen, global persistent values like language should remain...
		 */
		self.reset = function(){
			//av.require('dom');
			self.currentItem = '';
			self.currentSetting = '';
			
			self.types = {};
			
			self.state = 'hidden';
			var ui = av.dom.get('AVSettingsUI');
			if(ui !== null){
				av.doc.body.removeChild(ui);
				ui = null;
			}
			
			contentArea = null;//reference to the ui area that settings are presented in
			leftMenu = null;
			self.parentFocus = '';
			
			
			
			self.cssSuffix=av.sdhd;
			
			av.log.debug('Detected width='+self.width +' and height='+self.height);
		}
		
		var addSuffix = function(str){
			str = typeof(str) == 'undefined' ? '' : str;
			return str + self.cssSuffix;
		}
		
		self.showLoading = function(){
			
		}
		
		self.hideLoading = function(){
			
		}
		
		self.loadSetting = function(type){
			//(a) We've already loaded the JS that defines this settings screen
			av.log.debug("loadSetting("+type+")")
			
			var typesDebug = 'Existing Types: ';for(var currentType in self.types){typesDebug+=',settings.types.'+currentType+'.id='+self.types[currentType].id;}
			av.log.debug(typesDebug);
			av.log.debug(self.types);
			
			var loaded = false;
			if(!self.types.hasOwnProperty(type)){
				self.showLoading();
				var url = 'settings/' + type + '.settings';
				//Now create the script element asynchronouslly preferably, but sync will do if local file system and will reduce complexity
				//try{
				av.load(url);
				/*
				var scriptElement = self.doc.createElement('script');
					scriptElement.setAttribute('src',url);
					scriptElement.setAttribute ("type", "application/ecmascript");
					document.getElementsByTagName("head").item(0).appendChild(scriptElement);
				*/	
					loaded = true
				/*}catch(e){
					av.log.debug("ERROR! Could not load settings file: " + url);
				}*/
				
				//self.types[type] should exist now, so present it
				if(!loaded || !self.types[type]){
					var contentArea = av.dom.get('AVSettingsContent');
					//setTimeout(function(){av.log.debug(av.dom.get('AVSettingsContent'))},1000)
					contentArea.innerHTML = self.lang.ERROR_LOADING + "<br />" + type + '(' + url + ')';
					return false;
				}
			}
			self.curSetting = self.types[type];
			av.log.debug("Loaded " + type + ", calling self.types["+type+"].present(self.doc,"+self.language+");");
			var elem = self.types[type].present(self.doc,self.language, contentArea);
			self.present(elem);
			
			//contentArea.innerHTML = '';
			//contentArea.appendChild(settingsav.dom.create);
			return true;
			
		}
		
		self.present = function(domEl){
			
			
			av.log.debug('present() - showing ' + domEl.outerHTML +' returned by the settings')
			av.dom.replaceChildren('AVSettingsContent',domEl);
			
			/*
			var c = av.dom.get('AVSettingsPairingInstructions');
			if(c){
				av.log.debug('For some reason AVSettingsPairingInstructions still exists!!!');
			}
			*/
		}
		
		
		self.init = function(currentDocument){
			self.reattach(currentDocument);
			self.reset();
			
			
			//var foundPath = self.detectPath();
			
			//Attach the stylesheet for settings// <link href="../css/global.css" id="" rel="stylesheet" type="text/css"/> 
			//av.log.debug('Num CSS' + self.doc.getElementsByTagName('link')
			//av.log.debug('setting css');
			//var css = self.doc.createElement('link');
			/*
				av.log.debug('setting type');
				css.setAttribute('type',"text/css");
				av.log.debug('setting rel');
				css.setAttribute('rel', "stylesheet");
				av.log.debug('setting href');
				css.setAttribute('href',self.path + 'avsettings.css');
				
				av.log.debug('link: ' + css);
				
				document.getElementsByTagName("head").item(0).appendChild(css);
				*/
			
			//av.log.debug("Detected path? (" + (foundPath ? 'YES' : 'NO') + ') --> ' + self.path);
			
		}
		
		self.reset();
	
		return self;
	}
	av.extend(av,{'settings':new settings});//attach this to av.settings
})(av);
/*
if(typeof(window.settings) == 'undefined'){
	window.settings = new window._settings();
}

window.settings.init(document);

*/

//window.settings.loadSetting('avwebremote');
