/**
 * @author Chad Wagner (c.wagner@avnetworks.com)
 * @fileoverview avrsp2.js is the official "round 2" of integration with ActiveVideo's RSP web service
 * @version 1.0.20100316
 */
if(!av.exists('av.apis.RSP')){
	av.require('net','string');
	/**
	 * @class Provides an interface and methods to extract hierarchichal and asset details via the ActiveVideo RSP server API, usage: av.require('apis.RSP'); var rspObject = new av.apis.RSP('http://my.rsp.server/api','json','xzx-xxxxxxx-xxxx')
	 * @deprecated
	 * @private
	 * @param {String} sHost
	 * @param {String} [sFormat = json] JSON or XML, default = JSON
	 * @param {String} sApiKey self is the api-key that appears at the top of the Content Provider page in the RSP back office. Example: "94eb996f-39f4-41aa-bdd7-c44d69e90bbc"
	 * @param {String} [bEdgeNode = true] true/false. If a boolean is used, it will be converted to a string.
	 * @param {Number} iLogLevel 0 = debug, 1 = info, 2 = warn, 3 = error, 4 = fatal
	 * @param {Number} [maxTries = 1] because remote requests to RSP are made, if RSP returns a server error header other than 200, how many times should we re-attempt to load a request?
	 * @param {Object} <pre>defaults Contains all of the "defaults" that should be used when not present in individual function calls for sort order, pagination, etc, else empty string is used when absent.
	 * 				   possible keys within the object are:
	 * 					-cat (String - regular expression)
	 * 					-ni (Integer - max records to return)
	 * 					-offset (Integer - record to begin on),
	 * 					-ob (String - order by column, choose from:
	 *  					id
	 *						feed_id
	 *						guid
	 *						link
	 *						title
	 *						copyright
	 *						explicit
	 *						content
	 *						created_at
	 *						status
	 *						passthru
	 *						update_uuid
	 *						updated_parsed
	 *						published_parsed
	 *						content
	 *				   Note: the "config" object that is sent to RSP at instantiation is the same format as those used throughout. Use the config
	 *				   object on any call to pass parameters that should override defaults. Logic for later functions is: (a) if the currently executed
	 *				   function call contains a value for self option, use it. otherwise (b) if the instantiated config has it, use that, (c) otherwise
	 *				   remove the parameter from self call (or leave it blank)
	 * 				   example: {cat:"^saints",ni:20,ob:"updated_parsed",ot:"DESC"} </pre>
	 * @version 2.1
	 * @public
	 * @example av.require('apis.RSP'); 
	 * var rsp = new av.apis.RSP(
	 * 		'http://my.rsp.server/api', 
	 * 		'json',
	 * 		'94eb996f-39f4-41aa-bdd7-c44d69e90bbc',
	 * 		'true',
	 * 		0,
	 * 		{cat:"^saints",ni:20,ob:"updated_parsed",ot:"DESC"}
	 * 		  //means the default would be posts/feeds that start with
	 * 		  //"saints", 20 per page, ordered by the date they were
	 * 		  //published descending
	 * );
	 * @requires av.Net ({@link av.Net})
	 * @requires av ({@link av}) 
	 * @name av.apis.RSP
	 * @constructor
	 */
	
	/**
	 * @private
	 */
	var RSP = function(sHost, sFormat, sApiKey, iLogLevel, maxTries, async, defaults){
		/** @lends av.apis.RSP.prototype */
		var self = this;
		self._about = {
				version: '2.0.2010.03.01',
				author: 'Studio Development Team @ ActiveVideo Networks'
			};
	//INITIALIZATION	
		self._log        = new av.Log(av.getEffectiveLogLevel('apis.rsp'),'av.apis.rsp');
		self._numRequests = 0;
		self._analytics = {};
		self._currentAnalysis = '';
		self._requests = [];
		
		/**
		 * The external RSP urls. Urls are generally formatted with variables being inserted as "template" parameters. For example, when params.cat is set to "ted",
		 * then a URL that has [[cat]] in it will have [[cat]] replaced with "ted", other non-existent settings/parameters in the URL will be empty, so [[ni]], if params.ni = null,
		 * will be empty.
		 * Example: for the groups url, [[host]]/groups/list.[[format]]?, if self._settings={host:'http://rsp1/api',format:'json'}, then the url that gets hit for the data
		 * would be http://rsp1/api/groups/list.json?
		 * @private
		 */
		self._urls = {
			categories	: '[[host]]/feeds/list_cat.[[format]]?',//list all categoires
			groups 		: '[[host]]/groups/list.[[format]]?',//use "groups" to get an array of groups
			group		: '[[host]]/groups/show/[[id]].[[format]]?',//use "group" to get all feeds in a group
			feed		: '[[host]]/feeds/show_correct/[[id]].[[format]]?cat=[[cat]]&ni=[[ni]]&offset=[[offset]]&pb=[[ob]]',//use "feed" to get a feed with all posts in that feed
			listFeeds	: '[[host]]/feeds/list.[[format]]?',//(NOTE: does not retain the parent group id of each feed returned) 
															//use "listFeeds" to get an array of all feeds belonging to the content 
															//provider that your api-key refers to
			
		}
		
		/**
		 * self._settings
		 * @type (Object) Data sanitization of arguments and default settings
		 * @private
		 */
		self._settings = {
			'host' 		: arguments[0] != undefined && arguments[0] != null && arguments[0].toString() != '' ?  arguments[0].toString() : '',//default host = "" empty string
			'format' 	: arguments[1] != undefined && arguments[1] != null && arguments[1].toString() != '' ?  arguments[1].toString() : 'JSON',//default data type = "JSON"
			'apiKey' 	: arguments[2] != undefined && arguments[2] != null && arguments[2].toString() != '' ?  arguments[2].toString() : '',//default apiKey = "" empty string
			'edgeNode' 	: arguments[3] != undefined && arguments[3] != null && arguments[3].toString() != '' ?  arguments[3].toString() : 'true',// default "edgeNode" = "true"
			'logLevel' 	: arguments[4] != undefined && arguments[4] != null && !isNaN(parseInt(arguments[4])) ?  parseInt(arguments[4]) : 0,//default log level = 0
			'maxTries' 	: arguments[5] != undefined && arguments[5] != null && !isNaN(parseInt(arguments[5])) ?  parseInt(arguments[5]) : 1,//default maxTries = 1
			'async'	 	: arguments[6] != undefined && arguments[6] != null && arguments[6].toString() != '' ?  Boolean(arguments[6]) : true,// default "async" = true
			'defaults' 	: arguments[7] != undefined && arguments[7] != null && typeof(arguments[7]) == 'object' ?  arguments[7] : {},//default config is an empty object
		}
		
		self._headers    = { 'device-id':av.getClientId(), 'api-key':self._settings.apiKey, 'edge-node':self._settings.edgeNode };
		/**
		 * self._data
		 * @type (Object) when groups or feeds are received, in order to allow calls by ID later or to determine the context of a requested
		 * 				  feed, we store the minimal amount of data required to identify that feed... namely the "name/alias" and "id".
		 * 				  self is due to the current lack of RSP api functions for "get feed by alias" and "get group by name" - which is our
		 * 				  most common usage pattern of RSP to date.
		 * @private
		 */
		self._data = {'groups':{},'feeds':{}};
		
		/**
		 * Returns the version/author of the instantiated RSP object.
		 * @name av.apis.RSP.about
		 * @methodOf av.apis.RSP#
		 * @example console.log(uneval(window.rsp.about()));
		 * //output:
		 * {
		 *  version: '2.0.2010.03.01',
		 *  author: 'Studio Development Team @ ActiveVideo Networks'
		 * }
		 */
		self.about = function(){
			return self._about
		};
		
	//END INITIALIZATION	
	
	//PUBLIC METHODS ***************************************
		/**
		 * Get the current number of external API calls made to the RSP server - a count of the number of ASYC calls made so far.
		 * @name av.apis.RSP.count
		 * @methodOf av.apis.RSP#
		 * @return {Number}
		 * @example var cback = window.rsp.count.bind(window.rsp);
		 * window.rsp.getEverything(cback);//will show how many calls we made to the RSP API
		 * //15
		 * 
		 */
		self.count = function(){return self._numRequests;}
		
		/**
		 * Print information about the current content provider, including the API-KEY, host, and the data (Note: must have logLevel set to 0 to see output in cosole).
		 * @name av.apis.RSP.printHierarchy 
		 * @methodOf av.apis.RSP#
		 */
		self.printHierarchy = function(){
			self._log.debug({
				"API-KEY": self._settings.apiKey,
				"host": self._settings.host,
				"Current 'internal' hierarchy within RSP for content provider": self._data,
			});
		}
		
		//Helpers
		/**
		 * Helper - alias for calling getGroups(verbose=true,{ni:10000})
		 * @name av.apis.RSP.getEverything
		 * @methodOf av.apis.RSP#
		 * @param {Object} callback callback will be invoked as callback(data) with the entire RSP group/feeds/posts hiererarchy
		 * @example window.rsp.getEverything(window.goToFirstwindow.bind(window));
		 */
		self.getEverything = function(callback){return self.getGroups(callback, true, {'ni':10000});}
		
		/**
		 * Helper - alias for calling getGroups(verbose=true,{ni:0});
		 * @name av.apis.RSP.getEverythingButPosts
		 * @methodOf av.apis.RSP#
		 * @param {Function} callback will be invoked as callback(data) with the entire RSP group/feeds hiererarchy (less posts)
		 * @example window.rsp.getEverythingButPosts(window.goToFirstwindow.bind(window));
		 */
		self.getEverythingButPosts = function(callback){return self.getGroups(callback, true, {'ni':0});}
		
		/**
		 * Return the entire hierarchy = {feeds:'xxx',groups:'xxx'} that we have built up from any calls to self RSP content provider
		 * @name av.apis.RSP.getHierarchy
		 * @methodOf av.apis.RSP#
		 * @return {XMLHttp} a handle to the initial XMLHttp request to the api call for groups
		 * @example window.rsp.getEverythingButPosts(window.goToFirstwindow.bind(window));
		 * var h = window.rsp.getHierarchy();
		 * var debug = "There are currently " + h.feeds.length " feeds and " 
		 * 				+ h.groups.length + " groups in the hierarchy of RSP"
		 * console.log(debug);
		 */
		self.getHierarchy = function(){return self._data;}
		
		/**
		 * Return the "group" hierarchy that we have built up from any calls to self RSP content provider
		 * @name av.apis.RSP.getGroupHierarchy
		 * @methodOf av.apis.RSP#
		 * @return {Array}
		 * @example var callback = function(data){
		 * 	console.log("The full groups object with all fields and feeds is " + data);
		 * 	//print out the GROUP hierarchy
		 *  console.log("The stripped down groups object with title/id/feeds "
		 *  	  + window.rsp.getGroupHierarchy());
		 * }
		 * window.getGroups(callback);
		 */
		self.getGroupHierarchy = function(){return self._data.groups;}
		
		/**
		 * Return the "feed" hierarchy that we have built up from any calls to self RSP content provider
		 * @name av.apis.RSP.getFeedHierarchy
		 * @methodOf av.apis.RSP#
		 * @return {Array}
		 * @example var callback = function(data){
		 * 	console.log("The full groups object with all fields and feeds is " + data);
		 * 	//print out the FEED hierarchy
		 * 	console.log("The feeds extracted from it were: "
		 *  		+ window.rsp.getFeedHierarchy());
		 * }
		 * window.getGroups(callback);
		 */
		self.getFeedHierarchy = function(){return self._data.feeds;}
		
		
		/**
		 * Given the numeric ID of a feed located on the current RSP, assuming the current API-KEY has access to that feed, will build up the feed subject to the post requirements given in "params" and once it has it, will trigger callback(data); NOTE: Asynchronous method
		 * @name av.apis.RSP.getCategories
		 * @methodOf av.apis.RSP#
		 * @param {Number} id
		 * @param {Function} callback
		 * @param {Object} params
		 * @param {Boolean} context
		 * @example window.rsp.getFeedById(
		 * 	  3
		 * 	, function(data){console.log('received ' + data + 'back from rsp getFeedById(3)');}
		 * 	, {ni:10}//ni=10 means only 10 posts should be retrieved for self feed
		 * );
		 */
		self.getCategories = function(callback){
			self._trackFunction('RSP.getCategories',arguments);
			
			self._log.debug("RSP.getCategories() called");
			self._get(self._urls.categories, callback);
		}
		
		/**
		 * startAnalysis - begin an analysis of self and any future requests to the RSP server and keep them
		 * grouped under "namespace"
		 * @name av.apis.RSP.startAnalysis
		 * @methodOf av.apis.RSP#
		 * @param {String} namespace
		 * @return {Number} number of milliseconds since midnight of January 1, 1970 and the specified date - when self analysis was started.
		 * @example var cback = function(data){window.log.debug(window.rsp.getAnalysis('all groups'));};
		 * window.rsp.startAnalysis('all groups');
		 * window.rsp.getEverythingButPosts(cback);
		 */
		self.startAnalysis = function(namespace){
			self._log.debug("Beginning analysis on '"+namespace+"' ");
			self._analytics[namespace] = {
				start : (new Date()).getTime(),
				end : '',
				elapsed : '', 
				numRequests : 0,
				requests : {},
				functionCalls : [],
			}
			
			self._currentAnalysis = namespace;
			return self._analytics[namespace].start;
		}
		
		
		
		/**
		 * getAnalysis() - return the request/function trace analysis that we have built up during usage 
		 * under the the tracking id "namespace"
		 * @name av.apis.RSP.getAnalysis
		 * @methodOf av.apis.RSP#
		 * @param {Object} namespace
		 * @return {String}
		 * @return {Object}
		 * 
		 * @example var cback = function(data){window.log.debug(window.rsp.getAnalysis('all groups'));};
		 * window.rsp.startAnalysis('all groups');
		 * window.rsp.getEverythingButPosts(cback);
		 * 
		 * //output: when RSP triggers the callback, we'll see:
		 *  {
		 *  "requests": {
		 *    "http://avdev2.contentdevrsp.ictv.com/api/groups/list.json?": {
		 *    "start": 1268782802099,
		 *    "end": 1268782802208,
		 *    "elapsed": 109,
		 *    "response": "...trucated, would be full text"
		 *   }
		 * },
		 * "functionCalls": [
		 *  "1268782802099: RSP.getGroups( FUNCTION, false )",
		 *  "1268782802099: (internal/private method): RSP._get( '[[host]]/groups/list.[[format]]?', FUNCTION, OBJECT )",
		 *  "1268782802208: (internal/private method): RSP._passResponseThru( ARRAY[4], FUNCTION, 'http://...' )",
		 *  "1268782802224: (internal/private method): RSP._addData( ARRAY[4], FUNCTION )",
		 *  "1268782802224: (internal/private method): RSP._addGroupToHierarchy( '1', 'Olympics-Group', '' )",
		 *  "1268782802224: (internal/private method): RSP._addGroupToHierarchy( '2', 'Medals', '' )",
		 *  "1268782802224: (internal/private method): RSP._addGroupToHierarchy( '3', 'OlympicsVOD', '' )",
		 *  "1268782802224: (internal/private method): RSP._addGroupToHierarchy( '4', 'Olympics Photo', '' )"
		 * ],
		 * "start": 1268782802099,
		 * "end": 1268782802224,
		 * "elapsed": 125,//milliseconds
		 * "numRequests": 1
		 * }
		 */
		self.getAnalysis = function(namespace){
			namespace = Boolean(namespace) ? namespace : self._currentAnalysis;
			if(self._analytics[namespace]){
				self._analytics[namespace].end = (new Date()).getTime();
				self._analytics[namespace].elapsed = self._analytics[namespace].end - self._analytics[namespace].start;
				
				return self._analytics[namespace];
			}else{
				return "RSP.getAnalysis('" + namespace + "') - No analytics exist under the analytics id: '" + namespace + "'.";
			}
		}
		
		
		
		
		/**
		 * normalize() - Given data, self function will recurse through the object looking for all "attributes" objects and pull them up one level, removing
		 * them from the object at each level so that they remain on the same level as the rest of the data[key] values (NOTE!!! Normalizing data can take an additional 200-1000ms, with 500ms being the median, to accomplish - avoid usage in production!).
		 * 
		 * In self way, feeds[1].posts[i] can contain the title, updated_parsed, etc... that naturally comes back from RSP nested in the 
		 * data.attributes (where data =feeds[1].posts[i] and attributes = feeds[1].posts[i].attributes in self example)  
		 * @name av.apis.RSP.normalize
		 * @methodOf av.apis.RSP#
		 * @param {Object} data - data object/array to be normalized. all xxx.attributes.yyy will be moved up to xxx.yyy recursively
		 * @param {Object} attributes - recursive argument, do not send self argument when calling from externally
		 * @return {Array} if you send an Array as the argument, will return an Array
		 * @return {Object} if you send an Object as the argument, will return an Object
		 * @example var callback = function(data){
		 * 	console.log("The full groups object with all fields and feeds is " + data);
		 *  console.log("The normalized data has data.attributes.xxx moved " +
		 *  		"up to data.xxx");
		 *  console.log(window.rsp.normalize(data));
		 * }
		 * window.getGroups(callback);//non-verbose version of groups
		 */
		self.normalize = function(data,attributes,internal){
			self._trackFunction((internal ? "        (recursive) " : "") + 'RSP.normalize',arguments);
			if(attributes){
				for(key in attributes) data[key] = attributes[key];	
				delete(data.attributes);
				return;
			}
			
			if(typeof(data) == 'object' && data != null){
				for(key in data){
					if(key == 'attributes') self.normalize(data,data[key],true);//extract attributes
					else if(typeof(data[key]) == 'object') self.normalize(data[key],null,true);//look for attributes deeper in the object
				}
				return data;
			}else{
				return data;	
			}
		}
		
		
	//
		//BEGIN GROUPS ************************************* self.group(), self.getGroupById(), self.getGroupByName()
		
		/**
		 * getGroups() - get "groups" that belong to the content provider for self RSP instance
		 * @name av.apis.RSP.getGroups
		 * @methodOf av.apis.RSP#
		 * @param {Object} callback
		 * @param {Boolean} verbose - after retrieving groups, should we proceed to getting the feeds in each of the groups as well?
		 * @param {Object} params
		 * @return {XMLHttp}
		 * @example var callback = function(data){
		 * 	console.log("The full groups object with all fields and feeds is " + data);
		 * }
		 * window.getGroups(callback);//non-verbose version of groups
		 */
		self.getGroups = function(callback, verbose, params){
			self._trackFunction('RSP.getGroups',arguments);
			verbose = Boolean(verbose);
			params = Boolean(params) ? params : {};
			
			var cbackAfterAddDataToHierarchy = verbose ? self.getEachGroupInGroups.bind(self,callback,verbose,params, null, null) : callback;
			var cback = self._addData.bind(self,cbackAfterAddDataToHierarchy, null);
			
			
			return self._get(self._urls.groups, cback, params);
		}
		
		
		
		/**
		 * getEachGroupInGroups() - given a valid "groups" object, iterate over each and get the feeds for that group, grabbing posts as well if "verbose" is true
		 * @name av.apis.RSP.getEachGroupInGroups 
		 * @methodOf av.apis.RSP#
		 * @param {Object} callback
		 * @param {Boolean} verbose - should we grab posts for each of the feeds in the groups obtained?
		 * @param {Object} params
		 * @param {Object} context - private argument used to notify the function when executed in "context" as a callback to another internal function call
		 * @param {Object} groups - can be an array of groups that is normalized or not, we account for locating the id of each group in the attributes or normalized top level id's in each array element
		 * @example 
		 * //upon getting the groups back, go get each group WITH it's feeds,
		 * //and print it out when done
		 * var cback = window.rsp.getEachGroupInGroups(
		 * 					window.rsp,
		 * 					[function(groups){console.log(groups);},false]
		 * );
		 * 
		 * window.rsp.getGroups(cback, false);
		 * 
		 */
		self.getEachGroupInGroups = function(callback,verbose,params,context, groups){
			self._trackFunction('RSP.getEachGroupInGroups',arguments);
			if (!groups) {
				self._log.warn("RSP.getEachGroupInGroups(groups,callback="+typeof(callback)+", verbose="+verbose+", params="+uneval(params)+", context="+context+") - 'groups' object received contains no data, no groups to iterate over. Ensure getEachGroupInGroups(groups,...) has a non-zero length array of groups as the first argument.");
				callback(groups);
			}
			context = Boolean(context);
			params = Boolean(params) ? params : {};
			//The following 4 lines are for efficiency. If the requested params want 0 posts, or it's null and the defaults are 0, skip getting posts
			
			self._log.debug("RSP.getEachGroupInGroups(groups,callback="+typeof(callback)+", verbose="+verbose+", params="+uneval(params)+", context="+context+") - Adding " + groups.length + " groups.")
			
			self._log.debug("getEachGroupInGroups() - groups object as sent to getEachGroupInGroups(): "+groups)
			self._log.debug({"getEachGroupInGroups() - params object as sent to getEachGroupInGroups()":params})
	
			if (groups.length) {
				for (var i = 0; i < groups.length; i++) {
					//each time that a group is finished being built, the _buildObjectReturnIfReady(...) function will be used as a callback,
					//which when "groups.length" groups have finished populating, will call the "callback" function
					var grabEachGroupCallback = self._buildObjectReturnIfReady.bind(self,groups, null, groups.length, i, callback);
					var addDataToHierarchyFirst = self._addData.bind(self,grabEachGroupCallback, null);
					var id = groups[i].id ? groups[i] : groups[i].attributes.id;
					self.getGroupById(id, addDataToHierarchyFirst, verbose, params);
				}
			}else{
				callback(group);
			}
			
		}
		
		
		
		/**
		 * Given either an id or name of a group, will grab from RSP the feeds in that group (no post data unless verbose = true), and send it to the callback
		 * @name av.apis.RSP.getGroup
		 * @methodOf av.apis.RSP#
		 * @param {Number, String} idOrName
		 * @param {Function} callback
		 * @param {Boolean} verbose
		 * @param {Object} params
		 * @return {XMLHttp}
		 * @example callback = function(ads){
		 * 	var i=0;
		 * 	for(ad in ads.feeds[0].posts){
		 * 		populateAd(i, ad);
		 * 		console.log("Got ad #" + i + ": " + ad.attributes.title);
		 *		i++;
		 * 	}
		 * }
		 * 
		 * window.rsp.getGroup("Olympics Ads", callback, true)
		 */
		self.getGroup = function(idOrName, callback, verbose, params){
			self._trackFunction('RSP.getGroup',arguments);
			self._log.debug("RSP.getGroup('"+idOrName+"')...");
			
			verbose = Boolean(verbose);
			var parsed = parseInt(idOrName);
			var group = self._getGroup(idOrName);
			//do we already know about self group hierarchy based on previous calls?
			if (group) {
				return self.getGroupById(group.id, callback, verbose, params);
			//no... so is it a group "id" or "name" we are after?	
			}else if(!isNaN(parsed) && parsed.toString() == idOrName.toString() && parsed > 0 ){
				return self.getGroupById(parsed, callback, verbose, params);
			//ok, OK!... we'll get it by name, geesh!.	
			}else{
				return self.getGroupByName(idOrName, callback, verbose, params)
			}
			
		}
		
		
		
		/**
		 * Given either an id of a group, will grab from RSP the feeds in that group (no post data unless verbose = true), and send it to the callback
		 * @name av.apis.RSP.getGroupById
		 * @methodOf av.apis.RSP#
		 * @param {Number} id
		 * @param {Function} callback
		 * @param {Boolean} verbose
		 * @param {Object} params
		 * @param {Boolean} context - private argument used to notify the function when executed in "context" as a callback to another internal function call
		 * @return {XMLHttp}
		 * @example callback = function(ads){
		 * 	var i=0;
		 * 	for(ad in ads.feeds[0].posts){
		 * 		populateAd(i, ad);
		 * 		console.log("Got ad #" + i + ": " + ad.attributes.title);
		 *		i++;
		 * 	}
		 * }
		 * //assume we know that we are interested in the group with id=3
		 * window.rsp.getGroupById(3, callback, true)
		 */
		self.getGroupById = function(id, callback, verbose, params, context){
			self._trackFunction('RSP.getGroupById',arguments);
			
			context = Boolean(context);
			verbose = Boolean(verbose);
			params = params ? params : {};
			
			self._log.debug("RSP.getGroupById(id="+id+", callback="+typeof(callback)+", verbose="+verbose+", params="+uneval(params)+", context="+context+") called");
			
			var group = self._getGroup(id);
			
			//var key = self._data._groups[id];
			var cback = self._addData.bind(self,callback, id);//extract any hierarchical information and send the callback the response
			
			//Verbose and already know feed ids for self group?
			if (verbose && group && (group.feeds.length || context)) {
				self._log.debug("RSP.getGroupById(id="+id+",...) - have group, going to tet feeds (not implemented)");
				var grabEachFeedCallback = self._buildObjectReturnIfReady.bind(self,group, 'feeds', group.feeds.length, callback)
				
			//verbose but first need the ids of feeds in self group?
			}else if (verbose && !context) {
				var cback = self.getFeedsInGroup.bind(self,id,callback,verbose,params, true);//we want only bound arguments
				var addGroupCallback = self._addData.bind(self,cback,id);
				params.id = id;
				self._get(self._urls.group, addGroupCallback, params);
			//they just want group info, and we already have the title... doesn't matter, they want the full group info, which they must not have yet
			}else if(group){
				
				callback(group);
			//they just want group info, but we need to grab that group first... let's just grab all groups, then return the one they want	
			}else if(!context){
				params.id = id;
				self._get(self._urls.group, cback, params);
			}else{
				self._log.warn("getGroupById("+id+",...) - no group with self id found");
				callback({});//no group found
			}	
		}
		
		
		
		/**
		 * Given either an name of a group, will grab from RSP the feeds in that group (no post data unless verbose = true), and send it to the callback
		 * @name av.apis.RSP.getFeedsInGroup
		 * @methodOf av.apis.RSP#
		 * @param {Object} group
		 * @param {Number} id
		 * @param {Function} callback
		 * @param {Boolean} verbose
		 * @param {Object} params
		 * @param {Boolean} context - private argument used to notify the function when executed in "context" as a callback to another internal function call
		 * @return {XMLHttp}
		 */
		self.getFeedsInGroup = function(id,callback,verbose,params,context, group){
			self._trackFunction('RSP.getFeedsInGroup',arguments);
			if (!group || !group.feeds || !group.feeds.length) {
				self._log.debug("RSP.getFeedsInGroup() - 'group' object received contains no data, no group.feeds to iterate over. Ensure getFeedsInGroup(group,...) has a non-zero length array of feeds within it, and is sent as the first argument.");
				callback(group);
			}
			context = Boolean(context);
			params = Boolean(params) ? params : {};
			//The following 4 lines are for efficiency. If the requested params want 0 posts, or it's null and the defaults are 0, skip getting posts
			var numPosts = (params.ni != undefined && params.ni != null) ? params.ni : null;
			var defaults = self._settings.defaults;
			var numPostsDefault = (defaults.ni != undefined && defaults.ni != null) ? defaults.ni : null;
			self._log.debug("RSP.getFeedsInGroup() - Adding " + group.feeds.length + " feeds.")
			
			//self._log.debug({"feeds in getFeedsInGroup()":group})
			//IF STATMENT EXPLANATION: we want to let params.ni override defaults.ni, but when (see (2) below) params.ni is null and defaults.ni is 0, we can skip
			//if (1) there are no feeds, and  
			//(2) either params specified numPosts > 0 --OR-- params didn't specify number and defaults are not zero
			if (group.feeds.length && (numPosts > 0 || (numPosts == null && numPostsDefault!=0))) {//if params.ni is empty or non-zero, then numPosts will be non-zero. Otherwise they don't need the posts
				for (var i = 0; i < group.feeds.length; i++) {
					var grabEachFeedCallback = self._buildObjectReturnIfReady.bind(self,group, 'feeds', group.feeds.length, i, callback);
					var addEachFeedToHierarchyFirst = self._addData.bind(self,grabEachFeedCallback, null);
					self.getFeedById(group.feeds[i].attributes.id, addEachFeedToHierarchyFirst, params);
				}
			}else{
				self._log.info("RSP.getFeedsInGroup() - No feeds in group with id " + id + ", returning group WITH empty feeds.");
				callback(group);
			}
			
		}
		
		
		
		/**
		 * RSP.getGroupByName()
		 * @name av.apis.RSP.getGroupByName
		 * @methodOf av.apis.RSP#
		 * @param {String} name
		 * @param {Function} callback
		 * @param {Boolean} verbose
		 * @param {Object} params
		 * @param {Boolean} context
		 * @example callback = function(ads){
		 * 	var i=0;
		 * 	for(ad in ads.feeds[0].posts){
		 * 		populateAd(i, ad);
		 * 		console.log("Got ad #" + i + ": " + ad.attributes.title);
		 *		i++;
		 * 	}
		 * }
		 * 
		 * window.rsp.getGroupByName("Olympics Ads", callback, true)
		 * //same as window.rsp.getGroup("Olympics Ads", callback, true)
		 */
		self.getGroupByName = function(name, callback, verbose, params, context){
			self._trackFunction('RSP.getGroupByName',arguments);
			self._log.debug("RSP.getGroupByName('"+name+"')..."+uneval(params));
			verbose = Boolean(verbose);
			context = Boolean(context);
			
			var group = self._getGroup(name);
			
			//1. Do we know self group's id? If so, pass off (id,callback) to the getGroupById() function
			if(group && verbose){
				return self.getGroupById(group.id, callback, verbose, params);
			}else if(group){
				callback(group);
			//2. We don't have the group's id, so as long as we are not being executed as a callback to ourselves (indicated when 3rd argument "context" is not null)	
			}else if(!context){
				var cback = (function(){self.getGroupByName(name,callback,verbose,params, true);}).bind(self);//we want only bound arguments
				return self.getGroups(cback);
			//execute the callback with an empty string... sorry - but (1) no valid response, and (2) context indicates there is no group with self name even after all groups were grabbed from RSP	
			}else{
				self._log.warn("self.getGroupByName(name='"+name+"',...) - unable to find matching group by self name in RSP.");
				callback(group);
			}
		}
		
		
		
		//END GROUPS **************************************
	//	
		//BEGIN FEEDS ************************************* self.getFeed(), self.getFeedById(), self.getFeedByName()
		
		/**
		 * Given the numeric ID OR NAME of a feed located on the current RSP, assuming the current API-KEY has access to that feed, will build up the feed subject to the post requirements given in "params" and once it has it, will trigger callback(data); NOTE: Asynchronous method
		 * @name av.apis.RSP.getFeed
		 * @methodOf av.apis.RSP#
		 * @param {String} idOrName
		 * @param {Function} callback
		 * @param {Object} params
		 * 
		 */
		self.getFeed = function(idOrName, callback, params){
			self._trackFunction('RSP.getFeed',arguments);
			self._log.debug("RSP.getFeed(idOrName='"+idOrName+"')...");
			
			params = params ? params : {};
					
			var parsed = parseInt(idOrName);
			var feed = self._getFeed(idOrName);
			
			if (feed) {
				return self.getFeedById(feed.id, callback, params);
			//no... so is it a group "id" or "name" we are after?	
			}else if(!isNaN(parsed) && parsed.toString() == idOrName.toString() && parsed > 0 ){
				return self.getFeedById(parsed, callback, params);
			//ok, OK!... we'll get it by name, geesh!.	
			}else{
				return self.getFeedByName(idOrName, callback, params)
			}	
			
	
		}
		
		
		
		/**
		 * Given the numeric ID of a feed located on the current RSP, assuming the current API-KEY has access to that feed, will build up the feed subject to the post requirements given in "params" and once it has it, will trigger callback(data); NOTE: Asynchronous method
		 * @name av.apis.RSP.getFeedById
		 * @methodOf av.apis.RSP#
		 * @param {Number} id
		 * @param {Function} callback
		 * @param {Object} params
		 * @param {Boolean} context
		 * @example window.rsp.getFeedById(
		 * 	  3
		 * 	, function(data){console.log('received ' + data + 'back from rsp getFeedById(3)');}
		 * 	, {ni:10}//ni=10 means only 10 posts should be retrieved for self feed
		 * );
		 */
		self.getFeedById = function(id, callback, params, context){
			self._trackFunction('RSP.getFeedById',arguments);
			params = params ? params : {};
			params.id = id;
			
			self._log.debug("RSP.getFeedById(id=" + id+",...) called");
			self._get(self._urls.feed, callback, params);
		}
		
		/**
		 * Given the name of a feed, self function will build up the feed subject to the post requirements given in "params" and once it has it, will trigger callback(data). NOTE: Asynchronous method
		 * @name av.apis.RSP.getFeedByName
		 * @methodOf av.apis.RSP#
		 * @param {String} name
		 * @param {Function} callback
		 * @param {Object} params
		 * @param {Boolean} context - private argument used to notify the function when executed in "context" as a callback to another internal function call
		 * @example var callback = function(data, feedTitle){
		 * 	console.log("Got data back for the feed with title: " + feedTitle);
		 * 	console.log(data);		
		 * }
		 * window.rsp.getFeedByName("Superbowl News Highlights",
		 * 		callback.bind(root,"SB H-lites"),
		 * 		{ni:10},//just get the last 10 news items
		 * );
		 */
		self.getFeedByName = function(name, callback, params, context){
			self._trackFunction('RSP.getFeedByName',arguments);
			self._log.debug("RSP.getFeedByName(name='"+name+"',callback="+typeof(callback)+",params="+uneval(params)+")");
			
			context = Boolean(context);
			
			var feed = self._getFeed(name);
			
			//1. Do we know self feed's id? If so, pass off (id,callback) to the getFeedById() function
			if(feed){
				return self.getFeedById(feed.id, callback, params, true);
			//2. We don't have the feed's id, so as long as we are not being executed as a callback to ourselves (indicated when 4rd argument "context" is not null)	
			}else if(!context){
				var cback = (function(){self.getFeedByName(name,callback,params, true);}).bind(self);//we want only bound arguments
				return self.getAllFeeds(cback, false);
			//execute the callback with an empty string... sorry - but (1) no valid response, and (2) context indicates there is no group with self name even after all groups were grabbed from RSP	
			}else{
				self._log.warn("self.getFeedByName(name='"+name+"',...) - unable to find matching group by self name in RSP.");
				callback(feed);
			}
		}
		
		/**
		 * Get all feeds in the current content provider, and optionally some or all of the posts per feed.
		 * @name av.apis.RSP.getAllFeeds
		 * @methodOf av.apis.RSP#
		 * @param {Function} callback
		 * @param {Boolean} verbose
		 * @param {Object} params
		 * @param {Boolean} context (private)
		 * @param {Object} feeds - (private) internal argument used when verbosity = true in a callee so that we can iterate over it and build it up with nested data objects from RSP like posts
		 * @return {XMLHttp} Handle to the outbound RSP API request
		 * @example var cback = window.log.debug.bind(window.log);
		 * console.log("Going to get all feeds, when they're in you'll see them logged");
		 * 
		 * //call #1, just feeds, no posts
		 * window.rsp.getAllFeeds(cback,false);
		 * 
		 * //call #2, feeds plus the first 2 posts in each matching the "news" category
		 * window.rsp.getAllFeeds(cback,true,{ni:2,cat:'news'});
		 * 
		 * //output: you would see 2 arrays come back, 1 with just feed info, 
		 * //and 1 that had AT MOST 2 posts per feed matching the params
		 */
		self.getAllFeeds = function(callback, verbose, params, context, feeds){//feeds at the end here so that we (if needed in callback) can determine if we were successfule
			self._trackFunction('RSP.getAllFeeds',arguments);
			params = params ? params : {};
			verbose = Boolean(verbose);
			context = Boolean(context);
			
			//1. Get all feeds and then come back here and iterate over the feeds
			if(verbose && !context){
				var cback = (function(data){data = data ? data : []; self._log.debug({"data for all feeds":data}); self.getAllFeeds(callback,verbose,params,true, data);}).bind(self);//we want only bound arguments
				return self._get(self._urls.listFeeds, cback);
				
			//2. Get all feeds and then stop, no verbosity requested	
			}else if(!verbose && !context){
				var cback = self._addData.bind(self,callback, null);//add the data to our hierarchy and then continue on!
				return self._get(self._urls.listFeeds, cback);
			//3. We have the feeds, now verify that we have valid feeds and if so update the hierarchy, and then go get each feed's data
			}else if(verbose && context){
				self._log.debug("RSP.getAllFeeds() - executed for a second time, and verbosity requested. Will attempt to get each feed now...");
				if(feeds && feeds.length){
					self._addData(feeds);
					
					//3.a. - if they want all feeds with verbosity on, but requested params.ni explicitlty to be zero, we stop here
					if(params.ni != undefined && params.ni != null && params.ni == 0){
						callback(feeds);
						return feeds;
					}
					//3.b. get the feed with posts if thye requested verbosity true
					for(var i=0; i<feeds.length; i++){
						self._addFeedToHierarchy(feeds[i].attributes.id, feeds[i].attributes.title);//[groups, null, groups.length, i, callback]
						var cbackToAddFeedToFeedsArrayAndReturnIfReady = self._buildObjectReturnIfReady.bind(self,feeds, null, feeds.length, i, callback);
						self.getFeedById(feeds[i].attributes.id, cbackToAddFeedToFeedsArrayAndReturnIfReady, params, true);//adding context = true since internal callback
					}
				}else{
					self._log.warn("RSP.getAllFeeds() - NO FEEDS returned from RSP, ensure that your rsp api url and api-key are correct.");
					callback([]);//return an empty array, sorry... no feeds returned, just an empty array... what more can we do eh? - Nothing!!! :(
				}
			//4. We are being executed IN CONTEXT, but no verbosity requested... we either DO or DO NOT have valid feeds, either way... callback will be executed	
			}else{
				
				callback(feeds ? feeds : []);	
				return true;
			}
			
		}
	
		//END FEEDS ***************************************
	//
	
		
	//END PUBLIC METHODS **********************************
	//PRIVATE METHODS, Helpers
		/**
		 * init() - not used, place holder for reset/etc functionality
		 * @private
		 */	
		self.init = function(){
			
		}
		
		/**
		 * @param {Function} callback
		 * @param {Number} parentId
		 * @param {Object} data Either a group or feed. Will extract the title and store it to the right place within the cp/groups/feeds/posts hierarchy
		 * 				   since we know RSP does not currently support API methods for getting feeds/groups by alias/name
		 */
		self._addData = function(callback, parentId, data){
			self._trackFunction('RSP._addData',arguments);
			if(parentId == null || parentId == undefined) parentId = '';
			
			self._log.debug({'function call to':'RSP._addData(data='+typeof(data)+',callback='+typeof(callback)+', parentId='+parentId+')',arguments:arguments});
			
			//1. Did we get a valid response
			if(data != null && data != undefined && typeof(data) == 'object'){//typeof(null) == 'object', so extra careful here :)
				var atts = data.attributes != null && data.attributes != undefined ? data.attributes : {title:'', id:0};
				//2. Now determine "what" type of data is contained inside of "data"... is it a feed, a group, or an array of feeds, an array of groups
				//is it a feed?
				if(data.totalposts != null && data.totalposts != undefined){
					//feeds are not stored if they are the direct result of a call to get posts, because they do not retain group information
				//is it a group	
				}else if(data.feeds){
					self._addGroupToHierarchy(data.attributes.id, data.attributes.name, data.attributes.description);//add group
					for(var i=0; i<data.feeds.length; i++) self._addFeedToHierarchy(data.feeds[i].attributes.id, data.feeds[i].attributes.title, data.attributes.id);//add each feed
				//is it an array of groups or feeds?	
				}else if(data.length){
					for(var i=0; i<data.length; i++){
						//if each element has a feed_url ==> feed
						if(data[i].attributes.feed_url){
							self._addFeedToHierarchy(data[i].attributes.id, data[i].attributes.title, parentId);
						//else ==> group	
						}else{
							self._addGroupToHierarchy(data[i].attributes.id, data[i].attributes.name, data[i].attributes.description);
						}
						
					}
				}else{
					self._log.warn("Internal RSP library problem - could not identify the type of data received by _addData");
				}
			}else{
				self._log.warn('RSP._addData(data='+typeof(data)+', callback='+typeof(callback)+', parentId='+parentId+') - called with no data in first argument!');
			}
			
			if(typeof(callback) == 'function') callback(data);
			else self._log.debug("RSP._addData - NO CALLBACK RECEIVED, function execution complete.");
		}
		
		/**
		 * 
		 * @param {Number} id
		 * @param {String} title
		 * @param {Number} groupId - optional
		 */
		self._addFeedToHierarchy = function(id,title,groupId){
			self._trackFunction('RSP._addFeedToHierarchy',arguments);
			//in the instance where we've previouslly determined the group's id, don't let subsequent calls to getFeedById() override our group ID with NULL
			var feed = self._getFeed(id);
			if(feed && feed.groupId && !groupId) groupId = feed.groupId;
			
			self._data.feeds[id] 	= {id:id, title:title,groupId:groupId};
			
			//if we are executing in the context of having awareness of our group id for self feed, insert a reference to it for hierarchal reduction of future callse
			if(groupId && self._data.groups[groupId]){
				self._data.groups[groupId].feeds.push({id:id, title : title});
			}
		}
		
		/**
		 * 
		 * @param {Number} id
		 * @param {String} title
		 * @param {String} description
		 */
		self._addGroupToHierarchy = function(id,title,description){
			self._trackFunction('RSP._addGroupToHierarchy',arguments);
			self._data.groups[id] = {id:id,name:title,description:description,feeds:[]};//reset group's feeds
		}
		
		/**
		 * 
		 * @param {String} idOrName
		 */
		self._getGroup = function(idOrName){
			self._trackFunction('RSP._getGroup',arguments);
			var id = '';
			if(isNaN(parseInt(idOrName)) || parseInt(idOrName).toString() != idOrName.toString()) {
				for(var gid in self._data.groups){
					if(self._data.groups[gid].name == idOrName){
						id = gid;
						break;
					}
				}
			}else id = idOrName;
			if(id && self._data.groups[id]) return self._data.groups[id];
			else return '';
		}
		
		/**
		 * 
		 * @param {String} idOrName
		 */
		self._getFeed = function(idOrName){
			self._trackFunction('RSP._getFeed',arguments);
			var parsed = parseInt(idOrName);
			if(isNaN(parsed) || parsed.toString() != idOrName.toString()) {
				for(var fid in self._data.feeds){
					if(self._data.feeds[fid].title == idOrName){
						return self._data.feeds[fid];
					}
				}
				return 0;//we haven't loaded any info about self feed yet
			}else if(self._data.feeds[parsed]){
				return self._data.feeds[parsed];
			}else{
				return false;
			}
			
		}
		
		/**
		 * 
		 * 
		 * @param {Object} toReturn
		 * @param {String} key use "" or null if you do not have an object with an array for the data (i.e. just iterating over an array at the top level)
		 * @param {Number} totalResponses
		 * @param {Number} index
		 * @param {Function} callback
		 * @param {Object} data
		 */
		self._buildObjectReturnIfReady = function(toReturn, key, totalResponses, index, callback, data){
			self._trackFunction('RSP._buildObjectReturnIfReady',arguments);
			//self._log.debug({"feeds currently":toReturn[key]})
			
			key = Boolean(key) ? key : '';
			self._log.debug({'RSP._buildObjectReturnIfReady()...':'','arguments to _buildObjectReturnIfReady()': {data:typeof(data),toReturn:typeof(toReturn),'key':key,totalResponses:totalResponses,index:index,callback:typeof(callback)}})
					
			//If the array we are building up is nested as an array within an object, update the data at toReturn[key][index]... otherwise, treat toReturn as an array and insert data at toReturn[index]
			if (key) {
				/*
				if(!toReturn || !toReturn[key]){//callback even on 404's from RSP
								window.log.debug("_buildObjectReturnIfReady(data,toReturn,key='"+key+"',totalResponses="+totalResponses+", index="+index+") - either the toReturn object is invalid or nothing exists in toReturn['"+key+"'], returning as is...");
								callback(toReturn ? toReturn : {});
							}
				*/
				toReturn[key][index] = data;
			}else {
				/*
				if(!toReturn){//callback even on 404's from RSP
								window.log.debug("_buildObjectReturnIfReady(data,toReturn,key='"+key+"',totalResponses="+totalResponses+", index="+index+") - either the toReturn object is invalid or nothing exists in toReturn['"+key+"'], returning as is...");
								callback(toReturn ? toReturn : {});
							}
				*/
				toReturn[index] = data;
			}
			
			
			//determine how many we have found
			if(!Boolean(toReturn._found)) toReturn._found = 1;
			else toReturn._found++;
				
			if(toReturn._found == totalResponses){
				self._log.debug("RSP.buildObjectReturnIfReady() - internal method called and we now have " + totalResponses + " responses, which is how many we were interested in. Invoking the callback function.");
				delete toReturn._found;//self was used to keep track of progress, do not return in results
				callback(toReturn);
			}else{
				self._log.debug("RSP.buildObjectReturnIfReady() - internal method called and we now have " + toReturn._found + " of " + totalResponses + " responses... waiting for more.");
			}
		}
		
		/**
		 * 
		 * @param {Object} url
		 * @param {Object} callback
		 * @param {Object} params object of the format {'key':'val','key2':'val2'} that will override any default replacements in the 'url'
		 */
		self._get = function(url, callback, params){
			self._trackFunction('RSP._get',arguments);
			if(params == null || params == undefined) params = {};
			//Build up the replacements, starting with the defaults, then the explicit params so that they override any default replacements
			var replacements = {};
			//copy each value to avoid overriding actual self._settings object values which hold defaults for all calls to RSP
			for(var key in self._settings) replacements[key] = self._settings[key];
			for(var key in params) replacements[key] = params[key];
			
			//build the URL starting with the syntax from self._urls (where [[xxx]] represents a replacements[xxx] value will be used for [[xxx]] in the string)
			var fullUrl = av.string.populateTemplate(url,replacements);
			self._numRequests++;
			
			var cback = self._passResponseThru.bind(self,callback, fullUrl);
			
			self._trackRequest(fullUrl);
			if (self._settings.async) {//(url, callback, method, params, options)
				var xmlHttpObject = av.net.makeRequest(fullUrl, cback, 'GET', '', {headers:self._headers, evalJSON : true,});
				self._log.debug("RSP._get() - Request began to RSP URL (async): " + fullUrl);
				return xmlHttpObject;
			}else{
				//@TODO update so that self receives the JSON response and calls the callback, SYNCHRONOUSLLY
				var response = av.net.makeRequest(fullUrl, null, 'GET', '', {headers: self._headers, evalJSON : true,});
				self._log.debug("RSP._get() - Request began to RSP URL (sync): " + fullUrl);
				return callback(response);//call the callback method. If it is internal
			}
			
			
		}
		
		/**
		 * Used as a callback to all RSP API calls to intercept data return from XMLHttp.onReadyStateChange(data) calls and allow logging 
		 * of the response in context of the URL
		 * 
		 * @param {Object} callback
		 * @param {Object} url
		 * @param {Object} request - xmlHttp will insert self argument if you bind self function prior to using it as the callback. See self._get definition of "cback"
		 */
		self._passResponseThru = function(callback,url, request){
			var data = request.responseJSON;
			/*self._log.debug({"response from url":url,"data":data,"callback":callback});
			self._log.debug("\n\n_______________________");
			for(var i=0; i<arguments.length; i++){
				self._log.debug("_passResponseThru.arguments["+i+"] : ");
				self._log.debug(arguments[i]);
				if(typeof(arguments[i]) == 'function' && typeof(arguments[i].responseText) != 'undefined'){
					self._log.debug("Response Text: " + arguments[i].responseText);
				}
			}
			self._log.debug("_______________________\n\n");
			*/
			//self._trackFunction('RSP._passResponseThru',arguments);
			self._trackRequest(url,data);
			
			callback(data);
		}
		
		/**
		 * Track a request to a web service and the elapsed time once it returns
		 * @param {Object} url
		 * @param {Object} response optional - argument of the response
		 */
		self._trackRequest = function(url,response){
			if(self._currentAnalysis != '' && url){
				if(self._analytics[self._currentAnalysis].requests[url]){
					self._analytics[self._currentAnalysis].requests[url].end = (new Date()).getTime();
					self._analytics[self._currentAnalysis].requests[url].response = uneval(response);
					self._analytics[self._currentAnalysis].requests[url].elapsed = 
							self._analytics[self._currentAnalysis].requests[url].end - self._analytics[self._currentAnalysis].requests[url].start;
				}else{
					self._analytics[self._currentAnalysis].requests[url] = {
						'start' 	: (new Date()).getTime(),
						'end'		: '',
						'elapsed'	: '',
						'response'	: '',
					}
					self._analytics[self._currentAnalysis].numRequests++;
				}
			}
		}
		
		/**
		 * Track a function execution and the arguments received by that function
		 * @param {Object} func
		 * @param {Object} Arguments
		 */
		self._trackFunction = function(func, Arguments){
			if(!self._currentAnalysis || !func) return false;

			if(func.indexOf('RSP._') == 0) func = '        (internal/private method): ' + func;
			/*self._log.info("Arguments - " + typeof(Arguments) + ', length: ' + Arguments.length + ", array? " + (Arguments instanceof Array));
			self._log.info(Arguments);
			self._log.info("End Arguments -");*/
			var args = [], argsAsString = '';
			if(Arguments && Arguments.length){
				for(var i=0; i<Arguments.length; i++){
					self._log.info("Arguments["+i+"] - " + typeof(Arguments[i]));
					switch(typeof(Arguments[i])){
					//Object and Array too verbose, do not show explicitly	
						case 'object':
							if(Arguments[i] == null) args[i] = "null";
							else if(Arguments[i].length) args[i] = 'ARRAY['+Arguments[i].length+']';
							else args[i] = 'OBJECT';
							break;
						case 'function':
							var funcString = uneval(Arguments[i]);
							/*self._log.info("Funcstring: " + funcString)
							var funcString = funcString.substring(2,funcString.indexOf(')')-1);
							args[i] = 'F'+funcString+'}';//concatenate "F" and the rest of the initial function definition
							*///only works in firefox!!!
							args[i] = "FUNCTION";
							
							break;
					//show first few letters of a string	
						case 'string':
							var asString = uneval(Arguments[i]);
							var asString = "'"+asString.substring(1,asString.length-1)+"'";
							args[i] = asString.substring(0,45);
							if(asString.length && asString.length != args[i].length) args[i] += "...'";//if we truncated a string, indicate that...
							break;	
					//numbers, dates, boolean		
						default:
							args[i]=uneval(Arguments[i]);
							break;
					}
					//args[i].toString().replace(/\\"/ig,'"');
				}
				argsAsString = args.join(", ");
			}
			self._analytics[self._currentAnalysis].functionCalls.push((new Date()).getTime().toString() + ': ' + func + "( " + argsAsString + " )");	
		}
		
		
		
	
		
	
		return self;
	
	}
	av.nameSpace('av.apis.RSP');
	av.apis.RSP = RSP;

}//end if !exists