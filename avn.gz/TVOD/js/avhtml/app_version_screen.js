/**
 * @fileoverview Defines a appinfo interface
 */
if(!av.exists('av.app_version_screen')){

	/**
	 * @namespace Provides an interface for a configurable appinfo screen. 
	 * 
	 */
	 av.app_version_screen = new (function(){
		/**
		 * @fileoverview Defines an appinfo interface
		 */
		//	Application Initialization Variables		
		var appinfo_check_function; //The id of the setInterval Function
		var appinfo_overlay; //The div containing the appinfo information
		var appinfo_text; //The div contining the text relaying the about of time left before the window close.		
		var	appinfo_headerText; //The div containing the header information in the text box.
		var	appinfo_bodyText; //The div containing the body information in the text box.
		var userDefinedParameters = arguments[0];		
		var activeElement; //Used to save the focusElement
		
		//Set the default parameters for the screen overlay
		var defaultStyleObject_overlay = {
			"z-index" : "2000",
			"display" : "none",
			"width" : "100%",		
			"height" : "100%",				
			"backgroundColor" : "rgba(0, 0, 0, 0.8)",				
			"color" : "white",				
			"position" : "absolute",				
			"top" : "0px",				
			"left" : "0px",	
		};
		
		//Set the default parameters for the appinfo textbox
		var defaultStyleObject_appinfoText = {
			"font-family" : "\"Liberation Sans\",\"Helvetica Neue\", \"Helvetica\", \"MgOpen Moderna\", \"Arial\", sans-serif",
			"display" : "block",
			"width" : "640px",		
			"height" : "360px",				
			"backgroundColor" : "#141414",
			"text-align" : "left",
			"font-size" : "30pt",				
			"color" : "white",
			"padding" : "22px",						
			"margin" : "0px auto",
			"margin-top" : "160px",	
			"border-radius" : "10px",
			"border-style" : "solid",
			"border-width" : "3px",
			"border-color" : "#6e7272",
			"overflow" : "hidden",
		};
		
		var defaultStyleObject_appinfoHeaderText = {
			"text-align" : "left",
			"font-size" : "26pt",	
			"font-weight" : "bold",				
			"color" : "#586463",		
			"margin-bottom" : "0px",
			"backgroundColor" : "transparent",
		};
		
		var defaultStyleObject_appinfoBodyText = {
			"text-align" : "left",
			"font-size" : "16pt",
			"font-weight" : "bold",								
			"color" : "#bbcecc",
			"backgroundColor" : "transparent",
		};
				
		//Updates the appinfo object with user-specified arguments.
		loadUniqueArguments = function(){
			if((userDefinedParameters["screenOverlay"])){		
				for (var property in userDefinedParameters["screenOverlay"]){
	    			defaultStyleObject_overlay[property] = userDefinedParameters["screenOverlay"][property];
				}	
			}
			if((userDefinedParameters["textOverlay"])){		
				for (var property in userDefinedParameters["textOverlay"]){
	    			defaultStyleObject_appinfoText[property] = userDefinedParameters["textOverlay"][property];
				}	
			}
			if((userDefinedParameters["textOverlay_header"])){		
				for (var property in userDefinedParameters["textOverlay_header"]){
	    			defaultStyleObject_appinfoHeaderText[property] = userDefinedParameters["textOverlay_header"][property];
				}	
			}
			if((userDefinedParameters["textOverlay_body"])){		
				for (var property in userDefinedParameters["textOverlay_body"]){
	    			defaultStyleObject_appinfoBodyText[property] = userDefinedParameters["textOverlay_body"][property];
				}	
			}
		}; 		
		
		//The event listener for keypresses.
		//Updates the most recent keypress
		window.addEventListener("keydown",function(event){
			if(appinfo_overlay){
				if(appinfo_overlay.style.display == "block"){
					hideOverlay_appinfo();
				}
			}
		}, true);

		/**
		 * Builds the overlay scrren components that will appear above the current application when the appinfo warning occurs. 
		 */		
		createOverlay_appinfo = function(){
			//Create the div objects
			appinfo_overlay = buildDiv("appinfo_overlay", defaultStyleObject_overlay);
			appinfo_text = buildDiv("appinfo_textDiv", defaultStyleObject_appinfoText);
			appinfo_headerText = buildDiv("appinfo_headerTextDiv", defaultStyleObject_appinfoHeaderText,"");
			appinfo_bodyText = buildDiv("appinfo_bodyTextDiv", defaultStyleObject_appinfoBodyText);
			
			//Organize the heirarchy
			appinfo_text.appendChild(appinfo_headerText);	
			appinfo_text.appendChild(appinfo_bodyText);	
			appinfo_overlay.appendChild(appinfo_text);	
			document.getElementsByTagName('body')[0].appendChild(appinfo_overlay);
			
			//Store a pointer to the objects in local memory
			appinfo_headerText = document.getElementById("appinfo_headerTextDiv");
			appinfo_bodyText = document.getElementById("appinfo_bodyTextDiv");
			appinfo_overlay = document.getElementById("appinfo_overlay");
			appinfo_text = document.getElementById("appinfo_textDiv");
		}

		/**
		 * Dynamic structure to build divs. 
		 */
		buildDiv = function(divID,propertyArray,_innerHTML){
			//Generate the inner div			
			var _divName = document.createElement("div");
						
			for (var property in propertyArray){
    			_divName.style[property] = propertyArray[property];
			}			
			_divName.id = divID;
			if(_innerHTML){
				_divName.innerHTML = _innerHTML;
			}	
			return _divName;			
		}

		/**
		 * Hides the overlay (used when switching away from the appinfo warning screen) 
		 */
		hideOverlay_appinfo = function(){
			if(appinfo_overlay){
				document.getElementsByTagName('body')[0].removeChild(appinfo_overlay);
				appinfo_overlay = null;
				activeElement.focus();
			}
			else{
				av.log.err("No overlay found");
			}	
		}

		/**
		 * Shows the overlay (used when switching to the appinfo warning screen) 
		 */
		showOverlay_appinfo = function(){
			if(appinfo_overlay){
				appinfo_overlay.style.display = "block";
			}
			else{
				av.log.err("No overlay found");
			}	 
		}

		/**
		 * Builds and shows an appinfo message
		 */
		self.showAppInfoMessage = function(){			
			if(userDefinedParameters){
				loadUniqueArguments();
			}
			createOverlay_appinfo();
			showOverlay_appinfo();
			
			//Assumes everything is pre-configred in av.config			
			appinfo_bodyText.innerHTML = "Application Name: " + window.config.app.appName + "<br>";
			appinfo_bodyText.innerHTML += "Application Code: " + window.config.app.appCode + "<br>";
			appinfo_bodyText.innerHTML += "Application Version: " + window.config.app.version + "<br>";
			appinfo_bodyText.innerHTML += "Last Modified: " + window.config.app.lastModified + "<br><br>";
			appinfo_bodyText.innerHTML += window.config.app.appName + " is brought to you by the Development Team: " + window.config.app.developers + "<br><br>";
			appinfo_bodyText.innerHTML += "ActiveVideo Studio Team: " + window.config.app.developers_all;
			if(document.activeElement != null){
				activeElement = document.activeElement;
				document.activeElement.blur();
			}
		}
		return self;			
	}
)};