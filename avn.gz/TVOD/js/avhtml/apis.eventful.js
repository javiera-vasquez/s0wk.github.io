/**
 * @fileoverview Experimental API integration with Eventful 
 */

/**
 * @private
 * @depricated Not fully finished
 */
if(!av.exists('av.apis.eventful')){
	av.require('net');
	
	av.apis.Eventful = function(params){
		var self = this;
		
		var params = typeof(params) == 'object' ? params : {};
		var defaultParams = {
			api_key : "3hrJ2KNbBk5XCKvC,"
		}
		params = av.mergeObjects(defaultParams, params);
		self.log = new av.Log(av.getEffectiveLogLevel('apis.eventful'),'av.apis.eventful');
		
		self.urls = {
			'search' : 'http://api.evdb.com/json/categories/list?app_key=[[api_key]]&format=jsonp',
		}
		
		self.param = function(name, value){
			params[name] = value;
		}
		
		/**
		 * The twitter class comes predefined with several 
		 */
		self.addURL = function(objectOrString, val){
			if(typeof(objectOrString) != 'string'){
				for(var urlName in objectOrString){
					self.addURL(urlName, objectOrString[urlName]);
				}
			}else{
				self.urls[objectOrString] = val;
			}
		}
		
		/**
		 * Call a method in the 
		 * @param {String} name of api method to call, must be one of av.twitter.urls{}
		 * @param {String,Function} a string that represents a global function ,else an actual function
		 * @param 
		 * 
		 */
		self.call = function(method, callback, options){
			var url = av.getProperty(self.urls, method, '');
			
			var p = av.mergeObjects(params, typeof(options) == 'object' ? options : {}, true);
			
			if(!url){
				self.log.error("Cannot call twitter API method '" + method + "' method does not exist" );
				callback(false);
				return false;
			}
			console.log('options:'); console.log(options);
			
			var url =  av.string.populateTemplate(self.urls[method], p);
			
			return av.net.jsonp(url, callback)
		}
		
		
		return self;
	}
	
	
	av.apis.eventful = new av.apis.Eventful();//single instance so that users can have more than 1 outside of the av.apis namespace if they like
}
