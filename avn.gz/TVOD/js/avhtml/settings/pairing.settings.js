/**
 * @fileoverview Used by avsettings() to present "webremote" specific settings to the user.
 * @author C.Wagner (cwagner@activevideo.com)
 */

av.extend(av.settings.types,{'pairing': new (function(){
	av.require('pairing');
	av.require('dom');
	
	/**
	 * After presented, should contain an actual reference TO the dome element that gains focus by default...
	 */

	var self = this;
		self.version = '1.0';
	self.numDevicesToShow = av.issd ? 2 : 5;
	self.defaultFocus = '';
	self.pairingOffset = 0;
	self.devices = [];
	self.prefix = 'AVSettingsPairingDevice';
	self.pairingBarcode = av.getConfigValue('pairing.barcodeImage','http://app.scanlife.com/gui/CodeImage.do?codeId=17385183&barcodeFormat=1');
	
	/**
	 * using the currentDocument, create a av.dom.create and return it. Should contain entire navigation and event listeners needed to
	 * complete all logic for the settings managed by this component
	 */
	self.present = function(currentDocument, languageCode){
		self.lang = typeof(self.language[languageCode]) == 'undefined' ? self.language['en'] : self.language[languageCode]
		//Is the web remote present in the session?
		av.log.debug('avwebremote.present() - ' + av.pairing);
		var wr = typeof(av.pairing) == 'undefined' ? false : av.pairing;
		if(!wr){
			av.log.debug('avwebremote.present() - no WebRemote found');
			var elem = self.errorDisplay(currentDocument); 
		}else{
			av.log.debug('avwebremote.present() - YAY WebRemote found');
			var pairingBox = av.dom.create('div','AVSettingsPairings','AVSettingsPairings',{width:'100%',height:'100%',top:'0px', left:'0px'});
			
			var inst = av.dom.create('p','AVSettingsPairingsInsructions','AVSettingsPairingsInsructions',{height:'64px'},true)
				inst.appendChild(av.doc.createTextNode(self.lang.PAIRING_INFO));
				inst.appendChild(av.dom.create('br'));
				
				var barcode = av.dom.create('img','AVSettingsPairingBarcode','',
						{top:'32px',left:'66%',height:'64px',width:'64px'}
						,false);
					av.log.debug("Setting pairingBarcode.src = " + self.pairingBarcode)
					barcode.src = self.pairingBarcode;	
				
			var code = av.dom.create('p','AVSettingsPairingsCode','AVSettingsLarge AVSettingsLarge'+av.sdhd,{top:'48px',height:'48px','padding-top':'0px','text-align':'center','background-image':"url('"+av.themePath+"images/text_field.png')",width:'60%'},true);
				code.appendChild(av.doc.createTextNode(wr.getPairingKey()));
				
			
				
			var deviceHolder = av.dom.create('div','AVSettingsPairingDeviceHolder','AVSettingsDevices AVSettingsDevices'+av.sdhd, {top:'50%',height:'40%'}, true);
			var loadingMessage = av.dom.create('p','AVSettingsPairingDeviceLoading','',null,true)
				loadingMessage.appendChild(av.doc.createTextNode(self.lang.LOADING_LIST));
				deviceHolder.appendChild(loadingMessage);
			
				pairingBox.appendChild(inst);
				pairingBox.appendChild(code);
				pairingBox.appendChild(deviceHolder);
				pairingBox.appendChild(barcode);
			
			var count = av.dom.create('p','AVSettingsPairingDeviceCount','AVSettingsPairingDeviceCount AVSettingsPairingDeviceCount'+av.sdhd,{top:'90%',height:'10%'},true);
				pairingBox.appendChild(count);
			
			var elem = pairingBox;
			av.log.debug(pairingBox);
			
			//Now get a list interface into the currently paired devices	
			self.getPairedDevices();	
			
		}
		
		av.log.debug('Presented!' + elem.outterHTML);
		
		return elem;
	}
	
	self.updateCount = function(index){
		//var index = elem instanceof HTMLElement ? elem.offset + 1 : 0;
		var count = av.dom.get('AVSettingsPairingDeviceCount');
		var total = self.devices.paired_devices ? self.devices.paired_devices.length : 0;
		var prefix = index === total ? ' ' : '↓';
		var suffix = index === 1 ? ' ' : '↑';
		count.innerHTML = index + ' of ' + total + prefix + suffix;
	}
	
	
	self.createList = function(){
		var ds = self.devices;
		var prefix = self.prefix;
		var height = Math.round(100/self.numDevicesToShow);
		var list = []
		var numDevices = self.devices.paired_devices.length;
		
		var parentElement = av.dom.get('AVSettingsPairingDeviceHolder');
		av.log.debug('Parent = ' + parentElement);
		
		for(var i=0; i<self.numDevicesToShow; i++){
			//var prefix = 'AVSettingsPairingDevice';
			 
			var styles = {height:height+'%', top:height*(i)+'%',};
			av.log.debug("Creating list item #" +i +" with styles: " + uneval(styles));
			var	item = av.dom.create('div',prefix+i,prefix + ' ' + prefix + av.sdhd,styles,true);
				
				item.addEventListener('keydown',function(evt){
					//av.settings.focusMenu
					var k = evt.keyIdentifier, elem = evt.currentTarget, id = elem.id, index = elem.index, offset=elem.offset;
					av.log.debug("keydown: " + k + " on elem " + id + ", item.index="+index +", and offset=" + offset + " of numDevices="+numDevices + " and numDevicesToShow="+self.numDevicesToShow)
					switch(k){
						case "Left":
							av.log.debug("left key pressed on " + id)
							av.settings.focusMenu();
							break;
						case "Down":
							if(index == (self.numDevicesToShow-1) && offset != (numDevices-1)){
								av.log.debug("Scrolling list down");
								self.pairingOffset++;
								self.updateList();
								self.updateCount(evt.currentTarget.offset+1);
							}
							break;
						case "Up":
							if(index == 0 && offset != 0){
								av.log.debug("Scrolling list up");
								self.pairingOffset--;
								self.updateList();
								self.updateCount(evt.currentTarget.offset+1);
							}
							break;
						case "Enter":
							
							break;
						default:
							av.log.debug(k + " key pressed on " + id)
							break;
					}
				},true);
				item.addEventListener('focus',function(evt){self.updateCount(evt.currentTarget.offset+1);},true)
				
				
				
				//av.log.debug('a')
				var title = av.dom.create('p',prefix+'Title'+i, prefix+'Title ' + prefix+'Title' + av.sdhd, null, true);
					//title.innerHTML = 'place holder'
				item.appendChild(title);
				var button = av.dom.create('button',prefix+'Button'+i,'AVSettingsButton ' + prefix+'Button ' + prefix + 'Button' + av.sdhd + ' AVSettingsButton' + av.sdhd, {top:'50%',left:'60%'}, false);
					button.innerHTML = self.lang.REMOVE_PAIRING;
					av.log.debug("New button: " + button.outerHTML)
					
					button.style.navUp = i ? prefix+'Button' + (i-1) : prefix+'Button' + i;
					button.style.navDown = i < (self.numDevicesToShow-1) ? prefix+'Button' + (i+1) : prefix+'Button';
					
					av.dom.createRollover(button,av.themePath+"images/btn_f.png",av.themePath+"images/btn_d.png",false)
					
					button.addEventListener('click',function(evt){
						var elem = av.dom.create('p','lightboxJunk','',{height:'20%'},true);
							elem.innerHTML = 'I am a lightbox!!!';
							//av.dom.createLightbox(elem,{opacity:60,width:'50%',height:'120px'},false)
							//av.dom.alert(self.lang.REMOVE_PAIRING_ALERT, self.lang.REMOVE_PAIRING, {width:"80%", height:'450px'});
							var lb = av.dom.confirm(
									self.lang.REMOVE_PAIRING_ALERT, 
									self.lang.REMOVE_PAIRING, 
									self.lang.REMOVE_PAIRING_CANCEL,
									{toggleVideos:false,}// opacity:40, width:"40%", height:'350px'}
							);
					},true)
					
				item.appendChild(button);
				if(i!=0) self.defaultFocus = button;
					
				list.push(item);
		}
		if(numDevices) self.updateCount(1);
		
		av.dom.replaceChildren(parentElement, list);
		
		//self.updateList(parentElement);
	}
	
	self.updateList = function(){
		
		var ds = self.devices && self.devices.paired_devices ? self.devices.paired_devices : [];
		av.log.debug("updateList()");
		av.log.debug(uneval(ds ) + "\n" + ds.length);
		
		for(var i=0; i<self.numDevicesToShow; i++){
			var index = self.pairingOffset + i, item = av.dom.get(self.prefix + i);
			av.log.debug('updateList() - ' + i + ' :: ' + index);
			if(ds.length > index){
				var title=av.dom.get(self.prefix + 'Title' + i);
				var titleText = (index+1) + ') ' + ds[index].pairing_name;
				av.log.debug("Title #"+i +" will say: " + titleText)
				title.innerHTML = titleText;
				
				var item = av.dom.get(self.prefix + i);
					item.index = i;//position in list
					item.offset = index;//actual index
			}else{
				//item.disable();
				av.log.debug('Not enough devices to show item '+i+' == #' + index);
			}
			
		}
	}
	
	self.updatePairingKeyDisplay = function(){
		
	}
	
	self.listDevices = function(devices){
		av.log.debug('listDevices() - received devices:'+uneval(devices));
		av.log.debug(uneval(devices));
		
		self.devices = devices;
		self.pairingOffset = 0;
		
		self.createList();
		self.updateList();
		
	}
	
	self.getPairedDevices = function(){
		av.log.debug('getPairedDevices()');
		av.pairing.getPairedDevices(self.listDevices);
	}
	
	self.errorDisplay = function(doc){
		var errorText = av.doc.createElement('p');
			errorText.innerHTML = self.lang.CANNOT_CONNECT;
			errorText.setAttribute('style','position:absolute; top:0px; left:0px; width: 320px; height:320px;');
			errorText.setAttribute('id','avwebremote_error');
		return errorText;
	}
	
	self.focus = function(){
		var item = self.devices.paired_devices.length ? 'AVSettingsPairingDeviceButton0' : '';
		av.log.debug("Focusing on " + item)
		if(item != ''){
			
			av.dom.get(item).focus();
		}
	}
	
	
	
	self.language = {
			'en' : {
				'CANNOT_CONNECT' : 'Sorry, but because we are currently unable to connect to the WebRemote service, settings are unavailable for this component. Check back again shortly.',
				'PAIRING_INFO'	 : 'To pair, please use the code below:',
				'LOADING_LIST'	:  '...',//Loading a list of currently paired devices, one moment please...',
				'REMOVE_PAIRING': 'Remove',
				'REMOVE_PAIRING_CANCEL': 'Cancel',
				'REMOVE_PAIRING_ALERT': 'Are you sure you want to remove this pairing?',
			},
			'es' : {
				'CANNOT_CONNECT' : 'Lo sentimos, pero debido a que actualmente no pueden conectarse al servicio de WebRemote, opciones no estÃ¡n disponibles para este componente. Compruebe de nuevo en breve.',
				'PAIRING_INFO'	 : 'Para establecer un vÃ­nculo, por favor use el siguiente cÃ³digo:',
				'LOADING_LIST'	:  'Carga de una lista de dispositivos vinculados en ese momento, un momento por favor ...',
				'REMOVE_PAIRING': 'Quitar',
				'REMOVE_PAIRING_CANCEL': 'Cancel',
				'REMOVE_PAIRING_ALERT': 'Are you sure you want to remove this pairing?',
			}
		}
	return this;
})()});

av.log.debug('I am avwebremote.settings.js and I was just loaded');
