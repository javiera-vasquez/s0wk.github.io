/**
 * @fileoverview Used by avsettings() to present "facebook" description to the user for settings.
 * @author C.Wagner (cwagner@activevideo.com)
 */

av.extend(av.settings.types,{'facebook':  new (function(){	
	av.require('dom');
	/**
	 * using the currentDocument, create a domElement and return it. Should contain entire navigation and event listeners needed to
	 * complete all logic for the settings managed by this component
	 */
	var self = this;
	self.version = '1.0';
	
	self.present = function(currentDocument, languageCode){
		av.log.debug("about.present()");
		self.lang = typeof(self.language[languageCode]) == 'undefined' ? self.language['en'] : self.language[languageCode];
		
		var elem = av.dom.create('p','AVSettingsFacebook','',null,true);
			elem.innerHTML = self.lang.FACEBOOK_SETTINGS;
		
		return elem;
	}
	
	self.focus = function(){
		return false;//no focus here!
	}
	
	self.language = {
			'en' : {
				'FACEBOOK_SETTINGS' : 'Manage your facebook settings accross applications from here.',
			},
			'es' : {
				'FACEBOOK_SETTINGS' : 'Administrar la configuracion de todas las aplicaciones desde una ubicacion unica, a traves de un interfaz estandar. Seleccione un elemento de la izquierda para ver o cambiar la configuracion.',
			},
			'ko' : {
				'FACEBOOK_SETTINGS' : '표준 인터페이스를 통해서 단 하나 위치에서 신청의 맞은편에 조정을, 처리하십시오. 조정을 전망하거나 바꾸기 위하여 좌측에 품목을 선정하십시오.',
			},
			
			//
		}
	
	return this;
})()});

print('I am facebook.settings.js and I was just loaded');