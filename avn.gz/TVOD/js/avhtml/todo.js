/*
 * @namespace av.request Library which allows full XMLHttp wrapper and utility methods;
 * 
 * Redirect logic:
 *	1) create a new XMLHttp object
 *	2) copy over all headers less the "Authenticate" header (re-calucluated just-in-time within "send" call)
 *	3) point the nex "onreadystatechange" to the previouslly set "request.onreadystatechange"
 *	4) copy over request parameters (token, key, etc)
 */
av.request = {}

/**
 * @namespace av.states Provides state based tracking, from page to page (so long as window.top or session is used for av), and can restore state/save state to cookies.
 */
av.states = {}