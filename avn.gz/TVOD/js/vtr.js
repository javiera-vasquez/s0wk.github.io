/*
	NAME: TVOD API - VTR On Demand TV
	DESCRIPTION: Integration Framework CloudTV - AVN - Adrenalin (API)
*/

var VTR = {
	version: '1.0 R5.15',
	environment: 'Production',
	init: function(){
        av.tracker.track('app-start');
        av.config.timeoutWarning = VTR.Properties.inactivityTimeout;
        VTR.Properties.titleMenu1stLevel = '';
        VTR.Properties.titleMenu2ndLevel = '';
        VTR.Properties.titleMenu3rdLevel = '';
        VTR.Properties.titleMenu4rdLevel = '';
        VTR.UI.renderHtmlBase();
        VTR.UI.renderListMenu();
	}
}
